package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.HotBoard;
import com.genpact.cora.scm.entity.VAInbound;

public interface InboundHotBoardRepository extends JpaRepository<VAInbound, Integer> {
				
	@Query("SELECT new com.genpact.cora.scm.dto.HotBoard(va.weekNo,count(va.serialNumber),hs.city) FROM VAInbound va INNER JOIN HubSc hs on hs.accountName = va.origin where va.weekNo in (:weeksList) group by va.weekNo ,hs.city")
	public List<HotBoard> getInboundData(@Param("weeksList") List<Object> weeksList);
	
	@Query("SELECT notificationDate, estimatedReceivingDate, actualReceivingDate, alertDescription, origin, destination FROM VAInbound where serialNumber = :serialNumber AND status = :status") 
    public List<Object[]> findInBoundDetailsBySerialNumberStatus(@Param("serialNumber") String serialNumber, @Param("status") String status);

    @Query(value = "select distinct weekno,[SerialNumber],[Status],[Origin],[Destination],[AlertDescription],[DueDate],[NotificationDate], \r\n" + 
       		"[EstimatedReceivingDate],[ActualReceivingdate],[AlertType] from [tbl_VAInbound] A \r\n" + 
       		"LEFT JOIN tbl_master_Calendar B ON (CONVERT(DATE,A.duedate) =CONVERT(DATE,B.Date)) \r\n" + 
       		"where B.WeekstartDate >= (SELECT WeekStartdate FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE())) \r\n" + 
       		"AND B.WeekstartDate<=(SELECT DATEADD(Day,21,WeekStartdate) FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE()))" ,nativeQuery = true)
     public List<Object[]> getInboundHotBoardData(); 
    
     
    // temorary fix  query .... commented because of QA testing only need to be reverted back once get proper data
    
/*    @Query(value = " select distinct weekno,[SerialNumber],[Status],[Origin],[Destination],[AlertDescription],[DueDate],[NotificationDate], \r\n" + 
    		"       [EstimatedReceivingDate],[ActualReceivingdate],[AlertType] from [tbl_VAInbound]  where\r\n" + 
    		"  weekno  between '2018-48' and '2018-51'" ,nativeQuery = true)*/
//    	public List<Object[]> getInboundHotBoardData(); 
}
