package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.List;

public class SingleModelOutput implements Serializable {

	private static final long serialVersionUID = 1L;

	private int modelId;
	private String modelName;
	private boolean isBestFit;
	private boolean isConfigured;
	private float mapePercent;
	private float madPercent;
	private float rmsePercent;
	private List<MonthDataUnit> monthData;

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public float getMapePercent() {
		return mapePercent;
	}

	public void setMapePercent(float mapePercent) {
		this.mapePercent = mapePercent;
	}

	public float getMadPercent() {
		return madPercent;
	}

	public void setMadPercent(float madPercent) {
		this.madPercent = madPercent;
	}

	public float getRmsePercent() {
		return rmsePercent;
	}

	public void setRmsePercent(float rmsePercent) {
		this.rmsePercent = rmsePercent;
	}

	public List<MonthDataUnit> getMonthData() {
		return monthData;
	}

	public void setMonthData(List<MonthDataUnit> monthData) {
		this.monthData = monthData;
	}

	public boolean isBestFit() {
		return isBestFit;
	}

	public void setBestFit(boolean isBestFit) {
		this.isBestFit = isBestFit;
	}

	public boolean isConfigured() {
		return isConfigured;
	}

	public void setConfigured(boolean isConfigured) {
		this.isConfigured = isConfigured;
	}

}
