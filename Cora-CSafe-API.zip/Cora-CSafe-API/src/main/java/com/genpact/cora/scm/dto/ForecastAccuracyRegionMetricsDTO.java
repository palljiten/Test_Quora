package com.genpact.cora.scm.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ForecastAccuracyRegionMetricsDTO {

	private int regionId;
	private String regionName;
	private String month;
	private int monthValue;
	private int year;
	private int day;
	private Date date;
	private Integer statistical;
	private Integer bpbased;
	private Integer aligned;
	private Integer consensus;
	
	public int getRegionId() {
		return regionId;
	}
	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Integer getStatistical() {
		return statistical;
	}
	public void setStatistical(Integer statistical) {
		this.statistical = statistical;
	}
	public Integer getBpbased() {
		return bpbased;
	}
	public void setBpbased(Integer bpbased) {
		this.bpbased = bpbased;
	}
	public Integer getAligned() {
		return aligned;
	}
	public void setAligned(Integer aligned) {
		this.aligned = aligned;
	}
	public Integer getConsensus() {
		return consensus;
	}
	public void setConsensus(Integer consensus) {
		this.consensus = consensus;
	}
	public int getMonthValue() {
		return monthValue;
	}
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
}
