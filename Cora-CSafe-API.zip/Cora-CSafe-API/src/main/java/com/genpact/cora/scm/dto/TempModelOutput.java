package com.genpact.cora.scm.dto;

public class TempModelOutput {
	private Integer modelId; 
	private String modelName; 
	private String techniqueName; 
	private float value; 
	private String monthYear; 
	private float forecastValue;
	
	public TempModelOutput() {}
	
	public TempModelOutput(Integer modelId, String modelName, String techniqueName, 
			float value, String monthYear, float forecastValue) {
		
		this.modelId = modelId;
		this.modelName = modelName;
		this.techniqueName = techniqueName;
		this.value = value;
		this.monthYear = monthYear;
		this.forecastValue = forecastValue;
	}
	
	public TempModelOutput(Integer modelId, String modelName, String techniqueName, 
			Double value, String monthYear, Double forecastValue) {
		
		this.modelId = modelId;
		this.modelName = modelName;
		this.techniqueName = techniqueName;
		if (value != null) {
			this.value = value.floatValue();
		}
		this.monthYear = monthYear;
		this.forecastValue = forecastValue.floatValue();
	}
	
	public Integer getModelId() {
		return modelId;
	}
	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getTechniqueName() {
		return techniqueName;
	}
	public void setTechniqueName(String techniqueName) {
		this.techniqueName = techniqueName;
	}
	public float getValue() {
		return value;
	}
	public void setValue(float value) {
		this.value = value;
	}
	public String getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
	public float getForecastValue() {
		return forecastValue;
	}
	public void setForecastValue(float forecastValue) {
		this.forecastValue = forecastValue;
	} 
}
