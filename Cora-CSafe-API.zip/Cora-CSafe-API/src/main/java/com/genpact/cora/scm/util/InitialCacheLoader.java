package com.genpact.cora.scm.util;

import javax.servlet.ServletContext;

import com.genpact.cora.scm.controller.ContainerForecastBpBasedController;

public final class InitialCacheLoader {
	
	//SELECT HubID, Code, CountryID, RegionID FROM [dbo].[tbl_master_HubSC] WHERE HubId = '21'
	//SELECT * FROM [dbo].[tbl_master_Country] WHERE CountryID = 16
	//SELECT * FROM [dbo].[tbl_master_Region] WHERE RegionID = 1
	
	//Caching of Bp-Based
	//https://csafedev.azurewebsites.net/CoraAnalytics/scm/bpForecast?regionId=2&countryId=13&hubId=14&months=6
	//https://csafedev.azurewebsites.net/CoraAnalytics/scm/baselineDemand?regionId=2&countryId=13&hubId=14&months=18
	
	public static void loadBpBasedData(ContainerForecastBpBasedController cfbbController, ServletContext servletContext, 
			Integer defaultRegionId, Integer defaultCountryId, Integer defaultHubId, 
			Integer forecastMonths, Integer demandMonths) {
		System.out.println("\n\ncfbbController = " + cfbbController + "\n\n");
		servletContext.setAttribute("bpBasedForecast", cfbbController.getForecastData(defaultRegionId, defaultCountryId, defaultHubId, forecastMonths).getBody());
		servletContext.setAttribute("bpBasedDemand", cfbbController.getBaselineDemand(defaultRegionId, defaultCountryId, defaultHubId, demandMonths).getBody());
	}
	
}
