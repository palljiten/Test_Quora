package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AlignedForecastRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<AlignedForecastMonthData> forecastValues = new ArrayList<>();

	public List<AlignedForecastMonthData> getForecastValues() {
		return forecastValues;
	}
 

	public void setForecastValues(List<AlignedForecastMonthData> forecastValues) {
		this.forecastValues = forecastValues;
	}



}
