package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.ModelEditConfig;

public interface ModelEditConfigRepository extends JpaRepository<ModelEditConfig, Integer> {

	@Query("SELECT f FROM ModelEditConfig f "
			+ "WHERE f.hubsc.hubId = :hubId AND f.country.countryId = :countryId "
			+ "AND f.region.regionId = :regionId AND f.model.modelId = :modelId AND f.flag = 1")
	public ModelEditConfig getModelEditConfig(@Param("regionId") int regionId, @Param("countryId") int countryId,
			@Param("hubId") int hubId, @Param("modelId") int modelId);
	
	@Modifying
    @Query("UPDATE ModelEditConfig sp SET sp.flag = 0 "
    		+ "WHERE sp.flag=1 AND sp.hubsc.hubId = :hubId AND sp.country.countryId = :countryId "
    		+ "AND sp.region.regionId = :regionId AND sp.model.modelId = :modelId")
    int updateModelEditConfig(@Param("modelId") int modelId, @Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId);

}
