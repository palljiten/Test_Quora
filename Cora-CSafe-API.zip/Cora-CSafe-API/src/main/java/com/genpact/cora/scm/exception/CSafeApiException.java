package com.genpact.cora.scm.exception;

import org.springframework.http.HttpStatus;

public class CSafeApiException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private HttpStatus status;
	
	public CSafeApiException(String message) {
        super(message);
    }

    public CSafeApiException(String message, Throwable cause) {
        super(message, cause);
    }

    public CSafeApiException(Throwable cause) {
        super(cause);
    }
    
	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}
}
