package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ModelParams implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int modelId;
	private List<ModelParam> modelParams = new ArrayList<>();
	private boolean normalForecast = true;
	private boolean baselinePercentageAdjustment = false;
	private Float percentage;

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	public List<ModelParam> getModelParams() {
		return modelParams;
	}

	public void setModelParams(List<ModelParam> modelParams) {
		this.modelParams = modelParams;
	}

	public boolean isNormalForecast() {
		return normalForecast;
	}

	public void setNormalForecast(boolean normalForecast) {
		this.normalForecast = normalForecast;
		if (this.normalForecast) {
			this.baselinePercentageAdjustment = false;
		}
	}

	public boolean isBaselinePercentageAdjustment() {
		return baselinePercentageAdjustment;
	}

	public void setBaselinePercentageAdjustment(boolean baselinePercentageAdjustment) {
		this.baselinePercentageAdjustment = baselinePercentageAdjustment;
		if (this.baselinePercentageAdjustment) {
			this.normalForecast = false;
		}
	}

	public Float getPercentage() {
		return percentage;
	}

	public void setPercentage(Float percentage) {
		this.percentage = percentage;
	}

}
