package com.genpact.cora.scm.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Repository;

@Repository
public class ConsensusForecastSPRepository {
	
	@PersistenceContext
    private EntityManager entityManager;
	
	public boolean callConsensusForecastSP(){
		
		StoredProcedureQuery query  = entityManager.createStoredProcedureQuery("ConsensusForecastSP");
		return query.execute();
		
	}

}
