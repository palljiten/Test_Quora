package com.genpact.cora.scm.exception;

import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.http.converter.HttpMessageNotReadableException;

import com.genpact.cora.scm.config.CSafeMDCFilterConfiguration;

import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import org.slf4j.MDC;

@ControllerAdvice
public class CSafeGlobalExceptionHandler {

	@ExceptionHandler({ Exception.class })
	public ResponseEntity<Object> handleAnyException(Exception ex, WebRequest request) {
		CSafeApiError apiError = new CSafeApiError(MDC.get(CSafeMDCFilterConfiguration.CSAFE_MDC_UUID_TOKEN_KEY),
				HttpStatus.INTERNAL_SERVER_ERROR, extractSlimMessage(ex.getMessage()), request.getDescription(false) + " ## " + ex.getMessage());
		return new ResponseEntity<Object>(apiError, new HttpHeaders(), apiError.getStatus());
	}
	
	@ExceptionHandler({ MethodArgumentNotValidException.class })
	public ResponseEntity<Object> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex, WebRequest request) {
		CSafeApiError apiError = new CSafeApiError(MDC.get(CSafeMDCFilterConfiguration.CSAFE_MDC_UUID_TOKEN_KEY),
				HttpStatus.BAD_REQUEST,  extractSlimMessage(ex.getMessage()), "Method Argument Not Valid >> " + request.getDescription(false) + " ## " + ex.getMessage());
		return new ResponseEntity<Object>(apiError, new HttpHeaders(), apiError.getStatus());
	}

	@ExceptionHandler({ HttpMessageNotReadableException.class })
	public ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, WebRequest request) {
		CSafeApiError apiError = new CSafeApiError(MDC.get(CSafeMDCFilterConfiguration.CSAFE_MDC_UUID_TOKEN_KEY),
				HttpStatus.BAD_REQUEST,  extractSlimMessage(ex.getMessage()), request.getDescription(false) + " ## " + ex.getMessage());
		return new ResponseEntity<Object>(apiError, new HttpHeaders(), apiError.getStatus());
	}

	@ExceptionHandler({ MethodArgumentTypeMismatchException.class })
	public ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex,
			WebRequest request) {

		String error = ex.getName() + " should be of type " + ex.getRequiredType().getName();
		
		String message = ex.getLocalizedMessage();
		
		if (ex.getRequiredType().getName().equals("com.genpact.cora.scm.validation.ContainerSparesTypeEnum")) {
			message = "\n Allowed values are 'Container' and 'Spares' ";
		}
		
		CSafeApiError apiError = new CSafeApiError(MDC.get(CSafeMDCFilterConfiguration.CSAFE_MDC_UUID_TOKEN_KEY),
				HttpStatus.BAD_REQUEST, message, error);
		return new ResponseEntity<Object>(apiError, new HttpHeaders(), apiError.getStatus());
	}

	@ExceptionHandler({ MissingServletRequestParameterException.class })
	protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex,
			WebRequest request) {
		String error = ex.getParameterName() + " parameter is missing";

		CSafeApiError apiError = new CSafeApiError(MDC.get(CSafeMDCFilterConfiguration.CSAFE_MDC_UUID_TOKEN_KEY),
				HttpStatus.BAD_REQUEST, ex.getLocalizedMessage(), error);
		return new ResponseEntity<Object>(apiError, new HttpHeaders(), apiError.getStatus());
	}

	@ExceptionHandler({ ConstraintViolationException.class })
	public ResponseEntity<?> invalidParamsExceptionHandler(ConstraintViolationException ex, WebRequest request) {
		List<String> errors = new ArrayList<String>();
		for (ConstraintViolation<?> violation : ex.getConstraintViolations()) {
			errors.add(violation.getRootBeanClass().getName() + " " + violation.getPropertyPath() + ": "
					+ violation.getMessage());
		}

		CSafeApiError errorDetails = new CSafeApiError(MDC.get(CSafeMDCFilterConfiguration.CSAFE_MDC_UUID_TOKEN_KEY),
				HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), errors);
		return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({ CSafeApiException.class })
	public ResponseEntity<Object> handleCSafeApiException(CSafeApiException ex, WebRequest request) {
		HttpStatus status = ex.getStatus();
		if (status == null) {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		CSafeApiError apiError = new CSafeApiError(MDC.get(CSafeMDCFilterConfiguration.CSAFE_MDC_UUID_TOKEN_KEY),
				status, ex.getLocalizedMessage() + " :: " + request.getDescription(false),
				ex.getCause().toString());
		return new ResponseEntity<Object>(apiError, new HttpHeaders(), status);
	}
	
	@ExceptionHandler({ EmailTemplateNotFoundException.class })
	public ResponseEntity<Object> handleEmailTemplateNotFoundException(EmailTemplateNotFoundException ex, WebRequest request) {
		CSafeApiError apiError = new CSafeApiError(MDC.get(CSafeMDCFilterConfiguration.CSAFE_MDC_UUID_TOKEN_KEY),
				ex.getStatus(), ex.getMessage() + " :: " + request.getDescription(false),
				ex.getCause().toString());
		return new ResponseEntity<Object>(apiError, new HttpHeaders(), ex.getStatus());
	}
	
	private String extractSlimMessage(String fatMessage) {
		String[] splits = fatMessage.split(":");
		return splits[0];	
	}

}
