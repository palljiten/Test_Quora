package com.genpact.cora.scm.dto;

public class TempConfigModel {

	private Integer modelId; 
	private Integer configModelId; 
	private String monthYear;
	
	public TempConfigModel(Integer modelId, Integer configModelId, String monthYear) {
		this.modelId = modelId;
		this.configModelId = configModelId;
		this.monthYear = monthYear;
	}
	
	public TempConfigModel(Integer modelId, Integer configModelId) {
		this.modelId = modelId;
		this.configModelId = configModelId;
	}
	
	public Integer getModelId() {
		return modelId;
	}
	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}
	public Integer getConfigModelId() {
		return configModelId;
	}
	public void setConfigModelId(Integer configModelId) {
		this.configModelId = configModelId;
	}
	public String getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
}
