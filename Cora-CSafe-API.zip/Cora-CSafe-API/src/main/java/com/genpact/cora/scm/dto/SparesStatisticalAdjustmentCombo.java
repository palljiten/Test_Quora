package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class SparesStatisticalAdjustmentCombo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int regionId;
	private int countryId;
	private int hubId;
	private String partId;

	private List<String> monthYearMetaData = new ArrayList<>();
	
	@NotNull
	@NotEmpty
	private List<MonthDataUnit> adjustmentValues = new ArrayList<>();
	
	private Map<String, Float> valueSummary = new HashMap<>();

	public List<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(List<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}

	public List<MonthDataUnit> getAdjustmentValues() {
		return adjustmentValues;
	}

	public void setAdjustmentValues(List<MonthDataUnit> adjustmentValues) {
		this.adjustmentValues = adjustmentValues;
	}

	public int getRegionId() {
		return regionId;
	}

	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public int getHubId() {
		return hubId;
	}

	public void setHubId(int hubId) {
		this.hubId = hubId;
	}

	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId;
	}

	public Map<String, Float> getValueSummary() {
		return valueSummary;
	}

	public void setValueSummary(Map<String, Float> valueSummary) {
		this.valueSummary = valueSummary;
	}

}
