package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_EMPTY)
@Entity
@Table(name = "[dbo].[tbl_RepairWorkOrderParts]")
public class RepairWorkOrderParts {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PartUsed2WorkOrderSCID", unique = true, nullable = false)
	private Integer rwpId;

	@Column(name = "WorkOrderID")
	private Integer workOrderID;

	@Column(name = "PartNumber", nullable = true, length = 100)
	private String partNumber;

	@Column(name = "Quantity")
	private Integer quantity;

	@Column(name = "SC", nullable = true, length = 100)
	private String sc;

	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(name = "CreateDate", nullable = true)
	private Date createDate;
	
	@Column(name ="Description")
	private String description;
	
	@Column(name = "CurrentlyInStock", nullable = true)
	private int currentlyInStock;

	public RepairWorkOrderParts() {}
	
	public RepairWorkOrderParts(String partNumber) {
		this.partNumber = partNumber;
	}
	
	public RepairWorkOrderParts(String partNumber, String sc) {
		this.partNumber = partNumber;
		this.sc = sc;
	}
	
	public Integer getRwpId() {
		return rwpId;
	}

	public void setRwpId(Integer rwpId) {
		this.rwpId = rwpId;
	}

	public Integer getWorkOrderID() {
		return workOrderID;
	}

	public void setWorkOrderID(Integer workOrderID) {
		this.workOrderID = workOrderID;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getSc() {
		return sc;
	}

	public void setSc(String sc) {
		this.sc = sc;
	}

	/**
	 * @return the currentlyInStock
	 */
	public int getCurrentlyInStock() {
		return currentlyInStock;
	}

	/**
	 * @param currentlyInStock the currentlyInStock to set
	 */
	public void setCurrentlyInStock(int currentlyInStock) {
		this.currentlyInStock = currentlyInStock;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
