package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.genpact.cora.scm.entity.ConsensusAdjustment;

public interface ConsensusAdjustmentRepository extends JpaRepository<ConsensusAdjustment, Integer>{
	
	@Query("SELECT value,monthYear,createdDate,modifiedBy FROM ConsensusAdjustment "
			+ "where (date < dateadd(m,6, getdate()) and date > getdate() and flag='1' and country.countryId=:countryId and hubsc.hubId=:hubId and region.regionId=:regionId)")
	public List<Object> findConsensusAdjustment(@Param("countryId") int countryId,@Param("hubId") int hubId,@Param("regionId") int regionId);
	
	@Transactional
	@Modifying
	@Query(value="UPDATE tbl_ConsensusAdjustment SET flag=0.0 WHERE (countryId=:countryId and hubId=:hubId and regionId=:regionId and monthyear=:monthYear)" , nativeQuery = true)
	public int updateConsensusAdjustment(@Param("countryId") int countryId,@Param("hubId") int hubId,@Param("regionId") int regionId,@Param("monthYear") String monthYear);
}
