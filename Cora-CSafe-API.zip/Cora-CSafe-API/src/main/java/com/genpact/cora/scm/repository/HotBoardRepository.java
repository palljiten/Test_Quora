package com.genpact.cora.scm.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.HubCtLatLong;
import com.genpact.cora.scm.entity.VAInbound;

public interface HotBoardRepository extends CrudRepository<VAInbound, Integer>{
	
	@Query(value ="select distinct(hs.[City]) from [dbo].[tbl_VAInbound] va ,[dbo].[tbl_master_HUBSC] hs where va.[Origin] = hs.[AccountName]",nativeQuery=true)
	public List<Object[]> getCityList();
	
	@Query(value="select distinct top(4)  DATEPART(week,Date) as weekNum, DATEPART(year,Date) as year" + 
					" from tbl_master_Calendar where Date < DATEADD(wk,-4, GETDATE()) and Date < GETDATE()" + 
					"	order by  DATEPART(year,Date),DATEPART(wk,Date) ASC",nativeQuery=true)
	List<Object[]> getFutureWeekYears();
	
    @Query("select distinct(status),origin from  VAInbound where status is not null")
	public List<Object[]> getIbHotBoardFilter();

/*	@Query(value ="select distinct top(4) CONCAT(DATEPART(year,c.Date),'-',c.[WeekOfYear]) as yearWeek ,DATEPART(year,c.Date) as year  from [dbo].[tbl_master_Calendar] c \r\n" + 
			" WHERE  DATE>=GETDATE()  order by year asc" , nativeQuery=true)*/
	//the below query to previous data
	@Query(value ="select  distinct top(4)  DATEPART(year,c.Date) as year,DATEPART(wk,c.Date) as weeks \r\n" + 
			"				 from tbl_master_Calendar c where Date < DATEADD(wk,4, GETDATE())\r\n" + 
			"			 and Date >GETDATE() order by  DATEPART(year,Date),DATEPART(wk,Date) ASC",nativeQuery =true)
	public List<Object[]> getFutureYearWeek();

	
	@Query("select new com.genpact.cora.scm.dto.HubCtLatLong(hs.city,hs.latitude,hs.longitude) from HubSc hs")
	public List<HubCtLatLong> getCityLatLongList();
}
