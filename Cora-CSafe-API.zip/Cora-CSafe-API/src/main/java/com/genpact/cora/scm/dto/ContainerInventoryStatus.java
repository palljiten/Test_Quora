package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class ContainerInventoryStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	private String country;
	private String city;
	private String hubCode;
	private String status;
	private long containerCount;
	private Float longitude;
	private Float latitude;
	
	 
	
	public ContainerInventoryStatus(){
		
	}
	
	
public ContainerInventoryStatus(String hubCode,String city,String country,String status, long containerCount,Float longitude,Float latitude){
	
	this.country = country;
	this.city = city;
	this.hubCode = hubCode;
	this.status = status;
	this.containerCount = containerCount;
	this.longitude = longitude;
	this.latitude = latitude;
		
	}
	
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the hubCode
	 */
	public String getHubCode() {
		return hubCode;
	}
	/**
	 * @param hubCode the hubCode to set
	 */
	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}
	/**
	 * @return the containerCount
	 */
	public long getContainerCount() {
		return containerCount;
	}
	/**
	 * @param containerCount the containerCount to set
	 */
	public void setContainerCount(long containerCount) {
		this.containerCount = containerCount;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}


	/**
	 * @return the longitude
	 */
	public Float getLongitude() {
		return longitude;
	}


	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(Float longitude) {
		this.longitude = longitude;
	}


	/**
	 * @return the latitude
	 */
	public Float getLatitude() {
		return latitude;
	}


	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(Float latitude) {
		this.latitude = latitude;
	}
	
	
	
	
	
}
