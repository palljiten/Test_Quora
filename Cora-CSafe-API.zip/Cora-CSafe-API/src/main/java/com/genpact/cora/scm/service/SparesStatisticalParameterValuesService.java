package com.genpact.cora.scm.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.genpact.cora.scm.dto.CustomParameter;
import com.genpact.cora.scm.dto.CustomParameterCombo;
import com.genpact.cora.scm.dto.ModelParam;
import com.genpact.cora.scm.entity.ModelEditConfig;
import com.genpact.cora.scm.entity.SparesModelEditConfig;
import com.genpact.cora.scm.entity.StatisticalParametersMaster;
import com.genpact.cora.scm.repository.SparesModelEditConfigRepository;
import com.genpact.cora.scm.repository.SparesStatisticalParameterValuesRepository;
import com.genpact.cora.scm.repository.StatisticalParametersMasterRepository;
import com.genpact.cora.scm.util.ParamConstants;

@Service
public class SparesStatisticalParameterValuesService {

	@Autowired
	SparesStatisticalParameterValuesRepository paramRepository;
	
	@Autowired
	StatisticalParametersMasterRepository paramMasterRepo;
	
	@Autowired
	SparesModelEditConfigRepository modelEditConfigRepo;
	
	public CustomParameterCombo getParamValues(int modelId, int regionId, int countryId,
			int hubId, String partId) {
		CustomParameterCombo pc = new CustomParameterCombo();
		pc.setModelId(modelId);

		List<CustomParameter> result = paramRepository.getParamValuesForModelId(modelId, regionId, countryId, hubId, partId);
		
		if (result == null || result.isEmpty()) {
			result = new ArrayList<>();
			List<StatisticalParametersMaster> modelMasterParams = paramMasterRepo.findByModelId(modelId);
			//This is temporary. When DB will incorporate the parameter default values, we need to
			//read from database
			for (StatisticalParametersMaster param : modelMasterParams) {	
				CustomParameter mp = new CustomParameter();
				
				mp.setParamId(param.getId());
				mp.setParamName(param.getParameterName());
				if (param.getParameterName().equals(ParamConstants.FORECAST)) {
					mp.setParamValue(6);
				} else if (param.getParameterName().equals(ParamConstants.HISTORIC)) {
					mp.setParamValue(12);
				}
				
				if (param.getModel().getModelName().equals(ParamConstants.WEIGHTED_AVERAGE)) {
					if (param.getParameterName().equals(ParamConstants.WEIGHT)) {
						mp.setParamValue(0.4f);
					} else if (param.getParameterName().equals(ParamConstants.PERIOD)) {
						mp.setParamValue(5);
					}
				} else if (param.getModel().getModelName().equals(ParamConstants.MOVING_AVERAGE)) {
					if (param.getParameterName().equals(ParamConstants.PERIOD)) {
						mp.setParamValue(5);
					}					
				} else if (param.getModel().getModelName().equals(ParamConstants.SINGLE_EXPONENTIAL)) {
					if (param.getParameterName().equals(ParamConstants.ALPHA)) {
						mp.setParamValue(0.2f);
					}					
				} else if (param.getModel().getModelName().equals(ParamConstants.DOUBLE_EXPONENTIAL)) {
					if (param.getParameterName().equals(ParamConstants.ALPHA)) {
						mp.setParamValue(0.2f);
					} else if (param.getParameterName().equals(ParamConstants.BETA)) {
						mp.setParamValue(0.2f);
					}							
				} else if (param.getModel().getModelName().equals(ParamConstants.CROSTON_VARIANT)) {
					if (param.getParameterName().equals(ParamConstants.ALPHA)) {
						mp.setParamValue(0.2f);
					} else if (param.getParameterName().equals(ParamConstants.BETA)) {
						mp.setParamValue(0.2f);
					}						
				} else if (param.getModel().getModelName().equals(ParamConstants.LINEAR_REGRESSION)) {
					mp.setParamId(param.getId());
					mp.setParamName(param.getParameterName());
					mp.setParamValue(0);
				}
				result.add(mp);
			}
		}
		
		pc.setModelParams(result);
		
		SparesModelEditConfig mec = modelEditConfigRepo.getModelEditConfig(regionId, countryId, hubId, partId, modelId);
		if (mec == null) {
			pc.setNormalForecast(true);
			pc.setBaselinePercentageAdjustment(false);
		} else {
			pc.setNormalForecast(mec.getNormalForecast());
			pc.setBaselinePercentageAdjustment(mec.getBaselineAdjustment());
			pc.setPercentage(mec.getPercentage());
		}
		return pc;
	}
}
