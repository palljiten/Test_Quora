package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.dto.ConsensusAdjustmentValueCombo;

@Repository
public class ConsensusAdjustmentOverrideRepository {

	@PersistenceContext
	private EntityManager entityManager;

	public List<ConsensusAdjustmentValueCombo> getAdjustmentOverride(int regionId, int countryId, int hubId) {
		@SuppressWarnings("unchecked")
		List<ConsensusAdjustmentValueCombo> adjustmentObject = entityManager.createNativeQuery(
				"select distinct b.value as v ,concat(substring(c.MonthName,1,3),'-',c.Year) as my"
						+ "  from tbl_master_Calendar c left outer join tbl_ConsensusAdjustment b"
						+ "	 on concat(substring(c.MonthName,1,3),'-',c.Year)=b.MonthYear and b.Flag=1 "
						+ " and b.RegionID=:regionId and b.CountryID=:countryId and b.HubID=:hubId"
						+ " where date < dateadd(m,6, getdate()) and date > getdate()")
				.setParameter("regionId", regionId).setParameter("countryId", countryId).setParameter("hubId", hubId)
				.getResultList();

		return adjustmentObject;
	}

}
