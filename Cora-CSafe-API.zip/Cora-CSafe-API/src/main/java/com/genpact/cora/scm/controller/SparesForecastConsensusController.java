package com.genpact.cora.scm.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.SparesConsensusAdjustmentCombo;
import com.genpact.cora.scm.dto.SparesConsensusCorrectionFactors;
import com.genpact.cora.scm.dto.SparesConsensusForecastCombo;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.SparesForecastConsensusService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
public class SparesForecastConsensusController {

	private static Logger logger = LoggerFactory.getLogger(SparesForecastConsensusController.class);

	@Autowired
	SparesForecastConsensusService sparesForecastConsensusService;

	@GetMapping(value = "/sparesForecast/consensus", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves baseline and statistical forecast")
	public ResponseEntity<Object> getBaselineAndStatisticalForecast(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") String partId) {
		SparesConsensusForecastCombo data;
		logger.info("SparesForecastConsensusController: Entering getBaselineAndStatisticalForecast() method");
		try 
		{
			data = sparesForecastConsensusService.getSparesConsensusForecast(regionId, countryId, hubId, partId);

		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getBaselineAndStatisticalForecast in SparesForecastCommonController :",
					e.getCause());
		}
		logger.info("SparesForecastConsensusController: Exiting getBaselineAndStatisticalForecast() method");
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@GetMapping(value = "/sparesForecast/consensus/correction-factors", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves correction factors")
	public ResponseEntity<Object> getCorrectionFactors(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") int partId) {

		logger.info("SparesForecastConsensusController: Entering getCorrectionFactors() method");
		SparesConsensusCorrectionFactors data;
		try
		{
			data = sparesForecastConsensusService.getCorrectionFactors(regionId, countryId, hubId, partId);

		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getCorrectionFactors in SparesForecastCommonController :",
					e.getCause());
		}
		logger.info("SparesForecastConsensusController: Exiting getCorrectionFactors() method");
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@PutMapping(value = "/sparesForecast/consensus/correction-factors", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update Correction Factors")
	public ResponseEntity<Object> updateCorrectionFactors(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") int partId,@Valid @RequestBody SparesConsensusCorrectionFactors correctionFactors) {
		logger.info("SparesForecastConsensusController: Entering updateCorrectionFactors() method");
		try 
		{
			sparesForecastConsensusService.updateCorrectionFactors(regionId, countryId, hubId, partId,
					correctionFactors);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for updateCorrectionFactors in SparesForecastCommonController :",
					e.getCause());
		}
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("SparesForecastConsensusController: Exiting updateCorrectionFactors() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}

	@GetMapping(value = "/sparesForecast/consensus/adjustments", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves adjustments")
	public ResponseEntity<Object> getAdjustments(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") int partId) {
		logger.info("SparesForecastConsensusController: Entering getAdjustments() method");
		SparesConsensusAdjustmentCombo data;
		try
		{
			data = sparesForecastConsensusService.getAdjustments(regionId, countryId, hubId, partId);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getAdjustments in SparesForecastCommonController :",
					e.getCause());
		}

		logger.info("SparesForecastConsensusController: Exiting getAdjustments() method");
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@PutMapping(value = "/sparesForecast/consensus/adjustments", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update adjustments")
	public ResponseEntity<Object> updateAdjustments(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") int partId,@Valid @RequestBody SparesConsensusAdjustmentCombo adjustments) {
		logger.info("SparesForecastConsensusController: Entering updateAdjustments() method");
		try
		{
			sparesForecastConsensusService.updateAdjustments(regionId, countryId, hubId, partId, adjustments);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for updateAdjustments in SparesForecastCommonController :",
					e.getCause());
		}
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("SparesForecastConsensusController: Exiting updateAdjustments() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}
}
