package com.genpact.cora.scm.email;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class EmailConfigurationRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String hubName;
	private String kpi;
	private int notificationDay;
	private int leaseEndERD;
	private int repositioningERD;
	private int repairEndERD;
	private int inRepairERD;
	private List<AlertMailContent> alertMailContent;
	
	public String getHubName() {
		return hubName;
	}


	public void setHubName(String hubName) {
		this.hubName = hubName;
	}

	
	public String getKpi() {
		return kpi;
	}


	public void setKpi(String kpi) {
		this.kpi = kpi;
	}


	public int getNotificationDay() {
		return notificationDay;
	}


	public void setNotificationDay(int notificationDay) {
		this.notificationDay = notificationDay;
	}


	public int getLeaseEndERD() {
		return leaseEndERD;
	}


	public void setLeaseEndERD(int leaseEndERD) {
		this.leaseEndERD = leaseEndERD;
	}


	public int getRepositioningERD() {
		return repositioningERD;
	}


	public void setRepositioningERD(int repositioningERD) {
		this.repositioningERD = repositioningERD;
	}


	public int getRepairEndERD() {
		return repairEndERD;
	}


	public void setRepairEndERD(int repairEndERD) {
		this.repairEndERD = repairEndERD;
	}


	public int getInRepairERD() {
		return inRepairERD;
	}


	public void setInRepairERD(int inRepairERD) {
		this.inRepairERD = inRepairERD;
	}


	public List<AlertMailContent> getAlertMailContent() {
		return alertMailContent;
	}


	public void setAlertMailContent(List<AlertMailContent> alertMailContent) {
		this.alertMailContent = alertMailContent;
	}


	public static class AlertMailContent {
		private String status;
		private String alertType;
		private String alertDescription;
		private String toMailIds;
		private String ccMailIds;
		private String mailSubject;
		private String mailDescription;
		
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getAlertType() {
			return alertType;
		}
		public void setAlertType(String alertType) {
			this.alertType = alertType;
		}
		public String getAlertDescription() {
			return alertDescription;
		}
		public void setAlertDescription(String alertDescription) {
			this.alertDescription = alertDescription;
		}
		public String getToMailIds() {
			return toMailIds;
		}
		public void setToMailIds(String toMailIds) {
			this.toMailIds = toMailIds;
		}
		public String getCcMailIds() {
			return ccMailIds;
		}
		public void setCcMailIds(String ccMailIds) {
			this.ccMailIds = ccMailIds;
		}
		public String getMailSubject() {
			return mailSubject;
		}
		public void setMailSubject(String mailSubject) {
			this.mailSubject = mailSubject;
		}
		public String getMailDescription() {
			return mailDescription;
		}
		public void setMailDescription(String mailDescription) {
			this.mailDescription = mailDescription;
		}
		
	}
	
	
}
