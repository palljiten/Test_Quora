package com.genpact.cora.scm.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.DemandAllocationEdit;

public interface DemandAllocationEditRepository extends JpaRepository<DemandAllocationEdit, Integer>{

	@Query("select d.editPercentage from DemandAllocationEdit d where "
			+ " d.region.regionId = :regionID and d.country.countryId = :countryID AND d.hubSc.hubId = :hubID and"
			+ " d.flag=1 and d.weekNumber=datepart(wk,:wkStartDate) and d.weekYear=datepart(year,:wkStartDate) and"
			+ " d.parentShipper=:parentShipper and d.hubType='shipper'")
	Float getShipperPer(@Param("regionID")Integer regionID,@Param("countryID")Integer countryID, 
			@Param("hubID")Integer hubID,@Param("parentShipper") String parentShipper,@Param("wkStartDate") Date wkStartDate);

	@Query("select d.editPercentage from DemandAllocationEdit d where "
			+ " d.region.regionId = :regionID and d.country.countryId = :countryID AND d.hubSc.hubId = :hubID and"
			+ " d.flag=1 and d.weekNumber=datepart(wk,:wkStartDate) and d.weekYear=datepart(year,:wkStartDate) and"
			+ " d.parentShipper=:parentShipper and d.hubType='lane' and d.lane=:lane")
	Float getLanePer(@Param("regionID")Integer regionID,@Param("countryID")Integer countryID, 
			@Param("hubID")Integer hubID,@Param("parentShipper") String parentShipper,@Param("lane") String lane,
			@Param("wkStartDate") Date wkStartDate);

	@Query("select d from DemandAllocationEdit d where "
			+ " d.region.regionId = :regionID and d.country.countryId = :countryID AND d.hubSc.hubId = :hubID and"
			+ " d.flag=1 and d.parentShipper=:parentShipper and d.hubType='shipper'")
	DemandAllocationEdit get(@Param("regionID")Integer regionID,@Param("countryID")Integer countryID, 
			@Param("hubID")Integer hubID,@Param("parentShipper") String parentShipper);

	@Query("select d from DemandAllocationEdit d where "
			+ " d.region.regionId = :regionID and d.country.countryId = :countryID AND d.hubSc.hubId = :hubID and"
			+ " d.flag=1  and d.parentShipper=:parentShipper and d.hubType='lane' and d.lane=:lane")
	DemandAllocationEdit get(@Param("regionID")Integer regionID,@Param("countryID")Integer countryID, 
			@Param("hubID")Integer hubID,@Param("parentShipper")  String parentShipper,@Param("lane") String lane);
}
