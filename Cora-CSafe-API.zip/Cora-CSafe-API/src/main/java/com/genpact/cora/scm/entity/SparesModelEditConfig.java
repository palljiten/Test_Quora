package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "[dbo].[tbl_SparesModelEditConfig]")
public class SparesModelEditConfig {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private Integer id;
	
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CountryID")
    @JsonProperty(access = Access.WRITE_ONLY)
    private Country country;
    
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RegionID")
    @JsonProperty(access = Access.WRITE_ONLY)
    private Region region;
    
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HubID")
    @JsonProperty(access = Access.WRITE_ONLY)
    private HubSc hubsc;
    
    @Column(name = "PartID")
    private String partId;
    
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ModelID")
	private StatisticalModel model;
    
    @Column(name = "NormalForecast")
    private Boolean normalForecast;
    
    @Column(name = "BaselineAdjustment")
    private Boolean baselineAdjustment;
    
    @Column(name = "Percentage")
    private Float percentage;
    
    @Column(name = "flag")
    private Integer flag;
    
	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CreatedDate", nullable = true)
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ModifiedDate", nullable = true)
	private Date modifiedDate;
	
    @Column(name = "CreatedBy")
    private String createdBy;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public HubSc getHubsc() {
		return hubsc;
	}

	public void setHubsc(HubSc hubsc) {
		this.hubsc = hubsc;
	}

	public StatisticalModel getModel() {
		return model;
	}

	public void setModel(StatisticalModel model) {
		this.model = model;
	}

	public Boolean getNormalForecast() {
		return normalForecast;
	}

	public void setNormalForecast(Boolean normalForecast) {
		this.normalForecast = normalForecast;
	}

	public Boolean getBaselineAdjustment() {
		return baselineAdjustment;
	}

	public void setBaselineAdjustment(Boolean baselineAdjustment) {
		this.baselineAdjustment = baselineAdjustment;
	}

	public Float getPercentage() {
		return percentage;
	}

	public void setPercentage(Float percentage) {
		this.percentage = percentage;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}
}
