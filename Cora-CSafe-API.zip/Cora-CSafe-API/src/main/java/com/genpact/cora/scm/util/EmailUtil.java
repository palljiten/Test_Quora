package com.genpact.cora.scm.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sendgrid.Content;
import com.sendgrid.Email;
import com.sendgrid.Mail;
import com.sendgrid.Method;
import com.sendgrid.Personalization;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;

@Service("mailService")
public class EmailUtil implements MailService {

	// @Value("${spring.sendgrid.api-key}")
	String sendgridApiKey = "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";

	public static void main(String[] args) throws Exception {
		EmailUtil eu = new EmailUtil();
		eu.sendMail();
	}

	/*
	 * @Override public Map<String, String> sendMail() { Response response = null;
	 * try { SendGrid sg = new SendGrid(System.getenv(sendgridApiKey)); Request
	 * request = new Request(); request.setMethod(Method.POST);
	 * request.setEndpoint("mail/send"); request.setBody(
	 * "{\"from\": {\"email\": \"malik.sanjoy@gmail.com\"},\"personalizations\":[{\"to\": [{\"email\": \"malik.sanjoy@gmail.com\"}],\"dynamic_template_data\": {\"subject\": \"Testing Templates\",\"name\": \"Example User\", \"city\": \"Denver\"}}],\"template_id\": \"d-baa1108cfefc489b9a81868f57bc717f\"}"
	 * ); response = sg.api(request); System.out.println(response.getStatusCode());
	 * System.out.println(response.getBody());
	 * System.out.println(response.getHeaders()); } catch (IOException ex) {
	 * ex.printStackTrace(); return null; } return response.getHeaders(); }
	 */

	@Override
	public void sendMail() throws Exception {
		Mail mail = new Mail();
	    mail.setFrom(new Email("malik.sanjoy@gmail.com"));
	    mail.setTemplateId("d-028272228eeb48589d0330c2a8c1e619");
	    
	    System.out.println(new Date());
	    SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd kk:mm:ss z yyyy");
	    Date d = sdf.parse("Wed Nov 28 14:05:15 IST 2018");

	    Calendar c = Calendar.getInstance();
	    c.setTime(d);
	    long time = c.getTimeInMillis();
	    long curr = System.currentTimeMillis();
	    long sendAt = time - curr;    //Time difference in milliseconds
	    
	    mail.setSendAt(sendAt);

	    DynamicTemplatePersonalization personalization = new DynamicTemplatePersonalization();
	    personalization.addDynamicTemplateData("subject", "Due Date Reminder Notification - Scheduling Test");
	    personalization.addDynamicTemplateData("user", "CSafe Team");
	    personalization.addDynamicTemplateData("body", "test body");
	    personalization.addTo(new Email("malik.sanjoy@gmail.com"));
	    mail.addPersonalization(personalization);
	            
	    SendGrid sg = new SendGrid(sendgridApiKey);
	    Request request = new Request();
	    try {
	      request.setMethod(Method.POST);
	      request.setEndpoint("mail/send");
	      request.setBody(mail.build());
	      Response response = sg.api(request);
	      System.out.println(response.getStatusCode());
	      System.out.println(response.getBody());
	      System.out.println(response.getHeaders());
	    } catch (IOException ex) {
	      ex.printStackTrace();
	    }
	    
	    // https://sendgrid.com/docs/ui/sending-email/formatting-html/
	    
		/*Email from = new Email("malik.sanjoy@gmail.com");
		String subject = "Updated SendGrid Testing";
		Email to = new Email("malik.sanjoy@gmail.com");
		Content content = new Content("text/plain", "Good morning!"); 
		//Mail mail = new Mail(from, subject, to, content);

		Mail mail = new Mail();
		mail.setFrom(from); // mail.setSubject(subject);

		mail.setTemplateId("d-baa1108cfefc489b9a81868f57bc717f");

		DynamicTemplatePersonalization personalization = new DynamicTemplatePersonalization();
		personalization.addDynamicTemplateData("user", "Sanjoy");
		personalization.addDynamicTemplateData("city", "Bengaluru");
		personalization.addTo(to);
		mail.addPersonalization(personalization);

		SendGrid sg = new SendGrid(sendgridApiKey);

		Request request = new Request();
		Response response = null;
		try {
			request.setMethod(Method.POST);
			request.setEndpoint("mail/send");
			request.setBody(mail.build());
			response = sg.api(request);
			System.out.println(response.getStatusCode());
			System.out.println(response.getBody());
			System.out.println(response.getHeaders());
		} catch (IOException ex) {
			ex.printStackTrace();
			Map<String, String> m = new HashMap<String, String>();
			m.put("status", "failed");
			return m;
		}
		return response.getHeaders();*/
	}
	
	// Send Attachment: https://stackoverflow.com/questions/38599079/sendgrid-emailing-api-send-email-attachment
	

}
