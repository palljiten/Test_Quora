package com.genpact.cora.scm.repository;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.genpact.cora.scm.dto.ActivityDto;
import com.genpact.cora.scm.dto.CloseAlertRequest;
import com.genpact.cora.scm.dto.DemandCockpitCharts;
import com.genpact.cora.scm.dto.DemandCockpitExceptionsAlerts;
import com.genpact.cora.scm.dto.DemandCockpitExceptionsReportDownloadData;
import com.genpact.cora.scm.dto.ForecastAccuracyHubMetricsDTOWrapper;
import com.genpact.cora.scm.dto.ForecastAccuracyRegionMetricsDTOWrapper;
import com.genpact.cora.scm.dto.ForecastAcuracyReportDownloadDTOWrapper;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.util.DemandCockpitConstants;

@Repository
@EnableTransactionManagement
public class GenericSPCaller {

	private static Logger logger = LoggerFactory.getLogger(GenericSPCaller.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Transactional
	public Map<String, Object> callMyTestSP(String inParam) {
		Map<String, Object> simpleJdbcCallResult = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("MyTestSP");
			simpleJdbcCall.declareParameters(new SqlParameter("CName", Types.VARCHAR));
			MapSqlParameterSource paramMap = new MapSqlParameterSource().addValue("CName", inParam);
			simpleJdbcCallResult = simpleJdbcCall.execute(paramMap);
			Object obj = simpleJdbcCallResult.get("#result-set-1");
			System.out.println("\n\n\nSP Output:" + obj.getClass());
			if (obj instanceof ResultSet) {
				System.out.println("Is ResultSet? Yes");
			}
			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				System.out.println("Key: " + size);
				for (int i = 0; i < size; i++) {
					if (list.get(i) instanceof Map) {
						Map m = (Map) list.get(i);
						System.out.println("Value 1: " + m.get("CountryID"));
						System.out.println("Value 2: " + m.get("CountryName"));
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}

		return simpleJdbcCallResult;
	}

	@Transactional
	public DemandCockpitCharts callExceptionChartSP(String type) {
		Map<String, Object> spResult = new HashMap<>();
		DemandCockpitCharts dcCharts = new DemandCockpitCharts();
		String spName = (type.equals(DemandCockpitConstants.CONTAINER_TYPE))
				? DemandCockpitConstants.CONTAINER_EXCEPTIONS_CHART_SP
				: DemandCockpitConstants.SPARES_EXCEPTIONS_CHART_SP;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			spResult = simpleJdbcCall.execute(paramMap);
 
			Object obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				//logger.info("size...."+size);
				
				if(size!=0)
				{
				Map m = (Map) list.get(size - 1);
				//logger.info("map...."+m);
				dcCharts.setUnderConsumedForecast20((Integer) m.get(DemandCockpitConstants.UNDER_CONSUMED_FORECAST20));
				dcCharts.setOverConsumedForecast20((Integer) m.get(DemandCockpitConstants.OVER_CONSUMED_FORECAST20));
				if (type.equals(DemandCockpitConstants.CONTAINER_TYPE)) {
					dcCharts.setMtdWarning((Integer) m.get(DemandCockpitConstants.MTD_WARNING));
				}
				dcCharts.setMonthConsumptionWarning3(
						(Integer) m.get(DemandCockpitConstants.MONTH_CONSUMPTION_WARNING3));
				dcCharts.setMonthConsumptionWarning4(
						(Integer) m.get(DemandCockpitConstants.MONTH_CONSUMPTION_WARNING4));
				dcCharts.setEarlyWarningSignal((Integer) m.get(DemandCockpitConstants.EARLY_WARNING_SIGNAL));
				dcCharts.setPast3MonthsFacLess60((Integer) m.get(DemandCockpitConstants.PAST_3MONTHS_FAC_LESS60));
				dcCharts.setYtdAvgSaleVsAvgForecast(
						(Integer) m.get(DemandCockpitConstants.YTD_AVGSALES_VS_AVGFORECAST));
				dcCharts.setZeroActualsButForecasted(
						(Integer) m.get(DemandCockpitConstants.ZERO_ACTUALS_BUT_FORECASTED));
				}
			}
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		return dcCharts;
	}

	public Map<String, List<DemandCockpitExceptionsAlerts>> callExceptionAlertsSP(String type, int regionId,
			int countryId, int hubId, String partId) {
		Map<String, Object> spResult = new HashMap<>();
		Map<String, List<DemandCockpitExceptionsAlerts>> data = new HashMap<>();
		DemandCockpitExceptionsAlerts alerts = new DemandCockpitExceptionsAlerts();
		List<DemandCockpitExceptionsAlerts> dataList = new ArrayList<>();

		String spName = (type.equals(DemandCockpitConstants.CONTAINER_TYPE))
				? DemandCockpitConstants.CONTAINER_EXCEPTIONS_ALERTS_SP
				: DemandCockpitConstants.SPARES_EXCEPTIONS_ALERTS_SP;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_REGION_ID, regionId);
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_COUNTRY_ID, countryId);
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_HUB_ID, hubId);
			if (type.equals(DemandCockpitConstants.SPARES_TYPE)) {
				paramMap.addValue(DemandCockpitConstants.SP_PARAM_PART_ID, partId);
			}
			spResult = simpleJdbcCall.execute(paramMap);
			System.out.println("\n\n aaaaa  " + spResult + "\n\n");
			Object obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				if (size == 0) {
					alerts.setHubId(-1);
					alerts.setHubCode("-1");
					alerts.setUnderConsumedForecast20(-1);
					alerts.setOverConsumedForecast20(-1);
					alerts.setMtdWarning(-1);
					alerts.setMonthConsumptionWarning3(-1);
					alerts.setMonthConsumptionWarning4(-1);
					alerts.setEarlyWarningSignal(-1);
					alerts.setPast3MonthsFacLess60(-1);
					alerts.setYtdAvgSaleVsAvgForecast(-1);
					alerts.setZeroActualsButForecasted(-1);
					dataList.add(alerts);
				}
				for (int j = 0; j < size; j++) {
					alerts = new DemandCockpitExceptionsAlerts();
					Map m = (Map) list.get(j);
					alerts.setHubId((Integer) m.get(DemandCockpitConstants.HUBID));
					alerts.setHubCode((String) m.get(DemandCockpitConstants.HUBCODE));
					alerts.setUnderConsumedForecast20(
							(Integer) m.get(DemandCockpitConstants.UNDER_CONSUMED_FORECAST20));
					alerts.setOverConsumedForecast20((Integer) m.get(DemandCockpitConstants.OVER_CONSUMED_FORECAST20));
					if (type.equals(DemandCockpitConstants.CONTAINER_TYPE)) {
						alerts.setMtdWarning((Integer) m.get(DemandCockpitConstants.MTD_WARNING));
					}
					alerts.setMonthConsumptionWarning3(
							(Integer) m.get(DemandCockpitConstants.MONTH_CONSUMPTION_WARNING3));
					alerts.setMonthConsumptionWarning4(
							(Integer) m.get(DemandCockpitConstants.MONTH_CONSUMPTION_WARNING4));
					alerts.setEarlyWarningSignal((Integer) m.get(DemandCockpitConstants.EARLY_WARNING_SIGNAL));
					alerts.setPast3MonthsFacLess60((Integer) m.get(DemandCockpitConstants.PAST_3MONTHS_FAC_LESS60));
					alerts.setYtdAvgSaleVsAvgForecast(
							(Integer) m.get(DemandCockpitConstants.YTD_AVGSALES_VS_AVGFORECAST));
					alerts.setZeroActualsButForecasted(
							(Integer) m.get(DemandCockpitConstants.ZERO_ACTUALS_BUT_FORECASTED));
					dataList.add(alerts);
				}
			}
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}

		data.put("alerts", dataList);
		return data;
	}

	public DemandCockpitExceptionsAlerts callExceptionReportSP(String type, int regionId, int countryId, int hubId,
			String partId) {
		Map<String, Object> spResult = new HashMap<>();
		DemandCockpitExceptionsAlerts alerts = new DemandCockpitExceptionsAlerts();
		String spName = (type.equals(DemandCockpitConstants.CONTAINER_TYPE))
				? DemandCockpitConstants.CONTAINER_EXCEPTIONS_REPORT_SP
				: DemandCockpitConstants.SPARES_EXCEPTIONS_REPORT_SP;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_REGION_ID, regionId);
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_COUNTRY_ID, countryId);
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_HUB_ID, hubId);
			if (type.equals(DemandCockpitConstants.SPARES_TYPE)) {
				paramMap.addValue(DemandCockpitConstants.SP_PARAM_PART_ID, partId);
			}

			spResult = simpleJdbcCall.execute(paramMap);
			System.out.println("\n\n result   " + spResult + "\n\n");
			Object obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				if (size > 0) {
					Map m = (Map) list.get(size - 1);
					alerts.setHubId((Integer) m.get(DemandCockpitConstants.HUBID));
					alerts.setHubCode((String) m.get(DemandCockpitConstants.HUBCODE));
					alerts.setUnderConsumedForecast20(
							(Integer) m.get(DemandCockpitConstants.UNDER_CONSUMED_FORECAST20));
					alerts.setOverConsumedForecast20((Integer) m.get(DemandCockpitConstants.OVER_CONSUMED_FORECAST20));
					if (type.equals(DemandCockpitConstants.CONTAINER_TYPE)) {
						alerts.setMtdWarning((Integer) m.get(DemandCockpitConstants.MTD_WARNING));
					}
					alerts.setMonthConsumptionWarning3(
							(Integer) m.get(DemandCockpitConstants.MONTH_CONSUMPTION_WARNING3));
					alerts.setMonthConsumptionWarning4(
							(Integer) m.get(DemandCockpitConstants.MONTH_CONSUMPTION_WARNING4));
					alerts.setEarlyWarningSignal((Integer) m.get(DemandCockpitConstants.EARLY_WARNING_SIGNAL));
					alerts.setPast3MonthsFacLess60((Integer) m.get(DemandCockpitConstants.PAST_3MONTHS_FAC_LESS60));
					alerts.setYtdAvgSaleVsAvgForecast(
							(Integer) m.get(DemandCockpitConstants.YTD_AVGSALES_VS_AVGFORECAST));
					alerts.setZeroActualsButForecasted(
							(Integer) m.get(DemandCockpitConstants.ZERO_ACTUALS_BUT_FORECASTED));
				}
			}
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		return alerts;
	}

	public DemandCockpitExceptionsReportDownloadData callExceptionReportDataSP(String type) {
		Map<String, Object> spResult = new HashMap<>();
		DemandCockpitExceptionsReportDownloadData reportData = new DemandCockpitExceptionsReportDownloadData();
		String spName = (type.equals(DemandCockpitConstants.CONTAINER_TYPE))
				? DemandCockpitConstants.CONTAINER_EXCEPTIONS_REPORT_DOWNLOAD_SP
				: DemandCockpitConstants.SPARES_EXCEPTIONS_REPORT_DOWNLOAD_SP;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			spResult = simpleJdbcCall.execute(paramMap);

			Object obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				System.out.println("size---  "+size);
				if(size!=0)
				{
				Map m = (Map) list.get(size - 1);
				reportData.setHubCode((String) m.get(DemandCockpitConstants.HUBCODE));
				reportData.setCountryName((String) m.get(DemandCockpitConstants.COUNTRY_NAME));
				reportData.setRegionName((String) m.get(DemandCockpitConstants.REGION_NAME));
				reportData
						.setUnderConsumedForecast20((Integer) m.get(DemandCockpitConstants.UNDER_CONSUMED_FORECAST20));
				reportData.setOverConsumedForecast20((Integer) m.get(DemandCockpitConstants.OVER_CONSUMED_FORECAST20));
				if (type.equals(DemandCockpitConstants.CONTAINER_TYPE)) {
					reportData.setMtdWarning((Integer) m.get(DemandCockpitConstants.MTD_WARNING));
				}
				reportData.setMonthConsumptionWarning3(
						(Integer) m.get(DemandCockpitConstants.MONTH_CONSUMPTION_WARNING3));
				reportData.setMonthConsumptionWarning4(
						(Integer) m.get(DemandCockpitConstants.MONTH_CONSUMPTION_WARNING4));
				reportData.setEarlyWarningSignal((Integer) m.get(DemandCockpitConstants.EARLY_WARNING_SIGNAL));
				reportData.setPast3MonthsFacLess60((Integer) m.get(DemandCockpitConstants.PAST_3MONTHS_FAC_LESS60));
				reportData.setYtdAvgSaleVsAvgForecast(
						(Integer) m.get(DemandCockpitConstants.YTD_AVGSALES_VS_AVGFORECAST));
				reportData.setZeroActualsButForecasted(
						(Integer) m.get(DemandCockpitConstants.ZERO_ACTUALS_BUT_FORECASTED));
				reportData.setAlert((String) m.get(DemandCockpitConstants.ALERT));
			   }
			}
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		return reportData;
	}

	public Map<String, Object> callReportSummaryDataSP(String type) {
		Map<String, Object> spResult = new HashMap<>();
		Map<String, Object> finalMap = new HashMap<>();

		finalMap.put("type", type);
		
		String spName = (type.equals(DemandCockpitConstants.CONTAINER_TYPE))
				? DemandCockpitConstants.CONTAINER_REVIEW_SUMMARY_SP
				: DemandCockpitConstants.SPARES_REVIEW_SUMMARY_SP;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			spResult = simpleJdbcCall.execute(paramMap);

			Object obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				Map m = (Map) list.get(size - 1);
				finalMap.put(DemandCockpitConstants.REVIEW_COMPLETED,
						(Integer) m.get(DemandCockpitConstants.REVIEW_COMPLETED));
				finalMap.put(DemandCockpitConstants.REVIEW_PENDING,
						(Integer) m.get(DemandCockpitConstants.REVIEW_PENDING));
			}
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		return finalMap;
	}

	public boolean callCloseAlertSP(String type, String partNumber, CloseAlertRequest request) {
		String spName = (type.equals(DemandCockpitConstants.CONTAINER_TYPE))
				? DemandCockpitConstants.CONTAINER_CLOSE_ALERT_SP
				: DemandCockpitConstants.SPARES_CLOSE_ALERT_SP;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_HUB_ID, request.getHubId());
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_COMMENT, request.getComment());
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_CLOSEDBY,
					request.getClosedBy() == null ? "CSafeAPI" : request.getClosedBy());
			if (type.equals(DemandCockpitConstants.SPARES_TYPE)) {
				paramMap.addValue(DemandCockpitConstants.SP_PARAM_PART_NUMBER, partNumber);
			}

			simpleJdbcCall.execute(paramMap);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException("Facing issue during stored procedure call", e);
		}
		return true;
	}
	
	public ActivityDto callActivityChartSP() {
		Map<String, Object> spResult = new HashMap<>();
		ActivityDto data = new ActivityDto();
		String containerSP = DemandCockpitConstants.CONTAINER_ACTIVITY_CHART_SP;
		String sparesSP = DemandCockpitConstants.SPARES_ACTIVITY_CHART_SP;
		
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(containerSP);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			spResult = simpleJdbcCall.execute(paramMap);

			Object obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				if (size >= 0) {
					Map m = (Map) list.get(size - 1);
					data.setContainerReviewCompleted((Integer) m.get(DemandCockpitConstants.REVIEW_COMPLETED));
					data.setContainerReviewPending((Integer) m.get(DemandCockpitConstants.REVIEW_PENDING));
				}
			}
			
			simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(sparesSP);
			spResult = simpleJdbcCall.execute(paramMap);

			obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				if (size >= 0) {
					Map m = (Map) list.get(size - 1);
					data.setSparesReviewCompleted((Integer) m.get(DemandCockpitConstants.REVIEW_COMPLETED));
					data.setSparesReviewPending((Integer) m.get(DemandCockpitConstants.REVIEW_PENDING));
				}
			}
			
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException("Facing issue during stored procedure call", e);
		}
		return data;
	}
	
	public ForecastAccuracyRegionMetricsDTOWrapper callForecastAccuracyRegionMetricsSP(String type, String monthYear) {
		ForecastAccuracyRegionMetricsDTOWrapper wrapper = new ForecastAccuracyRegionMetricsDTOWrapper();
		Map<String, Object> spResult = new HashMap<>();
		String spName = (type.equals(DemandCockpitConstants.CONTAINER_TYPE))
				? DemandCockpitConstants.CONTAINER_FA_REGION_METRICS_SP
				: DemandCockpitConstants.SPARES_FA_REGION_METRICS_SP;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_MONTH_YEAR, monthYear);
			spResult = simpleJdbcCall.execute(paramMap);
			
			Object obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			System.out.println(obj);
/*			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				Map m = (Map) list.get(size - 1);
				finalMap.put(DemandCockpitConstants.REVIEW_COMPLETED,
						(Integer) m.get(DemandCockpitConstants.REVIEW_COMPLETED));
				finalMap.put(DemandCockpitConstants.REVIEW_PENDING,
						(Integer) m.get(DemandCockpitConstants.REVIEW_PENDING));
			}*/
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException("Facing issue during stored procedure call", e);
		}
		return wrapper;
	}
	
	public ForecastAccuracyHubMetricsDTOWrapper callForecastAccuracyHubMetricsSP(String type, int regionId, String monthYear) {
		ForecastAccuracyHubMetricsDTOWrapper wrapper = new ForecastAccuracyHubMetricsDTOWrapper();
		Map<String, Object> spResult = new HashMap<>();
		String spName = (type.equals(DemandCockpitConstants.CONTAINER_TYPE))
				? DemandCockpitConstants.CONTAINER_FA_HUB_METRICS_SP
				: DemandCockpitConstants.SPARES_FA_HUB_METRICS_SP;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_REGION_ID, regionId);
			paramMap.addValue(DemandCockpitConstants.SP_PARAM_MONTH_YEAR, monthYear);
			spResult = simpleJdbcCall.execute(paramMap);
			
			Object obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			System.out.println(obj);
/*			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				Map m = (Map) list.get(size - 1);
				finalMap.put(DemandCockpitConstants.REVIEW_COMPLETED,
						(Integer) m.get(DemandCockpitConstants.REVIEW_COMPLETED));
				finalMap.put(DemandCockpitConstants.REVIEW_PENDING,
						(Integer) m.get(DemandCockpitConstants.REVIEW_PENDING));
			}*/
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException("Facing issue during stored procedure call", e);
		}
		return wrapper;
	}
	
	public ForecastAcuracyReportDownloadDTOWrapper callForecastAccuracyReportDownloadSP(String type) {
		ForecastAcuracyReportDownloadDTOWrapper wrapper = new ForecastAcuracyReportDownloadDTOWrapper();
		Map<String, Object> spResult = new HashMap<>();
		String spName = (type.equals(DemandCockpitConstants.CONTAINER_TYPE))
				? DemandCockpitConstants.CONTAINER_FA_REPORT_DOWNLOAD_SP
				: DemandCockpitConstants.SPARES_FA_REPORT_DOWNLOAD_SP;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			spResult = simpleJdbcCall.execute(paramMap);
			
			Object obj = spResult.get(DemandCockpitConstants.SP_RESULT_SET_1);
			System.out.println(obj);
/*			if (obj instanceof List) {
				List list = (List) obj;
				int size = list.size();
				Map m = (Map) list.get(size - 1);
				finalMap.put(DemandCockpitConstants.REVIEW_COMPLETED,
						(Integer) m.get(DemandCockpitConstants.REVIEW_COMPLETED));
				finalMap.put(DemandCockpitConstants.REVIEW_PENDING,
						(Integer) m.get(DemandCockpitConstants.REVIEW_PENDING));
			}*/
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException("Facing issue during stored procedure call", e);
		}
		return wrapper;
	}
}
