package com.genpact.cora.scm.repository;

public interface StoredProcedureRepository {

	//[dbo].[BudgetForecastSP]
	public void callBudgetForecastSP();
}
