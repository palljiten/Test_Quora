package com.genpact.cora.scm.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "[dbo].[tbl_VABalanceInHand]")
public class BalanceInHand 
{
	    
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
	Integer ID;
	@Column(name = "Code", nullable = true)
	String Code;
	@Column(name = "City", nullable = true)
	String City;
	@Column(name = "CountryName", nullable = true)
	String CountryName;
	@Column(name = "WeekNo", nullable = true)
	String WeekNo;
	@Column(name = "BalanceInHand", nullable = true)
	Integer BalanceInHand;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DueDate")
	private Date dueDate;
	
	public Integer getID() {
		return ID;
	}
	public void setID(Integer iD) {
		ID = iD;
	}
	public String getCode() {
		return Code;
	}
	public void setCode(String code) {
		Code = code;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getCountryName() {
		return CountryName;
	}
	public void setCountryName(String countryName) {
		CountryName = countryName;
	}
	public String getWeekNo() {
		return WeekNo;
	}
	public void setWeekNo(String weekNo) {
		WeekNo = weekNo;
	}
	public Integer getBalanceInHand() {
		return BalanceInHand;
	}
	public void setBalanceInHand(Integer balanceInHand) {
		BalanceInHand = balanceInHand;
	}
	/**
	 * @return the dueDate
	 */
	public Date getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	
}
