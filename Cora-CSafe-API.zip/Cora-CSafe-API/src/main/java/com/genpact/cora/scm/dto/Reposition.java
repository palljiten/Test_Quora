/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.io.Serializable;

/**
 * @author 703158077
 *
 */
public class Reposition implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543217L;
	String serialNum = "";
	String mode = "";
	String carrier = "";
	String scheduleDelivery ="";
	String shippingId = "";
	String tripName = "";
	String weight = "";
	
	
	
	/**
	 * @return the serialNum
	 */
	public String getSerialNum() {
		return serialNum;
	}
	/**
	 * @param serialNum the serialNum to set
	 */
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}
	/**
	 * @return the mode
	 */
	public String getMode() {
		return mode;
	}
	/**
	 * @param mode the mode to set
	 */
	public void setMode(String mode) {
		this.mode = mode;
	}
	/**
	 * @return the carrier
	 */
	public String getCarrier() {
		return carrier;
	}
	/**
	 * @param carrier the carrier to set
	 */
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	/**
	 * @return the scheduleDelivery
	 */
	public String getScheduleDelivery() {
		return scheduleDelivery;
	}
	/**
	 * @param scheduleDelivery the scheduleDelivery to set
	 */
	public void setScheduleDelivery(String scheduleDelivery) {
		this.scheduleDelivery = scheduleDelivery;
	}
	/**
	 * @return the shippingId
	 */
	public String getShippingId() {
		return shippingId;
	}
	/**
	 * @param shippingId the shippingId to set
	 */
	public void setShippingId(String shippingId) {
		this.shippingId = shippingId;
	}
	/**
	 * @return the tripName
	 */
	public String getTripName() {
		return tripName;
	}
	/**
	 * @param tripName the tripName to set
	 */
	public void setTripName(String tripName) {
		this.tripName = tripName;
	}
	/**
	 * @return the weight
	 */
	public String getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}
	
	
}
