package com.genpact.cora.scm.validation;

import java.util.Arrays;

public enum EmailAlertCodeEnum {
	
	DDRIN("DDR-IN"), CHRIN("CHR-IN"), SRRRE("SRR-RE"), CRDRE("CRD-RE");
	private String value;

	private EmailAlertCodeEnum(String value) {
		this.value = value;
	}

	public static EmailAlertCodeEnum fromValue(String value) {
		for (EmailAlertCodeEnum alertCode : values()) {
			if (alertCode.value.equalsIgnoreCase(value)) {
				return alertCode;
			}
		}
		throw new IllegalArgumentException(
				"Unknown enum type " + value + ", Allowed values are " + Arrays.toString(values()));
	}
	
	public String getValue() {
		return value;
	}
}
