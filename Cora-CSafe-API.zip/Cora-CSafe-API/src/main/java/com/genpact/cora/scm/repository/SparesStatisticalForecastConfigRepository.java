package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.TempConfigModel;
import com.genpact.cora.scm.entity.SparesStatisticalForecastBestFit;
import com.genpact.cora.scm.entity.SparesStatisticalForecastConfig;

public interface SparesStatisticalForecastConfigRepository extends JpaRepository<SparesStatisticalForecastConfig, Integer>{
	
	@Query("SELECT f FROM SparesStatisticalForecastConfig f "
			+ "WHERE f.hub.hubId = :hubId AND f.country.countryId = :countryId "
			+ "AND f.region.regionId = :regionId AND f.partId = :partId")
	public List<SparesStatisticalForecastConfig> getConfiguredModel(@Param("regionId") int regionId, @Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId);
	
	@Modifying
    @Query("UPDATE SparesStatisticalForecastConfig sp SET sp.flag = 0 "
    		+ "WHERE sp.flag=1 AND sp.hub.hubId = :hubId AND sp.country.countryId = :countryId AND sp.partId = :partId "
    		+ "AND sp.region.regionId = :regionId AND sp.configuredModel.modelId = :modelId ")
    int updateStatisticalForecastConfigModel(@Param("modelId") int modelId, @Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId);
}
