package com.genpact.cora.scm.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "[dbo].[tbl_VANotificationContent]")
public class EmailAlertContent {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;
	
	@Column(name = "AccountName")
	private String accountName;
	
	@Column(name = "KPI")
	private String kpi;
	
	@Column(name = "Status")
	private String status;
	
	@Column(name = "AlertType")
	private String alertType;
	
	@Column(name = "ToMailIDs")
	private String toMailIDs;
	
	@Column(name = "CCMailIDs")
	private String ccMailIDs;
	
	@Column(name = "AlertDescription")
	private String alertDescription;
	
	@Column(name = "MailSubject")
	private String mailSubject;
	
	@Column(name = "MailDescription")
	private String mailDescription;
	
	@Column(name = "MailTemplateId")
	private String mailTemplateId;
	
	@Column(name = "CreatedDate")
	private Date CreatedDate;
	
	@Column(name = "ModifiedDate")
	private Date ModifiedDate;
	
	@Column(name = "ModifiedBy")
	private String modifiedBy;
	
	@Column(name = "Flag")
	private Boolean flag;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	public String getKpi() {
		return kpi;
	}

	public void setKpi(String kpi) {
		this.kpi = kpi;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public String getAlertDescription() {
		return alertDescription;
	}

	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}
	
	public String getToMailIDs() {
		return toMailIDs;
	}

	public void setToMailIDs(String toMailIDs) {
		this.toMailIDs = toMailIDs;
	}

	public String getCcMailIDs() {
		return ccMailIDs;
	}

	public void setCcMailIDs(String ccMailIDs) {
		this.ccMailIDs = ccMailIDs;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public String getMailDescription() {
		return mailDescription;
	}

	public void setMailDescription(String mailDescription) {
		this.mailDescription = mailDescription;
	}

	public String getMailTemplateId() {
		return mailTemplateId;
	}

	public void setMailTemplateId(String mailTemplateId) {
		this.mailTemplateId = mailTemplateId;
	}

	public Date getCreatedDate() {
		return CreatedDate;
	}

	public void setCreatedDate(Date createdDate) {
		CreatedDate = createdDate;
	}

	public Date getModifiedDate() {
		return ModifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		ModifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Boolean getFlag() {
		return flag;
	}

	public void setFlag(Boolean flag) {
		this.flag = flag;
	}

}
