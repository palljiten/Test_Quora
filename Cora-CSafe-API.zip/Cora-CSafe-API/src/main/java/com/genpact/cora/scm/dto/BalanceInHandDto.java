package com.genpact.cora.scm.dto;

public class BalanceInHandDto 
{
	    
	String  region;
	String hubSc;
	String city;
	String countryName;
	String weekNo;
	Integer balanceInHand;
	private int safetyStock;
	Integer status;
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getHubSc() {
		return hubSc;
	}
	public void setHubSc(String hubSc) {
		this.hubSc = hubSc;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getWeekNo() {
		return weekNo;
	}
	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}
	public Integer getBalanceInHand() {
		return balanceInHand;
	}
	public void setBalanceInHand(Integer balanceInHand) {
		this.balanceInHand = balanceInHand;
	}
	public int getSafetyStock() {
		return safetyStock;
	}
	public void setSafetyStock(int safetyStock) {
		this.safetyStock = safetyStock;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	
	
	
}
