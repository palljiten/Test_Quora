package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.email.EmailConfigurationRequest;
import com.genpact.cora.scm.entity.EmailAlertContent;
import com.genpact.cora.scm.entity.EmailAlertSettings;

@Repository
public class EmailAlertRepository {
	
	@PersistenceContext
	private EntityManager entityManager;

    public List<EmailAlertContent> fetchMailContent(String accountName, String status, String alertType, String alertDescription){
    	Query query = entityManager.createQuery(
			 "FROM EmailAlertContent ec "
			+ "where ec.accountName = :accountName AND ec.status = :status AND ec.alertType = :alertType AND ec.alertDescription = :alertDescription");
    	
    	query.setParameter("accountName", accountName);
    	query.setParameter("status", status);
    	query.setParameter("alertType", alertType);
    	query.setParameter("alertDescription", alertDescription);
    	return query.getResultList();
    }
    
    public List<EmailAlertSettings> fetchHubAlertConfiguration(String hubName, String kpi) {
    	Query query = entityManager.createQuery(
    			"FROM EmailAlertSettings es "
    			+ "where es.accountName = :accountName AND es.kpi = :kpi");
        	
        	query.setParameter("accountName", hubName);
        	query.setParameter("kpi", kpi);
        	return query.getResultList();
    }
    
    public List<EmailAlertContent> fetchHubAlertContents(String hubName, String kpi) {
    	Query query = entityManager.createQuery(
    			"FROM EmailAlertContent ec "
    			+ "where ec.accountName = :accountName AND ec.kpi = :kpi");
        	
        	query.setParameter("accountName", hubName);
        	query.setParameter("kpi", kpi);
        	return query.getResultList();
    }
    
    public void saveHubAlertConfiguration(EmailAlertSettings entity) {
    	entityManager.merge(entity);
    }
    
    public void saveHubAlertContent(EmailAlertContent entity) {
    	entityManager.merge(entity);
    }
}
