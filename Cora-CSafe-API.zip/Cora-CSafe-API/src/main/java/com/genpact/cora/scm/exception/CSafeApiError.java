package com.genpact.cora.scm.exception;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;

public class CSafeApiError {
	private String traceId;
    private HttpStatus status;
    private String message;
    private List<String> errors;
 
    public CSafeApiError(String traceId, HttpStatus status, String message, List<String> errors) {
    	this.traceId = traceId;
        this.status = status;
        this.message = message;
        this.errors = errors;
    }
 
    public CSafeApiError(String traceId, HttpStatus status, String message, String error) {
    	this.traceId = traceId;
        this.status = status;
        this.message = message;
        this.errors = Arrays.asList(error);
    }

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

	public String getTraceId() {
		return traceId;
	}

	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}
}
