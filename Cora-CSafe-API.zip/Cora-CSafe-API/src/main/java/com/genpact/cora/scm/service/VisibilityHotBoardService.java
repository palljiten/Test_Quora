package com.genpact.cora.scm.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.BalanceHotBoard;
import com.genpact.cora.scm.dto.BalanceInHandDto;
import com.genpact.cora.scm.dto.HotBoard;
import com.genpact.cora.scm.dto.HubCtLatLong;
import com.genpact.cora.scm.dto.RepairEnd;
import com.genpact.cora.scm.dto.RepairEndData;
import com.genpact.cora.scm.dto.ResolvedIssuesDto;
import com.genpact.cora.scm.dto.SparePart;
import com.genpact.cora.scm.dto.VAInboundData;
import com.genpact.cora.scm.dto.VALeaseEndData;
import com.genpact.cora.scm.dto.VARepairData;
import com.genpact.cora.scm.entity.BalanceInHand;
import com.genpact.cora.scm.entity.ResolvedIssues;
import com.genpact.cora.scm.entity.SpareParts;
import com.genpact.cora.scm.entity.VABalanceInHand;
import com.genpact.cora.scm.entity.VAInbound;
import com.genpact.cora.scm.entity.VALeaseEnd;
import com.genpact.cora.scm.entity.VARepair;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.BalanceInHandRepository;
import com.genpact.cora.scm.repository.ContainerForecastRepository;
import com.genpact.cora.scm.repository.HotBoardAnalyseRepository;
import com.genpact.cora.scm.repository.HotBoardRepository;
import com.genpact.cora.scm.repository.HubRepository;
import com.genpact.cora.scm.repository.InboundHotBoardRepository;
import com.genpact.cora.scm.repository.LeaseEndHotBoardRepository;
import com.genpact.cora.scm.repository.OutBoundRepository;
import com.genpact.cora.scm.repository.RepairHotBoardRepository;
import com.genpact.cora.scm.repository.ResolvedIssuesRepository;
import com.genpact.cora.scm.repository.SparesPartsRepository;
import com.genpact.cora.scm.repository.VisibilityHotBoardRepository;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

@Service
public class VisibilityHotBoardService {

	private static Logger logger = LoggerFactory.getLogger(VisibilityHotBoardService.class);

	@Autowired
	InboundHotBoardRepository inboundHotBoardRepository;
	@Autowired
	OutBoundRepository outBoundRepository;
	@Autowired
	LeaseEndHotBoardRepository leaseEndHotBoardRepository;
	@Autowired
	RepairHotBoardRepository repairHotBoardRepository;

	@Autowired
	SparesPartsRepository partsRepository;

	@Autowired
	BalanceInHandRepository balanceInHandRepository;

	@Autowired
	ResolvedIssuesRepository resolvedIssuesRepository;

	@Autowired
	HotBoardRepository hotBoardRepository;

	@Autowired
	HotBoardAnalyseRepository hotBoardAnalyseRepository;

	@Autowired
	VisibilityHotBoardRepository visibilityHotBoardRepository;

	@Autowired
	HubRepository hubRepository;

	public List<VAInboundData> getInboundHotBoard() throws CSafeServiceException {

		List<VAInboundData> inboundList = new ArrayList<>();

		SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy");
		@NotNull
		List<Object[]> inboundData = inboundHotBoardRepository.getInboundHotBoardData();
		for (Object[] vi : inboundData) {
			VAInboundData inbData = new VAInboundData();
			inbData.setSerialNumber(vi[1].toString());
			inbData.setStatus(vi[2].toString());
			if(vi[3]!=null) {
				inbData.setOrigin(vi[3].toString());
				}
				else {
					inbData.setOrigin(null);
				}
				if(vi[4]!=null) {
					inbData.setDestination(vi[4].toString());
					}
					else {
						inbData.setDestination(null);
					}
				
			inbData.setAlertDescription(vi[5].toString());
			inbData.setAlertType(vi[10].toString());
			inbData.setWeekNo(vi[0].toString());
			if (vi[6] != null)
				inbData.setDueDate(sm.format((Date) vi[6]));
			else
				inbData.setDueDate(null);
			if (vi[7] != null)
				inbData.setNotificationDate(sm.format((Date) vi[7]));
			else
				inbData.setNotificationDate(null);
			if (vi[8] != null)
				inbData.setEstimatedReceivingDate(sm.format((Date) vi[8]));
			else
				inbData.setEstimatedReceivingDate(null);
			if (null != vi[9])
				inbData.setActualReceivingDate(sm.format((Date) vi[9]));
			else
				inbData.setActualReceivingDate(null);
			inboundList.add(inbData);
		}

		return inboundList;
	}

	public List<VALeaseEndData> getLeaseEndHotBoard() throws CSafeServiceException {
		SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy");

		List<Object[]> leaseEndData = leaseEndHotBoardRepository.getLeaseEndHotBoardData();
		List<VALeaseEndData> leaseList = new ArrayList<>();
		for (Object[] le : leaseEndData) {
			VALeaseEndData leaseData = new VALeaseEndData();
			leaseData.setSerialNumber(le[0].toString());
			if (le[1] != null) {
				leaseData.setStatus(le[1].toString());
			} else {
				leaseData.setStatus(null);
			}
			
			if (le[2] != null) {
				leaseData.setOrigin(le[2].toString());
			} else {
				leaseData.setOrigin(null);
			}
			if (le[3] != null) {
				leaseData.setDestination(le[3].toString());
			} else {
				leaseData.setDestination(null);
			}
			
			leaseData.setAlertDescription(le[4].toString());
			leaseData.setAlertType(le[10].toString());
			leaseData.setDueDate(sm.format((Date) le[6]));
			leaseData.setNotificationDate(sm.format((Date) le[7]));
			leaseData.setEstimatedReceivingDate(sm.format((Date) le[8]));
			if (le[9] != null)
				leaseData.setActualReceivingDate(sm.format((Date) le[9]));
			else
				leaseData.setActualReceivingDate(null);
			leaseData.setWeekNo(le[5].toString());
			leaseList.add(leaseData);
		}

		return leaseList;
	}

	public List<VARepairData> getRepairHotBoardData() throws CSafeServiceException {
		SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy");

		List<VARepairData> vaRepairList = new ArrayList<>();
		List<Object[]> repairEndData = repairHotBoardRepository.getRepairHotBoardData();
		System.out.println("repairEndData size  :   "+repairEndData.size());
		for (Object[] re : repairEndData) {
			VARepairData vaRepairData = new VARepairData();
			vaRepairData.setSerialNumber(re[1].toString());
			vaRepairData.setStatus(re[2].toString());
			if(re[3]!=null) {
			vaRepairData.setContainerLocation(re[3].toString());
			}
			else {
				vaRepairData.setContainerLocation(null);
			}
			vaRepairData.setAlertDescription(re[4].toString());
			vaRepairData.setAlertType(re[9].toString());
			vaRepairData.setWeekNo(re[0].toString());
			vaRepairData.setDueDate(sm.format((Date)re[5]));
			vaRepairData.setNotificationDate(sm.format((Date)re[6]));
			vaRepairData.setEstimatedReceivingDate(sm.format((Date)re[7]));
			if(re[8]!=null)
			vaRepairData.setActualReceivingDate(sm.format((Date)re[8]));
			vaRepairList.add(vaRepairData);
		}

		return vaRepairList;
	}
	
	
	/*public List<RepairEnd> getRepairHotBoardData() throws CSafeServiceException {
		SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy");
		
		List<VARepairData> vaRepairList = new ArrayList<>();
		List<RepairEnd> repairEndData = visibilityHotBoardRepository.getRepairHotBoardData();
		System.out.println("repairEndData size  :   "+repairEndData.size());
		for (RepairEnd re : repairEndData) {
			VARepairData vaRepairData = new VARepairData();
			vaRepairData.setSerialNumber(repairEndData.get(1).toString());
			vaRepairData.setStatus(repairEndData.get(2).toString());
			vaRepairData.setContainerLocation(repairEndData.get(3).getContainerLocation());
			vaRepairData.setAlertDescription(repairEndData.get(4).getAlertDescription());
			vaRepairData.setAlertType(repairEndData.get(9).getAlertType());
			vaRepairData.setWeekNo(repairEndData.get(0).getWeekNo());
			vaRepairData.setDueDate(sm.format((Date)repairEndData.get(5).getDueDate()));
			vaRepairData.setNotificationDate(sm.format((Date)repairEndData.get(6).getNotificationDate()));
			vaRepairData.setEstimatedReceivingDate(sm.format((Date)repairEndData.get(7).getEstimatedReceivingDate()));
			if(repairEndData.get(8)!=null)
			vaRepairData.setActualReceivingDate(sm.format((Date)repairEndData.get(8).getActualReceivingDate()));
			vaRepairList.add(vaRepairData);
		}

	/*
	 * public List<RepairEnd> getRepairHotBoardData() throws CSafeServiceException {
	 * SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy");
	 * 
	 * List<VARepairData> vaRepairList = new ArrayList<>(); List<RepairEnd>
	 * repairEndData = visibilityHotBoardRepository.getRepairHotBoardData();
	 * System.out.println("repairEndData size  :   "+repairEndData.size()); for
	 * (RepairEnd re : repairEndData) { VARepairData vaRepairData = new
	 * VARepairData();
	 * vaRepairData.setSerialNumber(repairEndData.get(1).toString());
	 * vaRepairData.setStatus(repairEndData.get(2).toString());
	 * vaRepairData.setContainerLocation(repairEndData.get(3).getContainerLocation()
	 * );
	 * vaRepairData.setAlertDescription(repairEndData.get(4).getAlertDescription());
	 * vaRepairData.setAlertType(repairEndData.get(9).getAlertType());
	 * vaRepairData.setWeekNo(repairEndData.get(0).getWeekNo());
	 * vaRepairData.setDueDate(sm.format((Date)repairEndData.get(5).getDueDate()));
	 * vaRepairData.setNotificationDate(sm.format((Date)repairEndData.get(6).
	 * getNotificationDate()));
	 * vaRepairData.setEstimatedReceivingDate(sm.format((Date)repairEndData.get(7).
	 * getEstimatedReceivingDate())); if(repairEndData.get(8)!=null)
	 * vaRepairData.setActualReceivingDate(sm.format((Date)repairEndData.get(8).
	 * getActualReceivingDate())); vaRepairList.add(vaRepairData); }
	 * 
	 * return repairEndData; }
	 */

	public List<SpareParts> getSpareParts() throws CSafeServiceException {
		List<SpareParts> sparePartsList = partsRepository.findAll();
		List<SparePart> mainList = new ArrayList<SparePart>();
		populateSparePartsData(sparePartsList, mainList);
		return sparePartsList;
	}

	private void populateSparePartsData(List<SpareParts> sparePartsList, List<SparePart> mainList) {

		for (SpareParts sca : sparePartsList) {
			SparePart data = new SparePart();
			data.setPartNumber(sca.getPartNumber());
			data.setPartDesc(sca.getPartDesc());
			data.setMaxInvLevel(sca.getMaxInvLevel());
			data.setMinInvLevel(sca.getMinInvLevel());
			data.setRop(sca.getRop());
			data.setConsumedQty(sca.getConsumedQty());
			data.setActualQty(sca.getActualQty());
			data.setAlertDesc(sca.getAlertDesc());
			mainList.add(data);
		}
	}

	public List<BalanceInHandDto> getBalanceInHand() throws CSafeServiceException {

		List<BalanceInHandDto> mainList = new ArrayList<BalanceInHandDto>();
		List<Object[]> balanceInHandData = balanceInHandRepository.getBalanceInHandData();
		logger.info("BalanceInHand size  :   " + balanceInHandData.size());
		populateBalanceInHandData(balanceInHandData, mainList);
		return mainList;
	}

	private void populateBalanceInHandData(List<Object[]> balanceInHandList, List<BalanceInHandDto> mainList) {

		for (int i = 0; i < balanceInHandList.size(); i++) {
			Object obj[] = balanceInHandList.get(i);
			BalanceInHandDto data = new BalanceInHandDto();
			data.setRegion(obj[0].toString());
			data.setHubSc(obj[1].toString());
			data.setCity(obj[2].toString());
			data.setCountryName(obj[3].toString());
			data.setWeekNo(obj[4].toString());
			data.setBalanceInHand(Integer.parseInt(obj[5].toString()));
			data.setSafetyStock(Integer.parseInt(obj[6].toString()));
			data.setStatus(Integer.parseInt(obj[7].toString()));
			mainList.add(data);
		}

	}

	public List<ResolvedIssuesDto> getResolvedIssues() throws CSafeServiceException {
		List<ResolvedIssues> resolvedIssuesList = resolvedIssuesRepository.findAll();
		List<ResolvedIssuesDto> mainList = new ArrayList<ResolvedIssuesDto>();
		populateResolvedIssues(resolvedIssuesList, mainList);
		return mainList;
	}

	private void populateResolvedIssues(List<ResolvedIssues> resolvedIssuesList, List<ResolvedIssuesDto> mainList) {

		SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy");

		for (ResolvedIssues ri : resolvedIssuesList) {
			ResolvedIssuesDto data = new ResolvedIssuesDto();

			data.setSerialNumber(ri.getSerialNumber());
			data.setStatus(ri.getStatus());
			data.setOrigin(ri.getOrigin());
			data.setDestination(ri.getDestination());
			data.setAlertDescription(ri.getAlertDescription());
			data.setWeek(ri.getWeek());
			data.setDueDate(sm.format((Date) ri.getDueDate()));
			data.setNotificationDate(sm.format((Date) ri.getNotificationDate()));
			data.setEstimatedReceivingDate(sm.format((Date) ri.getEstimatedReceivingDate()));
			data.setActualReceivingDate(sm.format((Date) ri.getActualReceivingDate()));

			mainList.add(data);
		}
	}

	public Map<String, Object> getHotBoardData() throws CSafeServiceException {

		Map<String, Object> hotBoard = new LinkedHashMap<>();
		List<Object> weeksList = new ArrayList<>();
		List<Object> metrics = Arrays.asList("inbound", "outbound", "balanceInHand", "repair");

		List<HubCtLatLong> cityLatlongList = hotBoardRepository.getCityLatLongList();
		List<Object[]> weekYearList = hotBoardRepository.getFutureYearWeek();
		List<String> cities = new ArrayList<>();
		List<Float> cityLat = new ArrayList<>();
		List<Float> cityLong = new ArrayList<>();
		for (Object[] result : weekYearList) {
			 weeksList.add(result[0].toString().concat("-").concat(result[1].toString()));
		}
		Map<String, Object> inboundMap = new LinkedHashMap<>();
		Map<Object, Object> outCity = new LinkedHashMap<>();
		Map<Object, Object> inBoundCity = new LinkedHashMap<>();
		Map<Object, Object> balCity = new LinkedHashMap<>();
		Map<Object, Object> repairCity = new LinkedHashMap<>();
		Map<String, Object> balanceMap = new LinkedHashMap<>();
		Map<String, Object> repairMap = new LinkedHashMap<>();
		List<HotBoard> inboundData;
		List<HotBoard> outboundData;
		List<Object> outboundDataSet = new ArrayList<>();
		List<Object> inboundDataSet = new ArrayList<>();
		List<Object> balDataSet = new ArrayList<>();
		List<Object> repairDataSet = new ArrayList<>();
		List<BalanceHotBoard> balanceInHandData;
		List<HotBoard> repairData;
		List<String> inboundCtList = new ArrayList();
		List<String> outCtList = new ArrayList<>();
		List<String> repairCtList = new ArrayList<>();
		List<String> balCtList = new ArrayList<>();
		inboundData = inboundHotBoardRepository.getInboundData(weeksList);
		outboundData = outBoundRepository.getOutboundData(weeksList);
		balanceInHandData = balanceInHandRepository.getBalanceInHandData(weeksList);
		repairData = repairHotBoardRepository.getRepairData(weeksList);

		for (HubCtLatLong hcl : cityLatlongList) {

			for (HotBoard ib : inboundData) {
				if (hcl.getCity() != null && !hcl.getCity().isEmpty() && ib.getOrigin() != null
						&& !ib.getOrigin().isEmpty()) {
					if (hcl.getCity().matches(ib.getOrigin())) {

						Map<String, Object> inBoundMap = new LinkedHashMap<>();
						inBoundMap.put(ib.getWeekNo(), ib.getSerialNumber());
						inboundDataSet.add(ib.getOrigin());
						inboundDataSet.add(hcl.getLongitude());
						inboundDataSet.add(hcl.getLatitude());
						inboundDataSet.add(inBoundMap);

					}
				}
			}
			for (HotBoard ib : outboundData) {
				if (hcl.getCity() != null && !hcl.getCity().isEmpty() && ib.getOrigin() != null
						&& !ib.getOrigin().isEmpty()) {
					if (hcl.getCity().matches(ib.getOrigin())) {
						Map<String, Object> outBoundMap = new LinkedHashMap<>();
						outBoundMap.put(ib.getWeekNo(), ib.getSerialNumber());
						outboundDataSet.add(ib.getOrigin());
						outboundDataSet.add(outBoundMap);

					}
				}
			}
			for (BalanceHotBoard ib : balanceInHandData) {
				if (hcl.getCity() != null && !hcl.getCity().isEmpty() && ib.getAccountName() != null
						&& !ib.getAccountName().isEmpty()) {
					if (hcl.getCity().matches(ib.getAccountName())) {
						Map<String, Object> balInHandMap = new LinkedHashMap<>();
						balInHandMap.put(ib.getWeekNo(), ib.getBalanceInHand());
						balDataSet.add(ib.getAccountName());
						balDataSet.add(balInHandMap);
						// balanceMap.put(ib.getWeekNo(), ib.getBalanceInHand());
						if (ib.getSafetyStock() != null && ib.getRop() != null) {
							if (ib.getBalanceInHand() < ib.getSafetyStock()) {
								balanceMap.put("color", "RED");
							} else if (ib.getBalanceInHand() > ib.getRop()) {
								balanceMap.put("color", "GREEN");
							} else if ((ib.getBalanceInHand() > ib.getSafetyStock())
									&& (ib.getBalanceInHand() > ib.getRop())) {
								balanceMap.put("color", "YELLOW");
							}
						}

					}
				}
			}
			for (HotBoard ib : repairData) {

				if (hcl.getCity() != null && !hcl.getCity().isEmpty() && ib.getOrigin() != null
						&& !ib.getOrigin().isEmpty()) {
					if (hcl.getCity().matches(ib.getOrigin())) {
						Map<String, Object> repairendMap = new LinkedHashMap<>();
						repairendMap.put(ib.getWeekNo(), ib.getSerialNumber());
						repairDataSet.add(ib.getOrigin());
						repairDataSet.add(repairendMap);
					}
				}
			}
		}
		for (HubCtLatLong hsl : cityLatlongList) {
			cities.add(hsl.getCity());
			cityLat.add(hsl.getLatitude());
			cityLong.add(hsl.getLongitude());

		}
		hotBoard.put("metrics", metrics);
		hotBoard.put("weeks", weeksList);
		hotBoard.put("city", cities);
		hotBoard.put("latitude", cityLat);
		hotBoard.put("longitude", cityLong);
		hotBoard.put("inbound", inboundDataSet);                           // or this format
		// hotBoard.put("inBoundCity", inboundCtList);
		hotBoard.put("outBound", outboundDataSet);
		// hotBoard.put("outBoundCity", outCtList);
		// hotBoard.put("balanceInHand", balanceMap);
		hotBoard.put("balanceInHand", balanceInHandData);
		hotBoard.put("repair", repairData);                                        // this format 
		// hotBoard.put("repairCity", repairCtList);

		return hotBoard;

	}

	public Map<String, Object> getLeaseEndDetails(String serialNumber) throws CSafeServiceException {

		SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy");

		Map<String, Object> leaseEndMap = new LinkedHashMap<>();
		Map<String, Object> orderDetails = new LinkedHashMap<>();
		Map<String, Object> transportationDetails = new LinkedHashMap<>();
		List<Object[]> ler = hotBoardAnalyseRepository.getLeaseEndDrillDownData(serialNumber);

		for (Object obj[] : ler) {
			for (int i = 0; i < obj.length; i++) {
				orderDetails.put("OrderNo", obj[0]);
				orderDetails.put("OrderStatus", obj[1]);
				orderDetails.put("Consignor", obj[2]);
				orderDetails.put("Origin", obj[3]);
				orderDetails.put("SerialNumber", obj[4]);
				orderDetails.put("DueDate", sm.format((Date) obj[5]));
				orderDetails.put("OrderValue", obj[6]);
				orderDetails.put("Currency", obj[7]);
				orderDetails.put("Consignee", obj[8]);
				orderDetails.put("Destination", obj[9]);
				orderDetails.put("NotificationDate", sm.format((Date) obj[10]));
				orderDetails.put("RDD", sm.format((Date) obj[11]));

				if (i > 11) {
					transportationDetails.put("AWBNO", obj[14]);
					transportationDetails.put("Mode", obj[15]);
					transportationDetails.put("Carrier", obj[16]);
					transportationDetails.put("Weight", obj[17]);
					transportationDetails.put("UOM", obj[19]);
					transportationDetails.put("ScheduleDelivery", sm.format((Date) obj[12]));
					transportationDetails.put("ActualDelivery", sm.format((Date) obj[20]));
					transportationDetails.put("ShippingId", obj[13]);
					transportationDetails.put("TripName", obj[18]);
				}

			}
			leaseEndMap.put("orderDetails", orderDetails);
			leaseEndMap.put("transportationDetails", transportationDetails);

		}
		return leaseEndMap;
	}

	public Map<String, Object> getRepositioningData(String serialNumber) throws CSafeServiceException {

		SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy");
		Map<String, Object> orderDetails = new LinkedHashMap<>();

		List<Object[]> repositionData = hotBoardAnalyseRepository.getRepositioningData(serialNumber);

		for (Object obj[] : repositionData) {
			for (int i = 0; i < obj.length; i++) {
				orderDetails.put("SerialNumber", obj[5]);
				orderDetails.put("Mode", obj[0]);
				orderDetails.put("Carrier", obj[1]);
				orderDetails.put("scheduleDelivery", sm.format((Date) obj[2]));
				orderDetails.put("ShippingId", obj[3]);
				orderDetails.put("TripName", obj[4]);
				orderDetails.put("Weight", obj[6]);

			}

		}
		return orderDetails;
	}

	public List<RepairEndData> getRepairEndData(String serialNumber) throws CSafeServiceException {

		List<RepairEndData> repairEndData = repairHotBoardRepository.getRepairEndData(serialNumber);

		return repairEndData;
	}

	public Map<String, Object> getVisibilityHotBoardFilter(String visibilityType,Date startDate,Date endDate) {

		Map<String, Object> filter = new LinkedHashMap<>();
		Set<Object> visibilityStatus = new LinkedHashSet<>();
		Set<Object> origin = new LinkedHashSet<>();

		List<Object[]> inboundFilterData = visibilityHotBoardRepository.getVisibilityHotBoardFilter(visibilityType,startDate,endDate);
		if (visibilityType != null && visibilityType.equalsIgnoreCase("InboundHotBoard")
				|| visibilityType.equalsIgnoreCase("BalanceInHand")
				|| visibilityType.equalsIgnoreCase("ResolvedIssues")) {
			for (Object obj[] : inboundFilterData) {
				visibilityStatus.add(obj[0]);
				origin.add(obj[1]);
			}

			if (visibilityStatus != null) {
				filter.put("statusNDesc", visibilityStatus);
			}
			if (origin != null) {
				filter.put("origin", origin);
			}
			filter.put("weekYear", getWeekYearData());

		} else if (visibilityType.equalsIgnoreCase("LeaseEndHotBoard")) {

			filter.put("origin", inboundFilterData);
			filter.put("weekYear", getWeekYearData());
		} else if (visibilityType.equalsIgnoreCase("Repair")) {

			filter.put("alertDescription", inboundFilterData);
			filter.put("weekYear", getWeekYearData());
		}
		return filter;
	}
// for repair hotboard and analyse data 
	//RepairEnd analyze also
	public List<RepairEndData> getRepairEndAnalyseData(String serialNumber, String alertDesc) {

		List<RepairEndData> repairEndAnalyseData = visibilityHotBoardRepository.getRepairEndAnalyseData(serialNumber,
				alertDesc);
		return repairEndAnalyseData;
	}

	private Set<Object> getWeekYearData() {

		Set<Object> yearWeek = new LinkedHashSet<>();
		List<Object[]> weekYearData = visibilityHotBoardRepository.getFutureYearWeeks();
		for (Object obj[] : weekYearData) {
			yearWeek.add(obj[0]);
		}
		return yearWeek;
	}

}
