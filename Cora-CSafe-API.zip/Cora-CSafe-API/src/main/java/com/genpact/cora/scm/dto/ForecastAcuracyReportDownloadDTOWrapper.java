package com.genpact.cora.scm.dto;

import java.util.List;

public class ForecastAcuracyReportDownloadDTOWrapper {

	private List<String> monthMetaData;
	private String type;
	private List<ForecastAcuracyReportDownloadDTO> downloadData;
	
	public List<String> getMonthMetaData() {
		return monthMetaData;
	}
	public void setMonthMetaData(List<String> monthMetaData) {
		this.monthMetaData = monthMetaData;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<ForecastAcuracyReportDownloadDTO> getDownloadData() {
		return downloadData;
	}
	public void setDownloadData(List<ForecastAcuracyReportDownloadDTO> downloadData) {
		this.downloadData = downloadData;
	}
}
