package com.genpact.cora.scm.pojo;

public class ModelParameters {
	
	private int Historic;

    private int Forecast;

    private int Period;

    private int Weight;

    private int Alpha;

    private int Beta;

	public int getHistoric() {
		return Historic;
	}

	public void setHistoric(int historic) {
		Historic = historic;
	}

	public int getForecast() {
		return Forecast;
	}

	public void setForecast(int forecast) {
		Forecast = forecast;
	}

	public int getPeriod() {
		return Period;
	}

	public void setPeriod(int period) {
		Period = period;
	}

	public int getWeight() {
		return Weight;
	}

	public void setWeight(int weight) {
		Weight = weight;
	}

	public int getAlpha() {
		return Alpha;
	}

	public void setAlpha(int alpha) {
		Alpha = alpha;
	}

	public int getBeta() {
		return Beta;
	}

	public void setBeta(int beta) {
		Beta = beta;
	}

}
