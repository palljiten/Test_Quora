/**
 * 
 */
package com.genpact.cora.scm.dto;

/**
 * @author 703158077
 *
 */
public class SupplyCockpitStokPolicyDto {

	private Integer compliant;
	private Integer nonCompliant;
	private Integer total;
	private Integer compliantPercent;
	private Integer nonCompliantPercent;
	
	
	/**
	 * @return the compliant
	 */
	public Integer getCompliant() {
		return compliant;
	}
	/**
	 * @param compliant the compliant to set
	 */
	public void setCompliant(Integer compliant) {
		this.compliant = compliant;
	}
	/**
	 * @return the nonCompliant
	 */
	public Integer getNonCompliant() {
		return nonCompliant;
	}
	/**
	 * @param nonCompliant the nonCompliant to set
	 */
	public void setNonCompliant(Integer nonCompliant) {
		this.nonCompliant = nonCompliant;
	}
	/**
	 * @return the total
	 */
	public Integer getTotal() {
		return total;
	}
	/**
	 * @param total the total to set
	 */
	public void setTotal(Integer total) {
		this.total = total;
	}
	/**
	 * @return the compliantPercent
	 */
	public Integer getCompliantPercent() {
		return compliantPercent;
	}
	/**
	 * @param compliantPercent the compliantPercent to set
	 */
	public void setCompliantPercent(Integer compliantPercent) {
		this.compliantPercent = compliantPercent;
	}
	/**
	 * @return the nonCompliantPercent
	 */
	public Integer getNonCompliantPercent() {
		return nonCompliantPercent;
	}
	/**
	 * @param nonCompliantPercent the nonCompliantPercent to set
	 */
	public void setNonCompliantPercent(Integer nonCompliantPercent) {
		this.nonCompliantPercent = nonCompliantPercent;
	}
	
	
}
