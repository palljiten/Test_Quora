/**
 * 
 */
package com.genpact.cora.scm.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.ActivityDto;
import com.genpact.cora.scm.dto.CloseAlertRequest;
import com.genpact.cora.scm.dto.DemandCockpitCharts;
import com.genpact.cora.scm.dto.DemandCockpitExceptionsAlerts;
import com.genpact.cora.scm.dto.DemandCockpitExceptionsReportDownloadData;
import com.genpact.cora.scm.dto.ForecastAccuracyChartDTO;
import com.genpact.cora.scm.dto.ForecastAccuracyHubMetricsDTOWrapper;
import com.genpact.cora.scm.dto.ForecastAccuracyMetricsDTO;
import com.genpact.cora.scm.dto.ForecastAccuracyMetricsSixMonthsDTO;
import com.genpact.cora.scm.dto.ForecastAccuracyPercentageDTO;
import com.genpact.cora.scm.dto.ForecastAccuracyRegionMetricsDTO;
import com.genpact.cora.scm.dto.ForecastAccuracyRegionMetricsDTOWrapper;
import com.genpact.cora.scm.dto.ForecastAcuracyReportDownloadDTOWrapper;
import com.genpact.cora.scm.dto.ForecastWaterfallContainer;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.CountryRepository;
import com.genpact.cora.scm.repository.GenericSPCaller;
import com.genpact.cora.scm.service.DemandCockpitService;
import com.genpact.cora.scm.util.DemandCockpitConstants;
import com.genpact.cora.scm.validation.ContainerSparesTypeEnum;
import com.genpact.cora.scm.validation.ValidMonthYear;

@RestController
@RequestMapping(value = "/scm/demandCockpit")
@Api(tags = { "Demand Cockpit" })
public class DemandCockpitController {

	public static Logger logger = LoggerFactory.getLogger(DemandCockpitController.class);

	@Autowired
	DemandCockpitService demandCockpitService;

	@Autowired
	GenericSPCaller genericSPCaller;

	@Autowired
	CountryRepository countryRepo;

	@GetMapping(value = "/activity/review/chart", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Activity Review Chart")
	public ResponseEntity<ActivityDto> getActivityChart() {
		ActivityDto activityDto;
		try {
			activityDto = genericSPCaller.callActivityChartSP();
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during fetiching data for activity chart", csse.getCause());
		}
		return new ResponseEntity<ActivityDto>(activityDto, HttpStatus.OK);
	}

	@GetMapping(value = "/exceptions/review", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Activity Review Chart")
	public ResponseEntity<Map<String, Object>> getExceptionsReview(
			@Valid @RequestParam("type") ContainerSparesTypeEnum type) {
		Map<String, Object> map = new HashMap<>();
		try {
			map = genericSPCaller.callReportSummaryDataSP(type.getValue());
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during fetiching data for exceptions review summary",
					csse.getCause());
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@GetMapping(value = "/exceptions/charts", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Exception")
	public ResponseEntity<DemandCockpitCharts> getForeCastExceptionRules(
			@Valid @RequestParam("type") ContainerSparesTypeEnum type) {
		DemandCockpitCharts charts = new DemandCockpitCharts();
		try {
			charts = genericSPCaller.callExceptionChartSP(type.getValue());
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during retrieving exceptions chart data...",
					csse.getCause());
		}

		return new ResponseEntity<DemandCockpitCharts>(charts, HttpStatus.OK);
	}

	@GetMapping(value = "/exceptions/alerts", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Exception")
	public ResponseEntity<?> getForeCastExceptionAlerts(@Valid @RequestParam("type") ContainerSparesTypeEnum type,
			@RequestParam("regionId") int regionId, @RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId, @RequestParam(value = "partId", required = false) String partId) {
		Map<String, List<DemandCockpitExceptionsAlerts>> data = new HashMap<>();
		DemandCockpitExceptionsAlerts alerts = new DemandCockpitExceptionsAlerts();
		try {
			if (type.getValue().equals(DemandCockpitConstants.SPARES_TYPE)) {
				if (partId == null || partId.equals("")) {
					throw new CSafeApiException("Please provide 'partId' in query string");
				}
			}

			data = genericSPCaller.callExceptionAlertsSP(type.getValue(), regionId, countryId, hubId, partId);
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during retrieving exceptions alerts data...",
					csse.getCause());
		} catch (CSafeApiException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			csse.setStatus(HttpStatus.BAD_REQUEST);
			throw csse;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@GetMapping(value = "/exceptions/report", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Exception")
	public ResponseEntity<?> getForeCastExceptionReport(@Valid @RequestParam("type") ContainerSparesTypeEnum type,
			@RequestParam("regionId") int regionId, @RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId, @RequestParam(value = "partId", required = false) String partId) {
		DemandCockpitExceptionsAlerts report = new DemandCockpitExceptionsAlerts();
		try {
			report = genericSPCaller.callExceptionReportSP(type.getValue(), regionId, countryId, hubId, partId);
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during retrieving exceptions report data...",
					csse.getCause());
		}
		return new ResponseEntity<>(report, HttpStatus.OK);
	}

	@GetMapping(value = "/exceptions/report/download", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Exception")
	public ResponseEntity<DemandCockpitExceptionsReportDownloadData> getForeCastExceptionReportDownloadData(
			@Valid @RequestParam("type") ContainerSparesTypeEnum type) {
		DemandCockpitExceptionsReportDownloadData reportData = new DemandCockpitExceptionsReportDownloadData();
		try {
			reportData = genericSPCaller.callExceptionReportDataSP(type.getValue());
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during retrieving exceptions report download data...",
					csse.getCause());
		}
		return new ResponseEntity<DemandCockpitExceptionsReportDownloadData>(reportData, HttpStatus.OK);
	}

	@PostMapping(value = "/exceptions/alerts/close", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Exception")
	public ResponseEntity<?> closeAlerts(@Valid @RequestParam("type") ContainerSparesTypeEnum type,
			@RequestParam(value = "partNumber", required = false) String partNumber,
			@Valid @RequestBody CloseAlertRequest request) {
		try {
			if (type.getValue().equals(DemandCockpitConstants.SPARES_TYPE)) {
				if (partNumber == null || partNumber.equals("")) {
					throw new CSafeApiException("Please provide 'partNumber' in query string");
				}
			}
			genericSPCaller.callCloseAlertSP(type.getValue(), partNumber, request);
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during alerts closing...", csse.getCause());
		} catch (CSafeApiException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			csse.setStatus(HttpStatus.BAD_REQUEST);
			throw csse;
		} catch (Exception e) {
			e.printStackTrace();
			throw new CSafeApiException("API error occured during alerts closing...", e);
		}

		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("ContainerForecastStatisticalController: Exiting getForecastModels() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}

	@GetMapping(value = "/forecastAccuracy/chart", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Accuracy")
	public ResponseEntity<ForecastAccuracyChartDTO> getForecastAccuracy(
			@Valid @RequestParam("type") ContainerSparesTypeEnum type) {
		ForecastAccuracyChartDTO forecastAccuracyChartDTO;
		try {
			forecastAccuracyChartDTO = demandCockpitService.getForecastAccuracyChart(type.getValue());
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> accuracy graph API.",
					csse.getCause());
		}
		return new ResponseEntity<ForecastAccuracyChartDTO>(forecastAccuracyChartDTO, HttpStatus.OK);
	}

	@GetMapping(value = "/forecastAccuracy/percentage", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Accuracy")
	public ResponseEntity<ForecastAccuracyPercentageDTO> getForecastAccuracyPercentage(
			@Valid @RequestParam("type") ContainerSparesTypeEnum type, @RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam(value = "partId", required = false) String partId) {
		if (type.getValue().equals(DemandCockpitConstants.SPARES_TYPE)) {
			if (partId == null || partId.equals("")) {
				throw new CSafeApiException("Please provide 'partId' in query string");
			}
		}
		ForecastAccuracyPercentageDTO forecastAccuracyPercentageDTO = new ForecastAccuracyPercentageDTO();
		try {
			forecastAccuracyPercentageDTO = demandCockpitService.getForecastAccuracyPercentage(type.getValue(),
					regionId, countryId, hubId, partId);
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> accuracy graph API.",
					csse.getCause());
		}
		return new ResponseEntity<ForecastAccuracyPercentageDTO>(forecastAccuracyPercentageDTO, HttpStatus.OK);
	}

	@GetMapping(value = "/forecastAccuracy/metrics", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Accuracy")
	public ResponseEntity<?> getForecastAccuracyMetrics(
			@Valid @RequestParam("type") ContainerSparesTypeEnum type, @RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam(value = "partId", required = false) String partId,
			@RequestParam(value = "monthYear", required = false) String monthYear) {
		if (type.getValue().equals(DemandCockpitConstants.SPARES_TYPE)) {
			if (partId == null || partId.equals("")) {
				throw new CSafeApiException("Please provide 'partId' in query string");
			}
		}

		if (monthYear != null && !monthYear.isEmpty() && !monthYear.matches("^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\-\\d{4}$")) {
			throw new CSafeApiException("MonthYear is not valid. It should follow MMM-yyyy pattern.");
		}

		ForecastAccuracyMetricsDTO forecastAccuracyMetricsDTO = new ForecastAccuracyMetricsDTO();
		ForecastAccuracyMetricsSixMonthsDTO sixMonthData = new ForecastAccuracyMetricsSixMonthsDTO();
		try {
			if (monthYear != null && !monthYear.isEmpty()) {
				forecastAccuracyMetricsDTO = demandCockpitService.getForecastAccuracyMetrics(type.getValue(), regionId,
						countryId, hubId, partId, monthYear);
			} else {
				System.out.println("\n\n monthYear = " + monthYear + "\n\n");
				sixMonthData = demandCockpitService.getForecastAccuracyMetricsForSixMonths(type.getValue(), regionId, countryId, hubId, partId);
			}
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> accuracy graph API.",
					csse.getCause());
		}
		if (monthYear == null) {
			return new ResponseEntity<>(sixMonthData, HttpStatus.OK);
		}
		return new ResponseEntity<>(forecastAccuracyMetricsDTO, HttpStatus.OK);
	}

	@GetMapping(value = "/forecastAccuracy/metrics/regions", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Accuracy")
	public ResponseEntity<ForecastAccuracyRegionMetricsDTOWrapper> getForecastAccuracyRegionMetrics(
			@Valid @RequestParam("type") ContainerSparesTypeEnum type, @RequestParam(value = "monthYear") String monthYear) {
		ForecastAccuracyRegionMetricsDTOWrapper wrapper;
		if (monthYear != null && !monthYear.isEmpty() && !monthYear.matches("^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\-\\d{4}$")) {
			throw new CSafeApiException("MonthYear is not valid. It should follow MMM-yyyy pattern.");
		}
		try {
			wrapper = genericSPCaller.callForecastAccuracyRegionMetricsSP(type.getValue(), monthYear);
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> accuracy graph API.",
					csse.getCause());
		}
		return new ResponseEntity<ForecastAccuracyRegionMetricsDTOWrapper>(wrapper, HttpStatus.OK);
	}

	@GetMapping(value = "/forecastAccuracy/metrics/hubs", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Accuracy")
	public ResponseEntity<ForecastAccuracyHubMetricsDTOWrapper> getForecastAccuracyRegionMetrics(
			@Valid @RequestParam("type") ContainerSparesTypeEnum type, @RequestParam(value = "regionId") int regionId,
			@RequestParam(value = "monthYear") String monthYear) {
		ForecastAccuracyHubMetricsDTOWrapper wrapper;
		if (monthYear != null && !monthYear.isEmpty() && !monthYear.matches("^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\-\\d{4}$")) {
			throw new CSafeApiException("MonthYear is not valid. It should follow MMM-yyyy pattern.");
		}
		try {
			wrapper = genericSPCaller.callForecastAccuracyHubMetricsSP(type.getValue(), regionId, monthYear);
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> accuracy graph API.",
					csse.getCause());
		}
		return new ResponseEntity<ForecastAccuracyHubMetricsDTOWrapper>(wrapper, HttpStatus.OK);
	}
	
	@GetMapping(value = "/forecastAccuracy/report/download", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Demand Cockpit Accuracy")
	public ResponseEntity<ForecastAcuracyReportDownloadDTOWrapper> getForecastAccuracyReportDownloadData(
			@Valid @RequestParam("type") ContainerSparesTypeEnum type) {
		ForecastAcuracyReportDownloadDTOWrapper wrapper;

		try {
			wrapper = genericSPCaller.callForecastAccuracyReportDownloadSP(type.getValue());
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> accuracy graph API.",
					csse.getCause());
		}
		return new ResponseEntity<ForecastAcuracyReportDownloadDTOWrapper>(wrapper, HttpStatus.OK);
	}
	
	@GetMapping(value = "/forecastWaterfall", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Demand Cockpit ForecastWaterfallContainer")
	public ResponseEntity<ForecastWaterfallContainer> getForeCastWaterfallContainer() {
		ForecastWaterfallContainer forecastWFContainer;
		try {
			forecastWFContainer = demandCockpitService.getForeCastWaterfallContainer();
		} catch (CSafeServiceException csse) {
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException(
					"API error occured during get data for demand cockpit >> WaterfallContainer API.", csse.getCause());
		}
		return new ResponseEntity<ForecastWaterfallContainer>(forecastWFContainer, HttpStatus.OK);
	}

}
