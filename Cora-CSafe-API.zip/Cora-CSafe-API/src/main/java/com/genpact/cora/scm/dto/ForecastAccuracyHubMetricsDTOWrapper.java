package com.genpact.cora.scm.dto;

import java.util.List;
import java.util.Map;

public class ForecastAccuracyHubMetricsDTOWrapper {

	private List<String> hubMetaData; //�: [�BOS�, �MIA�, �PHL�, �RDU�, �ATL�]
	private int regionId;
	private String monthYear;
	private String type;
	private Map<String, ForecastAccuracyHubMetricsDTO> hubMap;
	
	public List<String> getHubMetaData() {
		return hubMetaData;
	}
	public void setHubMetaData(List<String> hubMetaData) {
		this.hubMetaData = hubMetaData;
	}
	public int getRegionId() {
		return regionId;
	}
	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}
	public String getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Map<String, ForecastAccuracyHubMetricsDTO> getHubMap() {
		return hubMap;
	}
	public void setHubMap(Map<String, ForecastAccuracyHubMetricsDTO> hubMap) {
		this.hubMap = hubMap;
	}
	
	
}
