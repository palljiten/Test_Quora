package com.genpact.cora.scm.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.FieldDetails;
import com.genpact.cora.scm.dto.HubDetails;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.HubService;
import com.genpact.cora.scm.service.RepairWorkOrderPartsService;
import com.genpact.cora.scm.util.CommonLogic;

import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping(value = "/scm")
public class SparesForecastCommonController {

	@Autowired
	private ServletContext servletContext;
	
	@Autowired
	HubService hubService;

	@Autowired
	RepairWorkOrderPartsService partsService;

	private static Logger logger = LoggerFactory.getLogger(SparesForecastStatisticalController.class);

	@GetMapping(value = "/fields", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves fields - countries, regions, HubSc, parts")
	public ResponseEntity<Object> getFields() {
		System.out.println("\n\n\n");
		long startTime1 = System.currentTimeMillis();
		Object cachedFields = servletContext.getAttribute("fields");
		if (cachedFields != null) {
			System.out.println("Cached fields: " + servletContext.getAttribute("fields"));
			long endTime = System.currentTimeMillis();
			System.out.println("Time taken to return cached fields: " + (endTime - startTime1));
			System.out.println("\n\n\n");
			return new ResponseEntity<>(cachedFields, HttpStatus.OK);
		}

		FieldDetails fields;
		try {
			Map<String, HubDetails> scMap = new HashMap<>();
			long startTime = System.currentTimeMillis();
			fields = CommonLogic.createFieldMap(hubService.getAllHubs(), scMap);
			long endTime = System.currentTimeMillis();
			System.out.println("\n\n\n\nTime taken by hubService.getAllHubs() = " + (System.currentTimeMillis() - startTime));
			partsService.getAllPartNumbers(scMap);
			System.out.println("Time taken by partsService.getAllPartNumbers(scMap) = " + (System.currentTimeMillis() - endTime) + "\n\n\n\n");
			// fields.setPartDetails(partsService.getAllPartNumbers(scMap));
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getFields in SparesForecastCommonController",
					e.getCause());
		}
		return new ResponseEntity<>(fields, HttpStatus.OK);
	}
}
