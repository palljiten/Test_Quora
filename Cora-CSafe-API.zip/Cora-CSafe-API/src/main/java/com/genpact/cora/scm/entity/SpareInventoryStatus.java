/**
 * 
 */
package com.genpact.cora.scm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author 703158077
 *
 */
@Entity
@Table(name="tbl_IMInventoryStatusSpares")
public class SpareInventoryStatus implements Serializable {
	
	private static final long serialVersionUID = 9876543217L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	private Integer id;
	
	@Column(name="PartNumber")
	private String partNumber;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="HubID")
	private HubSc hub;
	
	@Column(name="InventoryQty")
	private Integer InventoryQty;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "RegionID")
	private Region region;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "CountryID")
	private Country country;
	
	
	
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the hub
	 */
	public HubSc getHub() {
		return hub;
	}
	/**
	 * @param hub the hub to set
	 */
	public void setHub(HubSc hub) {
		this.hub = hub;
	}
	/**
	 * @return the region
	 */
	public Region getRegion() {
		return region;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(Region region) {
		this.region = region;
	}
	/**
	 * @return the country
	 */
	public Country getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(Country country) {
		this.country = country;
	}
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
		
	/**
	 * @return the inventoryQty
	 */
	public Integer getInventoryQty() {
		return InventoryQty;
	}
	/**
	 * @param inventoryQty the inventoryQty to set
	 */
	public void setInventoryQty(Integer inventoryQty) {
		InventoryQty = inventoryQty;
	}
	
	

}
