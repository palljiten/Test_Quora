package com.genpact.cora.scm.repository;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Repository
@EnableTransactionManagement
public class DemandAllocationSPRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Transactional
	public void callSP(String inParam) {

		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("DemandAllocationForecastSP");
			simpleJdbcCall.declareParameters(new SqlParameter("InpParam", Types.VARCHAR));
			MapSqlParameterSource paramMap = new MapSqlParameterSource().addValue("InpParam", inParam);
			System.out.println("\n\n\n Stored Procedure is being called with input parameter....");
			System.out.println(inParam);
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(paramMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
