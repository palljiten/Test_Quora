package com.genpact.cora.scm.controller;


import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.InventoryPCCSubmitDto;
import com.genpact.cora.scm.dto.InventoryPlanningContainersDto;
import com.genpact.cora.scm.dto.InventoryPlanningSpareDto;
import com.genpact.cora.scm.dto.InventoryPlanningSparesConfigDto;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.InventoryPlanningService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value="/scm")
@Api(tags= {"Inventory Mangement - Inventory Planning"})
public class InventoryPlanningController {

	private static Logger logger=LoggerFactory.getLogger(InventoryPlanningController.class);
	
	@Autowired
	InventoryPlanningService inventoryPlanningService;
	
	
	
	/**
	 * @return
	 * To find Inventory Planning Container data.
	 */
	@GetMapping(value="/inventoryManagement/inventoryPlaningContainers",produces=MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves all containers data from  inventory planned")
	public ResponseEntity<List<InventoryPlanningContainersDto>> getContainersInventoryPlanned(@RequestParam("regionId") int regionId,@RequestParam("countryId") int countryId,@RequestParam("hubId") int hubId){
		logger.info("CONTROLLER: InventoryPlanningController: Entering getContainersInventoryPlanned() method");
		List<InventoryPlanningContainersDto> invtPlanningContainersDto;
		try {
			invtPlanningContainersDto = inventoryPlanningService.getContainersInventoryPlanned(regionId,countryId,hubId);
		}
		catch(CSafeServiceException e){
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching containers inventory planned data", e.getCause());
		}
		logger.info("CONTROLLER: InventoryPlanningController: Exiting getContainersInventoryPlanned() method");
		return new ResponseEntity<>(invtPlanningContainersDto, HttpStatus.OK);
	}
	
	
	/**
	 * @return
	 * To find Inventory Planning Spares data.
	 */
	@GetMapping(value="/inventoryManagement/inventoryPlaningSpares",produces=MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves all spares inventory planned data")
	public ResponseEntity<List<InventoryPlanningSpareDto>> getSparesInventoryPlan(@RequestParam("regionId") int regionId,@RequestParam("countryId") int countryId,@RequestParam("hubId") int hubId, @RequestParam("partNumber")String partNumber){
		
		logger.info("CONTROLLER: InventoryPlanningController: Entering getSparesInventoryPlan() method");
		
		List<InventoryPlanningSpareDto> inventoryPlanningSpareDto;
		try {
			inventoryPlanningSpareDto=inventoryPlanningService.getSparesInventoryPlan(regionId,countryId,hubId,partNumber);
		}catch(CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching spares inventory plan data", e.getCause());
		}
		logger.info("CONTROLLER: InventoryPlanningController: Exiting getSparesInventoryPlanned() method");
		
		return new ResponseEntity<>(inventoryPlanningSpareDto,HttpStatus.OK);
	}

	/**
	 * @param configParam
	 * @return
	 */
	@GetMapping(value="/inventoryManagement/inventoryPlaningContainerConfig", produces= MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Inventory management planning Container Configured data")
	public ResponseEntity<Map<String, String>> getConfiguredContainerInventoryPlan(@RequestParam Integer hubId){
		
		logger.info("CONTROLLER: InventoryPlanningController: Entering getConfiguredContainerInventoryPlan() method");
		Map<String, String> configMapData=null;
		try {
			configMapData=inventoryPlanningService.getConfiguredCIPByHubId(hubId);
		}
		catch(CSafeServiceException e){
			
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching containers inventory planned data", e.getCause());
		}
		
		logger.info("CONTROLLER: InventoryPlanningController: Exiting getConfiguredContainerInventoryPlan() method");
		return new ResponseEntity<>(configMapData, HttpStatus.OK);
	}
	
	/**
	 * @param inventoryPCCSubmitDto
	 * @return
	 */
	@PostMapping(value="/inventoryManagement/IPCConfig", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Updating Inventory management planning Container Configured data")
	public ResponseEntity<Object> updateCCInventoryPlan(@Valid @RequestBody Map<String, String> json ){
		
		InventoryPCCSubmitDto inventoryPCCSubmitDto = new InventoryPCCSubmitDto();
		inventoryPCCSubmitDto.setHubId(Integer.parseInt(json.get("hubId")));
		inventoryPCCSubmitDto.setServiceLevel(json.get("serviceLevel"));
		inventoryPCCSubmitDto.setSKURequired(json.get("sKURequired"));
		inventoryPCCSubmitDto.setLeadTime(json.get("leadTime"));
		inventoryPCCSubmitDto.setSafetyRequired(json.get("safetyRequired"));
		
		SuccessResponse sr;
		logger.info("Entring into updateCCInventoryPlan() method.");
		sr = inventoryPlanningService.updateCCInventoryPlan(inventoryPCCSubmitDto);
		logger.info("InventoryPlanningController: updateCCInventoryPlan() method");
		return new ResponseEntity<>(sr, HttpStatus.OK);
	}
	
	/*
	@GetMapping(value="/inventoryManagement/configuredSpareInventoryPlan")
	@ApiOperation(value = "Retrieves Configured spares inventory planned data")
	public ResponseEntity<List<InventoryPlanningSpareDto>> getConfiguredSparesInventoryPlan(){
		
		logger.info("CONTROLLER: InventoryPlanningController: Entering getConfiguredSparesInventoryPlan() method");
		
		List<InventoryPlanningSpareDto> spareInventoryPlan=null;
		
		try {
			
			spareInventoryPlan=inventoryPlanningService.getConfiguredSparesInventoryPlan();
			
		}catch(CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching spares inventory plan data", e.getCause());
		}
		
		logger.info("CONTROLLER: InventoryPlanningController: Exiting getConfiguredSparesInventoryPlan() method");
		
		return new ResponseEntity<>(spareInventoryPlan,HttpStatus.OK);
		
	}
	*/
	@GetMapping(value="/inventoryManagement/inventoryPlaningSparesConfig", produces= MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves inventory management palnning spares config data")
	public ResponseEntity<Map<String, String>> getContainerInventoryPlanSparesConfig(@RequestParam("regionId") int regionId,@RequestParam("countryId") int countryId,@RequestParam("hubId") int hubId,@RequestParam String partNumber){
		
		logger.info("CONTROLLER: InventoryPlanningController: Entering getConfiguredContainerInventoryPlan() method");
		Map<String, String> configMapData=null;
		try {
			configMapData=inventoryPlanningService.getConfiguredCIMSByPartNumber(regionId,countryId,hubId,partNumber);
		}
		catch(CSafeServiceException e){
			
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching containers inventory planned data", e.getCause());
		}
		
		logger.info("CONTROLLER: InventoryPlanningController: Exiting getConfiguredContainerInventoryPlan() method");
		return new ResponseEntity<>(configMapData, HttpStatus.OK);
	}
	
	
	@PostMapping(value="/inventoryManagement/IMPSConfig", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Updating Inventory management planning spares configured data")
	public ResponseEntity<Object> IMPSConfig(@Valid @RequestBody InventoryPlanningSparesConfigDto ipsDtoRequest ){
		SuccessResponse sr;
		logger.info("Entring into updateCCInventoryPlan() method.");
		sr = inventoryPlanningService.updateIMPSConfig(ipsDtoRequest);
		//System.out.println("UPDATE spares config data :-"+ipsDtoRequest.getPartNumber()+" "+ipsDtoRequest.getSafetyRequired()+" "+ipsDtoRequest.getHubId());
		
		logger.info("InventoryPlanningController: updateCCInventoryPlan() method");
		return new ResponseEntity<>(sr, HttpStatus.OK);
	}
	
	
}
