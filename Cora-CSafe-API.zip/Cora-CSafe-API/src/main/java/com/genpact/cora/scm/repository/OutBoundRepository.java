package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.HotBoard;
import com.genpact.cora.scm.entity.VAOutBound;

public interface OutBoundRepository extends JpaRepository<VAOutBound, Integer>{
	
	@Query(value ="SELECT new com.genpact.cora.scm.dto.HotBoard(vo.weekNo,count(vo.serialNumber),hs.city) FROM VAOutBound vo INNER JOIN HubSc hs on hs.accountName = vo.location where vo.weekNo in (:weeksList) group by vo.weekNo,hs.city")
	public List<HotBoard> getOutboundData(@Param("weeksList") List<Object> weeksList); 

}
