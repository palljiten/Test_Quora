package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.genpact.cora.scm.dto.TempModelOutput;

@Entity
@Table(name = "[dbo].[tbl_master_StatisticalModel]")
@SqlResultSetMapping(
        name = "TempModelOutputMapping",
        classes = @ConstructorResult(
                targetClass = TempModelOutput.class,
                columns = {
                    @ColumnResult(name = "modelId"),
                    @ColumnResult(name = "modelName"),
                    @ColumnResult(name = "techniqueName"),
                    @ColumnResult(name = "value"),
                    @ColumnResult(name = "monthYear"),
                    @ColumnResult(name = "forecastValue")}))
public class StatisticalModel {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ModelID", unique = true, nullable = false)
    private Integer modelId;
     
    @Column(name = "ModelName", nullable = false, length = 100)
    private String modelName;

	public Integer getModelId() {
		return modelId;
	}

	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
    
}
