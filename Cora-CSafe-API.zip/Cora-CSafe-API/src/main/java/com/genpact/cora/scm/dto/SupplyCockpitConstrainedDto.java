/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.util.Map;
import java.util.TreeMap;

/**
 * @author 703158077
 *
 */
public class SupplyCockpitConstrainedDto {
	
	private Integer forecast;
	private Integer inventory;
	
	public SupplyCockpitConstrainedDto(Integer forecast ,Integer inventory){
		this.forecast = forecast;
		this.inventory = inventory;
	}
	
	private Map<String,SupplyCockpitConstrainedDto> map = new TreeMap<String,SupplyCockpitConstrainedDto>();


	/**
	 * @return the forecast
	 */
	public Integer getForecast() {
		return forecast;
	}


	/**
	 * @return the inventory
	 */
	public Integer getInventory() {
		return inventory;
	}

	

	/**
	 * @return the map
	 */
	public Map<String, SupplyCockpitConstrainedDto> getMap() {
		return map;
	}

	/**
	 * @param map the map to set
	 */
	public void setMap(Map<String, SupplyCockpitConstrainedDto> map) {
		this.map = map;
	}
	
	

}
