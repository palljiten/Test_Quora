package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class WeightedAverage implements Serializable {

	private static final long serialVersionUID = 1L;

	private float baseline;
	private float statistical;

	public float getBaseline() {
		return baseline;
	}

	public void setBaseline(float baseline) {
		this.baseline = baseline;
	}

	public float getStatistical() {
		return statistical;
	}

	public void setStatistical(float statistical) {
		this.statistical = statistical;
	}

	
}
