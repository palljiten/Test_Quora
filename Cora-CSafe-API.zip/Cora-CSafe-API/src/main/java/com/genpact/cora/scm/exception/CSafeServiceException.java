package com.genpact.cora.scm.exception;

import org.springframework.http.HttpStatus;

public class CSafeServiceException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private HttpStatus status;
	
	public CSafeServiceException(String message) {
        super(message);
    }

    public CSafeServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public CSafeServiceException(Throwable cause) {
        super(cause);
    }

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}
}
