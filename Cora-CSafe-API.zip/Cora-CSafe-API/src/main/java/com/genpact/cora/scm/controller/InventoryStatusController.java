package com.genpact.cora.scm.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.SpareInventoryStatusDto;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.InventoryStatusService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
@Api(tags = {"Inventory Management - Inventory Status"})
public class InventoryStatusController {

	private static Logger logger = LoggerFactory.getLogger(InventoryStatusController.class);

	@Autowired
	InventoryStatusService inventoryStatusService;

	@GetMapping(value = "/inventoryManagement/containersInventoryStatus", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves containers inventory status")
	public ResponseEntity<Map<String,Object>> getContainersInventoryStatus(@RequestParam(value = "selectedDate", required = false) String selectedDate,@RequestParam(value = "regionId") int regionId,@RequestParam(value = "countryId") int countryId,@RequestParam(value = "hubId") int hubId) {
		logger.info("CONTROLLER: InventoryStatusController: Entering getContainersInventoryStatus() method");
		Map<String,Object> responseList ;
		Date date = null;
		try {
			if (selectedDate == null) {
				date = new Date();
			}else{
				SimpleDateFormat sdf = null;
				if(selectedDate.contains("/")){
					sdf = new SimpleDateFormat("MM/dd/yyyy");
				}else if(selectedDate.contains("-")){
					sdf = new SimpleDateFormat("MM-dd-yyyy");
				}
				
				date = sdf.parse(selectedDate);
			}
			responseList = inventoryStatusService.getContainersInventoryStatus(date,regionId,countryId,hubId);
		} catch (CSafeServiceException | ParseException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching containers inventory data", e.getCause());
		}
		logger.info("CONTROLLER: InventoryStatusController: Exiting getContainersInventoryStatus() method");
		return new ResponseEntity<>(responseList, HttpStatus.OK);
	}
	
	

	/**
	 * @return
	 */
	@GetMapping(value = "/inventoryManagement/sparesInventoryStatus", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves spares inventory status")
	public ResponseEntity<List<Map<String, Object>>> getAllSparesInventoryStatus(@RequestParam(value = "regionId") int regionId,@RequestParam(value = "countryId") int countryId,@RequestParam(value = "hubId") int hubId,@RequestParam(value = "partNumber") String partNumber) {
		logger.info("CONTROLLER: InventoryStatusController: Entering getSparesInventoryStatus() method");
		List<Map<String, Object>> spareInventoryListOfMap = null;
		try {
			spareInventoryListOfMap = inventoryStatusService.getSparesInventoryStatus(regionId,countryId,hubId,partNumber);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching spares inventory data", e.getCause());
		}
		logger.info("CONTROLLER: InventoryStatusController: Exiting getSparesInventoryStatus() method");
		return new ResponseEntity<>(spareInventoryListOfMap, HttpStatus.OK);
	}
}
