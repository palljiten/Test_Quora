package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.genpact.cora.scm.entity.ApplicationLog;

/**
 *Application log repository interface. 
 * @author nirmal kamila
 *
 */
public interface ApplicationLogRepository extends JpaRepository<ApplicationLog, Integer> {
	
	

}
