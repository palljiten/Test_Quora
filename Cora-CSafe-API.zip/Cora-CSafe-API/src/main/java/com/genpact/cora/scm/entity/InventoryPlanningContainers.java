/**
 * 
 */
package com.genpact.cora.scm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author 703158077
 *
 */
@Entity
@Table(name="tbl_IMInventoryPlanningContainers")
public class InventoryPlanningContainers implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543218L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID", unique= true, nullable = false )
	private Integer id;
	
	@OneToOne(fetch= FetchType.EAGER)
	@JoinColumn(name="RegionID")
	private Region region;
	
	@OneToOne(fetch= FetchType.EAGER)
	@JoinColumn(name="HubID")
	private HubSc hub;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CountryID")
	private Country country;
	@Column(name="ServiceLevel")
	private Integer serviceLevel;
	@Column(name="InventoryLevel")
	private Integer inventoryLevel;
	@Column(name="TotalLeadTime")
	private Float totalLeadTime;
	@Column(name="DemandDuringLeadTime")
	private Float demandDuringLeadTime;
	@Column(name="AverageMonthlyDemand")
	private Integer averageMonthlyDemand;
	@Column(name="StandardDeviation")
	private Float standardDeviation;
	@Column(name="ROP")
	private Integer rop;
	@Column(name="SafetyStock")
	private Integer calcMinInventory;
	@Column(name="PriorityFlag")
	private Float priorityFlag;
	@Column(name="Flag")
	private Integer flag;
	
	
	
	
	/**
	 * @return the flag
	 */
	public Integer getFlag() {
		return flag;
	}
	/**
	 * @param flag the flag to set
	 */
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the region
	 */
	public Region getRegion() {
		return region;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(Region region) {
		this.region = region;
	}
	/**
	 * @return the hub
	 */
	public HubSc getHub() {
		return hub;
	}
	/**
	 * @param hub the hub to set
	 */
	public void setHub(HubSc hub) {
		this.hub = hub;
	}
	/**
	 * @return the country
	 */
	public Country getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(Country country) {
		this.country = country;
	}
	/**
	 * @return the serviceLevel
	 */
	public Integer getServiceLevel() {
		return serviceLevel;
	}
	/**
	 * @param serviceLevel the serviceLevel to set
	 */
	public void setServiceLevel(Integer serviceLevel) {
		this.serviceLevel = serviceLevel;
	}
	/**
	 * @return the inventoryLevel
	 */
	public Integer getInventoryLevel() {
		return inventoryLevel;
	}
	/**
	 * @param inventoryLevel the inventoryLevel to set
	 */
	public void setInventoryLevel(Integer inventoryLevel) {
		this.inventoryLevel = inventoryLevel;
	}
	/**
	 * @return the totalLeadTime
	 */
	public Float getTotalLeadTime() {
		return totalLeadTime;
	}
	/**
	 * @param totalLeadTime the totalLeadTime to set
	 */
	public void setTotalLeadTime(Float totalLeadTime) {
		this.totalLeadTime = totalLeadTime;
	}
	/**
	 * @return the demandDuringLeadTime
	 */
	public Float getDemandDuringLeadTime() {
		return demandDuringLeadTime;
	}
	/**
	 * @param demandDuringLeadTime the demandDuringLeadTime to set
	 */
	public void setDemandDuringLeadTime(Float demandDuringLeadTime) {
		this.demandDuringLeadTime = demandDuringLeadTime;
	}
	/**
	 * @return the averageMonthlyDemand
	 */
	public Integer getAverageMonthlyDemand() {
		return averageMonthlyDemand;
	}
	/**
	 * @param averageMonthlyDemand the averageMonthlyDemand to set
	 */
	public void setAverageMonthlyDemand(Integer averageMonthlyDemand) {
		this.averageMonthlyDemand = averageMonthlyDemand;
	}
	/**
	 * @return the standardDeviation
	 */
	public Float getStandardDeviation() {
		return standardDeviation;
	}
	/**
	 * @param standardDeviation the standardDeviation to set
	 */
	public void setStandardDeviation(Float standardDeviation) {
		this.standardDeviation = standardDeviation;
	}
	/**
	 * @return the rop
	 */
	public Integer getRop() {
		return rop;
	}
	/**
	 * @param rop the rop to set
	 */
	public void setRop(Integer rop) {
		this.rop = rop;
	}
	/**
	 * @return the calcMinInventory
	 */
	public Integer getCalcMinInventory() {
		return calcMinInventory;
	}
	/**
	 * @param calcMinInventory the calcMinInventory to set
	 */
	public void setCalcMinInventory(Integer calcMinInventory) {
		this.calcMinInventory = calcMinInventory;
	}
	/**
	 * @return the priorityFlag
	 */
	public Float getPriorityFlag() {
		return priorityFlag;
	}
	/**
	 * @param priorityFlag the priorityFlag to set
	 */
	public void setPriorityFlag(Float priorityFlag) {
		this.priorityFlag = priorityFlag;
	}
	
	
	
	
	

}
