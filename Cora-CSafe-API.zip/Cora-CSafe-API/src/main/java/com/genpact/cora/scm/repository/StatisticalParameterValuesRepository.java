package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.ModelParam;
import com.genpact.cora.scm.entity.StatisticalParameterValues;

public interface StatisticalParameterValuesRepository extends JpaRepository<StatisticalParameterValues, Integer> {

	/*
	 SELECT sm.ModelID, sp.PID, sp.ParameterName, spv.Value FROM [tbl_StatisticalParameterValues] as spv 
	INNER JOIN [tbl_master_StatisticalParameters] as sp ON spv.ParameterID = sp.PID
	INNER JOIN [tbl_master_StatisticalModel] as sm ON sp.ModelID = sm.ModelID
	WHERE sm.ModelID = 1 AND spv.RegionID = 1 AND spv.CountryID = 2 AND spv.HubID = 3 AND spv.Flag = 1
	 */
	@Query("SELECT new com.genpact.cora.scm.dto.ModelParam(sm.modelId, sp.id, sp.parameterName, spv.value) "
			+ "FROM StatisticalParameterValues spv INNER JOIN spv.parameter sp ON spv.parameter.id = sp.id "
			+ "INNER JOIN sp.model sm ON sp.model.modelId = sm.modelId "
			+ "WHERE sm.modelId = :modelId AND spv.region.regionId = :regionId AND spv.country.countryId = :countryId "
			+ "AND spv.hubsc.hubId = :hubId AND spv.flag = 1")
	public List<ModelParam> getParamValuesForModelId(@Param("modelId") int modelId, @Param("regionId") int regionlId,
			@Param("countryId") int countryId, @Param("hubId") int hubId);
	
	
	@Modifying
    @Query("UPDATE StatisticalParameterValues spv SET spv.flag = 0 "
    		+ "WHERE spv.flag=1 AND spv.hubsc.hubId = :hubId AND spv.country.countryId = :countryId "
    		+ "AND spv.region.regionId = :regionId AND spv.parameter.id = :paramId")
    int updateParams(@Param("paramId") int paramId, @Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId);
}
