package com.genpact.cora.scm.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ForecastAcuracyReportDownloadDTO {

	private String hubCode;
	private String partId;
	private String country;
	private String region;
	private String elements;
	private Map<String, Integer> monthYearMap = new HashMap<>();
	
	public String getHubCode() {
		return hubCode;
	}
	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}
	public String getPartId() {
		return partId;
	}
	public void setPartId(String partId) {
		this.partId = partId;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getElements() {
		return elements;
	}
	public void setElements(String elements) {
		this.elements = elements;
	}
	public Map<String, Integer> getMonthYearMap() {
		return monthYearMap;
	}
	public void setMonthYearMap(Map<String, Integer> monthYearMap) {
		this.monthYearMap = monthYearMap;
	}
}
