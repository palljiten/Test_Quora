package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.DemandAllocationHubLane;
import com.genpact.cora.scm.entity.DemandAllocationHubProfile;

public interface DemandAllocationRepository extends JpaRepository<DemandAllocationHubProfile, Integer> {

	@Query("select new DemandAllocationHubProfile(b.parentShipper,b.profilePercentage) from DemandAllocationHubProfile b"
			+ " where b.region.regionId = :regionId and b.country.countryId = :countryId AND b.hubSc.hubId = :hubId  ")
	List<DemandAllocationHubProfile> getParentShipperLevel(@Param("regionId")Integer regionID, @Param("countryId")Integer countryID, @Param("hubId")Integer hubID);

	@Query("select new DemandAllocationHubLane(b.profilePercentage,b.lane) from DemandAllocationHubLane b"
			+ " where b.region.regionId = :regionId and b.country.countryId = :countryId AND b.hubSc.hubId = :hubId and b.parentShipper=:parentShipper ")
	List<DemandAllocationHubLane> getLaneLevel(@Param("regionId")Integer regionID, @Param("countryId")Integer countryID, @Param("hubId")Integer hubID,
			@Param("parentShipper")String parentShipper);

}
