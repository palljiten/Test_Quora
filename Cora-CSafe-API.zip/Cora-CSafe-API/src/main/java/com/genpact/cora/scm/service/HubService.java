package com.genpact.cora.scm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.repository.HubRepository;

@Service
public class HubService {

	@Autowired
	HubRepository hubRepository;
	
	public List<HubSc> getAllHubs() {
		//return hubRepository.findAll();
		return hubRepository.getAllHubs();
	}
}
