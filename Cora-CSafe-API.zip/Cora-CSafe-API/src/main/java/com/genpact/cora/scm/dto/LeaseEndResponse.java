/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.io.Serializable;

/**
 * @author 703158077
 *
 */
public class LeaseEndResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543215L;
	
	private OrderDetails orderDetails;
	private transportationDetails transportationDetails;
	
	
	/**
	 * @return the orderDetails
	 */
	public OrderDetails getOrderDetails() {
		return orderDetails;
	}
	/**
	 * @param orderDetails the orderDetails to set
	 */
	public void setOrderDetails(OrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}
	/**
	 * @return the transportationDetails
	 */
	public transportationDetails getTransportationDetails() {
		return transportationDetails;
	}
	/**
	 * @param transportationDetails the transportationDetails to set
	 */
	public void setTransportationDetails(transportationDetails transportationDetails) {
		this.transportationDetails = transportationDetails;
	}
	
	
	
	

}
