package com.genpact.cora.scm.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.SparesInventoryClassification;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.SparesInventoryClassificationService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
@Api(tags = {"Inventory Management - Spare Inventory Classification"})
public class SpareInventoryClassificationController {
	
	private static Logger logger = LoggerFactory.getLogger(SpareInventoryClassificationController.class);
	
	@Autowired
	SparesInventoryClassificationService sparesInventoryClassificationService;
	
	@GetMapping(value = "/inventoryManagement/sparesInventoryClassification", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Spares inventory Classification")
	public ResponseEntity<List<SparesInventoryClassification>> getSparesInventoryClassification(@RequestParam ("regionId") int regionId,
			@RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId,
			@RequestParam("partNumber") String partNumber){
		logger.info("CONTROLLER:SpareInventoryClassificationController : Entering getSparesInventoryClassification() method");
		List<SparesInventoryClassification> sparesInventoryClassificationList = null;
		try {
			sparesInventoryClassificationList=sparesInventoryClassificationService.getSparesInventoryClassification(regionId,countryId,hubId ,partNumber);
		}
		catch(CSafeServiceException e){
			
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching spares inventory classification data", e.getCause());
		}
		logger.info("CONTROLLER:SpareInventoryClassificationController : Exiting getSparesInventoryClassification() method");
		return new ResponseEntity<>(sparesInventoryClassificationList, HttpStatus.OK);
	}
	
	
	/*//ConfigurationInventoryManagement is the setting
	@GetMapping(value = "/inventoryManagement/configurationInventoryManagement", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves region Spares inventory Classification")
	public ResponseEntity<Object> getSparesInventoryConfigurationInventoryManagement(@RequestBody ConfigurationInventoryClassificationDto configurationInventoryClassificationDto){
		
		logger.info("SpareInventoryClassificationController: Entering getSparesInventoryConfigurationInventoryManagement() method");
		List<ConfigurationInventoryClassificationDto> configurationInventoryClassificationDtoList =sparesInventoryClassificationService.getSparesInventoryConfigurationInventoryManagement(configurationInventoryClassificationDto);
		SuccessResponse sr = new SuccessResponse();
		sr.setStatus("SUCCESS");
		logger.info("SpareInventoryClassificationController: Exiting getSparesInventoryConfigurationInventoryManagement() method");
		return new ResponseEntity<>(sr, HttpStatus.OK);
	}
	*/
	
}
