package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_SparesStatisticalForecast]")
public class SparesStatisticalForecast {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer id;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RegionID")
	private Region region;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CountryID")
	private Country country;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "HubID")
	private HubSc hub;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ModelID")
	private StatisticalModelMaster model;
	
    @Column(name = "PartID", nullable = true)
    private String partId;
    
    @Column(name = "ForecastValue", nullable = true)
    private float forecastValue;
    
    @Column(name = "Flag", nullable = true)
    private int flag;
    
    @Column(name = "CreatedMonth", nullable = true)
    private String createdMonth;
    
    @Column(name = "MonthYear", nullable = true)
    private String monthYear;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}

	public StatisticalModelMaster getModel() {
		return model;
	}

	public void setModel(StatisticalModelMaster model) {
		this.model = model;
	}

	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId;
	}

	public float getForecastValue() {
		return forecastValue;
	}

	public void setForecastValue(float forecastValue) {
		this.forecastValue = forecastValue;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public String getCreatedMonth() {
		return createdMonth;
	}

	public void setCreatedMonth(String createdMonth) {
		this.createdMonth = createdMonth;
	}

	public String getMonthYear() {
		return monthYear;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
}
