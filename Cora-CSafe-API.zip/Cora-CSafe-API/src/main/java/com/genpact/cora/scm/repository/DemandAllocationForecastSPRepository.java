package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.genpact.cora.scm.entity.DemandAllocationForecast;
import com.genpact.cora.scm.repository.DemandAllocationForecastSPCustom;

public interface DemandAllocationForecastSPRepository
		extends JpaRepository<DemandAllocationForecast, Integer>, DemandAllocationForecastSPCustom {

}
