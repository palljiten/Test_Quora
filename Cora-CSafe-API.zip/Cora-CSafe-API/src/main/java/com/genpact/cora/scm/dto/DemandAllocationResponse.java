package com.genpact.cora.scm.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DemandAllocationResponse {

	@JsonProperty("weekMetaData")
	private List<Map<String,String>> weekMetaData = null;

	@JsonProperty("hub")
	private DemandAllocationHub hub;

	private Map<String, Object> otherProperties = new HashMap<>();

	public List<Map<String,String>> getWeekMetaData() {
		return weekMetaData;
	}

	public void setWeekMetaData(List<Map<String,String>> weekMetaData) {
		this.weekMetaData = weekMetaData;
	}
	
	public DemandAllocationHub getHub() {
		return hub;
	}

	public void setHub(DemandAllocationHub hub) {
		this.hub = hub;
	}

	@JsonAnyGetter
	public Map<String, Object> any() {
		return otherProperties;
	}

	@JsonAnySetter
	public void set(Map<String, Object> value) {
		this.otherProperties = value;
	}
}
