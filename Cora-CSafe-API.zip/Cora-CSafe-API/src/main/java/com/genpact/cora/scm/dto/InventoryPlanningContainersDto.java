package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class InventoryPlanningContainersDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543219L;
	
	
	private String hubCode;
	private Integer serviceLevel;
	private Integer inventoryLevel;
	private Float totalLeadTime;
	private Float demandDuringLeadTime;
	private Integer averageMonthlyDemand;
	private Float standardDeviation;
	private Integer rop;
	private Integer calcMinInventory;
	private Float priorityFlag;
	
	
	
	
	/**
	 * @return the hubCode
	 */
	public String getHubCode() {
		return hubCode;
	}
	/**
	 * @param hubCode the hubCode to set
	 */
	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}
	/**
	 * @return the serviceLevel
	 */
	public Integer getServiceLevel() {
		return serviceLevel;
	}
	/**
	 * @param serviceLevel the serviceLevel to set
	 */
	public void setServiceLevel(Integer serviceLevel) {
		this.serviceLevel = serviceLevel;
	}
	/**
	 * @return the inventoryLevel
	 */
	public Integer getInventoryLevel() {
		return inventoryLevel;
	}
	/**
	 * @param inventoryLevel the inventoryLevel to set
	 */
	public void setInventoryLevel(Integer inventoryLevel) {
		this.inventoryLevel = inventoryLevel;
	}
	/**
	 * @return the totalLeadTime
	 */
	public Float getTotalLeadTime() {
		return totalLeadTime;
	}
	/**
	 * @param totalLeadTime the totalLeadTime to set
	 */
	public void setTotalLeadTime(Float totalLeadTime) {
		this.totalLeadTime = totalLeadTime;
	}
	/**
	 * @return the demandDuringLeadTime
	 */
	public Float getDemandDuringLeadTime() {
		return demandDuringLeadTime;
	}
	/**
	 * @param demandDuringLeadTime the demandDuringLeadTime to set
	 */
	public void setDemandDuringLeadTime(Float demandDuringLeadTime) {
		this.demandDuringLeadTime = demandDuringLeadTime;
	}
	/**
	 * @return the averageMonthlyDemand
	 */
	public Integer getAverageMonthlyDemand() {
		return averageMonthlyDemand;
	}
	/**
	 * @param averageMonthlyDemand the averageMonthlyDemand to set
	 */
	public void setAverageMonthlyDemand(Integer averageMonthlyDemand) {
		this.averageMonthlyDemand = averageMonthlyDemand;
	}
	/**
	 * @return the standardDeviation
	 */
	public Float getStandardDeviation() {
		return standardDeviation;
	}
	/**
	 * @param standardDeviation the standardDeviation to set
	 */
	public void setStandardDeviation(Float standardDeviation) {
		this.standardDeviation = standardDeviation;
	}
	/**
	 * @return the rop
	 */
	public Integer getRop() {
		return rop;
	}
	/**
	 * @param rop the rop to set
	 */
	public void setRop(Integer rop) {
		this.rop = rop;
	}
	/**
	 * @return the calcMinInventory
	 */
	public Integer getCalcMinInventory() {
		return calcMinInventory;
	}
	/**
	 * @param calcMinInventory the calcMinInventory to set
	 */
	public void setCalcMinInventory(Integer calcMinInventory) {
		this.calcMinInventory = calcMinInventory;
	}
	/**
	 * @return the priorityFlag
	 */
	public Float getPriorityFlag() {
		return priorityFlag;
	}
	/**
	 * @param priorityFlag the priorityFlag to set
	 */
	public void setPriorityFlag(Float priorityFlag) {
		this.priorityFlag = priorityFlag;
	}
	
}
