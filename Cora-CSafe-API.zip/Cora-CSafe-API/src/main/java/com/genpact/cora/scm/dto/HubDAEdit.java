package com.genpact.cora.scm.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;

public class HubDAEdit {
	
	@JsonProperty("hubId")
	private int hubId; 
	
	@JsonProperty("hubCode")
	private String hubCode;
	
	@JsonProperty("parentShippers")
	private String parentShippers;

	@JsonProperty("parentShipperData")
	private Map<String, Object> parentShipperData = new HashMap<>();

	@JsonProperty("lane")
	private String lane;
	
	@JsonProperty("laneData")
	private Map<String, Object> laneData = new HashMap<>();

	public int getHubId() {
		return hubId;
	}

	public void setHubId(int hubId) {
		this.hubId = hubId;
	}

	public String getHubCode() {
		return hubCode;
	}

	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}

	public String getParentShippers() {
		return parentShippers;
	}

	public void setParentShippers(String parentShippers) {
		this.parentShippers = parentShippers;
	}

	public Map<String, Object> getParentShipperData() {
		return parentShipperData;
	}

	public void setParentShipperData(Map<String, Object> parentShipperData) {
		this.parentShipperData = parentShipperData;
	}

	public String getLane() {
		return lane;
	}

	public void setLane(String lane) {
		this.lane = lane;
	}

	public Map<String, Object> getLaneData() {
		return laneData;
	}

	public void setLaneData(Map<String, Object> laneData) {
		this.laneData = laneData;
	}
}
