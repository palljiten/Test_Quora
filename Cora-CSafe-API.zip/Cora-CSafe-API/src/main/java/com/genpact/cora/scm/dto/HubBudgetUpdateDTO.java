package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HubBudgetUpdateDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer regionId;
	private List<HubBudget> hubBudgetList = new ArrayList<>();
	
	public Integer getRegionId() {
		return regionId;
	}
	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}
	public List<HubBudget> getHubBudgetList() {
		return hubBudgetList;
	}
	public void setHubBudgetList(List<HubBudget> hubBudgetList) {
		this.hubBudgetList = hubBudgetList;
	}
}
