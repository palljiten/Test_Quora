package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.genpact.cora.scm.entity.RepairWorkOrderParts;
import com.genpact.cora.scm.entity.SpareParts;

public interface SparesPartsRepository extends JpaRepository<SpareParts, Integer>{
	
	

}
