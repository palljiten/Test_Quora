package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.dto.TempBestFitModel;
import com.genpact.cora.scm.dto.TempConfigModel;
import com.genpact.cora.scm.dto.TempModelOutput;
import com.genpact.cora.scm.entity.StatisticalModelMaster;

@Repository
public class SpecialForecastModelRepository {

	@PersistenceContext
    private EntityManager entityManager;
	
	public List<TempModelOutput> getTempForecastModels(int regionId, int countryId, 
			int hubId, List<String> monthYearList) {		
		
		@SuppressWarnings("unchecked")
		List<TempModelOutput> results = entityManager.createNativeQuery("select f.ModelId as modelId, m.ModelName as modelName, \r\n" + 
				"t.TechniqueName as techniqueName, w.Value as value, \r\n" + 
				"f.MonthYear as monthYear, f.ForecastValue as forecastValue \r\n" + 
				"from [dbo].[tbl_StatisticalForecast] f \r\n" + 
				"inner join [dbo].[tbl_master_StatisticalModel] m ON f.ModelId = m.ModelID\r\n" +
				"inner join [dbo].[tbl_StatisticalWeightedAvgTechnique] w ON w.ModelID = m.ModelID\r\n" + 
				"inner join [dbo].[tbl_master_StatisticalTechnique] t ON w.ATID = t.ATID\r\n" + 
				"where f.RegionId=  :regionId and f.CountryId= :countryId \r\n" + 
				"and f.HubId= :hubId and f.flag= 1 \r\n" + 
				"and (f.MonthYear IN (:monthYearList))", "TempModelOutputMapping")
		.setParameter("regionId", regionId)
		.setParameter("countryId", countryId)
		.setParameter("hubId", hubId)
		.setParameter("monthYearList", monthYearList)
		.getResultList();

		return results;
	}
	
	public List<TempModelOutput> getTempForecastModels1(int regionId, int countryId, 
			int hubId, List<String> monthYearList) {		
		
		StringBuffer sb = new StringBuffer("");
		sb.append("SELECT A.ModelID as modelId, B.ModelName as modelName, B.TechniqueName as techniqueName, B.Value AS value, A.MonthYear as monthYear, A.ForecastValue as forecastValue FROM \r\n" + 
				"		(SELECT A.RegionID,A.CountryID,A.HubID,A.ModelID,B.ModelName,A.ForecastValue,A.MonthYear FROM tbl_StatisticalForecast A\r\n" + 
				"		LEFT JOIN tbl_master_StatisticalModel B ON (A.ModelID = B.ModelID)\r\n" + 
				"		WHERE A.CreatedMonth = CONCAT((CONVERT(VARCHAR(3),DATENAME(Month,(SELECT StartDate FROM tbl_ForecastRunDate\r\n" + 
				"		WHERE CONVERT(DATE,GETDATE()) BETWEEN CONVERT(DATE,StartDate) AND CONVERT(DATE,EndDate))))),'-',YEAR((SELECT StartDate FROM tbl_ForecastRunDate\r\n" + 
				"		WHERE CONVERT(DATE,GETDATE()) BETWEEN CONVERT(DATE,StartDate) AND CONVERT(DATE,EndDate))))\r\n" + 
				"		AND Flag = 1) A\r\n" + 
				"		LEFT JOIN\r\n" + 
				"		(SELECT A.Value,A.RegionID,A.CountryID,A.HubID,A.ATID,B.TechniqueName,C.ModelName FROM tbl_StatisticalWeightedAvgTechnique A\r\n" + 
				"		LEFT JOIN tbl_master_StatisticalTechnique B ON (A.ATID=B.ATID)\r\n" + 
				"		LEFT JOIN tbl_master_StatisticalModel C ON (A.ModelID = C.ModelID)\r\n" + 
				"		WHERE A.CreatedMonth = CONCAT((CONVERT(VARCHAR(3),DATENAME(Month,(SELECT StartDate FROM tbl_ForecastRunDate\r\n" + 
				"		WHERE CONVERT(DATE,GETDATE()) BETWEEN CONVERT(DATE,StartDate) AND CONVERT(DATE,EndDate))))),'-',YEAR((SELECT StartDate FROM tbl_ForecastRunDate\r\n" + 
				"		WHERE CONVERT(DATE,GETDATE()) BETWEEN CONVERT(DATE,StartDate) AND CONVERT(DATE,EndDate))))) B\r\n" + 
				"		ON (A.RegionID =B.RegionID )AND (A.CountryID = B.CountryID) AND (A.HubID= B.HubID) AND (A.ModelName = B.ModelName) ");
		
		sb.append("WHERE A.RegionID = :regionId and A.CountryID = :countryId and A.HubId = :hubId");
		
		
		@SuppressWarnings("unchecked")
		List<TempModelOutput> results = entityManager.createNativeQuery(sb.toString(), "TempModelOutputMapping")
		.setParameter("regionId", regionId)
		.setParameter("countryId", countryId)
		.setParameter("hubId", hubId)
		.getResultList();
		
		
/*		List<TempModelOutput> results = entityManager.createNativeQuery("select f.ModelID as modelId, m.ModelName as modelName, \r\n" + 
				"t.TechniqueName as techniqueName, w.Value as value, \r\n" + 
				"f.MonthYear as monthYear, f.ForecastValue as forecastValue \r\n" + 
				"from [dbo].[tbl_SparesStatisticalForecast] f \r\n" + 
				"inner join [dbo].[tbl_master_StatisticalModel] m ON f.ModelID = m.ModelID\r\n" +
				"inner join [dbo].[tbl_SparesStatisticalWeightedAvgTechnique] w ON w.ModelID = m.ModelID\r\n" + 
				"inner join [dbo].[tbl_master_StatisticalTechnique] t ON w.ATID = t.ATID\r\n" + 
				"where f.RegionID=  :regionId and f.CountryID= :countryId and f.PartID= :partId \r\n" + 
				"and f.HubId= :hubId and f.flag= 1 \r\n" + 
				"and (f.MonthYear IN (:monthYearList))", "TempModelOutputMapping")
		.setParameter("regionId", regionId)
		.setParameter("countryId", countryId)
		.setParameter("hubId", hubId)
		.setParameter("partId", partId)
		.setParameter("monthYearList", monthYearList)
		.getResultList();*/

		return results;
	}
	
	
	public List<TempModelOutput> getTempSparesForecastModels(int regionId, int countryId, 
			int hubId, String partId, List<String> monthYearList) {		
		
		StringBuffer sb = new StringBuffer("");
		sb.append("SELECT A.ModelID as modelId, B.ModelName as modelName, B.TechniqueName as techniqueName, B.Value AS value, A.MonthYear as monthYear, A.ForecastValue as forecastValue FROM \r\n" + 
				"		(SELECT A.RegionID,A.CountryID,A.HubID,A.PartID,A.ModelID,B.ModelName,A.ForecastValue,A.MonthYear FROM tbl_SparesStatisticalForecast A\r\n" + 
				"		LEFT JOIN tbl_master_StatisticalModel B ON (A.ModelID = B.ModelID)\r\n" + 
				"		WHERE A.CreatedMonth = CONCAT((CONVERT(VARCHAR(3),DATENAME(Month,(SELECT StartDate FROM tbl_ForecastRunDate\r\n" + 
				"		WHERE CONVERT(DATE,GETDATE()) BETWEEN CONVERT(DATE,StartDate) AND CONVERT(DATE,EndDate))))),'-',YEAR((SELECT StartDate FROM tbl_ForecastRunDate\r\n" + 
				"		WHERE CONVERT(DATE,GETDATE()) BETWEEN CONVERT(DATE,StartDate) AND CONVERT(DATE,EndDate))))\r\n" + 
				"		AND Flag = 1) A\r\n" + 
				"		LEFT JOIN\r\n" + 
				"		(SELECT A.Value,A.RegionID,A.CountryID,A.HubID,A.PartID,A.ATID,B.TechniqueName,C.ModelName FROM tbl_SparesStatisticalWeightedAvgTechnique A\r\n" + 
				"		LEFT JOIN tbl_master_StatisticalTechnique B ON (A.ATID=B.ATID)\r\n" + 
				"		LEFT JOIN tbl_master_StatisticalModel C ON (A.ModelID = C.ModelID)\r\n" + 
				"		WHERE A.CreatedMonth = CONCAT((CONVERT(VARCHAR(3),DATENAME(Month,(SELECT StartDate FROM tbl_ForecastRunDate\r\n" + 
				"		WHERE CONVERT(DATE,GETDATE()) BETWEEN CONVERT(DATE,StartDate) AND CONVERT(DATE,EndDate))))),'-',YEAR((SELECT StartDate FROM tbl_ForecastRunDate\r\n" + 
				"		WHERE CONVERT(DATE,GETDATE()) BETWEEN CONVERT(DATE,StartDate) AND CONVERT(DATE,EndDate))))) B\r\n" + 
				"		ON (A.RegionID =B.RegionID )AND (A.CountryID = B.CountryID) AND (A.HubID= B.HubID) AND (A.PartID =B.PartID ) AND (A.ModelName = B.ModelName) ");
		
		sb.append("WHERE A.RegionID = :regionId and A.CountryID = :countryId and A.PartID= :partId \r\n" + 
				"		and A.HubId = :hubId");
		
		
		@SuppressWarnings("unchecked")
		List<TempModelOutput> results = entityManager.createNativeQuery(sb.toString(), "TempModelOutputMapping")
		.setParameter("regionId", regionId)
		.setParameter("countryId", countryId)
		.setParameter("hubId", hubId)
		.setParameter("partId", partId)
		//.setParameter("monthYearList", monthYearList)
		.getResultList();
		
		
/*		List<TempModelOutput> results = entityManager.createNativeQuery("select f.ModelID as modelId, m.ModelName as modelName, \r\n" + 
				"t.TechniqueName as techniqueName, w.Value as value, \r\n" + 
				"f.MonthYear as monthYear, f.ForecastValue as forecastValue \r\n" + 
				"from [dbo].[tbl_SparesStatisticalForecast] f \r\n" + 
				"inner join [dbo].[tbl_master_StatisticalModel] m ON f.ModelID = m.ModelID\r\n" +
				"inner join [dbo].[tbl_SparesStatisticalWeightedAvgTechnique] w ON w.ModelID = m.ModelID\r\n" + 
				"inner join [dbo].[tbl_master_StatisticalTechnique] t ON w.ATID = t.ATID\r\n" + 
				"where f.RegionID=  :regionId and f.CountryID= :countryId and f.PartID= :partId \r\n" + 
				"and f.HubId= :hubId and f.flag= 1 \r\n" + 
				"and (f.MonthYear IN (:monthYearList))", "TempModelOutputMapping")
		.setParameter("regionId", regionId)
		.setParameter("countryId", countryId)
		.setParameter("hubId", hubId)
		.setParameter("partId", partId)
		.setParameter("monthYearList", monthYearList)
		.getResultList();*/

		return results;
	}
	
	public List<TempConfigModel> getTempConfigModels(int regionId, int countryId, 
			int hubId, List<String> monthYearList) {		
		
		@SuppressWarnings("unchecked")
		List<TempConfigModel> results = entityManager.createNativeQuery("SELECT m.ModelId as modelId, c.ModelID as configModelID \r\n" + 
				"FROM tbl_master_statisticalModel as m LEFT OUTER JOIN [tbl_StatisticalForecastConfig] as c \r\n" + 
				"ON m.ModelID = c.ModelID \r\n" + 
				"WHERE " + //c.MonthYear IN (:monthYearList) \r\n" + 
				"c.RegionID = :regionId AND c.CountryID = :countryId AND c.HubID = :hubId AND Flag = 1", "StatisticalForecastConfigMapping")
		//.setParameter("monthYearList", monthYearList)
		.setParameter("regionId", regionId)
		.setParameter("countryId", countryId)
		.setParameter("hubId", hubId)
		.getResultList();

		return results;
	}
	
	public List<TempConfigModel> getTempSparesConfigModels(int regionId, int countryId, 
			int hubId, String partId, List<String> monthYearList) {		
		
		@SuppressWarnings("unchecked")
		List<TempConfigModel> results = entityManager.createNativeQuery("SELECT m.ModelId as modelId, c.ModelID as configModelID \r\n" + 
				"FROM tbl_master_StatisticalModel as m LEFT OUTER JOIN [tbl_SparesStatisticalForecastConfig] as c \r\n" + 
				"ON m.ModelID = c.ModelID \r\n" + 
				"WHERE " + //c.MonthYear IN (:monthYearList) \r\n" + 
				"c.RegionID = :regionId AND c.CountryID = :countryId AND c.HubID = :hubId AND c.PartID = :partId AND c.Flag = 1", "StatisticalForecastConfigMapping")
		//.setParameter("monthYearList", monthYearList)
		.setParameter("regionId", regionId)
		.setParameter("countryId", countryId)
		.setParameter("hubId", hubId)
		.setParameter("partId", partId)
		.getResultList();

		return results;
	}
	
	public List<TempBestFitModel> getTempSparesBestFitModels(int regionId, int countryId, 
			int hubId, String partId, List<String> monthYearList) {		
		
		@SuppressWarnings("unchecked")
		List<TempBestFitModel> results = entityManager.createNativeQuery("SELECT m.ModelId as modelId, c.ModelID as bestFitModelID \r\n" + 
				"FROM tbl_master_statisticalModel as m LEFT OUTER JOIN [tbl_SparesStatisticalForecastBestFit] as c \r\n" + 
				"ON m.ModelID = c.ModelID \r\n" + 
				"WHERE " + //c.MonthYear IN (:monthYearList) \r\n" + 
				"c.RegionID = :regionId AND c.CountryID = :countryId AND c.HubID = :hubId AND c.PartID = :partId AND c.Flag = 1", "StatisticalForecastBestFitMapping")
		//.setParameter("monthYearList", monthYearList)
		.setParameter("regionId", regionId)
		.setParameter("countryId", countryId)
		.setParameter("hubId", hubId)
		.setParameter("partId", partId)
		.getResultList();

		return results;
	}
	
	public List<TempBestFitModel> getTempBestFitModels(int regionId, int countryId, 
			int hubId, List<String> monthYearList) {		
		
		@SuppressWarnings("unchecked")
		List<TempBestFitModel> results = entityManager.createNativeQuery("SELECT m.ModelId as modelId, c.ModelID as bestFitModelID \r\n" + 
				"FROM tbl_master_statisticalModel as m LEFT OUTER JOIN [tbl_StatisticalForecastBestFit] as c \r\n" + 
				"ON m.ModelID = c.ModelID \r\n" + 
				//"WHERE c.MonthYear IN (:monthYearList) \r\n" + 
				"AND c.RegionID = :regionId AND c.CountryID = :countryId AND c.HubID = :hubId AND c.Flag = 1", "StatisticalForecastBestFitMapping")
		//.setParameter("monthYearList", monthYearList)
		.setParameter("regionId", regionId)
		.setParameter("countryId", countryId)
		.setParameter("hubId", hubId)
		.getResultList();

		return results;
	}
	
	
	public List<StatisticalModelMaster> getModels() {		
		
		@SuppressWarnings("unchecked")
		List<StatisticalModelMaster> results = entityManager.createNativeQuery("select * from tbl_master_statisticalModel where modelID <> 8")
		.getResultList();

		return results;
	}
}
