package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.genpact.cora.scm.entity.ResolvedIssues;

public interface ResolvedIssuesRepository extends JpaRepository<ResolvedIssues, Integer> {

}