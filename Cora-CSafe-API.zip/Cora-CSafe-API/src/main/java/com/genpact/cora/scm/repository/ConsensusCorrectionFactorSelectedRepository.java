package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.genpact.cora.scm.entity.ConsensusCorrectionFactorSelected;

public interface ConsensusCorrectionFactorSelectedRepository extends JpaRepository<ConsensusCorrectionFactorSelected, Integer> {

	@Transactional
	@Modifying
	@Query("update ConsensusCorrectionFactorSelected set flag=0 "
			+ "where region.regionId=:regionId and country.countryId=:countryId and hub.hubId=:hubId")
	void updateConsensusCorrectionFactorSelected(@Param("regionId")int regionId, @Param("countryId")int countryId, @Param("hubId")int hubId);

	@Query("select c from ConsensusCorrectionFactorSelected c where "
			+ "c.region.regionId=:regionId and c.country.countryId=:countryId and c.hub.hubId=:hubId and c.flag=1")
	ConsensusCorrectionFactorSelected get(@Param("regionId")int regionId, @Param("countryId")int countryId, @Param("hubId")int hubId);

}
