package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class PolicySetup implements Serializable{

	private static final long serialVersionUID = 1L;
	
	
}
