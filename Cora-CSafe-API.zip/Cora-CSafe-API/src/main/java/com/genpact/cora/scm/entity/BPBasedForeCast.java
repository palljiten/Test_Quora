package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_BudgetBasedForecast]")
public class BPBasedForeCast {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RegionId")
	private Region region;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CountryId")
	private Country country;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "HubID")
	private HubSc hubSc;

	@Column(name = "MonthYear", nullable = true)
	private String monthYear;

	@Column(name = "Value", nullable = true)
	private float value;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CreatedDate", nullable = true)
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ModifiedDate", nullable = true)
	private Date modifiedDate;
	
	@Column(name = "Flag", nullable = false)
	private Integer flag;

	@Column(name = "CreatedMonth", nullable = true)
	private String createdtMonth;

	public BPBasedForeCast(float value, String monthYear) {
		this.value = value;
		this.monthYear = monthYear;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getMonthYear() {
		return monthYear;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		this.value = value;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	public HubSc getHubSc() {
		return hubSc;
	}

	public void setHubSc(HubSc hubSc) {
		this.hubSc = hubSc;
	}

	public String getCreatedtMonth() {
		return createdtMonth;
	}

	public void setCreatedtMonth(String createdtMonth) {
		this.createdtMonth = createdtMonth;
	}

}
