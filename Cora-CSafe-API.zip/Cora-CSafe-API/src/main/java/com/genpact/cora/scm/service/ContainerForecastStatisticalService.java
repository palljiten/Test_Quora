package com.genpact.cora.scm.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.ContainerStatisticalBaselineForecastCombo;
import com.genpact.cora.scm.dto.ModelParam;
import com.genpact.cora.scm.dto.ModelParams;
import com.genpact.cora.scm.dto.MonthDataUnit;
import com.genpact.cora.scm.dto.MonthDataUnitUpdate;
import com.genpact.cora.scm.dto.PythonRequestObject;
import com.genpact.cora.scm.dto.PythonResponseObject;
import com.genpact.cora.scm.dto.PythonUpdatedForecastModelUpdateRequest;
import com.genpact.cora.scm.dto.SingleModelOutput;
import com.genpact.cora.scm.dto.StatisticalAdjustmentCombo;
import com.genpact.cora.scm.dto.StatisticalAdjustmentUpdateCombo;
import com.genpact.cora.scm.dto.StatisticalForecastModelOutput;
import com.genpact.cora.scm.dto.TempBestFitModel;
import com.genpact.cora.scm.dto.TempConfigModel;
import com.genpact.cora.scm.dto.TempModelOutput;
import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.ModelEditConfig;
import com.genpact.cora.scm.entity.Region;
import com.genpact.cora.scm.entity.StatisticalAdjustments;
import com.genpact.cora.scm.entity.StatisticalForecast;
import com.genpact.cora.scm.entity.StatisticalForecastBestFit;
import com.genpact.cora.scm.entity.StatisticalForecastConfig;
import com.genpact.cora.scm.entity.StatisticalModel;
import com.genpact.cora.scm.entity.StatisticalModelMaster;
import com.genpact.cora.scm.entity.StatisticalParameterValues;
import com.genpact.cora.scm.entity.StatisticalParametersMaster;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.ContainerForecastStatisticalRepositoryLatest;
import com.genpact.cora.scm.repository.IContainerForecastStatisticalRepository;
import com.genpact.cora.scm.repository.ModelEditConfigRepository;
import com.genpact.cora.scm.repository.SpecialForecastModelRepository;
import com.genpact.cora.scm.repository.StatisticalAdjustmentsRepository;
import com.genpact.cora.scm.repository.StatisticalForecastBestFitRepository;
import com.genpact.cora.scm.repository.StatisticalForecastConfigRepository;
import com.genpact.cora.scm.repository.StatisticalForecastRepository;
import com.genpact.cora.scm.repository.StatisticalModelRepository;
import com.genpact.cora.scm.repository.StatisticalParameterValuesRepository;
import com.genpact.cora.scm.repository.StatisticalParametersMasterRepository;
import com.genpact.cora.scm.util.ParamConstants;

@Service
public class ContainerForecastStatisticalService implements IContainerForecastStatisticalService {

	private static Logger logger = LoggerFactory.getLogger(ContainerForecastStatisticalService.class);

	@Autowired
	IContainerForecastStatisticalRepository containerForecastStatisticalRepository;

	@Autowired
	StatisticalAdjustmentsRepository ssaRepository;

	@Autowired
	ContainerForecastStatisticalRepositoryLatest cfsRepository;

	@Autowired
	StatisticalForecastConfigRepository configRepository;

	@Autowired
	StatisticalForecastBestFitRepository bestFitRepository;

	@Autowired
	StatisticalModelRepository smRepository;

	@Autowired
	SpecialForecastModelRepository specialForecastRepository;

	@Autowired
	StatisticalParameterValuesRepository statisticalParamValuesRepo;

	@Autowired
	ExternalServiceCaller externalService;

	@Autowired
	StatisticalForecastRepository sfRepo;
	
	@Autowired
	StatisticalParametersMasterRepository paramMasterRepo;
	
	@Autowired
	ModelEditConfigRepository modelEditConfigRepo;

	private static Map<Integer, String> monthValueMap = new HashMap<>();
	private static Map<String, Integer> monthValueReverseMap = new HashMap<>();
	private static Map<String, String> yearMap = new HashMap<>();
	private static Map<String, String> yearReverseMap = new HashMap<>();

	static {
		monthValueMap.put(0, "Jan");
		monthValueMap.put(1, "Feb");
		monthValueMap.put(2, "Mar");
		monthValueMap.put(3, "Apr");
		monthValueMap.put(4, "May");
		monthValueMap.put(5, "Jun");
		monthValueMap.put(6, "Jul");
		monthValueMap.put(7, "Aug");
		monthValueMap.put(8, "Sep");
		monthValueMap.put(9, "Oct");
		monthValueMap.put(10, "Nov");
		monthValueMap.put(11, "Dec");

		monthValueReverseMap.put("Jan", 0);
		monthValueReverseMap.put("Feb", 1);
		monthValueReverseMap.put("Mar", 2);
		monthValueReverseMap.put("Apr", 3);
		monthValueReverseMap.put("May", 4);
		monthValueReverseMap.put("Jun", 5);
		monthValueReverseMap.put("Jul", 6);
		monthValueReverseMap.put("Aug", 7);
		monthValueReverseMap.put("Sep", 8);
		monthValueReverseMap.put("Oct", 9);
		monthValueReverseMap.put("Nov", 10);
		monthValueReverseMap.put("Dec", 11);

		yearMap.put("15", "2015");
		yearMap.put("16", "2016");
		yearMap.put("17", "2017");
		yearMap.put("18", "2018");
		yearMap.put("19", "2019");
		yearMap.put("20", "2020");
		yearMap.put("21", "2021");
		yearMap.put("22", "2022");

		yearReverseMap.put("2015", "15");
		yearReverseMap.put("2016", "16");
		yearReverseMap.put("2017", "17");
		yearReverseMap.put("2018", "18");
		yearReverseMap.put("2019", "19");
		yearReverseMap.put("2020", "20");
		yearReverseMap.put("2021", "21");
		yearReverseMap.put("2022", "22");
	}

	@Transactional
	public void updateForecastModel(int modelId, int regionId, int countryId, int hubId,
			PythonUpdatedForecastModelUpdateRequest modelUpdate) {
		logger.info("SparesForecastStatisticalService: Entering updateForecastModel() method");
		try {
			System.out.println("\n\n");
			System.out.println("hubId = " + modelUpdate.getHubId());
			System.out.println("countryId = " + modelUpdate.getCountryId());
			System.out.println("regionId = " + modelUpdate.getRegionId());
			System.out.println("modelId = " + modelUpdate.getModelId());
			System.out.println("partNumber = " + modelUpdate.getPartNumber());
			System.out.println("madPercent = " + modelUpdate.getMadPercent());
			System.out.println("mapePercent = " + modelUpdate.getMapePercent());
			System.out.println("rmsePercent = " + modelUpdate.getRmsePercent());
			System.out.println("\n");
			List<MonthDataUnit> monthData = modelUpdate.getMonthData();

			if (monthData == null || monthData.size() < 6) {
				throw new CSafeServiceException("You should provide 6 month data for forecast model update");
			}

			StatisticalParameterValues spv = null;
			Country c = new Country();
			c.setCountryId(countryId);

			Region r = new Region();
			r.setRegionId(regionId);

			HubSc h = new HubSc();
			h.setHubId(hubId);
			h.setCountry(c);
			h.setRegion(r);

			StatisticalModelMaster sm = new StatisticalModelMaster();
			sm.setModelId(modelId);
			StatisticalModel stModel = new StatisticalModel();
			stModel.setModelId(modelId);
			StatisticalForecastConfig stForecastConfig = null;

			List<ModelParam> params = modelUpdate.getParameters();
			for (ModelParam mp : params) {
				// INSERT INTO [tbl_StatisticalParameterValues](RegionID, CountryID, HubID,
				// ParameterID, CreatedMonth, Value, Flag)
				// VALUES(1,2,3,15,'Nov-2018',10,1)
				spv = new StatisticalParameterValues();
				spv.setCountry(c);
				spv.setRegion(r);
				spv.setHubsc(h);
				StatisticalParametersMaster sp = new StatisticalParametersMaster();
				sp.setId(mp.getParamId());
				sp.setModel(sm);
				spv.setParameter(sp);
				spv.setCreatedMonth(getCurrentMothYear());
				spv.setValue(mp.getParamValue());
				spv.setFlag(1);

				System.out.println("paramId = " + mp.getParamId());
				System.out.println("paramName = " + mp.getParamName());
				System.out.println("paramValue = " + mp.getParamValue());
				System.out.println("\n");
				statisticalParamValuesRepo.updateParams(mp.getParamId(), regionId, countryId, hubId);
				statisticalParamValuesRepo.save(spv);
			}

			// UPDATE [tbl_StatisticalForecast] SET Flag = 0
			// WHERE RegionID = 2 AND CountryID = 3 AND HubID = 1 AND ModelID = 1 AND Flag =
			// 1

			// INSERT INTO [tbl_StatisticalForecast](RegionID, CountryID, HubID,
			// CreatedMonth, ModelID, MonthYear, ForecastValue, CreatedDate, Flag)
			// VALUES(2,3,1,'Dec-2018',1,9,GETDATE(),1)
			StatisticalForecast sf = null;
			sfRepo.updateModel(modelId, regionId, countryId, hubId);

			StatisticalModel m = new StatisticalModel();
			sm.setModelId(modelId);

			//update configRepository
			
			List<String> monthYearList = getMonthYearList();
			List<TempConfigModel> configModel = specialForecastRepository.getTempConfigModels(regionId, countryId, hubId,
					monthYearList);
			Integer configuredModelId = 0;
			if (!configModel.isEmpty()) {
				configuredModelId = configModel.get(0).getConfigModelId();
				for (TempConfigModel cm : configModel) {
					if (cm.getConfigModelId() != null) {
						configuredModelId = cm.getConfigModelId();
						break;
					}
				}
			}
			System.out.println("configuredModelId = " + configuredModelId);
			System.out.println("\n");
			if (configuredModelId > 0 ) {
				configRepository.updateStatisticalForecastConfigModel(configuredModelId, regionId, countryId, hubId);
			}
			stForecastConfig = new StatisticalForecastConfig();
			stForecastConfig.setCountry(c);
			stForecastConfig.setRegion(r);
			stForecastConfig.setHub(h);
			stForecastConfig.setCreatedMonth(getCurrentMothYear());
			stForecastConfig.setConfiguredModel(stModel);
			stForecastConfig.setFlag(1);
			configRepository.save(stForecastConfig);
			
			for (MonthDataUnit md : monthData) {
				sf = new StatisticalForecast();
				sf.setCountry(c);
				sf.setCreatedDate(new Date());
				sf.setCreatedMonth(getCurrentMothYear());
				sf.setFlag(1);
				sf.setForecastMonth(md.getMonth() + "-" + md.getYear());
				sf.setForecastValue(md.getValue());
				sf.setHubsc(h);
				sf.setRegion(r);
				sf.setModelId(modelId);
				sfRepo.save(sf);
			}
			
			modelEditConfigRepo.updateModelEditConfig(modelId, regionId, countryId, hubId);
			ModelEditConfig mec = new ModelEditConfig();
			mec.setBaselineAdjustment(modelUpdate.isBaselinePercentageAdjustment());
			mec.setCountry(c);
			mec.setCreatedBy("CSafeAdmin");
			mec.setCreatedDate(new Date());
			mec.setFlag(1);
			mec.setHubsc(h);
			mec.setModel(stModel);
			mec.setNormalForecast(modelUpdate.isNormalForecast());
			mec.setPercentage(modelUpdate.getPercentage());
			mec.setRegion(r);
			modelEditConfigRepo.save(mec);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("SparesForecastStatisticalService: Exiting updateForecastModel() method");
	}

	private String getCurrentMothYear() {
		Calendar c = Calendar.getInstance();
		return monthValueMap.get(c.get(Calendar.MONTH)) + "-" + c.get(Calendar.YEAR);
	}

	public ModelParams getStatistcalModelParams(int modelId, int regionId, int countryId, int hubId) {
		logger.info("SparesForecastStatisticalService: Entering getStatistcalModelParams() method");
		ModelParams params = new ModelParams();
		params.setModelId(modelId);
		List<ModelParam> result = statisticalParamValuesRepo.getParamValuesForModelId(modelId, regionId, countryId,
				hubId);
		
		if (result == null || result.isEmpty()) {
			result = new ArrayList<>();
			List<StatisticalParametersMaster> modelMasterParams = paramMasterRepo.findByModelId(modelId);
			
			//This is temporary. When DB will incorporate the parameter default values, we need to
			//read from database
			for (StatisticalParametersMaster param : modelMasterParams) {	
				ModelParam mp = new ModelParam();
				
				mp.setParamId(param.getId());
				mp.setParamName(param.getParameterName());
				if (param.getParameterName().equals(ParamConstants.FORECAST)) {
					mp.setParamValue(6);
				} else if (param.getParameterName().equals(ParamConstants.HISTORIC)) {
					mp.setParamValue(12);
				}
				
				if (param.getModel().getModelName().equals(ParamConstants.WEIGHTED_AVERAGE)) {
					if (param.getParameterName().equals(ParamConstants.WEIGHT)) {
						mp.setParamValue(0.4f);
					} else if (param.getParameterName().equals(ParamConstants.PERIOD)) {
						mp.setParamValue(5);
					}
				} else if (param.getModel().getModelName().equals(ParamConstants.MOVING_AVERAGE)) {
					if (param.getParameterName().equals(ParamConstants.PERIOD)) {
						mp.setParamValue(5);
					}					
				} else if (param.getModel().getModelName().equals(ParamConstants.SINGLE_EXPONENTIAL)) {
					if (param.getParameterName().equals(ParamConstants.ALPHA)) {
						mp.setParamValue(0.2f);
					}					
				} else if (param.getModel().getModelName().equals(ParamConstants.DOUBLE_EXPONENTIAL)) {
					if (param.getParameterName().equals(ParamConstants.ALPHA)) {
						mp.setParamValue(0.2f);
					} else if (param.getParameterName().equals(ParamConstants.BETA)) {
						mp.setParamValue(0.2f);
					}							
				} else if (param.getModel().getModelName().equals(ParamConstants.CROSTON_VARIANT)) {
					if (param.getParameterName().equals(ParamConstants.ALPHA)) {
						mp.setParamValue(0.2f);
					} else if (param.getParameterName().equals(ParamConstants.BETA)) {
						mp.setParamValue(0.2f);
					}						
				} else if (param.getModel().getModelName().equals(ParamConstants.LINEAR_REGRESSION)) {
					mp.setParamId(param.getId());
					mp.setParamName(param.getParameterName());
					mp.setParamValue(0);
				}
				result.add(mp);
			}
		}
		
		params.setModelParams(result);
		
		ModelEditConfig mec = modelEditConfigRepo.getModelEditConfig(regionId, countryId, hubId, modelId);
		if (mec == null) {
			params.setNormalForecast(true);
			params.setBaselinePercentageAdjustment(false);
		} else {
			params.setNormalForecast(mec.getNormalForecast());
			params.setBaselinePercentageAdjustment(mec.getBaselineAdjustment());
			params.setPercentage(mec.getPercentage());
		}
		
		logger.info("SparesForecastStatisticalService: Exiting getStatistcalModelParams() method");
		return params;
	}

	public StatisticalAdjustmentCombo getAdjustments(int regionId, int countryId, int hubId, int months) {
		logger.info("SparesForecastStatisticalService: Entering getIntelligenceOrAdjustment() method");
		StatisticalAdjustmentCombo data = new StatisticalAdjustmentCombo();
		List<String> monthYearList = getMonthYearList();
		List<StatisticalAdjustments> ssaList = ssaRepository.getStatisticalAdjustments(regionId, countryId, hubId,
				monthYearList);
		/*
		 * if( regionId==2 && countryId==3 && hubId ==1) { StatisticalAdjustments
		 * stObject = new StatisticalAdjustments();
		 * stObject.setCountry(ssaList.get(0).getCountry());
		 * stObject.setHub(ssaList.get(0).getHub());
		 * stObject.setRegion(ssaList.get(0).getRegion());
		 * stObject.setMonthYear("May-2019"); stObject.setValue(0);
		 * ssaList.add(stObject); }
		 */

		populate(data, ssaList, monthYearList);
		StatisticalAdjustmentCombo adjustmentData = addSixMonthDataForAdjustment(data);
		logger.info("SparesForecastStatisticalService: Exiting getIntelligenceOrAdjustment() method");
		return adjustmentData;
	}

	private StatisticalAdjustmentCombo addSixMonthDataForAdjustment(StatisticalAdjustmentCombo adjustmentData) {
		List<MonthDataUnit> ObjectValuesList = adjustmentData.getAdjustmentValues();
		List<String> sixMonthYearValuesLst = new ConsensusService().prepareSixMonthYearList();
		List<MonthDataUnit> monthList = new LinkedList<>();
		StatisticalAdjustmentCombo adjustmentDataNew = new StatisticalAdjustmentCombo();
		int count = 0;
		String name = null;
		String year = null;
		Date date = new Date();

		if (ObjectValuesList.size() > 0) {
			for (String value : sixMonthYearValuesLst) {
				name = value.substring(0, value.indexOf(" "));
				year = value.substring(value.indexOf(" ") + 1, value.length());
				count = getObjectIndexFromList(ObjectValuesList, name);

				if (count >= 0) {
					MonthDataUnit monthObject = ObjectValuesList.get(count);
					MonthDataUnit monthObjectNew = new MonthDataUnit();
					monthObjectNew.setMonth(monthObject.getMonth());
					monthObjectNew.setValue(monthObject.getValue());
					monthObjectNew.setYear(monthObject.getYear());
					monthObjectNew.setMonthValue(monthObject.getMonthValue());
					monthList.add(monthObjectNew);

				} else if (count < 0) {
					MonthDataUnit monthObjectNew = new MonthDataUnit();
					monthObjectNew.setMonth(name);
					monthObjectNew.setValue(0);
					monthObjectNew.setYear(Integer.parseInt(year));
					monthList.add(monthObjectNew);
					try {
						date = new SimpleDateFormat("MMMM").parse(name);
					} catch (ParseException e) {
						e.printStackTrace();
					}
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					monthObjectNew.setMonthValue(cal.get(Calendar.MONTH));
				}

			}
		}
		adjustmentData.setAdjustmentValues(monthList);
		adjustmentData.setMonthYearMetaData(sixMonthYearValuesLst);
		return adjustmentData;
	}

	private int getObjectIndexFromList(List<MonthDataUnit> objectValuesList, String name) {
		int index = 0;
		String monthName = "";
		for (MonthDataUnit obj : objectValuesList) {
			if (name.equalsIgnoreCase(obj.getMonth())) {
				return index;
			}
			index++;
		}
		return -1;
	}

	@Transactional
	public void updateAdjustments(int regionId, int countryId, int hubId,
			StatisticalAdjustmentUpdateCombo adjustments) {
		logger.info("SparesForecastStatisticalService: Entering updateAdjustments() method");

		StatisticalAdjustments entity = null;
		Country c = new Country();
		c.setCountryId(countryId);

		Region r = new Region();
		r.setRegionId(regionId);

		HubSc h = new HubSc();
		h.setHubId(hubId);
		h.setCountry(c);
		h.setRegion(r);

		List<MonthDataUnitUpdate> newValues = adjustments.getAdjustmentValues();
		for (MonthDataUnitUpdate newValue : newValues) {

			entity = new StatisticalAdjustments();
			entity.setRegion(r);
			entity.setCountry(c);
			entity.setHub(h);
			entity.setFlag(1);
			entity.setValue(newValue.getValue());

			String month = newValue.getMonth();
			int year = newValue.getYear();
			entity.setMonthYear(month + "-" + (year + ""));
			entity.setCreatedDate(new Date());
			entity.setModifiedDate(new Date());

			ssaRepository.updateStatisticalAdjustments(regionId, countryId, hubId, month + "-" + (year + ""));
			ssaRepository.save(entity);
		}

		logger.info("SparesForecastConsensusService: Exiting updateAdjustments() method");
	}

	private void populate(StatisticalAdjustmentCombo data, List<StatisticalAdjustments> ssaList,
			List<String> monthYearList) {

		if (ssaList.isEmpty()) {
			for (String mYear : monthYearList) {
				String monthYear = getProperMonthYear(mYear);
				data.getMonthYearMetaData().add(monthYear);
				MonthDataUnit mdu = new MonthDataUnit();

				String[] parts = monthYear.split(" ");
				mdu.setMonth(parts[0]);
				mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
				mdu.setYear(Integer.parseInt(parts[1]));
				mdu.setValue(0);

				data.getAdjustmentValues().add(mdu);
			}
		} else {
			for (StatisticalAdjustments ssa : ssaList) {
				String monthYear = getProperMonthYear(ssa.getMonthYear());
				data.getMonthYearMetaData().add(monthYear);

				MonthDataUnit mdu = new MonthDataUnit();

				String[] parts = monthYear.split(" ");
				mdu.setMonth(parts[0]);
				logger.info("\n\nmonthValueReverseMap: " + monthValueReverseMap);
				logger.info("\n\nparts[0]: " + parts[0] + "\n\n");
				mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
				mdu.setYear(Integer.parseInt(parts[1]));
				mdu.setValue(ssa.getValue());

				data.getAdjustmentValues().add(mdu);
			}
		}
	}

	private String getProperMonthYear(String my) {
		StringBuffer properMonthYear = new StringBuffer("");
		String[] parts = my.split("-");
		properMonthYear.append(parts[0]);
		properMonthYear.append(" ");
		properMonthYear.append(parts[1]);
		return properMonthYear.toString();
	}

	public ContainerStatisticalBaselineForecastCombo getBaseForecast(int regionId, int countryId, int hubId,
			int months) {
		ContainerStatisticalBaselineForecastCombo data = new ContainerStatisticalBaselineForecastCombo();
		List<String> myList = getMonthYearList();
		
		List<StatisticalForecast> list = new ArrayList<>();
		
		System.out.println("\n\n\n\n");
		System.out.println("Checking config model...");
		List<StatisticalForecastConfig> configuredModel = configRepository.getConfiguredModel(regionId, countryId, hubId);
		
		if (configuredModel != null && configuredModel.size() > 0) {
			
			System.out.println("regionId: " + regionId);
			System.out.println("countryId: " + countryId);
			System.out.println("hubId: " + hubId);
			System.out.println("Fetching configmodel data...ModelID = " + configuredModel.get(0).getConfiguredModel().getModelId() + "\n\n\n");
			list = cfsRepository.getStatisticalBaseForecast(regionId, countryId, hubId,
					configuredModel.get(0).getConfiguredModel().getModelId(), myList);
		} else {
			List<StatisticalForecastBestFit> bestFitModel = bestFitRepository.getBestFitModel(regionId, countryId,
					hubId);
			if (bestFitModel != null && bestFitModel.size() > 0) {
				System.out.println("\n\n\n\n Fetching best fit model data...\n\n\n");
				list = cfsRepository.getStatisticalBaseForecast(regionId, countryId, hubId,
						bestFitModel.get(0).getBestFitModel().getModelId(), myList);
			}
		}
		
		populate(data, list, myList);
		ContainerStatisticalBaselineForecastCombo statisticalData = addSixMonthData(data);
		return statisticalData;
	}

	private ContainerStatisticalBaselineForecastCombo addSixMonthData(
			ContainerStatisticalBaselineForecastCombo statisticalData) {
		List<MonthDataUnit> ObjectValuesList = statisticalData.getBaselineForecast();
		List<String> sixMonthYearValuesLst = new ConsensusService().prepareSixMonthYearList();
		List<MonthDataUnit> monthList = new LinkedList<>();
		ContainerStatisticalBaselineForecastCombo statisticalDataObjNew = new ContainerStatisticalBaselineForecastCombo();
		int count = 0;
		String name = null;
		String year = null;
		Date date = new Date();

		if (ObjectValuesList.size() > 0) {
			for (String value : sixMonthYearValuesLst) {
				name = value.substring(0, value.indexOf(" "));
				year = value.substring(value.indexOf(" ") + 1, value.length());
				count = getObjectIndexFromList(ObjectValuesList, name);

				if (count >= 0) {
					MonthDataUnit monthObject = ObjectValuesList.get(count);
					MonthDataUnit monthObjectNew = new MonthDataUnit();
					monthObjectNew.setMonth(monthObject.getMonth());
					monthObjectNew.setValue(monthObject.getValue());
					monthObjectNew.setYear(monthObject.getYear());
					monthObjectNew.setMonthValue(monthObject.getMonthValue());
					monthList.add(monthObjectNew);

				} else if (count < 0) {
					MonthDataUnit monthObjectNew = new MonthDataUnit();
					monthObjectNew.setMonth(name);
					monthObjectNew.setValue(0);
					monthObjectNew.setYear(Integer.parseInt(year));
					monthList.add(monthObjectNew);
					try {
						date = new SimpleDateFormat("MMMM").parse(name);
					} catch (ParseException e) {
						e.printStackTrace();
					}
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					monthObjectNew.setMonthValue(cal.get(Calendar.MONTH));
				}

			}
		}
		statisticalDataObjNew.setBaselineForecast(monthList);
		statisticalDataObjNew.setMonthYearMetaData(sixMonthYearValuesLst);
		return statisticalDataObjNew;
	}

	private List<String> getMonthYearList() {
		List<String> monthYearList = new ArrayList<>();

		Calendar c = Calendar.getInstance();

		// 10, 11, 0, 1, 2, 3

		int startingMonth = c.get(Calendar.MONTH);
		int nextMonth = startingMonth;
		boolean isChangeInYear = false;

		for (int i = 0; i < 6; i++) {
			System.out.println(nextMonth);
			String year = isChangeInYear ? ("" + (c.get(Calendar.YEAR) + 1)) : ("" + c.get(Calendar.YEAR));
			monthYearList.add(monthValueMap.get(nextMonth) + "-" + year);
			nextMonth = nextMonth + 1;
			int mod = nextMonth % 11;
			if ((nextMonth > 11) && mod > 0) {
				isChangeInYear = true;
				nextMonth = mod - 1;
			}
		}

		return monthYearList;
	}

	private List<String> getNext6MonthYearList() {
		List<String> monthYearList = new ArrayList<>();

		Calendar c = Calendar.getInstance();

		// 10, 11, 0, 1, 2, 3

		int startingMonth = c.get(Calendar.MONTH) + 1;
		int nextMonth = startingMonth;
		boolean isChangeInYear = false;

		for (int i = 0; i < 6; i++) {
			int mod = nextMonth % 11;
			if ((nextMonth > 11) && mod > 0) {
				isChangeInYear = true;
				nextMonth = mod - 1;
			}
			System.out.println(nextMonth);
			String year = isChangeInYear ? ("" + (c.get(Calendar.YEAR) + 1)) : ("" + c.get(Calendar.YEAR));
			monthYearList.add(monthValueMap.get(nextMonth) + "-" + year);
			nextMonth = nextMonth + 1;

		}

		return monthYearList;
	}

	private void populate(ContainerStatisticalBaselineForecastCombo data, List<StatisticalForecast> list,
			List<String> monthYearList) {

		for (String givenMY : monthYearList) {
			data.getMonthYearMetaData().add(getProperMonthYear(givenMY));
		}

		if (list.isEmpty()) {
			for (String mYear : monthYearList) {
				String monthYear = getProperMonthYear(mYear);
				// data.getMonthYearMetaData().add(monthYear);
				MonthDataUnit mdu = new MonthDataUnit();

				String[] parts = mYear.split("-");
				mdu.setMonth(parts[0]);
				mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
				mdu.setYear(Integer.parseInt(parts[1]));
				mdu.setValue(0);

				data.getBaselineForecast().add(mdu);
			}
		} else {
			for (StatisticalForecast sca : list) {
				String monthYear = getProperMonthYear(sca.getForecastMonth());
				// data.getMonthYearMetaData().add(monthYear);

				MonthDataUnit mdu = new MonthDataUnit();

				String[] parts = sca.getForecastMonth().split("-");
				mdu.setMonth(parts[0]);
				mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
				mdu.setYear(Integer.parseInt(parts[1]));
				mdu.setValue(sca.getForecastValue());

				data.getBaselineForecast().add(mdu);
			}
		}

	}

	public StatisticalForecastModelOutput getForecastModels(int regionId, int countryId, int hubId) {
		logger.info("ContainerForecastStatisticalService: Entering getForecastModels() method");
		StatisticalForecastModelOutput data = new StatisticalForecastModelOutput();
		List<String> monthYearList = getMonthYearList();

		for (String givenMY : monthYearList) {
			data.getMonthYearMetaData().add(getProperMonthYear(givenMY));
		}

		List<TempModelOutput> modelOuput = specialForecastRepository.getTempForecastModels1(regionId, countryId, hubId,
				monthYearList);
		List<TempConfigModel> configModel = specialForecastRepository.getTempConfigModels(regionId, countryId, hubId,
				monthYearList);

		System.out.println("\n\nRegionID: " + regionId);
		System.out.println("CountryID: " + countryId);
		System.out.println("HubID: " + hubId);
		System.out.println("monthYearList" + monthYearList + "\n\n");
		System.out.println("Calling specialForecastRepository.getTempBestFitModels...\n\n");
		List<TempBestFitModel> bestFitModel = specialForecastRepository.getTempBestFitModels(regionId, countryId, hubId,
				monthYearList);

		Integer configuredModelId = 0;
		Integer bestFitModelId = 0;
		if (!configModel.isEmpty()) {
			configuredModelId = configModel.get(0).getConfigModelId();
			for (TempConfigModel cm : configModel) {
				if (cm.getConfigModelId() != null) {
					configuredModelId = cm.getConfigModelId();
					break;
				}
			}
		}
		if (!bestFitModel.isEmpty()) {
			for (TempBestFitModel bft : bestFitModel) {
				if (bft.getBestFitModelId() != null) {
					bestFitModelId = bft.getBestFitModelId();
					break;
				}
			}
		}

		Map<Integer, SingleModelOutput> modelOutMap = new HashMap<>();
		Map<String, MonthDataUnit> monthDataMap = new HashMap<>();

		for (TempModelOutput tmOutput : modelOuput) {
			String monthYear = getProperMonthYear(tmOutput.getMonthYear());
			// data.getMonthYearMetaData().add(monthYear);

			SingleModelOutput smo = modelOutMap.get(tmOutput.getModelId());

			if (smo == null) {
				smo = new SingleModelOutput();
				smo.setModelId(tmOutput.getModelId());
				smo.setModelName(tmOutput.getModelName());
				List<MonthDataUnit> monthData = new ArrayList<>();
				smo.setMonthData(monthData);
				data.getModelOutput().add(smo);
				modelOutMap.put(tmOutput.getModelId(), smo);
			}

			MonthDataUnit mdu = monthDataMap.get(tmOutput.getMonthYear() + tmOutput.getModelId());
			if (mdu == null) {
				mdu = new MonthDataUnit();
				String[] parts = tmOutput.getMonthYear().split("-");
				mdu.setMonth(parts[0]);
				mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
				mdu.setYear(Integer.parseInt(parts[1]));
				mdu.setValue(tmOutput.getForecastValue());
				smo.getMonthData().add(mdu);
				monthDataMap.put(tmOutput.getMonthYear() + tmOutput.getModelId(), mdu);
			}

			String techniqueName = tmOutput.getTechniqueName();
			if (techniqueName.equals("MAPE")) {
				smo.setMapePercent(tmOutput.getValue());
			} else if (techniqueName.equals("MAD")) {
				smo.setMadPercent(tmOutput.getValue());
			} else if (techniqueName.equals("RMSE")) {
				smo.setRmsePercent(tmOutput.getValue());
			}

			if (tmOutput.getModelId() == configuredModelId) {
				smo.setConfigured(true);
			}

			if (tmOutput.getModelId() == bestFitModelId) {
				smo.setBestFit(true);
			}
		}
		/*if modelOutput is blank then add 0 for all models*/
		if(modelOuput.size() <=0 && configModel.size() <=0)
			populateDefaultValueForAllModel(data);
		logger.info("ContainerForecastStatisticalService: Exiting getForecastModels() method");
		return data;
	}
	
	private void populateDefaultValueForAllModel(StatisticalForecastModelOutput data) {
		List<SingleModelOutput> modelOutput = new ArrayList<>();
		List<String> monthMetaData = data.getMonthYearMetaData();
		List<MonthDataUnit> monthData = new ArrayList<>();
		MonthDataUnit monthObj = null;
		List<StatisticalModelMaster> modelList = specialForecastRepository.getModels();
		Iterator it = modelList.iterator();
		int index =0;
		
		for(int i=0;i<8;i++) {
			SingleModelOutput singleModelOutput = new SingleModelOutput();
			singleModelOutput.setBestFit(false);
			singleModelOutput.setConfigured(false);
			singleModelOutput.setMadPercent(0);
			singleModelOutput.setMapePercent(0);
			singleModelOutput.setRmsePercent(0);
			
			modelOutput.add(singleModelOutput);
		}
		
		while(it.hasNext()) {
			SingleModelOutput singleModelOutput = new SingleModelOutput();
			Object[] object = (Object[]) it.next();
			singleModelOutput = modelOutput.get(index);
			singleModelOutput.setModelId(Integer.parseInt(object[0].toString()));
			singleModelOutput.setModelName(object[1].toString());
			index++;
		}
		
			for(String month : monthMetaData) {
				monthObj = new MonthDataUnit();
				String[] parts = month.split(" ");
				monthObj.setMonth(parts[0]);
				monthObj.setMonthValue(monthValueReverseMap.get(parts[0]));
				monthObj.setYear(Integer.parseInt(parts[1]));
				monthObj.setValue(0);
				
				monthData.add(monthObj);
			}
			
			for(SingleModelOutput singleModelOutput : modelOutput) {
			 singleModelOutput.setMonthData(monthData);
		}
		data.setModelOutput(modelOutput);
		
	}

	public PythonResponseObject updateStatistcalModelParams(PythonRequestObject pythonRequestObject) {
		return (externalService.callOnDemandContainerService(pythonRequestObject));
	}

	public List<PythonResponseObject> processPython(PythonRequestObject onDemandContainerPojo) {
		List<PythonResponseObject> list = new ArrayList<>();
		PythonResponseObject data = new PythonResponseObject();

		data.setMadPercent(4);
		data.setMapPercent(0);
		data.setRmsePercent(0);

		data.setModelId(1);
		data.setModelName("SimpleAverage");

		List<MonthDataUnit> monthData = new ArrayList<>();

		MonthDataUnit mdu = new MonthDataUnit();
		mdu.setMonth("Dec");
		mdu.setMonthValue(11);
		mdu.setYear(2018);
		mdu.setValue(65);

		monthData.add(mdu);

		data.setMonthData(monthData);
		list.add(data);

		return list;
	}

}
