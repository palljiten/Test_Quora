package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class SparesStatisticalAdjustmentRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Valid
	@NotNull
	@NotEmpty
	private List<SparesStatisticalAdjustmentRequestUnit> adjustmentValues = new ArrayList<>();

	public List<SparesStatisticalAdjustmentRequestUnit> getAdjustmentValues() {
		return adjustmentValues;
	}

	public void setAdjustmentValues(List<SparesStatisticalAdjustmentRequestUnit> adjustmentValues) {
		this.adjustmentValues = adjustmentValues;
	}

}
