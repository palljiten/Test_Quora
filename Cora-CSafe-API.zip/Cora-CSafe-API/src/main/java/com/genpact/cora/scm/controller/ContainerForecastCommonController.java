package com.genpact.cora.scm.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.PythonRequestObject;
import com.genpact.cora.scm.dto.PythonResponseObject;
import com.genpact.cora.scm.repository.BudgetHubLevelPercentageRepository;
import com.genpact.cora.scm.service.ContainerForecastStatisticalService;
import com.genpact.cora.scm.service.IContainerForecastService;
import com.genpact.cora.scm.util.EmailUtil;

@RestController
@RequestMapping(value = "/scm")
public class ContainerForecastCommonController {

	private static final Logger logger = LoggerFactory.getLogger(ContainerForecastCommonController.class);
	
	@Autowired
	IContainerForecastService containerForecastService;
	
	@Autowired
	ContainerForecastStatisticalService cfService;
	
	@GetMapping(value = "/orders" , produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object>  getOrders(){
		
		List<String> orders = null;//containerForecastService.getOrders();
		
		return new ResponseEntity<>(orders, HttpStatus.OK);
	}
	
	@GetMapping(value = "/sendmail" , produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object>  sendMail(){
		EmailUtil mailService = new EmailUtil();
		return new ResponseEntity<>(null, HttpStatus.OK);
	}	
	
}
