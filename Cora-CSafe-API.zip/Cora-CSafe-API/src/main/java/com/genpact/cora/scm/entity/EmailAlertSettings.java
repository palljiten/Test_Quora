package com.genpact.cora.scm.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "[dbo].[tbl_VANotificationSettings]")
public class EmailAlertSettings {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;
	
	@Column(name = "AccountName")
	private String accountName;
	
	@Column(name = "KPI")
	private String kpi;
	
	@Column(name = "Status")
	private String status;
	
	@Column(name = "NotificationDay")
	private int notificationDay;
	
	@Column(name = "EstimatedReceivingDay")
	private int estimatedReceivingDay;
	
	@Column(name = "EscalationDay")
	private int escalationDay;
	
	@Column(name = "Createddate")
	private Date emailSubject;
	
	@Column(name = "ModifiedDate")
	private Date emailContent;
	
	@Column(name = "ModifiedBy")
	private String modifiedBy;
	
	@Column(name = "Flag")
	private Boolean flag;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	public String getKpi() {
		return kpi;
	}

	public void setKpi(String kpi) {
		this.kpi = kpi;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getNotificationDay() {
		return notificationDay;
	}

	public void setNotificationDay(int notificationDay) {
		this.notificationDay = notificationDay;
	}

	public int getEstimatedReceivingDay() {
		return estimatedReceivingDay;
	}

	public void setEstimatedReceivingDay(int estimatedReceivingDay) {
		this.estimatedReceivingDay = estimatedReceivingDay;
	}

	public int getEscalationDay() {
		return escalationDay;
	}

	public void setEscalationDay(int escalationDay) {
		this.escalationDay = escalationDay;
	}

	public Date getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(Date emailSubject) {
		this.emailSubject = emailSubject;
	}

	public Date getEmailContent() {
		return emailContent;
	}

	public void setEmailContent(Date emailContent) {
		this.emailContent = emailContent;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Boolean getFlag() {
		return flag;
	}

	public void setFlag(Boolean flag) {
		this.flag = flag;
	}
	
}
