package com.genpact.cora.scm.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "config.slf4jfilter")
public class CSafeMDCFilterConfiguration {

    public static final String CSAFE_RESPONSE_TOKEN_HEADER = "response_token";
    public static final String CSAFE_REQUEST_UUID_HEADER = "request_token";
    public static final String CSAFE_MDC_UUID_TOKEN_KEY = "CSafeMDCFilter.UUID";

    private String responseHeader = CSAFE_RESPONSE_TOKEN_HEADER;
    private String mdcTokenKey = CSAFE_MDC_UUID_TOKEN_KEY;
    private String requestHeader = CSAFE_REQUEST_UUID_HEADER;

	@Bean
    public FilterRegistrationBean<CSafeMDCFilter> servletRegistrationBean() {
        final FilterRegistrationBean<CSafeMDCFilter> registrationBean = new FilterRegistrationBean<>();
        final CSafeMDCFilter log4jMDCFilterFilter = new CSafeMDCFilter(responseHeader, mdcTokenKey, requestHeader);
        registrationBean.setFilter(log4jMDCFilterFilter);
        registrationBean.setOrder(2);
        return registrationBean;
    }
}