package com.genpact.cora.scm.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.HubBudget;
import com.genpact.cora.scm.dto.HubBudgetResponse;
import com.genpact.cora.scm.dto.HubBudgetUpdateDTO;
import com.genpact.cora.scm.dto.HubLavelPercentage;
import com.genpact.cora.scm.dto.HubLavelPercentageResponse;
import com.genpact.cora.scm.dto.RegionBudget;
import com.genpact.cora.scm.dto.RegionHubBudgetResponse;
import com.genpact.cora.scm.dto.SingleHubBudget;
import com.genpact.cora.scm.entity.BudgetHubLevelPercentage;
import com.genpact.cora.scm.entity.BudgetTopDownConfig;
import com.genpact.cora.scm.repository.BudgetForecastSPRepository;
import com.genpact.cora.scm.repository.BudgetHubLevelPercentageRepository;
import com.genpact.cora.scm.repository.BudgetTopDownConfigRepository;

@Service
public class TopDownConfigService {

	private static Logger logger = LoggerFactory.getLogger(TopDownConfigService.class);
	
	@Autowired
	BudgetHubLevelPercentageRepository bhlpRepository; 
	
	@Autowired
	BudgetTopDownConfigRepository btdcRepository; 
	
	@Autowired
	BudgetForecastSPRepository bfspRepository;
	
	@Transactional
	public void updateBudgetTopDownConfig(HubBudgetUpdateDTO hubBudgets) {
		
		Integer regionId = hubBudgets.getRegionId();
		logger.info("\n\nregionId : " + regionId);
		for (HubBudget hubBudget : hubBudgets.getHubBudgetList()) {
			BudgetTopDownConfig entity = new BudgetTopDownConfig();
			logger.info("\n\ncountryId : hubId " + hubBudget.getCountryId() + ":" + hubBudget.getHubId());
			entity.setRegionId(regionId);
			entity.setCountryId(hubBudget.getCountryId());
			entity.setHubId(hubBudget.getHubId());
			entity.setPercentage(hubBudget.getBudgetPercentage());
			entity.setFlag(1);
			entity.setCreatedDate(new Date());
			btdcRepository.save(entity);
		}
		
		bhlpRepository.callBudgetForecastSP();
	}
	
	public RegionHubBudgetResponse getHubBudgetsForAllRegions() {
		logger.info("TopDownConfigService: Entering getHubBudgetsForAllRegions() method");
		RegionHubBudgetResponse data = new RegionHubBudgetResponse();
		List<BudgetHubLevelPercentage> budgetList = bhlpRepository.getBudgetHubLevelPercentage();
		populate(data, budgetList);
		logger.info("TopDownConfigService: Exiting getHubBudgetsForAllRegions() method");
		return data;
	}
	
	private void populate(RegionHubBudgetResponse data, List<BudgetHubLevelPercentage> budgetList) {
		for (BudgetHubLevelPercentage budget : budgetList) {
			Integer regionId = budget.getRegion().getRegionId();
			String regionName = budget.getRegion().getRegionName().trim();
			data.getRegionNames().add(regionName);
			HubBudgetResponse hbr = data.getRegionHubBudgets().get(regionName);
			
			if (hbr == null) {
				hbr = new HubBudgetResponse();
				hbr.setRegionId(regionId);
				hbr.setRegionName(regionName);
				data.getRegionHubBudgets().put(regionName, hbr);
			}
			
			SingleHubBudget shb = new SingleHubBudget();
			shb.setHubId(budget.getHub().getHubId());
			shb.setHubCode(budget.getHub().getHubCode());
			shb.setHubType(budget.getHub().getLocationType());
			shb.setHubState(budget.getHub().getState());
			shb.setHubCountryId(budget.getCountry().getCountryId());
			shb.setHubCountryName(budget.getCountry().getCountryName());
			shb.setBudgetPercentage(budget.getPercentage());
			
			hbr.getHubBudgets().add(shb);
		}
	}
	
	/**
	 * @return
	 * To find regionsId , regionsName and total percentage of that regions.
	 */
	public HubLavelPercentageResponse getRegionDetails(){
		HubLavelPercentageResponse hlpr = new HubLavelPercentageResponse();
		List<RegionBudget> regionsDetails;
		List<HubLavelPercentage> hLPList= new ArrayList<HubLavelPercentage>();
		regionsDetails = bhlpRepository.findRegionBudgetValues();
		
		if(null!= regionsDetails && !regionsDetails.isEmpty() ){
			String numAsStr ="";
			double number =0f;
			for(RegionBudget rb:regionsDetails){
				HubLavelPercentage hlp = new HubLavelPercentage();
				hlp.setRegionId(rb.getRegionId());
				hlp.setRegionName(rb.getRegionName());
				number = rb.getBudgetPercent();
				if(number>0)
					numAsStr = String.format ("%.2f", number);
				hlp.setBudgetPercentage(numAsStr);
				
				hLPList.add(hlp);
			}
				
		}
		hlpr.setRegionBudgets(hLPList); 
		return hlpr;
	}
}
