package com.genpact.cora.scm.dto;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;

@ApiModel
public class ContainerForecastWeeklyAdjustments {
	@Valid
	@NotNull
	@NotEmpty
	@JsonProperty("weekMetaData")
	private List<WeekMetaData> weekMetaData = null;
	@Valid
	@NotNull
	@NotEmpty
	@JsonProperty("region")
	private Map<String, Object> region;
	@Valid
	@NotNull
	@NotEmpty
	@JsonProperty("country")
	private Map<String, Object> country;
	@Valid
	@NotNull
	@NotEmpty
	@JsonProperty("hub")
	private Map<String, Object> hub;
	@Valid
	@NotNull
	@NotEmpty
	@JsonProperty("adjustmentValues")
	private List<WeekData> adjustmentValues = null;

	public List<WeekMetaData> getWeekMetaData() {
		return weekMetaData;
	}

	public void setWeekMetaData(List<WeekMetaData> weekMetaData) {
		this.weekMetaData = weekMetaData;
	}

	public List<WeekData> getAdjustmentValues() {
		return adjustmentValues;
	}

	public void setAdjustmentValues(List<WeekData> adjustmentValues) {
		this.adjustmentValues = adjustmentValues;
	}

	public Map<String, Object> getRegion() {
		return region;
	}

	public void setRegion(Map<String, Object> region) {
		this.region = region;
	}

	public Map<String, Object> getCountry() {
		return country;
	}

	public void setCountry(Map<String, Object> country) {
		this.country = country;
	}

	public Map<String, Object> getHub() {
		return hub;
	}

	public void setHub(Map<String, Object> hub) {
		this.hub = hub;
	}
}
