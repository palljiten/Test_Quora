package com.genpact.cora.scm.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.DemandAlloactionEditRequest;
import com.genpact.cora.scm.dto.DemandAllocationHub;
import com.genpact.cora.scm.dto.DemandAllocationResponse;
import com.genpact.cora.scm.dto.FinalDemandForecastResponse;
import com.genpact.cora.scm.dto.InventoryStatusResponse;
import com.genpact.cora.scm.dto.WeekStartDate;
import com.genpact.cora.scm.entity.DemandAllocationForecast;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.DemandAllocationEditRepository;
import com.genpact.cora.scm.repository.DemandAllocationForecastRepository;
import com.genpact.cora.scm.repository.DemandAllocationForecastSPRepository;
import com.genpact.cora.scm.repository.DemandAllocationRepository;
import com.genpact.cora.scm.repository.DemandAllocationSPRepository;
import com.genpact.cora.scm.repository.HubRepository;
import com.genpact.cora.scm.repository.IDemandAllocationForecastSP;
import com.genpact.cora.scm.repository.StoredProcedureRepository;
import com.genpact.cora.scm.repository.VABalanceInHandRepository;
import com.genpact.cora.scm.repository.WeeklyForecastRepository;

@Service
public class DemandAllocationService {

	@Autowired
	DemandAllocationRepository allocationRepository;

	@Autowired
	WeeklyForecastRepository weeklyForecastRepository;

	@Autowired
	VABalanceInHandRepository vABalanceInHandRepository;

	@Autowired
	HubRepository hubRepository;

	@Autowired
	DemandAllocationEditRepository allocationEditRepository;

	@Autowired
	DemandAllocationForecastRepository allocationForecastRepository;
	
	@Autowired
	IDemandAllocationForecastSP oDemandAllocationForecastSP;
	
	@Autowired
	DemandAllocationForecastSPRepository dafSpRepo;
	
	@Autowired
	DemandAllocationSPRepository daspRepo;

	public DemandAllocationResponse getDemandAllocation(Integer regionID, Integer countryID, Integer hubID,
			Integer weeks) throws CSafeServiceException {

		HubSc hubSc = hubRepository.findById(hubID).get();
		FinalDemandForecastResponse demandForecastResponse = getFinalDemandForecast(regionID, countryID, hubID, weeks);
		DemandAllocationResponse allocationResponse = new DemandAllocationResponse();
		Map<String, Object> otherProp = new HashMap<>();
		List<Map<String, String>> weekMetaDatas = new ArrayList<>();
		Map<String, String> weekMetaData;
		for (String weekNum : demandForecastResponse.getValues().keySet()) {
			weekMetaData = new LinkedHashMap<>();
			weekMetaData.put("weekNum", weekNum);
			weekMetaData.put("weekStartDate", demandForecastResponse.getValues().get(weekNum).getStartDate());
			weekMetaDatas.add(weekMetaData);
		}
		allocationResponse.setWeekMetaData(weekMetaDatas);
		DemandAllocationHub hub = new DemandAllocationHub();
		hub.setHubId(hubSc.getHubId());
		hub.setHubCode(hubSc.getHubCode());
		Map<String, Integer> hubValues = demandForecastResponse.getFinalDemandForecast();
		String startWeekOfMonth = getStartDateOfAWeekForCurrentMonth();

		hub.setHubData(hubValues);
		Map<String, Object> hubOthers = new HashMap<>();
		List<String> parentShippers = new ArrayList<>();
		List<DemandAllocationForecast> parents = allocationForecastRepository.getParentShippers(regionID, countryID,
				hubID);
		parents.forEach((v) -> {
			parentShippers.add(v.getParentShipper());
			Map<String, Object> shipperOther = new LinkedHashMap<>();
			List<Object[]> psValues = allocationForecastRepository.getParentShippersValue(regionID, countryID, hubID,
					v.getParentShipper(), weeks,startWeekOfMonth);
			Map<String, Integer> shipperVals = new LinkedHashMap<>();
			for (Object[] objects : psValues) {
				if(objects[2] == null)
					continue;
				if (objects[0] != null) {
					Integer val = (Math.round(Float.valueOf(objects[0].toString())));
					shipperVals.put("wk-" + objects[2], val);
				} else {
					shipperVals.put("wk-" + objects[2], 0);
				}
			}
			shipperOther.put("shipperData", shipperVals);

			List<String> lane = new ArrayList<>();
			List<DemandAllocationForecast> lanes = allocationForecastRepository.getLanes(regionID, countryID, hubID,
					v.getParentShipper());
			lanes.forEach((v1) -> {
				lane.add(v1.getLane());
				List<Object[]> laneValues = allocationForecastRepository.getLanesValue(regionID, countryID, hubID,
						v1.getParentShipper(), v1.getLane(), weeks,startWeekOfMonth);
				Map<String, Integer> laneVals = new LinkedHashMap<>();
				for (Object[] objects : laneValues) {
					if(objects[2] == null)
						continue;
					if (objects[0] != null) {
						Integer val = (Math.round(Float.valueOf(objects[0].toString())));
						laneVals.put("wk-" + objects[2], val);
					} else {
						laneVals.put("wk-" + objects[2], 0);
					}
				}
				shipperOther.put(v1.getLane(), laneVals);
			});
			shipperOther.put("lanes", lane);
			if(v.getParentShipper() != null)
				hubOthers.put(v.getParentShipper(), shipperOther);
			
		});
		hub.set(hubOthers);
		hub.setParentShippers(parentShippers);
		allocationResponse.setHub(hub);
		allocationResponse.set(otherProp);
		return allocationResponse;
	}

	public String getStartDateOfAWeekForCurrentMonth() {
		Calendar now = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		String sDate1 = now.get(Calendar.YEAR) + "-" + (now.get(Calendar.MONTH) + 1) + "-" + "01";
		Date modifiedDate = new Date();
		// now.setTime(formatter.parse(sDate1));
		try {
			Date date = formatter.parse(sDate1);
			now.setTime(date);
			int day = now.get(Calendar.DAY_OF_WEEK);

			if (day == Calendar.SUNDAY)
				return formatter.format(sDate1);
			else {
				day = 8 - day;
				now.add(Calendar.DATE, day);
				modifiedDate = now.getTime();
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return formatter.format(modifiedDate);
	}

	public InventoryStatusResponse getCurrentInventoryStatus(Integer regionId, Integer countryID, Integer hubId)
			throws CSafeServiceException {
		String firstWeekDateOfMonth = getStartDateOfAWeekForCurrentMonth();
		List<Object[]> thirteenWeekDetailList = vABalanceInHandRepository.getThirteenWeeksDetail(firstWeekDateOfMonth);
		return (prepareJsonResponseForInventory(thirteenWeekDetailList, hubId, regionId, countryID));
	}

	private InventoryStatusResponse prepareJsonResponseForInventory(List<Object[]> thirteenWeekDetailList,
			Integer hubId, Integer regionId, Integer countryID) {
		Iterator it = thirteenWeekDetailList.iterator();
		HubSc hubSc = hubRepository.findById(hubId).get();
		;// getHub(regionId, countryID, hubId);
		InventoryStatusResponse inventoryStatusResponse = new InventoryStatusResponse();
		Set<String> weekMetaDataSet = new LinkedHashSet<>();
		Map<String, Integer> currentInventoryStatusMap = new LinkedHashMap<>();
		String weekNum = "";
		String weekString = "";
		String weekStringWithWK = "";
		SimpleDateFormat sm = new SimpleDateFormat("dd MMM yyyy");
		Map<String, WeekStartDate> values = new LinkedHashMap<>();
		WeekStartDate startDate = null;
		while (it.hasNext()) {
			Object[] weekData = (Object[]) it.next();
			weekString = weekData[0].toString();
			if(weekString.equals("53") && weekData[1].toString().equals("2018"))
				continue;
			weekNum = weekData[1].toString() + weekData[0].toString();
			weekStringWithWK = "wk-" + weekData[0].toString();
			weekMetaDataSet.add(weekStringWithWK);
			Float balanceValueOfAWeek = vABalanceInHandRepository.getCurrentInventoryStatus(weekNum,
					hubSc.getHubCode());
			if (balanceValueOfAWeek != null)
				currentInventoryStatusMap.put(weekStringWithWK, (Math.round(Float.valueOf(balanceValueOfAWeek))));
			else
				currentInventoryStatusMap.put(weekStringWithWK, 0);
			startDate = new WeekStartDate();
			startDate.setStartDate(sm.format((Date) weekData[2]));
			values.put(weekStringWithWK, startDate);
		}
		inventoryStatusResponse.setWeekMetaData(weekMetaDataSet);
		inventoryStatusResponse.setValues(values);
		inventoryStatusResponse.setCurrentInventoryStatus(currentInventoryStatusMap);
		return inventoryStatusResponse;
	}

	public FinalDemandForecastResponse getFinalDemandForecast(Integer regionID, Integer countryID, Integer hubID,
			Integer weeks) throws CSafeServiceException {

		FinalDemandForecastResponse finalDemandForecastResponse = new FinalDemandForecastResponse();
		Set<String> weekMetaDataSet = new LinkedHashSet<>();
		Map<String, Integer> finalDemandForecastMap = new LinkedHashMap<>();
		String weekString = "";
		Map<String, WeekStartDate> values = new LinkedHashMap<>();
		WeekStartDate startDate = null;
		
		/*get thirteen weeks detail*/
		String firstWeekDateOfMonth = getStartDateOfAWeekForCurrentMonth();
		List<Object[]> thirteenWeekDetailList = vABalanceInHandRepository.getThirteenWeeksDetail(firstWeekDateOfMonth);
		
		List<Object[]> forecastData = weeklyForecastRepository.getForecast(weeks, regionID, countryID, hubID,firstWeekDateOfMonth);
		SimpleDateFormat sm = new SimpleDateFormat("dd MMM yyyy");
		for (Object[] object : forecastData) {
			if(object[2] == null)
				continue;
			weekString = "wk-" + object[2].toString();
			startDate = new WeekStartDate();
			startDate.setStartDate(sm.format((Date) object[1]));
			weekMetaDataSet.add(weekString);
			values.put(weekString, startDate);
			if (object[0] != null) {
				Integer val = (Math.round(Float.valueOf(object[0].toString())));
				finalDemandForecastMap.put(weekString, val);
			} else
				finalDemandForecastMap.put(weekString, 0);
		}

		finalDemandForecastResponse.setWeekMetaData(weekMetaDataSet);
		finalDemandForecastResponse.setValues(values);
		finalDemandForecastResponse.setFinalDemandForecast(finalDemandForecastMap);
		return finalDemandForecastResponse;

	}

	@Transactional
	public void updateDemandAllocation(DemandAlloactionEditRequest demandAlloactionEditRequest) {
		HubSc hub = hubRepository.findById(demandAlloactionEditRequest.getHub().getHubId()).get();
		StringBuffer sb = new StringBuffer();

		if (!demandAlloactionEditRequest.getHub().getParentShipperData().isEmpty()
				&& demandAlloactionEditRequest.getHub().getLaneData().isEmpty()) {
			int i = 0;
			
			for (String weekData : demandAlloactionEditRequest.getHub().getParentShipperData().keySet()) {
				if (i != 0)
					sb.append(" & ");
				sb.append("'" + hub.getRegion().getRegionName() + "',");
				sb.append("'" + hub.getCountry().getCountryName() + "',");
				sb.append("'" + hub.getHubCode() + "',");
				sb.append("'" + demandAlloactionEditRequest.getHub().getParentShippers() + "',");
				sb.append("'',");
				sb.append(weekData.split("-")[1] + ",");
				sb.append(demandAlloactionEditRequest.getHub().getParentShipperData().get(weekData));
				i++;
			}
		}
		if (!demandAlloactionEditRequest.getHub().getLaneData().isEmpty()
				&& demandAlloactionEditRequest.getHub().getParentShipperData().isEmpty()) {
			int j = 0;
			sb.append("");
			for (String weekData : demandAlloactionEditRequest.getHub().getLaneData().keySet()) {
				if (j != 0)
					sb.append(" & ");
				sb.append("'" + hub.getRegion().getRegionName() + "',");
				sb.append("'" + hub.getCountry().getCountryName() + "',");
				sb.append("'" + hub.getHubCode() + "',");
				sb.append("'" + demandAlloactionEditRequest.getHub().getParentShippers() + "',");
				sb.append("'" + demandAlloactionEditRequest.getHub().getLane() + "',");
				sb.append(weekData.split("-")[1] + ",");
				sb.append(demandAlloactionEditRequest.getHub().getLaneData().get(weekData));
				j++;
			}
		}
		//oDemandAllocationForecastSP.DemandAllocationForecastSP(sb.toString());
		//dafSpRepo.callDemandAllocationForecastStoredProc(sb.toString());
		//allocationForecastRepository.Test(sb.toString());
		daspRepo.callSP(sb.toString());
		System.out.println("\n\n");
		
		//allocationForecastRepository.DemandAllocationForecastSP(sb.toString());
	}

}
