package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_StatisticalForecast]")
public class StatisticalForecast {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private Integer id;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RegionId")
    private Region region;
    
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CountryId")
    private Country country;
    
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HubId")
    private HubSc hubsc;
    
    @Column(name = "MonthYear", nullable = true, length = 100)
    private String forecastMonth;
    
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ModelId", insertable =  false, updatable = false)
    private StatisticalModel model;
    
    @JoinColumn(name = "ModelId")
    private int modelId;
    
    @Column(name = "ForecastValue", nullable = true)
    private float forecastValue;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CreatedDate", nullable = true)
    private Date createdDate;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modifiedDate", nullable = false, length = 100)
    private Date modifiedDate;
    
    @Column(name = "flag", nullable = false, length = 100)
    private int flag;
    
    @Column(name = "CreatedMonth")
    private String createdMonth;

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHubsc() {
		return hubsc;
	}

	public void setHubsc(HubSc hubsc) {
		this.hubsc = hubsc;
	}

	public String getForecastMonth() {
		return forecastMonth;
	}

	public void setForecastMonth(String forecastMonth) {
		this.forecastMonth = forecastMonth;
	}

	public float getForecastValue() {
		return forecastValue;
	}

	public void setForecastValue(float forecastValue) {
		this.forecastValue = forecastValue;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	public StatisticalModel getModel() {
		return model;
	}

	public void setModel(StatisticalModel model) {
		this.model = model;
	}

	public String getCreatedMonth() {
		return createdMonth;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public void setCreatedMonth(String createdMonth) {
		this.createdMonth = createdMonth;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}
    
}
