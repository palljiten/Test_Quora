package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.Region;

public class ConsensusCorrectionFactorCombo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*private Region region;
	private Country country;
	private HubSc hub;*/
	
	private WeightedAverage weightedAverage;
	private SimpleAverage simpleAverage;
	private List<CorrectionFactor> correctionValues;
	private Set<String> monthYearMetaData;
	private int selectedAverage;
	/*public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}*/

	public WeightedAverage getWeightedAverage() {
		return weightedAverage;
	}

	public void setWeightedAverage(WeightedAverage weightedAverage) {
		this.weightedAverage = weightedAverage;
	}

	public SimpleAverage getSimpleAverage() {
		return simpleAverage;
	}

	public void setSimpleAverage(SimpleAverage simpleAverage) {
		this.simpleAverage = simpleAverage;
	}

	public List<CorrectionFactor> getCorrectionValues() {
		return correctionValues;
	}

	public void setCorrectionValues(List<CorrectionFactor> correctionValues) {
		this.correctionValues = correctionValues;
	}

	public Set<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(Set<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}

	public int getSelectedAverage() {
		return selectedAverage;
	}

	public void setSelectedAverage(int selectedAverage) {
		this.selectedAverage = selectedAverage;
	}
}
