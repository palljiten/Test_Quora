package com.genpact.cora.scm.dto;

public class HubCtLatLong {
	
	private String city;
	private Float latitude;
	private Float longitude;
	
	public HubCtLatLong(String city,Float latitude,Float longitude) {
		this.city = city;
		this.latitude = latitude;
		this.longitude=longitude;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the latitude
	 */
	public Float getLatitude() {
		return latitude;
	}
	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(Float latitude) {
		this.latitude = latitude;
	}
	/**
	 * @return the longitude
	 */
	public Float getLongitude() {
		return longitude;
	}
	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(Float longitude) {
		this.longitude = longitude;
	}
	

}
