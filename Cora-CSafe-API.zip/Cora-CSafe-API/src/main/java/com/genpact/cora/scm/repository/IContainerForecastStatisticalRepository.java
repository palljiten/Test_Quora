package com.genpact.cora.scm.repository;

import java.util.List;

public interface IContainerForecastStatisticalRepository {

	public List<Object[]> getStatistcalModelParam(int modelId);

}
