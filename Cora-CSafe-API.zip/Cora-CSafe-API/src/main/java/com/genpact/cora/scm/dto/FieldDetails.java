package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.genpact.cora.scm.entity.RepairWorkOrderParts;

public class FieldDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private Set<String> regionNames = new TreeSet<>();
	private List<RegionDetail> regionDetails  = new ArrayList<>();
	//private Map<String, HubDetails> hubDetails  = new HashMap<>();
	private Set<Integer> hubIds = new TreeSet<>();
	private List<HubDetails> hubDetails  = new ArrayList<>();
	//private List<RepairWorkOrderParts> partDetails = new ArrayList<>();

	public Set<String> getRegionNames() {
		return regionNames;
	}

	public void setRegionNames(Set<String> regionNames) {
		this.regionNames = regionNames;
	}

	public List<RegionDetail> getRegionDetails() {
		return regionDetails;
	}

	public void setRegionDetails(List<RegionDetail> regionDetails) {
		this.regionDetails = regionDetails;
	}
	
	public List<HubDetails> getHubDetails() {
		return hubDetails;
	}

	public void setHubDetails(List<HubDetails> hubDetails) {
		this.hubDetails = hubDetails;
	}

	public Set<Integer> getHubIds() {
		return hubIds;
	}

	public void setHubIds(Set<Integer> hubIds) {
		this.hubIds = hubIds;
	}

}
