package com.genpact.cora.scm.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.genpact.cora.scm.email.EmailConfigurationRequest;
import com.genpact.cora.scm.email.EmailConfigurationRequest.AlertMailContent;
import com.genpact.cora.scm.email.EmailRequest;
import com.genpact.cora.scm.entity.EmailAlertContent;
import com.genpact.cora.scm.entity.EmailAlertSettings;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.EmailAlertRepository;
import com.genpact.cora.scm.repository.InboundHotBoardRepository;
import com.genpact.cora.scm.repository.LeaseEndHotBoardRepository;
import com.genpact.cora.scm.repository.RepairHotBoardRepository;
import com.genpact.cora.scm.util.DynamicTemplatePersonalization;
import com.sendgrid.Email;
import com.sendgrid.Mail;
import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;

@Service
public class EmailService {
	
	@Value("${spring.sendgrid.api-key}")
	private String sendgridApiKey;

	private static Logger logger = LoggerFactory.getLogger(EmailService.class);
	
	static final String LEASEEND = "lease end";
	static final String REPAIREND = "repair end";
	static final String REPOSITIONING = "repositioning";
	static final String INREPAIR = "in repair";

	@Autowired
	EmailAlertRepository emailRepository;
	
	@Autowired
	LeaseEndHotBoardRepository leaseEndHotBoardRepository;
	
	@Autowired
	InboundHotBoardRepository inboundHotBoardRepository;
	
	@Autowired
	RepairHotBoardRepository repairHotBoardRepository;
	
	public Map<String, Object> getEmailAlertConfigurationData(String hubName, String kpi) throws CSafeServiceException {
		logger.info("EmailService: Entering getEmailAlertConfigurationData() method");
		Map<String, Object> response = new LinkedHashMap<>();
		
		try {
			List<EmailAlertSettings> alertConfiguration = emailRepository.fetchHubAlertConfiguration(hubName,kpi);
			List<Map<String, Object>> statusConfigList = new ArrayList<>();
			Map<String, Object> statusConfig = null;
			for(EmailAlertSettings eas : alertConfiguration) {
				statusConfig = new LinkedHashMap<>();
				statusConfig.put("Status", eas.getStatus());
				statusConfig.put("NotificationDate", eas.getNotificationDay());
				statusConfig.put("EstimatedReceivingDate", eas.getEstimatedReceivingDay());
				statusConfigList.add(statusConfig);
			}
			response.put("AlertParameters", statusConfigList);
			List<EmailAlertContent> alertContents = emailRepository.fetchHubAlertContents(hubName,kpi);
			List<Map<String, Object>> statusContentList = new ArrayList<>();
			Map<String, Object> statusContent = null;
			for(EmailAlertContent eac : alertContents) {
				if(eac.getAlertType().equals("ESCALATION1") || eac.getAlertType().equals("ESCALATION2"))
					continue;
				statusContent = new LinkedHashMap<>();
				statusContent.put("Status", eac.getStatus());
				statusContent.put("AlertType", eac.getAlertType());
				statusContent.put("AlertDescription", eac.getAlertDescription());
				statusContent.put("ToMailList", eac.getToMailIDs());
				statusContent.put("CCMailList", eac.getCcMailIDs());
				statusContent.put("MailSubject", eac.getMailSubject());
				statusContent.put("MailContent", eac.getMailDescription());
				statusContentList.add(statusContent);
			}
			response.put("AlertMailContents", statusContentList);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			CSafeServiceException cse = new CSafeServiceException(e);
			cse.setStatus(HttpStatus.BAD_REQUEST);
			throw cse;
		}

		logger.info("EmailService: Exiting getEmailAlertConfigurationData() method");
		return response;
	}

	@Transactional
	public boolean saveEmailAlertConfigurationData(EmailConfigurationRequest configurationData) throws CSafeServiceException {
		logger.info("EmailService: Entering saveEmailAlertConfigurationData() method");
		Map<String, Object> response = new LinkedHashMap<>();
		try {
			List<EmailAlertSettings> result = emailRepository.fetchHubAlertConfiguration(configurationData.getHubName(), configurationData.getKpi().toUpperCase());
			for(EmailAlertSettings entity : result) {
				if(entity.getStatus().equalsIgnoreCase(LEASEEND)) {
					entity.setNotificationDay(configurationData.getNotificationDay());
					entity.setEstimatedReceivingDay(configurationData.getLeaseEndERD());
				}else if(entity.getStatus().equalsIgnoreCase(REPOSITIONING)) {
					entity.setNotificationDay(configurationData.getNotificationDay());
					entity.setEstimatedReceivingDay(configurationData.getRepositioningERD());
				}else if(entity.getStatus().equalsIgnoreCase(REPAIREND)) {
					entity.setNotificationDay(configurationData.getNotificationDay());
					entity.setEstimatedReceivingDay(configurationData.getRepairEndERD());
				}else if(entity.getStatus().equalsIgnoreCase(INREPAIR)) {
					entity.setNotificationDay(configurationData.getNotificationDay());
					entity.setEstimatedReceivingDay(configurationData.getInRepairERD());
				}
				emailRepository.saveHubAlertConfiguration(entity);
			}
			List<EmailAlertContent>  alertContentList = null;
			EmailAlertContent entity = null;
			for(AlertMailContent mailContent : configurationData.getAlertMailContent()) {
				alertContentList = emailRepository.fetchMailContent(configurationData.getHubName(), mailContent.getStatus(), mailContent.getAlertType(), mailContent.getAlertDescription());
				if(alertContentList.size()>0) {
					entity = alertContentList.get(0);
					entity.setToMailIDs(mailContent.getToMailIds());
					entity.setCcMailIDs(mailContent.getCcMailIds());
					entity.setMailSubject(mailContent.getMailSubject());
					entity.setMailDescription(mailContent.getMailDescription());
					emailRepository.saveHubAlertContent(entity);
				}
			}
			
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			CSafeServiceException cse = new CSafeServiceException(e);
			cse.setStatus(HttpStatus.BAD_REQUEST);
			throw cse;
		}

		logger.info("EmailService: Exiting saveEmailAlertConfigurationData() method");
		return true;
	}
	
	public Map<String, Object> getEmailContent(String serialNumber,	String status, boolean isLeaseEndHotboard) throws CSafeServiceException {
		logger.info("EmailService: Entering getEmailContent() method");
		Map<String, Object> response = null;
		try {
			List<Object[]> result = null;
			if(INREPAIR.equalsIgnoreCase(status)) {
				result = repairHotBoardRepository.findRepairDetailsBySerialNumber(serialNumber);
			}else {
				if(isLeaseEndHotboard) {
					result = leaseEndHotBoardRepository.findLeaseEndDetailsBySerialNumber(serialNumber);
				}else {
					result = inboundHotBoardRepository.findInBoundDetailsBySerialNumberStatus(serialNumber, status);
				}
			}
			String origin = "";
			String destination = "";
			String  alertType = ""; 
			String  alertDescription = ""; 
			Date today = new Date();
			if(result.size()>0) {
				Object[] data = result.get(0);
				origin = data[4] != null ? data[4].toString() : "";
				destination = data[5] != null ? data[5].toString() : "";
				if(data[2] == null) {
					if(today.compareTo((Date)data[0]) >= 0 && today.compareTo((Date)data[1]) < 0) {
						alertType = "NOTIFICATION";
					}else if(today.compareTo((Date)data[1]) > 0) {
						Calendar cal = Calendar.getInstance();
						cal.setTime((Date)data[1]);
						cal.add(Calendar.DATE, 8);
						Date escalation1Date = cal.getTime();
						cal.add(Calendar.DATE, 7);
						Date escalation2Date = cal.getTime();
						if(today.compareTo(escalation2Date) >= 0) {
							alertType = "ESCALATION2";
						}else if(today.compareTo(escalation1Date) >= 0) {
							alertType = "ESCALATION1";
						}else {
							alertType = "REMINDER";
						}
					}
				}
				if(!alertType.equals("NOTIFICATION")) {
					alertDescription = data[3].toString();
				}
			}
			List<EmailAlertContent> alertContentList = null;
			if(REPOSITIONING.equalsIgnoreCase(status) && !alertType.equals("NOTIFICATION")) { 
				// only in repositioning reminder and escalation alerts will be for origin hub\sc
				alertContentList = emailRepository.fetchMailContent(origin,status,alertType,alertDescription);
			}else {
				//for rest all cases alerts will be for destination hub/sc
				alertContentList = emailRepository.fetchMailContent(destination,status,alertType,alertDescription);
			}
			
			if(alertContentList.size() > 0) {
				EmailAlertContent entity = alertContentList.get(0);
				response = new LinkedHashMap<>();
				response.put("ToMailIds", entity.getToMailIDs());
				response.put("CCMailIds", entity.getCcMailIDs());
				response.put("MailSubject", entity.getMailSubject());
				response.put("MailDescription", entity.getMailDescription());
				response.put("MailtemplateId", entity.getMailTemplateId());
			}
			 
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			CSafeServiceException cse = new CSafeServiceException(e);
			cse.setStatus(HttpStatus.BAD_REQUEST);
			throw cse;
		}

		logger.info("EmailService: Exiting getEmailContent() method");
		return response;
	}

	public boolean sendMail(EmailRequest emailRequest) throws CSafeServiceException {
		logger.info("EmailService: Entering sendEmail() method");
		boolean isSuccessful = true;

		if (StringUtils.isEmpty(emailRequest.getMailTemplateId())) {
			Exception e = new Exception("No email template id found");
			logger.error("Error caught: " + e.getMessage(), e);
			CSafeServiceException cse = new CSafeServiceException(e);
			cse.setStatus(HttpStatus.NOT_FOUND);
			throw cse;
		}
		try {
			isSuccessful = sendEmail(emailRequest);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			CSafeServiceException cse = new CSafeServiceException(e);
			cse.setStatus(HttpStatus.BAD_REQUEST);
			throw cse;
		}

		logger.info("EmailService: Exiting sendEmail() method");
		return isSuccessful;
	}

	private boolean sendEmail(EmailRequest emailRequest) throws IOException {
		Mail mail = new Mail();
		mail.setFrom(new Email(emailRequest.getFromMailId()));
		mail.setTemplateId(emailRequest.getMailTemplateId());

		DynamicTemplatePersonalization personalization = new DynamicTemplatePersonalization();
		personalization.addDynamicTemplateData("subject", emailRequest.getSubject());
		personalization.addDynamicTemplateData("contentDescription", emailRequest.getContentDescription());
		personalization.addDynamicTemplateData("dynamicContent",  emailRequest.getDynamicContent());
		personalization.addDynamicTemplateData("fromTeam",  emailRequest.getDestinationHub());
		
		String[] mailIds = emailRequest.getToMailList().split(";");
		for(String to : mailIds) {
			personalization.addTo(new Email(to));
		}
		mailIds = emailRequest.getCcMailList().split(";");
		for(String cc : mailIds) {
			personalization.addCc(new Email(cc));
		}
		
		mail.addPersonalization(personalization);

		SendGrid sg = new SendGrid(sendgridApiKey);
		Request request = new Request();
		request.setMethod(Method.POST);
		request.setEndpoint("mail/send");
		request.setBody(mail.build());
		Response response = sg.api(request);
		
		System.out.println(response.getStatusCode());
		System.out.println(response.getBody());
		System.out.println(response.getHeaders());
		
		if (response.getStatusCode() == 202) {
			return true;
		}
		return false;
	}

}
