package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "[dbo].[tbl_EmailAlertTemplate]")
public class EmailAlertTemplate {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;
	
	@Column(name = "EmailTo")
	private String emailTo;
	
	@Column(name = "EmailCC")
	private String emailCc;
	
	@Column(name = "EmailSubject")
	private String emailSubject;
	
	@Column(name = "EmailContent")
	private String emailContent;
	
	@Column(name = "IsActive")
	private Boolean isActive;
	
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "AlertID")
    @JsonProperty(access = Access.WRITE_ONLY)
    private EmailAlertMaster emailAlert;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmailTo() {
		return emailTo;
	}

	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}

	public String getEmailCc() {
		return emailCc;
	}

	public void setEmailCc(String emailCc) {
		this.emailCc = emailCc;
	}

	public String getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	public String getEmailContent() {
		return emailContent;
	}

	public void setEmailContent(String emailContent) {
		this.emailContent = emailContent;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public EmailAlertMaster getEmailAlert() {
		return emailAlert;
	}

	public void setEmailAlert(EmailAlertMaster emailAlert) {
		this.emailAlert = emailAlert;
	}
}
