package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.List;

public class ModelValues  implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String mapPercent;
	private String madPercent;
	private String rmsePercent;
	private List<MonthDataUnit> values;

	public String getMapPercent() {
		return mapPercent;
	}

	public void setMapPercent(String mapPercent) {
		this.mapPercent = mapPercent;
	}

	public String getMadPercent() {
		return madPercent;
	}

	public void setMadPercent(String madPercent) {
		this.madPercent = madPercent;
	}

	public String getRmsePercent() {
		return rmsePercent;
	}

	public void setRmsePercent(String rmsePercent) {
		this.rmsePercent = rmsePercent;
	}

	public List<MonthDataUnit> getValues() {
		return values;
	}

	public void setValues(List<MonthDataUnit> values) {
		this.values = values;
	}
}
