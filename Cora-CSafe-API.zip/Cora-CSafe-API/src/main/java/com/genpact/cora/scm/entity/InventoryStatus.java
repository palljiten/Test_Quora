/**
 * 
 */
package com.genpact.cora.scm.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author 703158077
 *
 */
@Entity
@Table(name = "tbl_IMInventoryStatusContainer")
public class InventoryStatus implements Serializable {
	
	private static final long serialVersionUID = 9876543216L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID", unique= true, nullable = false )
	private Integer id;
	
	@OneToOne(fetch= FetchType.EAGER)
	@JoinColumn(name = "RegionID")
	private Region region;
	
	@OneToOne(fetch= FetchType.EAGER)
	@JoinColumn(name = "CountryID")
	private Country country;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "HubID")
	private HubSc hubSc;
	
	@Column(name = "ContainerCount",  nullable = true)
	private Integer containerCount;
	
	@Column(name = "Status",  nullable = false)
	private String status;
	
	@Column(name="WeekNumber")
	private Integer weekNumber;
	
	@Column(name="MonthYear")
	private String monthYear;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="InputDate")
	private Date inputDate;
	
	
	
	
	
	
	/**
	 * @return the weekNumber
	 */
	public Integer getWeekNumber() {
		return weekNumber;
	}
	/**
	 * @param weekNumber the weekNumber to set
	 */
	public void setWeekNumber(Integer weekNumber) {
		this.weekNumber = weekNumber;
	}
	/**
	 * @return the monthYear
	 */
	public String getMonthYear() {
		return monthYear;
	}
	/**
	 * @param monthYear the monthYear to set
	 */
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
	/**
	 * @return the inputDate
	 */
	public Date getInputDate() {
		return inputDate;
	}
	/**
	 * @param inputDate the inputDate to set
	 */
	public void setInputDate(Date inputDate) {
		this.inputDate = inputDate;
	}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the regionId
	 */
	public Region getRegion() {
		return region;
	}
	/**
	 * @param regionId the regionId to set
	 */
	public void setRegion(Region region) {
		this.region = region;
	}
	/**
	 * @return the countryId
	 */
	public Country getCountry() {
		return country;
	}
	/**
	 * @param countryId the countryId to set
	 */
	public void setCountryId(Country country) {
		this.country = country;
	}
	/**
	 * @return the hubId
	 */
	public HubSc getHubSc() {
		return hubSc;
	}
	/**
	 * @param hubId the hubId to set
	 */
	public void setHubId(HubSc hubSc) {
		this.hubSc = hubSc;
	}
	/**
	 * @return the containerCount
	 */
	public Integer getContainerCount() {
		return containerCount;
	}
	/**
	 * @param containerCount the containerCount to set
	 */
	public void setContainerCount(Integer containerCount) {
		this.containerCount = containerCount;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	
	

}
