package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_DemandAllocationEdit]")
public class DemandAllocationEdit {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
	private int id;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RegionID")
	private Region region;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CountyID")
	private Country country;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HubID")
	private HubSc hubSc;
	
	@Column(name="CreatedMonth")
	private String createdMonth;
	
	@Column(name="WeekYear")
	private int weekYear;
	
	@Column(name="WeekNumber")
	private int weekNumber;
	
	@Column(name="ParentShipper")
	private String parentShipper;
	
	@Column(name="Lane")
	private String lane;
	
	@Column(name="HubType")
	private String hubType;
	
	@Column(name="EditPercentage")
	private float editPercentage;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CreatedDate", nullable = true)
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ModifiedDate", nullable = true)
	private Date modifiedDate;

	@Column(name = "Flag", nullable = false)
	private Integer flag;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHubSc() {
		return hubSc;
	}

	public void setHubSc(HubSc hubSc) {
		this.hubSc = hubSc;
	}

	public String getCreatedMonth() {
		return createdMonth;
	}

	public void setCreatedMonth(String createdMonth) {
		this.createdMonth = createdMonth;
	}

	public int getWeekYear() {
		return weekYear;
	}

	public void setWeekYear(int weekYear) {
		this.weekYear = weekYear;
	}

	public int getWeekNumber() {
		return weekNumber;
	}

	public void setWeekNumber(int weekNumber) {
		this.weekNumber = weekNumber;
	}

	public String getParentShipper() {
		return parentShipper;
	}

	public void setParentShipper(String parentShipper) {
		this.parentShipper = parentShipper;
	}

	public String getLane() {
		return lane;
	}

	public void setLane(String lane) {
		this.lane = lane;
	}

	public String getHubType() {
		return hubType;
	}

	public void setHubType(String hubType) {
		this.hubType = hubType;
	}

	public float getEditPercentage() {
		return editPercentage;
	}

	public void setEditPercentage(float editPercentage) {
		this.editPercentage = editPercentage;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}
}
