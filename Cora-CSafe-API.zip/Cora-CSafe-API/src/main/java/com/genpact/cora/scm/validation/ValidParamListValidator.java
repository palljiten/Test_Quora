package com.genpact.cora.scm.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidParamListValidator implements ConstraintValidator<ValidParamList, List<?>> {
	
	private static Set<String> definedParamters = new TreeSet<>();
	
	static {
		definedParamters.add("Historic");
		definedParamters.add("Forecast");
		definedParamters.add("Period");
		definedParamters.add("Weight");
		definedParamters.add("Alpha");
		definedParamters.add("Beta");
	}
	
	@Override
	public void initialize(final ValidParamList annotation) {
		return;
	}

	@Override
	public boolean isValid(final List<?> list, final ConstraintValidatorContext context) {
		if (list == null || list.size() != 6) {
			return false;
		}
		
		Set<String> alreadyCheckedParams = new TreeSet<>();
		
		for(Object m : list) {
			if (m instanceof Map) {
				Set<String> keys = ((Map)m).keySet();
				if (keys.size() != 1) {
					return false;
				} else {
					for(String parameterName : keys) {
						if (!definedParamters.contains(parameterName)) {
							return false;
						} else {
							if (alreadyCheckedParams.contains(parameterName)) {
								return false;
							} else {
								alreadyCheckedParams.add(parameterName);
							}
						}
					}
				}
			}
		}
		
		return true;
	}
}