package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_DemandAllocationHubProfile]")
public class DemandAllocationHubProfile {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
	private int id;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RegionID")
	private Region region;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CountryID")
	private Country country;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HubID")
	private HubSc hubSc;

	@Column(name="ParentShipper")
	private String parentShipper;
    	      
	@Column(name="ProfilePercentage")
	private float profilePercentage;

	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CreatedDate" , nullable = true)
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ModifiedDate" , nullable = true)
	private Date modifiedDate;

	
	
	public DemandAllocationHubProfile(String parentShipper, float profilePercentage) {
		super();
		this.parentShipper = parentShipper;
		this.profilePercentage = profilePercentage;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHubSc() {
		return hubSc;
	}

	public void setHubSc(HubSc hubSc) {
		this.hubSc = hubSc;
	}

	public String getParentShipper() {
		return parentShipper;
	}

	public void setParentShipper(String parentShipper) {
		this.parentShipper = parentShipper;
	}

	public float getProfilePercentage() {
		return profilePercentage;
	}

	public void setProfilePercentage(float profilePercentage) {
		this.profilePercentage = profilePercentage;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
