package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_RepairWorkOrder]")
public class RepairWorkOrder {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	@Column(name ="WorkOrderID" ,unique=true,nullable=false)
	private Integer workOrderId; 
	@Column(name = "AccountID")
	private Long accountId;
	@Column(name ="ContainerID")
	private Long containerId;
	@Column(name = "PartNumber")
	private String partNumber;
	@Column(name = "Description")
	private String description;
	
	public Integer getWorkOrderId() {
		return workOrderId;
	}
	public void setWorkOrderId(Integer workOrderId) {
		this.workOrderId = workOrderId;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public Long getContainerId() {
		return containerId;
	}
	public void setContainerId(Long containerId) {
		this.containerId = containerId;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
