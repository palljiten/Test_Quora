package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.HotBoard;
import com.genpact.cora.scm.dto.RepairEnd;
import com.genpact.cora.scm.dto.RepairEndData;
import com.genpact.cora.scm.entity.VARepair;

public interface RepairHotBoardRepository extends JpaRepository<VARepair, Integer>{
	
	@Query("SELECT new com.genpact.cora.scm.dto.HotBoard(vr.weekNo,count(vr.serialNumber),vr.containerLocation) FROM VARepair vr INNER JOIN HubSc hs on hs.accountName =vr.containerLocation where vr.weekNo in (:weeksList) group by vr.weekNo,vr.containerLocation")
	public List<HotBoard> getRepairData(@Param("weeksList") List<Object> weeksList);
	
   @Query("select new com.genpact.cora.scm.dto.RepairEndData (rwp.partNumber, rwp.description, rwp.quantity, vr.containerLocation, vr.serialNumber, rwo.workOrderId,vr.dueDate) "
	   		+ "from VARepair vr,RepairWorkOrder rwo, RepairWorkOrderParts rwp where vr.serialNumber = :serialNumber and vr.containeerId = rwo.containerId and " + 
	   		"rwo.workOrderId =rwp.workOrderID and vr.currentlyInStock=0 and rwp.createDate >=vr.arrivalDate")
	public List<RepairEndData> getRepairEndData(@Param("serialNumber") String serialNumber);

   @Query("SELECT notificationDate, estimatedReceivingDate, actualReceivingDate, alertDescription, origin, containerLocation  FROM VARepair where serialNumber = :serialNumber") 
   public List<Object[]> findRepairDetailsBySerialNumber(@Param("serialNumber") String serialNumber);
   
   // actual query .... commented because of QA testing only need to be reverted back once get proper data
   
   @Query(value = "select distinct weekno,[SerialNumber],[Status],[ContainerLocation],[AlertDescription],[DueDate],[NotificationDate],\r\n" + 
   		"[EstimatedReceivingDate],[ActualReceivingdate],[AlertType] from [tbl_VARepair] A\r\n" + 
   		"LEFT JOIN tbl_master_Calendar B ON (CONVERT(DATE,A.duedate) =CONVERT(DATE,B.Date))\r\n" + 
   		"where B.WeekstartDate >= (SELECT WeekStartdate FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE()))\r\n" + 
   		"AND B.WeekstartDate<=(SELECT DATEADD(Day,21,WeekStartdate) FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE()))" ,nativeQuery = true)
	public List<Object[]> getRepairHotBoardData();
   
   // temorary fix  query .... commented because of QA testing only need to be reverted back once get proper data
/*   @Query(value = " select distinct weekno,[SerialNumber],[Status],[ContainerLocation],[AlertDescription],[DueDate],[NotificationDate], \r\n" + 
   		" [EstimatedReceivingDate],[ActualReceivingdate],[AlertType] from [tbl_VARepair] where\r\n" + 
   		"  weekno  between '2018-48' and '2018-51'" ,nativeQuery = true)
	public List<Object[]> getRepairHotBoardData();*/

}

