package com.genpact.cora.scm.dto;

public class RegionBudget {
	  private Integer regionId;
	  private double   budgetPercent;
	  private String regionName;

	  public RegionBudget(Integer regionId,String regionName, double budgetPercent) {
	    this.regionId = regionId;
	    this.regionName = regionName;
	    this.budgetPercent  = budgetPercent;
	  }

	public Integer getRegionId() {
		return regionId;
	}

	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}

	/**
	 * @return the budgetPercent
	 */
	public double getBudgetPercent() {
		return budgetPercent;
	}

	/**
	 * @param budgetPercent the budgetPercent to set
	 */
	public void setBudgetPercent(double budgetPercent) {
		this.budgetPercent = budgetPercent;
	}

	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}

	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	}
