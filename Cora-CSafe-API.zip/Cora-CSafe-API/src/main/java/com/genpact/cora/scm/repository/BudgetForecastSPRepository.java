package com.genpact.cora.scm.repository;

import org.springframework.data.repository.CrudRepository;

import com.genpact.cora.scm.entity.BudgetHubLevelPercentage;

public interface BudgetForecastSPRepository 
		extends CrudRepository<BudgetHubLevelPercentage, Integer>, StoredProcedureRepository {

}
