package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_master_StatisticalTechnique]")
public class StatisticalTechnique {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ATID", unique = true, nullable = false)
	private int atId;
	
	@Column(name = "TechniqueName")
	private String techniqueName;

	public int getAtId() {
		return atId;
	}

	public void setAtId(int atId) {
		this.atId = atId;
	}

	public String getTechniqueName() {
		return techniqueName;
	}

	public void setTechniqueName(String techniqueName) {
		this.techniqueName = techniqueName;
	}
}
