package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.entity.ConsensusAverageValues;
import com.genpact.cora.scm.entity.ConsensusCorrectionFactor;

@Repository
public class ConsensusAverageValueRepository {
	
	@PersistenceContext
    private EntityManager entityManager;
	
	public List<ConsensusAverageValues> getSimpleWeightedCorrectionFactor(int regionId, int countryId,int hubId){
		@SuppressWarnings("unchecked")			
		List<ConsensusAverageValues> correctionFactorsObject = entityManager.createNativeQuery("select value,forecastType from tbl_ConsensusAverageValues"
				+ " where RegionId=:regionId and CountryId=:countryId and HubID=:hubId and flag=1")
										.setParameter("regionId", regionId)
										.setParameter("countryId", countryId)
										.setParameter("hubId", hubId)
										.getResultList();
										
		return correctionFactorsObject;
	}

}

