package com.genpact.cora.scm.dto;

import io.swagger.annotations.ApiModel;

@ApiModel
public class WeekData extends WeekMetaData{
	
	private Integer value;

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}
}
