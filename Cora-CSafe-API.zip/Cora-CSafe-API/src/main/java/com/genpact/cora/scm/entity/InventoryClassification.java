/**
 * 
 */
package com.genpact.cora.scm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author 703158077
 *
 */
@Entity
@Table(name="tbl_IMInventoryClassification")
public class InventoryClassification implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543220L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private Integer id;
	@Column(name="PartNumber")
	private String partNumber;
	@Column(name="SC")
	private String serviceCenter;
	@Column(name="ABCDemand")
	private Integer abcDemand;
	@Column(name="ABCDemandVolume")
	private String abcDemandVolume;
	@Column(name="ABCValue")
	private Integer abcValue;
	@Column(name="ABCValueVolume")
	private String abcValueVolume;
	@Column(name="UnitCost")
	private Float unitCost;
	@Column(name="HML")
	private String hml;
	@Column(name="DemandCount")
	private Integer demandCount;
	@Column(name="FSN")
	private String fsn;
	@Column(name="Flag")
	private Integer flag;
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the serviceCenter
	 */
	public String getServiceCenter() {
		return serviceCenter;
	}
	/**
	 * @param serviceCenter the serviceCenter to set
	 */
	public void setServiceCenter(String serviceCenter) {
		this.serviceCenter = serviceCenter;
	}
	/**
	 * @return the abcDemand
	 */
	public Integer getAbcDemand() {
		return abcDemand;
	}
	/**
	 * @param abcDemand the abcDemand to set
	 */
	public void setAbcDemand(Integer abcDemand) {
		this.abcDemand = abcDemand;
	}
	/**
	 * @return the abcDemandVolume
	 */
	public String getAbcDemandVolume() {
		return abcDemandVolume;
	}
	/**
	 * @param abcDemandVolume the abcDemandVolume to set
	 */
	public void setAbcDemandVolume(String abcDemandVolume) {
		this.abcDemandVolume = abcDemandVolume;
	}
	/**
	 * @return the abcValue
	 */
	public Integer getAbcValue() {
		return abcValue;
	}
	/**
	 * @param abcValue the abcValue to set
	 */
	public void setAbcValue(Integer abcValue) {
		this.abcValue = abcValue;
	}
	/**
	 * @return the abcValueVolume
	 */
	public String getAbcValueVolume() {
		return abcValueVolume;
	}
	/**
	 * @param abcValueVolume the abcValueVolume to set
	 */
	public void setAbcValueVolume(String abcValueVolume) {
		this.abcValueVolume = abcValueVolume;
	}
	/**
	 * @return the unitCost
	 */
	public Float getUnitCost() {
		return unitCost;
	}
	/**
	 * @param unitCost the unitCost to set
	 */
	public void setUnitCost(Float unitCost) {
		this.unitCost = unitCost;
	}
	/**
	 * @return the hml
	 */
	public String getHml() {
		return hml;
	}
	/**
	 * @param hml the hml to set
	 */
	public void setHml(String hml) {
		this.hml = hml;
	}
	/**
	 * @return the demandCount
	 */
	public Integer getDemandCount() {
		return demandCount;
	}
	/**
	 * @param demandCount the demandCount to set
	 */
	public void setDemandCount(Integer demandCount) {
		this.demandCount = demandCount;
	}
	/**
	 * @return the fsn
	 */
	public String getFsn() {
		return fsn;
	}
	/**
	 * @param fsn the fsn to set
	 */
	public void setFsn(String fsn) {
		this.fsn = fsn;
	}
	/**
	 * @return the flag
	 */
	public Integer getFlag() {
		return flag;
	}
	/**
	 * @param flag the flag to set
	 */
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	
}
