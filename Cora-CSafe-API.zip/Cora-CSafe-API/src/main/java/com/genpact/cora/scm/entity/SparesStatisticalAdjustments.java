package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "[dbo].[tbl_SparesStatisticalAdjustments]")
public class SparesStatisticalAdjustments {

	/*
	 * INSERT INTO tbl_SparesStatisticalAdjustments (RegionID, CountryID, HubID, PartID, MonthYear, Value, Flag)
VALUES (3, 2, 1, 4, 'Aug-18', 40, 1)
INSERT INTO tbl_SparesStatisticalAdjustments (RegionID, CountryID, HubID, PartID, MonthYear, Value, Flag)
VALUES (3, 2, 1, 4, 'Sep-18', 50, 1)
INSERT INTO tbl_SparesStatisticalAdjustments (RegionID, CountryID, HubID, PartID, MonthYear, Value, Flag)
VALUES (3, 2, 1, 4, 'Oct-18', 60, 1)
INSERT INTO tbl_SparesStatisticalAdjustments (RegionID, CountryID, HubID, PartID, MonthYear, Value, Flag)
VALUES (3, 2, 1, 4, 'Nov-18', 35, 1)
INSERT INTO tbl_SparesStatisticalAdjustments (RegionID, CountryID, HubID, PartID, MonthYear, Value, Flag)
VALUES (3, 2, 1, 4, 'Dec-18', 25, 1)
INSERT INTO tbl_SparesStatisticalAdjustments (RegionID, CountryID, HubID, PartID, MonthYear, Value, Flag)
VALUES (3, 2, 1, 4, 'Jan-19', 30, 1)
	 */
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer id;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RegionID")
	private Region region;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CountryID")
	private Country country;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "HubID")
	private HubSc hub;
	
    @Column(name = "PartID", nullable = true)
    private String partId;
    
    @Column(name = "MonthYear", nullable = true)
    private String monthYear;
    
    @Column(name = "Value", nullable = true)
    private float value;
    
    @Column(name = "Flag", nullable = true)
    private int flag;
    
	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(name = "CreatedDate", nullable = true)
	private Date createdDate;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(name = "ModifiedDate", nullable = true)
	private Date modifiedDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}

	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId;
	}

	public String getMonthYear() {
		return monthYear;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		this.value = value;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}  
}
