package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.SparesConsensusAdjustment;

public interface SparesConsensusAdjustmentRepository extends JpaRepository<SparesConsensusAdjustment, Integer> {

	/*
	 * SELECT TOP (1000) [ID]
      ,[RegionID]
      ,[CountryID]
      ,[HubID]
      ,[PartID]
      ,[MonthYear]
      ,[Value]
      ,[CreatedDate]
      ,[ModifiedDate]
      ,[Flag]
  	  FROM [dbo].[tbl_SparesStatisticalAdjustments]
	 */
	
	@Query("SELECT a FROM SparesConsensusAdjustment a WHERE (MONTH(CURRENT_DATE()) < DATEADD(mm, :months, CURRENT_DATE()) AND a.flag=1 AND a.hub.hubId = :hubId AND a.country.countryId = :countryId AND a.region.regionId = :regionId AND a.partId = :partId AND a.flag = 1)")
	public List<SparesConsensusAdjustment> getSparesConsensusAdjustment(@Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") int partId,
			@Param("months") int months);

	@Modifying
    @Query("UPDATE SparesConsensusAdjustment a SET a.flag = 0 "
    		+ "WHERE a.flag=1 AND a.hub.hubId = :hubId AND a.country.countryId = :countryId "
    		+ "AND a.region.regionId = :regionId AND a.partId = :partId AND monthYear = :monthYear")
    int updateSparesConsensusAdjustment(@Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") int partId, @Param("monthYear") String monthYear);
}
