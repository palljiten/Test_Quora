package com.genpact.cora.scm.util;

import java.util.Map;

public interface MailService {

	public void sendMail() throws Exception;
	
}
