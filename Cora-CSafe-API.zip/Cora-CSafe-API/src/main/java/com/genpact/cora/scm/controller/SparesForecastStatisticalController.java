package com.genpact.cora.scm.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.CustomParameterCombo;
import com.genpact.cora.scm.dto.ModelParams;
import com.genpact.cora.scm.dto.ModelUpdateDTO;
import com.genpact.cora.scm.dto.PythonRequestObject;
import com.genpact.cora.scm.dto.PythonResponseObject;
import com.genpact.cora.scm.dto.PythonUpdatedForecastModelUpdateRequest;
import com.genpact.cora.scm.dto.SparesStatisticalAdjustmentCombo;
import com.genpact.cora.scm.dto.SparesStatisticalAdjustmentRequest;
import com.genpact.cora.scm.dto.SparesStatisticalBaselineDemandCombo;
import com.genpact.cora.scm.dto.SparesStatisticalBaselineForecastCombo;
import com.genpact.cora.scm.dto.SparesStatisticalForecastModelOutput;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.SparesForecastStatisticalService;
import com.genpact.cora.scm.service.SparesStatisticalParameterValuesService;
import com.genpact.cora.scm.service.StatisticalModelService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
public class SparesForecastStatisticalController {

	private static Logger logger = LoggerFactory.getLogger(SparesForecastStatisticalController.class);

	@Autowired
	SparesForecastStatisticalService sparesForecastStatisticalService;

	@Autowired
	StatisticalModelService smService;

	@Autowired
	SparesStatisticalParameterValuesService paramService;

	@GetMapping(value = "/sparesForecast/statistical/baselineDemand", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves baseline demand")
	public ResponseEntity<Object> getBaselineDemand(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") String partId, @RequestParam(value = "months", required = false) Integer months) {
		logger.info("CONTROLLER: SparesForecastStatisticalController: Entering getBaselineDemand() method");
		int mDefault = 18;
		SparesStatisticalBaselineDemandCombo data = null;
		try {
			if (months != null) {
				mDefault = months.intValue();
			}
			data = sparesForecastStatisticalService.getBaselineDemand(regionId, countryId, hubId, partId, mDefault);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for baseline demand (spares statistical)", e.getCause());
		}
		logger.info("CONTROLLER: SparesForecastStatisticalController: Exiting getBaselineDemand() method");
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@GetMapping(value = "/sparesForecast/statistical/baselineForecast", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves baseline forecast")
	public ResponseEntity<Object> getBaselineForecast(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") String partId) {
		logger.info("CONTROLLER: SparesForecastStatisticalController: Entering getBaselineForecast() method");
		SparesStatisticalBaselineForecastCombo data = null;
		try {
			data = sparesForecastStatisticalService.getBaselineForecast(regionId, countryId, hubId, partId, 6);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for baseline forecast (spares statistical)", e.getCause());
		}
		logger.info("CONTROLLER: SparesForecastStatisticalController: Exiting getBaselineForecast() method");
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@GetMapping(value = "/sparesForecast/statistical/adjustments", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves adjustment values")
	public ResponseEntity<Object> getIntelligenceOrAdjustment(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") String partId) {
		logger.info("CONTROLLER: SparesForecastStatisticalController: Entering getIntelligenceOrAdjustment() method");
		SparesStatisticalAdjustmentCombo data = null;
		try {
			data = sparesForecastStatisticalService.getIntelligenceOrAdjustment(regionId, countryId, hubId, partId, 6);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException("API error occured during fetching data for adjustments (spares statistical)",
					e.getCause());
		}
		logger.info("CONTROLLER: SparesForecastStatisticalController: Exiting getIntelligenceOrAdjustment() method");
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@PutMapping(value = "/sparesForecast/statistical/adjustments", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update Correction Factors")
	public ResponseEntity<Object> updateIntelligenceOrAdjustment(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") String partId, @Valid @RequestBody SparesStatisticalAdjustmentRequest adjustments) {
		logger.info(
				"CONTROLLER: SparesForecastStatisticalController: Entering updateIntelligenceOrAdjustment() method");

		try {
			sparesForecastStatisticalService.updateIntelligenceOrAdjustment(regionId, countryId, hubId, partId,
					adjustments);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException("API error occured during updating data for adjustments (spares statistical)",
					e.getCause());
		}
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("CONTROLLER: SparesForecastStatisticalController: Exiting updateIntelligenceOrAdjustment() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}

	@GetMapping(value = "/sparesForecast/statistical/forecastModels", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves forecast models")
	public ResponseEntity<Object> getForecastModels(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestParam("partId") String partId) {
		logger.info("CONTROLLER: SparesForecastStatisticalController: Entering getForecastModels() method");
		SparesStatisticalForecastModelOutput output = null;
		try {
			output = smService.getSparesForecastModels(regionId, countryId, hubId, partId);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for forecast models (spares statistical)", e.getCause());
		}
		logger.info("CONTROLLER: SparesForecastStatisticalController: Exiting getForecastModels() method");
		return new ResponseEntity<>(output, HttpStatus.OK);
	}

	@GetMapping(value = "/sparesForecast/statistical/forecastModels/{modelId}/params", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves forecast models")
	public ResponseEntity<Object> getForecastModelParams(@PathVariable("modelId") int modelId, 
			@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId,
			@RequestParam("partId") String partId) {
		logger.info("CONTROLLER: SparesForecastStatisticalController: Entering getForecastModelParams() method");
		// Table to be used: tbl_SparesStatisticalParameterValues,
		// tbl_master_StatisticalParameters
		CustomParameterCombo data = null;
		try {
			data = paramService.getParamValues(modelId, regionId, countryId, hubId, partId);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for model parameters (spares statistical)", e.getCause());
		}
		logger.info("CONTROLLER: SparesForecastStatisticalController: Exiting getForecastModelParams() method");
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@PutMapping(value = "/sparesForecast/statistical/forecastModels/{modelId}/params", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves forecast models")
	public ResponseEntity<PythonResponseObject> updatedForecastModelParams(
			@Valid @RequestBody PythonRequestObject onDemandContainerPojo) {
		logger.info("SparesForecastStatisticalController: Entering updateForecastModelParams() method");
		PythonResponseObject output = sparesForecastStatisticalService.updateStatistcalModelParams(onDemandContainerPojo);
		logger.info("SparesForecastStatisticalController: Exiting updateForecastModelParams() method");
		return new ResponseEntity<PythonResponseObject>(output, HttpStatus.OK);
	}

	@PutMapping(value = "/sparesForecast/statistical/forecastModels/{modelId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves forecast models")
	public ResponseEntity<Object> updatedForecastModel(@PathVariable("modelId") int modelId, 
			@RequestParam("regionId") int regionId, @RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId, @RequestParam("partId") String partId, 
			@RequestBody PythonUpdatedForecastModelUpdateRequest modelUpdate) {
		logger.info("CONTROLLER: SparesForecastStatisticalController: Entering updatedForecastModel() method");
		// Table to be used: tbl_SparesStatisticalParameterValues,
		// tbl_master_StatisticalParameters
		try {
			sparesForecastStatisticalService.updateForecastModel(modelId, regionId, countryId,
					hubId, partId, modelUpdate);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during updating data for forecast model (spares statistical)", e.getCause());
		}
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("CONTROLLER: SparesForecastStatisticalController: Exiting updatedForecastModel() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}
}
