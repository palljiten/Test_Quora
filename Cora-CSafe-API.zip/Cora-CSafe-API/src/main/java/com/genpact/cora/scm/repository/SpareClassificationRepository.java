/**
 * 
 */
package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.entity.InventoryClassification;



@Repository
public class SpareClassificationRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	public List<InventoryClassification> getSparesClassificationDetails(@Param("regionId") int regionId, @Param("countryId") int  countryId, 
			@Param("hubId") int  hubId, @Param("partNumber") String partNumber){

		String extendedWhere = "";
		extendedWhere += (regionId != -1) ? " and sc.region.regionId="+regionId : "";
		extendedWhere += (countryId != -1) ? " and sc.country.countryId="+countryId : "";
		extendedWhere += (hubId != -1) ? " and sc.hubId="+hubId+" " : "";
		extendedWhere += (!partNumber.equalsIgnoreCase("all")) ? " and ic.part='"+partNumber+"'" : "";
		
		String hql = "SELECT ic FROM InventoryClassification ic INNER JOIN HubSc sc on sc.hubCode = ic.serviceCenter WHERE ic.flag=1 "+extendedWhere;
		
		Query query = entityManager.createQuery(hql);
		return query.getResultList();
	}

}
