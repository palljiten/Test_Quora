package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_master_StatisticalParameters]")
public class StatisticalParametersMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PID", unique = true, nullable = false)
	private int id;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ModelID")
	private StatisticalModelMaster model;

	@Column(name = "ParameterName")
	private String parameterName;
	
	@Column(name = "CreatedDate")
	private Date createdDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public StatisticalModelMaster getModel() {
		return model;
	}

	public void setModel(StatisticalModelMaster model) {
		this.model = model;
	}

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
}
