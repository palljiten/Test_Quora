package com.genpact.cora.scm.dto;

/**
 * Application log dto. This pojo class will hold all 
 * log related data points which needs to be stored in DB.
 * @author Nirmal Kamila
 *
 */
public class ApplicationLogDto {
	
	private String moduleName;
	
	private String uuid;
	
	private String requestMethod;
	
	private String requestUrl;
	
	private String requestBody;
	
	private String responseBody;
	
	private String responseCode;
	
	private String exceptionStack;
	
	private String username;
	
	public ApplicationLogDto( String moduleName, String uuid,
	 String requestMethod, String requestUrl,
	 String requestBody,String responseBody,
	 String responseCode,String exceptionStack,
	 String username) {
		
		this.moduleName = moduleName;
		this.requestMethod = requestMethod;
		this.requestUrl = requestUrl;
		this.requestBody = requestBody;
		this.responseBody = responseBody;
		this.responseCode = responseCode;
		this.exceptionStack = exceptionStack;
		this.username = username;
		this.uuid = uuid;
		
	}
	
	public ApplicationLogDto(){
		
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getRequestMethod() {
		return requestMethod;
	}

	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public String getRequestUrl() {
		return requestUrl;
	}

	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public String getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(String responseBody) {
		this.responseBody = responseBody;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getExceptionStack() {
		return exceptionStack;
	}

	public void setExceptionStack(String exceptionStack) {
		this.exceptionStack = exceptionStack;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
}
