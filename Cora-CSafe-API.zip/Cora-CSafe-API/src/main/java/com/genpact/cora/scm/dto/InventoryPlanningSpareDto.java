package com.genpact.cora.scm.dto;

import java.io.Serializable;


public class InventoryPlanningSpareDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543221L;
	
	private String part;
	private Float serviceLevel;
	private Float inventoryLevel;
	private Float totalLeadTime;
	private Float demandDuringLeadTime;
	private Float averageMonthlyDemand;
	private Float standardDiviation;
	private Integer openOrder;
	private Float rop;
	private Integer calculatedMinInventory;
	private Float priorityFlag;
	
	
	
	/**
	 * @return the part
	 */
	public String getPart() {
		return part;
	}
	/**
	 * @param part the part to set
	 */
	public void setPart(String part) {
		this.part = part;
	}
	/**
	 * @return the serviceLevel
	 */
	public Float getServiceLevel() {
		return serviceLevel;
	}
	/**
	 * @param serviceLevel the serviceLevel to set
	 */
	public void setServiceLevel(Float serviceLevel) {
		this.serviceLevel = serviceLevel;
	}
	/**
	 * @return the inventoryLevel
	 */
	public Float getInventoryLevel() {
		return inventoryLevel;
	}
	/**
	 * @param inventoryLevel the inventoryLevel to set
	 */
	public void setInventoryLevel(Float inventoryLevel) {
		this.inventoryLevel = inventoryLevel;
	}
	/**
	 * @return the totalLeadTime
	 */
	public Float getTotalLeadTime() {
		return totalLeadTime;
	}
	/**
	 * @param totalLeadTime the totalLeadTime to set
	 */
	public void setTotalLeadTime(Float totalLeadTime) {
		this.totalLeadTime = totalLeadTime;
	}
	/**
	 * @return the demandDuringLeadTime
	 */
	public Float getDemandDuringLeadTime() {
		return demandDuringLeadTime;
	}
	/**
	 * @param demandDuringLeadTime the demandDuringLeadTime to set
	 */
	public void setDemandDuringLeadTime(Float demandDuringLeadTime) {
		this.demandDuringLeadTime = demandDuringLeadTime;
	}
	/**
	 * @return the averageMonthlyDemand
	 */
	public Float getAverageMonthlyDemand() {
		return averageMonthlyDemand;
	}
	/**
	 * @param averageMonthlyDemand the averageMonthlyDemand to set
	 */
	public void setAverageMonthlyDemand(Float averageMonthlyDemand) {
		this.averageMonthlyDemand = averageMonthlyDemand;
	}
	/**
	 * @return the standardDiviation
	 */
	public Float getStandardDiviation() {
		return standardDiviation;
	}
	/**
	 * @param standardDiviation the standardDiviation to set
	 */
	public void setStandardDiviation(Float standardDiviation) {
		this.standardDiviation = standardDiviation;
	}
	/**
	 * @return the openOrder
	 */
	public Integer getOpenOrder() {
		return openOrder;
	}
	/**
	 * @param openOrder the openOrder to set
	 */
	public void setOpenOrder(Integer openOrder) {
		this.openOrder = openOrder;
	}
	/**
	 * @return the rop
	 */
	public Float getRop() {
		return rop;
	}
	/**
	 * @param rop the rop to set
	 */
	public void setRop(Float rop) {
		this.rop = rop;
	}
	/**
	 * @return the calculatedMinInventory
	 */
	public Integer getCalculatedMinInventory() {
		return calculatedMinInventory;
	}
	/**
	 * @param calculatedMinInventory the calculatedMinInventory to set
	 */
	public void setCalculatedMinInventory(Integer calculatedMinInventory) {
		this.calculatedMinInventory = calculatedMinInventory;
	}
	/**
	 * @return the priorityFlag
	 */
	public Float getPriorityFlag() {
		return priorityFlag;
	}
	/**
	 * @param priorityFlag the priorityFlag to set
	 */
	public void setPriorityFlag(Float priorityFlag) {
		this.priorityFlag = priorityFlag;
	}
	
	
	
	
	

}
