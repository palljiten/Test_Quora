package com.genpact.cora.scm.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

public class DemandAllocationForecastSPCustomImpl implements DemandAllocationForecastSPCustom {

    @PersistenceContext
    EntityManager entityManager;

    @Override
    @Transactional
    public void callDemandAllocationForecastStoredProc(String inParam) {
    	//EXEC [dbo].[DemandAllocationForecastSP] @InpParam=''
    	//EXEC [dbo].[DemandAllocationForecastSP] @InpParam='''Europe'',''Netherlands'',''AMS'',''Abbvie'','''',49,8 & ''Europe'',''Netherlands'',''AMS'',''Abbvie'','''',50,5'
    	//EXEC [dbo].[DemandAllocationForecastSP] @InpParam='''Europe West'',''France'',''CDG'',''Sanofi'','''',49,8.41'
    	// OR call like this
    	//
    	//DECLARE	@return_value int
    	//	EXEC	@return_value = [dbo].[DemandAllocationForecastSP] @InpParam='''Europe West'',''Netherlands'',''AMS'',''Amgen'','''',50,3.9'
    	//	SELECT	'Return Value' = @return_value
    	//GO
		System.out.println("\n\nDemandAllocationForecastSP is being call with below input:");
		System.out.println("Input: " + inParam);
    	StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("SP_DemandAllocationForecast");
        query.setParameter("InpParam", inParam);
        System.out.println("Procedure Response: " + query.execute());
    }
}