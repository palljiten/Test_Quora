package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class SparesConsensusCorrectionFactors implements Serializable {

	private static final long serialVersionUID = 1L;

	@Valid
	@NotNull
	@NotEmpty
	private List<String> monthYearMetaData = new ArrayList<>();
	private String formula;
	@Valid
	@NotNull
	@NotEmpty
	private List<CorrectionFactor> correctionValues = new ArrayList<>();

	public String getFormula() {
		return formula;
	}

	public void setFormula(String formula) {
		this.formula = formula;
	}

	public List<CorrectionFactor> getCorrectionValues() {
		return correctionValues;
	}

	public void setCorrectionValues(List<CorrectionFactor> correctionValues) {
		this.correctionValues = correctionValues;
	}

	public List<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(List<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}
}
