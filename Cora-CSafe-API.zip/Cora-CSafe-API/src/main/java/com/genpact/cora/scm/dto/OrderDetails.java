/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.io.Serializable;

/**
 * @author 703158077
 *
 */
public class OrderDetails implements Serializable {

	private static final long serialVersionUID = 9876543213L;
	
	String serialNumber = "";
	String orderNo = "";
	String orderStatus = "";
	String orderValue = "";
	String consignor = "";
	String origin = "";
	String dueDate = "";
	String currency = "";
	String consignee = "";
	String destination = "";
	String notifDate = "";
	String rdd = "";
	
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the orderNo
	 */
	public String getOrderNo() {
		return orderNo;
	}
	/**
	 * @param orderNo the orderNo to set
	 */
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	/**
	 * @return the orderStatus
	 */
	public String getOrderStatus() {
		return orderStatus;
	}
	/**
	 * @param orderStatus the orderStatus to set
	 */
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	/**
	 * @return the orderValue
	 */
	public String getOrderValue() {
		return orderValue;
	}
	/**
	 * @param orderValue the orderValue to set
	 */
	public void setOrderValue(String orderValue) {
		this.orderValue = orderValue;
	}
	/**
	 * @return the consignor
	 */
	public String getConsignor() {
		return consignor;
	}
	/**
	 * @param consignor the consignor to set
	 */
	public void setConsignor(String consignor) {
		this.consignor = consignor;
	}
	/**
	 * @return the origin
	 */
	public String getOrigin() {
		return origin;
	}
	/**
	 * @param origin the origin to set
	 */
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	/**
	 * @return the dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * @return the consignee
	 */
	public String getConsignee() {
		return consignee;
	}
	/**
	 * @param consignee the consignee to set
	 */
	public void setConsignee(String consignee) {
		this.consignee = consignee;
	}
	/**
	 * @return the destination
	 */
	public String getDestination() {
		return destination;
	}
	/**
	 * @param destination the destination to set
	 */
	public void setDestination(String destination) {
		this.destination = destination;
	}
	/**
	 * @return the notifDate
	 */
	public String getNotifDate() {
		return notifDate;
	}
	/**
	 * @param notifDate the notifDate to set
	 */
	public void setNotifDate(String notifDate) {
		this.notifDate = notifDate;
	}
	/**
	 * @return the rdd
	 */
	public String getRdd() {
		return rdd;
	}
	/**
	 * @param rdd the rdd to set
	 */
	public void setRdd(String rdd) {
		this.rdd = rdd;
	}
	
}
