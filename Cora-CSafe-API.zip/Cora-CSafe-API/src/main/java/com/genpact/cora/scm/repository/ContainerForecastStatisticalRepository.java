package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class ContainerForecastStatisticalRepository implements IContainerForecastStatisticalRepository{
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Object[]> getStatistcalModelParam(int modelId){
		
		String hqlQuery = "select msm.ModelName , msp.ParameterName,spv.Value,spv.ParameterID from tbl_master_StatisticalModel msm,"
				+ " tbl_master_StatisticalParameters msp, tbl_StatisticalParameterValues spv where msm.ModelId = :ModelId and " 
				 + " msp.ModelId = msm.ModelId and msp.PID = spv.ParameterID" ;
		
		Query query = entityManager.createQuery(hqlQuery);
		query.setParameter("modelId", modelId);
		List<Object[]> result =query.getResultList();
		return result;
	}

}
