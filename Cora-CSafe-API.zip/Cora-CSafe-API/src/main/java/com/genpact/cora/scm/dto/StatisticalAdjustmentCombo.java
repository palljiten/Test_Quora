package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.Part;
import com.genpact.cora.scm.entity.Region;

public class StatisticalAdjustmentCombo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//private Integer region;
	//private Country country;
	//private HubSc hub;

	private List<String> monthYearMetaData = new ArrayList<>();
	private List<MonthDataUnit> adjustmentValues = new ArrayList<>();

/*	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}*/

	public List<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(List<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}

	public List<MonthDataUnit> getAdjustmentValues() {
		return adjustmentValues;
	}

	public void setAdjustmentValues(List<MonthDataUnit> adjustmentValues) {
		this.adjustmentValues = adjustmentValues;
	}

}
