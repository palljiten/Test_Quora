package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.genpact.cora.scm.entity.ConsensusAverageValues;

public interface ConsensusAveragevaluesRepository extends JpaRepository<ConsensusAverageValues, Integer> {
	
	@Transactional
	@Modifying
	@Query(value="UPDATE tbl_ConsensusAveragevalues SET flag=0 WHERE (countryId=:countryId and hubId=:hubId and regionId=:regionId)" , nativeQuery = true)
	public int updateCorrectionFactor(@Param("countryId") int countryId,@Param("hubId") int hubId,@Param("regionId") int regionId);


}
