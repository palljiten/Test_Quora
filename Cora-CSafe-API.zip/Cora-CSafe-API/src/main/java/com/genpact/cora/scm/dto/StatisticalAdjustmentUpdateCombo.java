package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class StatisticalAdjustmentUpdateCombo  implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<MonthDataUnitUpdate> adjustmentValues = new ArrayList<>();

	public List<MonthDataUnitUpdate> getAdjustmentValues() {
		return adjustmentValues;
	}

	public void setAdjustmentValues(List<MonthDataUnitUpdate> adjustmentValues) {
		this.adjustmentValues = adjustmentValues;
	}

}

