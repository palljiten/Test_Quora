package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "[dbo].[tbl_ConsensusForecast]")
public class AlignedForecast {

	
	public AlignedForecast(float alignedForecast, String monthYear) {
		this.alignedForecast = alignedForecast;
		this.monthYear = monthYear;
	}

	 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RegionId")
	private Region region;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CountryId")
	private Country country;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "HubID")
	private HubSc hubSc;
    
    
    @Column(name = "CreatedMonth")
    private String forecastMonth;
    
    @Column(name = "MonthYear", nullable = true)
    private String monthYear;
    
    @Column(name = "AlignedForecast", nullable = false, length = 100)
    private float alignedForecast;
    
    @Column(name = "ConsensusForecast", nullable = false, length = 100)
    private float consensusForecast;
    

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CreatedDate", nullable = false, length = 100)
    private Date createdDate;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ModifiedDate", nullable = false, length = 100)
    private Date modifiedDate;
    
    
    @Column(name = "Flag", nullable = false, length = 100)
    private Integer flag;


	

	
	public String getForecastMonth() {
		return forecastMonth;
	}


	public void setForecastMonth(String forecastMonth) {
		this.forecastMonth = forecastMonth;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Region getRegion() {
		return region;
	}


	public void setRegion(Region region) {
		this.region = region;
	}


	public Country getCountry() {
		return country;
	}


	public void setCountry(Country country) {
		this.country = country;
	}


	public HubSc getHubSc() {
		return hubSc;
	}


	public void setHubSc(HubSc hubSc) {
		this.hubSc = hubSc;
	}


	public String getMonthYear() {
		return monthYear;
	}


	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}


	public float getAlignedForecast() {
		return alignedForecast;
	}


	public void setAlignedForecast(float alignedForecast) {
		this.alignedForecast = alignedForecast;
	}


	public float getConsensusForecast() {
		return consensusForecast;
	}


	public void setConsensusForecast(float consensusForecast) {
		this.consensusForecast = consensusForecast;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public Date getModifiedDate() {
		return modifiedDate;
	}


	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}


	public Integer getFlag() {
		return flag;
	}


	public void setFlag(Integer flag) {
		this.flag = flag;
	}


	
}
