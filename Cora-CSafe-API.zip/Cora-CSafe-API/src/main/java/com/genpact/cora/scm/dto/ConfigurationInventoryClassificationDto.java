package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class ConfigurationInventoryClassificationDto implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String CriteriaSingle;
	private String CriteriaMultiple;
	private String Fmsn;
	private String AbcValue;
	private String AbcVolume;
	private String Hml;
	private String LeadTime;
	
	private Integer fastFmsn;
	private Integer modertaeFmsn;
	private Integer slowFmsn;
	private Integer nonFmsn;
	
	private Integer AAbcValue;
	private Integer BAbcValue;
	private Integer CAbcValue;
	
	private Integer AAbcVolume;
	private Integer BAbcVolume;
	private Integer CAbcVolume;
	
	private Integer HighHml;
	private Integer MediumHml;
	private Integer LowHml;
	
	private Integer ALeadTime;

	public String getCriteriaSingle() {
		return CriteriaSingle;
	}

	public void setCriteriaSingle(String criteriaSingle) {
		CriteriaSingle = criteriaSingle;
	}

	public String getCriteriaMultiple() {
		return CriteriaMultiple;
	}

	public void setCriteriaMultiple(String criteriaMultiple) {
		CriteriaMultiple = criteriaMultiple;
	}

	public String getFmsn() {
		return Fmsn;
	}

	public void setFmsn(String fmsn) {
		Fmsn = fmsn;
	}

	public String getAbcValue() {
		return AbcValue;
	}

	public void setAbcValue(String abcValue) {
		AbcValue = abcValue;
	}

	public String getAbcVolume() {
		return AbcVolume;
	}

	public void setAbcVolume(String abcVolume) {
		AbcVolume = abcVolume;
	}

	public String getHml() {
		return Hml;
	}

	public void setHml(String hml) {
		Hml = hml;
	}

	public String getLeadTime() {
		return LeadTime;
	}

	public void setLeadTime(String leadTime) {
		LeadTime = leadTime;
	}

	public Integer getFastFmsn() {
		return fastFmsn;
	}

	public void setFastFmsn(Integer fastFmsn) {
		this.fastFmsn = fastFmsn;
	}

	public Integer getModertaeFmsn() {
		return modertaeFmsn;
	}

	public void setModertaeFmsn(Integer modertaeFmsn) {
		this.modertaeFmsn = modertaeFmsn;
	}

	public Integer getSlowFmsn() {
		return slowFmsn;
	}

	public void setSlowFmsn(Integer slowFmsn) {
		this.slowFmsn = slowFmsn;
	}

	public Integer getNonFmsn() {
		return nonFmsn;
	}

	public void setNonFmsn(Integer nonFmsn) {
		this.nonFmsn = nonFmsn;
	}

	public Integer getAAbcValue() {
		return AAbcValue;
	}

	public void setAAbcValue(Integer aAbcValue) {
		AAbcValue = aAbcValue;
	}

	public Integer getBAbcValue() {
		return BAbcValue;
	}

	public void setBAbcValue(Integer bAbcValue) {
		BAbcValue = bAbcValue;
	}

	public Integer getCAbcValue() {
		return CAbcValue;
	}

	public void setCAbcValue(Integer cAbcValue) {
		CAbcValue = cAbcValue;
	}

	public Integer getAAbcVolume() {
		return AAbcVolume;
	}

	public void setAAbcVolume(Integer aAbcVolume) {
		AAbcVolume = aAbcVolume;
	}

	public Integer getBAbcVolume() {
		return BAbcVolume;
	}

	public void setBAbcVolume(Integer bAbcVolume) {
		BAbcVolume = bAbcVolume;
	}

	public Integer getCAbcVolume() {
		return CAbcVolume;
	}

	public void setCAbcVolume(Integer cAbcVolume) {
		CAbcVolume = cAbcVolume;
	}

	public Integer getHighHml() {
		return HighHml;
	}

	public void setHighHml(Integer highHml) {
		HighHml = highHml;
	}

	public Integer getMediumHml() {
		return MediumHml;
	}

	public void setMediumHml(Integer mediumHml) {
		MediumHml = mediumHml;
	}

	public Integer getLowHml() {
		return LowHml;
	}

	public void setLowHml(Integer lowHml) {
		LowHml = lowHml;
	}

	public Integer getALeadTime() {
		return ALeadTime;
	}

	public void setALeadTime(Integer aLeadTime) {
		ALeadTime = aLeadTime;
	}
	
}
