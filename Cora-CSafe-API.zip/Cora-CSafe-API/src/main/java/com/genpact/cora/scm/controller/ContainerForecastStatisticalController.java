package com.genpact.cora.scm.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.ContainerStatisticalBaselineForecastCombo;
import com.genpact.cora.scm.dto.ForecastModelUpdateRequest;
import com.genpact.cora.scm.dto.ModelParams;
import com.genpact.cora.scm.dto.PythonRequestObject;
import com.genpact.cora.scm.dto.PythonResponseObject;
import com.genpact.cora.scm.dto.PythonUpdatedForecastModelUpdateRequest;
import com.genpact.cora.scm.dto.SparesStatisticalAdjustmentCombo;
import com.genpact.cora.scm.dto.SparesStatisticalForecastModelOutput;
import com.genpact.cora.scm.dto.StatisticalAdjustmentCombo;
import com.genpact.cora.scm.dto.StatisticalAdjustmentUpdateCombo;
import com.genpact.cora.scm.dto.StatisticalForecastModelOutput;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.pojo.OnDemandContainerPojo;
import com.genpact.cora.scm.service.ContainerForecastStatisticalService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
@Api(tags = {"Container Forecast - Statistical"})
public class ContainerForecastStatisticalController {
	
	private static Logger logger = LoggerFactory.getLogger(ContainerForecastStatisticalController.class);
	
	@Autowired
	ContainerForecastStatisticalService cfService;
	
	@GetMapping(value="/statistical/forecastModels", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves forecast models")
	public ResponseEntity<Object> getForecastModels(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId){
		logger.info("ForecastStatisticalController: Entering getForecastModels() method");
		StatisticalForecastModelOutput output = cfService.getForecastModels(regionId, countryId, hubId);
		logger.info("ForecastStatisticalController: Exiting getForecastModels() method");
		return new ResponseEntity<>(output, HttpStatus.OK);
	}
	
	@GetMapping(value="/statistical/baseForecast", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves adjustment values")
	public ResponseEntity<Object> getBaseForecast(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId){
		logger.info("ContainerForecastStatisticalController: Entering getBaseForecast() method");
		ContainerStatisticalBaselineForecastCombo data = cfService.getBaseForecast(regionId, countryId, hubId, 6);
		logger.info("ContainerForecastStatisticalController: Exiting getBaseForecast() method");
		return new ResponseEntity<>(data,HttpStatus.OK);
	}
	
	@GetMapping(value="/forecastModels/adjustments", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves adjustment values")
	public ResponseEntity<Object> getAdjustments(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId){
		logger.info("ContainerForecastStatisticalController: Entering getAdjustments() method");
		StatisticalAdjustmentCombo data = cfService.getAdjustments(regionId, countryId, hubId, 6);
		logger.info("ContainerForecastStatisticalController: Exiting getAdjustments() method");
		return new ResponseEntity<>(data,HttpStatus.OK);
	}
	
	@PutMapping(value="/forecastModels/adjustments", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update Correction Factors")
	public ResponseEntity<Object> updateIntelligenceOrAdjustment (@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId, @RequestBody StatisticalAdjustmentUpdateCombo adjustments) {
		logger.info("ContainerForecastStatisticalController: Entering updateIntelligenceOrAdjustment() method");
		cfService.updateAdjustments(regionId, countryId, hubId, adjustments);
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("ContainerForecastStatisticalController: Exiting updateIntelligenceOrAdjustment() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}
	
	@GetMapping(value="/statistical/forecastModels/{modelId}/params", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves forecast models")
	public ResponseEntity<Object> getForecastModelParams(@PathVariable("modelId") int modelId, 
			@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId){
		//Sample call: http://localhost:8090/CoraAnalytics/scm/statistical/forecastModels/1/params?regionId=1&countryId=2&hubId=3
		logger.info("ContainerForecastStatisticalController: Entering getForecastModels() method");
		ModelParams output = cfService.getStatistcalModelParams(modelId, regionId, countryId, hubId);
		logger.info("ContainerForecastStatisticalController: Exiting getForecastModels() method");
		return new ResponseEntity<>(output, HttpStatus.OK);
	}
	
	@PutMapping(value="/statistical/forecastModels/{modelId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves forecast models")
	public ResponseEntity<Object> updateForecastModel(@PathVariable("modelId") int modelId, 
			@RequestParam("regionId") int regionId, @RequestParam("countryId") int countryId,
			@RequestParam("hubId") int hubId, @RequestBody PythonUpdatedForecastModelUpdateRequest modelUpdate){
		//Sample call: http://localhost:8090/CoraAnalytics/scm/statistical/forecastModels/1/params?regionId=1&countryId=2&hubId=3
		logger.info("ContainerForecastStatisticalController: Entering getForecastModels() method");
		cfService.updateForecastModel(modelId, regionId, countryId, hubId, modelUpdate);
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("ContainerForecastStatisticalController: Exiting getForecastModels() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}
	
	@PutMapping(value="/statistical/forecastModels/{modelId}/params", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update forecast models parameter")
	public ResponseEntity<PythonResponseObject> updateForecastModelParams(
			@Valid @RequestBody PythonRequestObject onDemandContainerPojo){
		logger.info("ContainerForecastStatisticalController: Entering updateForecastModelParams() method");
		PythonResponseObject output = cfService.updateStatistcalModelParams(onDemandContainerPojo);
		logger.info("ContainerForecastStatisticalController: Exiting updateForecastModelParams() method");
		return new ResponseEntity<PythonResponseObject>(output, HttpStatus.OK);
	}
}
