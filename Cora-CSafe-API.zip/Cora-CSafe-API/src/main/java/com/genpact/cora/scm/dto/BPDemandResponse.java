package com.genpact.cora.scm.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BPDemandResponse {
	@JsonProperty("region")
	private Map<String, Object> region;
	@JsonProperty("country")
	private Map<String, Object> country;
	@JsonProperty("hub")
	private Map<String, Object> hub;

	private List<String> monthYearMetaData = new ArrayList<>();
	private List<BaselineForecastResponse> demandValues;

	public Map<String, Object> getRegion() {
		return region;
	}

	public void setRegion(Map<String, Object> region) {
		this.region = region;
	}

	public Map<String, Object> getCountry() {
		return country;
	}

	public void setCountry(Map<String, Object> country) {
		this.country = country;
	}

	public Map<String, Object> getHub() {
		return hub;
	}

	public void setHub(Map<String, Object> hub) {
		this.hub = hub;
	}

	public List<BaselineForecastResponse> getDemandValues() {
		return demandValues;
	}

	public void setDemandValues(List<BaselineForecastResponse> demandValues) {
		this.demandValues = demandValues;
	}

	public List<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(List<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}
}
