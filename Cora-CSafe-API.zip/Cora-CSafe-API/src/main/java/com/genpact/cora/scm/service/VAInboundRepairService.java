/**
 * 
 */
package com.genpact.cora.scm.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.RepairEnd;
import com.genpact.cora.scm.repository.VAInboundRepairRepository;

/**
 * @author 703158077
 *
 */
@Service
public class VAInboundRepairService {
	private static Logger logger = LoggerFactory.getLogger(VAInboundRepairService.class);
	
	@Autowired
	VAInboundRepairRepository vairRepositoryEnd ;
	
	
	public RepairEnd findInboundRepairData(String serialNumber){
		
		return vairRepositoryEnd.findbySerialNumber(serialNumber);
	}
}
