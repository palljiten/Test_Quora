package com.genpact.cora.scm.dto;

public class BalanceHotBoard {
	
	private Long balanceInHand;
	private String weekNo;
	private Integer safetyStock;
	private Integer rop;
	private String accountName;
	
	public BalanceHotBoard(Long balanceInHand, String weekNo,String accountName ) {
		 this.balanceInHand = balanceInHand;
		 this.weekNo=weekNo;
		 this.accountName =accountName;
	}
	
	public Long getBalanceInHand() {
		return balanceInHand;
	}
	public void setBalanceInHand(Long balanceInHand) {
		this.balanceInHand = balanceInHand;
	}
	public String getWeekNo() {
		return weekNo;
	}
	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}
	public Integer getSafetyStock() {
		return safetyStock;
	}
	public void setSafetyStock(Integer safetyStock) {
		this.safetyStock = safetyStock;
	}
	public Integer getRop() {
		return rop;
	}
	public void setRop(Integer rop) {
		this.rop = rop;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

}
