package com.genpact.cora.scm.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class RepairEndData {

	@JsonInclude(Include.NON_NULL)
	private String partNumber;
	@JsonInclude(Include.NON_NULL)
	private String description;
	@JsonInclude(Include.NON_NULL)
	private Integer quantity;
	private String containerLocation;
	private String serialNumber;
	@JsonInclude(Include.NON_NULL)
	private Integer workOrderId;
	private Date dueDate;

	public RepairEndData(String partNumber, String description, Integer quantity, String containerLocation,
			String serialNumber, Integer workOrderId, Date dueDate) {

		this.partNumber = partNumber;
		this.description = description;
		this.quantity = quantity;
		this.containerLocation = containerLocation;
		this.serialNumber = serialNumber;
		this.workOrderId = workOrderId;
		this.dueDate = dueDate;

	}

	public RepairEndData(String containerLocation, String serialNumber, Date dueDate) {

		this.containerLocation = containerLocation;
		this.serialNumber = serialNumber;
		this.dueDate = dueDate;

	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getContainerLocation() {
		return containerLocation;
	}

	public void setContainerLocation(String containerLocation) {
		this.containerLocation = containerLocation;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public Integer getWorkOrderId() {
		return workOrderId;
	}

	public void setWorkOrderId(Integer workOrderId) {
		this.workOrderId = workOrderId;
	}

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

}
