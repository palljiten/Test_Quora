package com.genpact.cora.scm.validation;

import java.util.Arrays;

public enum MonthNameEnum {
	
	Jan("Jan"),Feb("Feb"),Mar("Mar"),Apr("Apr"),May("May"),Jun("Jun"),
	Jul("Jul"),Aug("Aug"),Sep("Sep"),Oct("Oct"),Nov("Nov"),Dec("Dec");
	
	private String value;

	private MonthNameEnum(String value) {
		this.value = value;
	}

	public static MonthNameEnum fromValue(String value) {
		for (MonthNameEnum monthName : values()) {
			if (monthName.value.equalsIgnoreCase(value)) {
				return monthName;
			}
		}
		throw new IllegalArgumentException(
				"Unknown enum type " + value + ", Allowed values are " + Arrays.toString(values()));
	}
	
	public String getValue() {
		return value;
	}
}
