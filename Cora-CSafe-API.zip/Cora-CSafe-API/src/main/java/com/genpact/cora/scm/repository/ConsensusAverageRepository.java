package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.genpact.cora.scm.entity.ConsensusAverage;

public interface ConsensusAverageRepository extends JpaRepository<ConsensusAverage, Integer> {

}
