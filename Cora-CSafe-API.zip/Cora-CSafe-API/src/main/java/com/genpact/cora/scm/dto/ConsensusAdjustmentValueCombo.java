package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class ConsensusAdjustmentValueCombo  implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*private Region region;
	private Country country;
	private HubSc hub;*/
	private List<ConsensusAdjustmentValue> adjustmentValues;
	private Set<String> monthYearMetaData;

	public List<ConsensusAdjustmentValue> getAdjustmentValues() {
		return adjustmentValues;
	}

	public void setAdjustmentValues(List<ConsensusAdjustmentValue> adjustmentValues) {
		this.adjustmentValues = adjustmentValues;
	}

	public Set<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(Set<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}
}
