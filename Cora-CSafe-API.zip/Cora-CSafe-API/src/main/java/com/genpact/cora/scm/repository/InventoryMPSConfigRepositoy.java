package com.genpact.cora.scm.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.InventoryPlanningSparesConfig;

public interface InventoryMPSConfigRepositoy extends JpaRepository<InventoryPlanningSparesConfig, Integer> {
	
	@Query("SELECT ipsc FROM InventoryPlanningSparesConfig ipsc WHERE ipsc.regionId = :regionId and ipsc.countryId = :countryId and ipsc.hubId = :hubId and ipsc.partNumber = :partNumber and ipsc.flag = 1 ")
	public List<InventoryPlanningSparesConfig> findConfigDetailsByPartNumber(@Param("regionId")Integer regionId,@Param("countryId")Integer countryId,@Param("hubId")Integer hubId,@Param("partNumber")String partNumber);
	

	
	@Transactional
	@Modifying
	@Query("UPDATE InventoryPlanningSparesConfig ipsc set ipsc.flag = :flag, ipsc.modifiedDate = :modifiedDate WHERE ipsc.hubId = :hubId and ipsc.parameter = :parameter and ipsc.partNumber = :partNumber")
	int updateFlag(@Param("flag") Integer flag, @Param("hubId") Integer hubId, @Param("parameter") String parameter,@Param("partNumber") String partNumber, @Param("modifiedDate") Date modifiedDate);

}
