package com.genpact.cora.scm.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.CorrectionFactor;
import com.genpact.cora.scm.dto.MonthDataUnit;
import com.genpact.cora.scm.dto.SparesConsensusAdjustmentCombo;
import com.genpact.cora.scm.dto.SparesConsensusCorrectionFactors;
import com.genpact.cora.scm.dto.SparesConsensusForecastCombo;
import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.Part;
import com.genpact.cora.scm.entity.Region;
import com.genpact.cora.scm.entity.SparesConsensusAdjustment;
import com.genpact.cora.scm.entity.SparesConsensusCorrectionFactor;
import com.genpact.cora.scm.entity.SparesStatisticalForecast;
import com.genpact.cora.scm.entity.SparesStatisticalForecastConfig;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.SparesConsensusAdjustmentRepository;
import com.genpact.cora.scm.repository.SparesConsensusCorrectionFactorRepository;
import com.genpact.cora.scm.repository.SparesStatisticalForecastConfigRepository;
import com.genpact.cora.scm.repository.SparesStatisticalForecastRepository;

@Service
public class SparesForecastConsensusService {

	private static Logger logger = LoggerFactory.getLogger(SparesForecastConsensusService.class);
	private static Map<Integer, String> monthValueMap = new HashMap<>();
	private static Map<String, Integer> monthValueReverseMap = new HashMap<>();
	private static Map<String, String> yearMap = new HashMap<>();
	private static Map<String, String> yearReverseMap = new HashMap<>();
	
	static {
		monthValueMap.put(0, "Jan");
		monthValueMap.put(1, "Feb");
		monthValueMap.put(2, "Mar");
		monthValueMap.put(3, "Apr");
		monthValueMap.put(4, "May");
		monthValueMap.put(5, "Jun");
		monthValueMap.put(6, "Jul");
		monthValueMap.put(7, "Aug");
		monthValueMap.put(8, "Sep");
		monthValueMap.put(9, "Oct");
		monthValueMap.put(10, "Nov");
		monthValueMap.put(11, "Dec");
		
		monthValueReverseMap.put("Jan", 0);
		monthValueReverseMap.put("Feb", 1);
		monthValueReverseMap.put("Mar", 2);
		monthValueReverseMap.put("Apr", 3);
		monthValueReverseMap.put("May", 4);
		monthValueReverseMap.put("Jun", 5);
		monthValueReverseMap.put("Jul", 6);
		monthValueReverseMap.put("Aug", 7);
		monthValueReverseMap.put("Sep", 8);
		monthValueReverseMap.put("Oct", 9);
		monthValueReverseMap.put("Nov", 10);
		monthValueReverseMap.put("Dec", 11);
		
		yearMap.put("15", "2015");
		yearMap.put("16", "2016");
		yearMap.put("17", "2017");
		yearMap.put("18", "2018");
		yearMap.put("19", "2019");
		yearMap.put("20", "2020");
		yearMap.put("21", "2021");
		yearMap.put("22", "2022");
		
		yearReverseMap.put("2015", "15");
		yearReverseMap.put("2016", "16");
		yearReverseMap.put("2017", "17");
		yearReverseMap.put("2018", "18");
		yearReverseMap.put("2019", "19");
		yearReverseMap.put("2020", "20");
		yearReverseMap.put("2021", "21");
		yearReverseMap.put("2022", "22");
	}
	
	@Autowired
	SparesConsensusAdjustmentRepository scaRepository; 
	
	@Autowired
	SparesConsensusCorrectionFactorRepository sccfRepository; 
	
	@Autowired
	SparesStatisticalForecastRepository forecastRepository;
	
	@Autowired
	SparesStatisticalForecastConfigRepository configRepository;

	public SparesConsensusForecastCombo getSparesConsensusForecast(int regionId, int countryId, int hubId, String partId) throws CSafeServiceException {
		SparesConsensusForecastCombo data = new SparesConsensusForecastCombo();
		List<SparesStatisticalForecastConfig> configuredModel = configRepository.getConfiguredModel(regionId, countryId, hubId, partId);
		List<SparesStatisticalForecast> list = forecastRepository.getSparesStatisticalForecast(regionId, countryId, hubId, partId, 
				configuredModel.get(0).getConfiguredModel().getModelId(), 6);
		populate(data, list, partId);
		return data;
	}
	
	public SparesConsensusCorrectionFactors getCorrectionFactors(int regionId, int countryId, int hubId, int partId) throws CSafeServiceException {
		logger.info("SparesForecastConsensusService: Entering getCorrectionFactors() method");
		SparesConsensusCorrectionFactors data = new SparesConsensusCorrectionFactors();
		List<SparesConsensusCorrectionFactor> sccfList = sccfRepository.getSparesConsensusCorrectionFactor(regionId, countryId, hubId, partId+"", 6);
		populate(data, partId+"", sccfList);
		logger.info("SparesForecastConsensusService: Eiting getCorrectionFactors() method");
		return data;
	}
	
	@Transactional
	public void updateCorrectionFactors(int regionId, int countryId, int hubId, int partId, SparesConsensusCorrectionFactors correctionFactors) throws CSafeServiceException{
		logger.info("SparesForecastConsensusService: Entering updateCorrectionFactors() method");
		
		SparesConsensusCorrectionFactor entity = null;
		Country c = new Country();
		c.setCountryId(countryId);
		
		Region r = new Region();
		r.setRegionId(regionId);
		
		HubSc h = new HubSc();
		h.setHubId(hubId);
		h.setCountry(c);
		h.setRegion(r);

		List<CorrectionFactor> newValues = correctionFactors.getCorrectionValues();
		for(CorrectionFactor newValue : newValues) {
			entity = new SparesConsensusCorrectionFactor();
			entity.setRegion(r);
			entity.setCountry(c);
			entity.setHub(h);
			entity.setPartId(partId+"");
			entity.setFlag(1);
			entity.setValue(newValue.getBaseline() + "");
			
			String month = newValue.getMonth();
			String year = newValue.getYear();
			entity.setMonthYear(month + "-" + yearReverseMap.get(year+""));
			entity.setCreatedDate(new Date());
			entity.setModifiedDate(new Date());
			entity.setModifiedBy("CsafeAdmin");
			
			sccfRepository.updateSparesConsensusCorrectionFactor(month + "-" + yearReverseMap.get(year+""), regionId, countryId, hubId, partId + "");
			sccfRepository.save(entity);
		}
		
		logger.info("SparesForecastConsensusService: Exiting updateCorrectionFactors() method");
	}
	
	public SparesConsensusAdjustmentCombo getAdjustments(int regionId, int countryId, int hubId, int partId) throws CSafeServiceException {
		logger.info("SparesForecastConsensusService: Entering getAdjustments() method");
		SparesConsensusAdjustmentCombo data = new SparesConsensusAdjustmentCombo();
		List<SparesConsensusAdjustment> scaList = scaRepository.getSparesConsensusAdjustment(regionId, countryId, hubId, partId, 2);
		populate(data, partId, scaList);
		logger.info("SparesForecastConsensusService: Exiting getAdjustments() method");
		return data;
	}
	
	@Transactional
	public void updateAdjustments(int regionId, int countryId, int hubId, int partId, SparesConsensusAdjustmentCombo adjustments) throws CSafeServiceException{
		logger.info("SparesForecastConsensusService: Entering updateAdjustments() method");
		
		SparesConsensusAdjustment entity = new SparesConsensusAdjustment();
		Country c = new Country();
		c.setCountryId(countryId);
		
		Region r = new Region();
		r.setRegionId(regionId);
		
		HubSc h = new HubSc();
		h.setHubId(hubId);
		h.setCountry(c);
		h.setRegion(r);

		List<MonthDataUnit> newValues = adjustments.getAdjustmentValues();
		for(MonthDataUnit newValue : newValues) {
			
			entity = new SparesConsensusAdjustment();
			entity.setRegion(r);
			entity.setCountry(c);
			entity.setHub(h);
			entity.setPartId(partId);
			entity.setFlag(1);
			entity.setValue(newValue.getValue());
			
			String month = newValue.getMonth();
			int year = newValue.getYear();
			entity.setMonthYear(month + "-" + yearReverseMap.get(year+""));
			entity.setCreatedDate(new Date());
			entity.setModifiedDate(new Date());
			entity.setModifiedBy("CsafeAdmin");
			
			scaRepository.updateSparesConsensusAdjustment(regionId, countryId, hubId, partId, month + "-" + yearReverseMap.get(year+""));
			scaRepository.save(entity);
		}
		
		logger.info("SparesForecastConsensusService: Exiting updateAdjustments() method");
	}
	
	private String getProperMonthYear(String my) throws CSafeServiceException{
		StringBuffer properMonthYear = new StringBuffer("");
		String[] parts = my.split("-");
		properMonthYear.append(parts[0]);
		properMonthYear.append(" ");
		properMonthYear.append(yearMap.get(parts[1]));
		return properMonthYear.toString();
	}
	
	private void populate(SparesConsensusAdjustmentCombo data, int partId, List<SparesConsensusAdjustment> scaList) {
		
		Part p = new Part();
		p.setPartNumber(partId + "");
		data.setPart(p);
		
		for(SparesConsensusAdjustment sca : scaList) {
			data.setCountry(sca.getCountry());
			data.setHub(sca.getHub());
			data.setRegion(sca.getRegion());
			
			String monthYear = getProperMonthYear(sca.getMonthYear());
			data.getMonthYearMetaData().add(monthYear);
			
			MonthDataUnit mdu = new MonthDataUnit();
			
			String[] parts = monthYear.split(" ");
			mdu.setMonth(parts[0]);
			mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
			mdu.setYear(Integer.parseInt(parts[1]));
			mdu.setValue(sca.getValue());
			
			data.getAdjustmentValues().add(mdu);
		}
	}
	
	private void populate(SparesConsensusCorrectionFactors data, String partId, List<SparesConsensusCorrectionFactor> sccfList)  {
		
		data.setFormula("WeightedAverage");
		for(SparesConsensusCorrectionFactor sccf : sccfList) {
			String monthYear = getProperMonthYear(sccf.getMonthYear());
			data.getMonthYearMetaData().add(monthYear);
			
			CorrectionFactor cf = new CorrectionFactor();
			
			String[] parts = monthYear.split(" ");
			cf.setMonth(parts[0]);
			cf.setMonthValue(monthValueReverseMap.get(parts[0]));
			cf.setYear(parts[1]);
			int baseline = Integer.parseInt(sccf.getValue());
			cf.setBaseline(baseline);
			cf.setStatistical(100 - baseline);
			
			data.getCorrectionValues().add(cf);
		}
	}
	
	private void populate(SparesConsensusForecastCombo data, List<SparesStatisticalForecast> list, String partId) {
		Part p = new Part();
		p.setPartNumber(partId + "");
		data.setPart(p);
		
		for(SparesStatisticalForecast sca : list) {
			data.setCountry(sca.getCountry());
			data.setHub(sca.getHub());
			data.setRegion(sca.getRegion());
			
			String monthYear = getProperMonthYear(sca.getMonthYear());
			data.getMonthYearMetaData().add(monthYear);
			
			MonthDataUnit mdu = new MonthDataUnit();
			
			String[] parts = monthYear.split(" ");
			mdu.setMonth(parts[0]);
			mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
			mdu.setYear(Integer.parseInt(parts[1]));
			mdu.setValue(sca.getForecastValue());
			
			data.getStatisticalForecast().add(mdu);
		}		
	}
}
