package com.genpact.cora.scm.dto;

import java.util.Date;

public class VARepairData {
	
		
	private String serialNumber;
		
	private String status;
		
	private String containerLocation;
	
	private String actualReceivingDate;
	
	private String arrivalDate;
	
	private String dueDate;
	
	private String notificationDate;
	
	private String estimatedReceivingDate;
	
	private String alertType;
	
	private String alertDescription;

	private String weekNo;
	
	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public String getContainerLocation() {
		return containerLocation;
	}

	public void setContainerLocation(String containerLocation) {
		this.containerLocation = containerLocation;
	}

	public String getActualReceivingDate() {
		return actualReceivingDate;
	}

	public void setActualReceivingDate(String actualReceivingDate) {
		this.actualReceivingDate = actualReceivingDate;
	}

	public String getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(String notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getEstimatedReceivingDate() {
		return estimatedReceivingDate;
	}

	public void setEstimatedReceivingDate(String estimatedReceivingDate) {
		this.estimatedReceivingDate = estimatedReceivingDate;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	
	public String getAlertDescription() {
		return alertDescription;
	}

	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}

	public String getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}

}
