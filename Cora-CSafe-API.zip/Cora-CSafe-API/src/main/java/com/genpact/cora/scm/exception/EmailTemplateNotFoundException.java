package com.genpact.cora.scm.exception;

import org.springframework.http.HttpStatus;

public class EmailTemplateNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	private HttpStatus status;

	public EmailTemplateNotFoundException(String message, HttpStatus status) {
        super(message);
        this.status = status;
    }

    public EmailTemplateNotFoundException(String message, HttpStatus status, Throwable cause) {
        super(message, cause);
    }

    public EmailTemplateNotFoundException(HttpStatus status, Throwable cause) {
        super(cause);
    }

	public HttpStatus getStatus() {
		return status;
	}
}
