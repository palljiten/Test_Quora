package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.Part;
import com.genpact.cora.scm.entity.Region;

public class SparesConsensusForecastCombo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Region region;
	private Country country;
	private HubSc hub;
	private Part part;
	
	private List<String> monthYearMetaData = new ArrayList<>();
	private List<MonthDataUnit> baselineForecast = new ArrayList<>();
	private List<MonthDataUnit> statisticalForecast = new ArrayList<>();

	public List<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(List<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}

	public List<MonthDataUnit> getBaselineForecast() {
		return baselineForecast;
	}

	public void setBaselineForecast(List<MonthDataUnit> baselineForecast) {
		this.baselineForecast = baselineForecast;
	}

	public List<MonthDataUnit> getStatisticalForecast() {
		return statisticalForecast;
	}

	public void setStatisticalForecast(List<MonthDataUnit> statisticalForecast) {
		this.statisticalForecast = statisticalForecast;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}

	public Part getPart() {
		return part;
	}

	public void setPart(Part part) {
		this.part = part;
	}
}
