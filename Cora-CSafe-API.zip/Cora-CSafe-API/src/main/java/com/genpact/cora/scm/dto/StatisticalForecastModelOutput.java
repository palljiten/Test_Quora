package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class StatisticalForecastModelOutput implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<String> monthYearMetaData = new ArrayList<>();
	private List<SingleModelOutput> modelOutput = new ArrayList<>();

	public List<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(List<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}

	public List<SingleModelOutput> getModelOutput() {
		return modelOutput;
	}

	public void setModelOutput(List<SingleModelOutput> modelOutput) {
		this.modelOutput = modelOutput;
	}
}