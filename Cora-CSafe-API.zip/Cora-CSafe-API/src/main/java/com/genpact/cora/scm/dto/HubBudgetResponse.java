package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HubBudgetResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer regionId;
	private String regionName;
	private List<SingleHubBudget> hubBudgets = new ArrayList<>();
	
	public Integer getRegionId() {
		return regionId;
	}
	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	public List<SingleHubBudget> getHubBudgets() {
		return hubBudgets;
	}
	public void setHubBudgets(List<SingleHubBudget> hubBudgets) {
		this.hubBudgets = hubBudgets;
	}
}
