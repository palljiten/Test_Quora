/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.io.Serializable;

/**
 * @author 703158077
 *
 */
public class transportationDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543214L;
	
	String awbNo = "";
	String mode = "";
	String carrier = "";
	String weight = "";
	String uom = "";
	String scheduleDelivery = "";
	String actualDelivery = "";
	String shippingId = "";
	String tripName = "";
	
	
	
	/**
	 * @return the awbNo
	 */
	public String getAwbNo() {
		return awbNo;
	}
	/**
	 * @param awbNo the awbNo to set
	 */
	public void setAwbNo(String awbNo) {
		this.awbNo = awbNo;
	}
	/**
	 * @return the mode
	 */
	public String getMode() {
		return mode;
	}
	/**
	 * @param mode the mode to set
	 */
	public void setMode(String mode) {
		this.mode = mode;
	}
	/**
	 * @return the carrier
	 */
	public String getCarrier() {
		return carrier;
	}
	/**
	 * @param carrier the carrier to set
	 */
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	/**
	 * @return the weight
	 */
	public String getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}
	/**
	 * @return the uom
	 */
	public String getUom() {
		return uom;
	}
	/**
	 * @param uom the uom to set
	 */
	public void setUom(String uom) {
		this.uom = uom;
	}
	/**
	 * @return the scheduleDelivery
	 */
	public String getScheduleDelivery() {
		return scheduleDelivery;
	}
	/**
	 * @param scheduleDelivery the scheduleDelivery to set
	 */
	public void setScheduleDelivery(String scheduleDelivery) {
		this.scheduleDelivery = scheduleDelivery;
	}
	/**
	 * @return the actualDelivery
	 */
	public String getActualDelivery() {
		return actualDelivery;
	}
	/**
	 * @param actualDelivery the actualDelivery to set
	 */
	public void setActualDelivery(String actualDelivery) {
		this.actualDelivery = actualDelivery;
	}
	/**
	 * @return the shippingId
	 */
	public String getShippingId() {
		return shippingId;
	}
	/**
	 * @param shippingId the shippingId to set
	 */
	public void setShippingId(String shippingId) {
		this.shippingId = shippingId;
	}
	/**
	 * @return the tripName
	 */
	public String getTripName() {
		return tripName;
	}
	/**
	 * @param tripName the tripName to set
	 */
	public void setTripName(String tripName) {
		this.tripName = tripName;
	}

}
