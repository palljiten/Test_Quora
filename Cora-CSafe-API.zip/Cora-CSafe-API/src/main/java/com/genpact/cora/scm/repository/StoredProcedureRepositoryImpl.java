package com.genpact.cora.scm.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class StoredProcedureRepositoryImpl implements StoredProcedureRepository {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public void callBudgetForecastSP() {
		this.em.createNativeQuery("BEGIN BudgetForecastSP(); END;").executeUpdate();
	}
}
