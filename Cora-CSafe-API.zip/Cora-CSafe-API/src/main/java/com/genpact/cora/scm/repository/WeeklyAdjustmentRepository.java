package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.genpact.cora.scm.entity.WeeklyAdjustment;

public interface WeeklyAdjustmentRepository extends JpaRepository<WeeklyAdjustment, Integer>{
	
}
