package com.genpact.cora.scm.repository;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.dto.RepairEnd;
import com.genpact.cora.scm.dto.RepairEndData;

@Repository
@SuppressWarnings("unchecked")
public class VisibilityHotBoardRepository {

	@PersistenceContext
	private EntityManager entityManager;

	public List<Object[]> getFutureYearWeeks() {
		//Query to be reverted back after QA ------ This is the actual query 
		/*String query = "select distinct top(4) CONCAT(DATEPART(year,c.Date),'-',DATEPART(week,c.Date)) as yearWeek, DATEPART(year,c.Date) as year,DATEPART(week,c.Date) as week  \r\n" + 
				"from tbl_master_Calendar c where Date > DATEADD(week,-4, GETDATE()) and Date <= GETDATE() order by  DATEPART(year,Date),DATEPART(week,Date) asc";*/
		
		String query = "select distinct top(4) CONCAT(DATEPART(year,c.Date),'-',DATEPART(week,c.Date)) as yearWeek, DATEPART(year,c.Date)\r\n" + 
				" as year,DATEPART(week,c.Date) as week  from tbl_master_Calendar c where Date < DATEADD(week,4, GETDATE())\r\n" + 
				"  and Date >= GETDATE() order by  DATEPART(year,Date),DATEPART(week,Date) asc";
		return entityManager.createNativeQuery(query).getResultList();

	}

	public List<Object[]> getVisibilityHotBoardFilter(String visibilityType, java.util.Date startDate,
			java.util.Date endDate) {
		StringBuilder hqlQuery = new StringBuilder("select  from ");
		List<Object> visibilityFields = Arrays.asList("status", "origin", "City", "CountryName", "alertDescription",
				"dueDate", "startDate", "endDate");
		Map<Integer, String> visibilitySource = new LinkedHashMap<>();
		visibilitySource.put(1, "VAInbound");
		visibilitySource.put(2, "VALeaseEnd");
		visibilitySource.put(3, "BalanceInHand");
		visibilitySource.put(4, "VARepair");
		visibilitySource.put(5, "ResolvedIssues");

		Query query = null;

		if (visibilityType != null && visibilityType.equalsIgnoreCase("InboundHotBoard")) {
			hqlQuery.insert(7, "distinct" + "(" + visibilityFields.get(0) + ")" + " ," + visibilityFields.get(1));
			String finalQuery = hqlQuery.toString().concat(visibilitySource.get(1));
			query = entityManager.createQuery(finalQuery);
		} else if (visibilityType != null && visibilityType.equalsIgnoreCase("LeaseEndHotBoard")) {
			hqlQuery.insert(7, "distinct" + "(" + visibilityFields.get(1) + ")");
			String finalQuery = hqlQuery.toString().concat(visibilitySource.get(2));
			query = entityManager.createQuery(finalQuery);
		} else if (visibilityType != null && visibilityType.equalsIgnoreCase("BalanceInHand")) {
			String finalQuery = null;
			hqlQuery.insert(7, "distinct" + "(" + visibilityFields.get(2) + ")" + " ," + visibilityFields.get(3));
			if (startDate == null && endDate == null) {
				finalQuery = hqlQuery.toString().concat(visibilitySource.get(3));
				query = entityManager.createQuery(finalQuery);
			} else {
				StringBuilder query2 = hqlQuery.append(visibilitySource.get(3)).append(" where ")
						.append(visibilityFields.get(5) + " between " + ":startDate" + " and " + ":endDate");
				finalQuery = query2.toString();
				query = entityManager.createQuery(finalQuery);
				query.setParameter("startDate", startDate);
				query.setParameter("endDate", endDate);
			}
		} else if (visibilityType != null && visibilityType.equalsIgnoreCase("Repair")) {
			hqlQuery.insert(7, "distinct" + "(" + visibilityFields.get(4) + ")");
			String finalQuery = hqlQuery.toString().concat(visibilitySource.get(4));
			query = entityManager.createQuery(finalQuery);
		} else if (visibilityType != null && visibilityType.equalsIgnoreCase("ResolvedIssues")) {
			hqlQuery.insert(7, "distinct" + "(" + visibilityFields.get(0) + ")" + " ," + visibilityFields.get(1));
			String finalQuery = hqlQuery.toString().concat(visibilitySource.get(5));
			query = entityManager.createQuery(finalQuery);
		}
		return query.getResultList();
	}

	public List<RepairEndData> getRepairEndAnalyseData(String serialNumber, String alertDesc) {

		Query query = null;

		if (alertDesc!=null && alertDesc.equalsIgnoreCase("Waiting for parts")) {

			String hqlQuery = "select new com.genpact.cora.scm.dto.RepairEndData (rwp.partNumber, rwp.description, rwp.quantity, vr.containerLocation, vr.serialNumber, rwo.workOrderId,vr.dueDate)"
					+ "from VARepair vr,RepairWorkOrder rwo, RepairWorkOrderParts rwp where vr.serialNumber = :serialNumber and vr.containeerId = rwo.containerId and "
					+ "rwo.workOrderId =rwp.workOrderID and vr.currentlyInStock=0 and rwp.createDate >=vr.arrivalDate "; //and vr.actualReceivingDate=null";

			query = entityManager.createQuery(hqlQuery);
			query.setParameter("serialNumber", serialNumber);
		}
		
		else {
			String hqlQuery = "select new com.genpact.cora.scm.dto.RepairEndData ( vr.containerLocation, vr.serialNumber,vr.dueDate)"
					+ "from VARepair vr where vr.serialNumber = :serialNumber";

			query = entityManager.createQuery(hqlQuery);
			query.setParameter("serialNumber", serialNumber);
		}

		/*else if ( alertDesc.equalsIgnoreCase("Due date crossed")) {

			String hqlQuery = "select new com.genpact.cora.scm.dto.RepairEndData ( vr.containerLocation, vr.serialNumber,vr.dueDate)"
					+ "from VARepair vr where vr.serialNumber = :serialNumber"; //and vr.containeerId = rwo.containerId and "
				//	+ " vr.dueDate < GETDATE() and vr.actualReceivingDate=null ";

			query = entityManager.createQuery(hqlQuery);
			query.setParameter("serialNumber", serialNumber);

		} else if (alertDesc.equalsIgnoreCase("Notification Sent")) {

			String hqlQuery = "select new com.genpact.cora.scm.dto.RepairEndData ( vr.containerLocation, vr.serialNumber,vr.dueDate)"
					+ "from VARepair vr where vr.serialNumber = :serialNumber"; and vr.containeerId = rwo.containerId and "
					+ " vr.dueDate <= GETDATE() and GETDATE() <=vr.estimatedReceivingDate and vr.actualReceivingDate=null ";

			query = entityManager.createQuery(hqlQuery);
			query.setParameter("serialNumber", serialNumber);

		} else if (alertDesc.equalsIgnoreCase("No Notification")) {

			String hqlQuery = "select new com.genpact.cora.scm.dto.RepairEndData ( vr.containerLocation, vr.serialNumber,vr.dueDate)"
					+ "from VARepair vr where vr.serialNumber = :serialNumber"; and vr.containeerId = rwo.containerId and "
					+ " vr.dueDate > GETDATE() and vr.actualReceivingDate=null ";

			query = entityManager.createQuery(hqlQuery);
			query.setParameter("serialNumber", serialNumber);

		}*/
		
		return query.getResultList();
	}

	public List<Object[]> getRepairHotBoardData() {
		
		List<Object[]> repairAnalyse = entityManager.createNativeQuery("select distinct weekno,[SerialNumber],[Status],[ContainerLocation],[AlertDescription],[DueDate],[NotificationDate], "
				+ " [EstimatedReceivingDate],[ActualReceivingdate],[AlertType] from [tbl_VARepair] A " 
				+ " LEFT JOIN tbl_master_Calendar B ON (CONVERT(DATE,A.duedate) =CONVERT(DATE,B.Date)) "  
				+" where B.WeekstartDate >= (SELECT WeekStartdate FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE())) "
				+" AND B.WeekstartDate<=(SELECT DATEADD(Day,21,WeekStartdate) FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE()))").getResultList();
		
		return repairAnalyse;

	}

}
