package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class SparesInventoryClassification implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String partNumber;
	private String serviceCenter;
	private String fsn;
	private String hits;
	private String hml;
	private String cost;
	private String abcDemand;
	private String abcDemandClassification;
	private String abcValue;
	private String abcValueClassification;
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the serviceCenter
	 */
	public String getServiceCenter() {
		return serviceCenter;
	}
	/**
	 * @param serviceCenter the serviceCenter to set
	 */
	public void setServiceCenter(String serviceCenter) {
		this.serviceCenter = serviceCenter;
	}
	/**
	 * @return the fsn
	 */
	public String getFsn() {
		return fsn;
	}
	/**
	 * @param fsn the fsn to set
	 */
	public void setFsn(String fsn) {
		this.fsn = fsn;
	}
	/**
	 * @return the hits
	 */
	public String getHits() {
		return hits;
	}
	/**
	 * @param hits the hits to set
	 */
	public void setHits(String hits) {
		this.hits = hits;
	}
	/**
	 * @return the hml
	 */
	public String getHml() {
		return hml;
	}
	/**
	 * @param hml the hml to set
	 */
	public void setHml(String hml) {
		this.hml = hml;
	}
	/**
	 * @return the cost
	 */
	public String getCost() {
		return cost;
	}
	/**
	 * @param cost the cost to set
	 */
	public void setCost(String cost) {
		this.cost = cost;
	}
	/**
	 * @return the abcDemand
	 */
	public String getAbcDemand() {
		return abcDemand;
	}
	/**
	 * @param abcDemand the abcDemand to set
	 */
	public void setAbcDemand(String abcDemand) {
		this.abcDemand = abcDemand;
	}
	/**
	 * @return the abcDemandClassification
	 */
	public String getAbcDemandClassification() {
		return abcDemandClassification;
	}
	/**
	 * @param abcDemandClassification the abcDemandClassification to set
	 */
	public void setAbcDemandClassification(String abcDemandClassification) {
		this.abcDemandClassification = abcDemandClassification;
	}
	/**
	 * @return the abcValue
	 */
	public String getAbcValue() {
		return abcValue;
	}
	/**
	 * @param abcValue the abcValue to set
	 */
	public void setAbcValue(String abcValue) {
		this.abcValue = abcValue;
	}
	/**
	 * @return the abcValueClassification
	 */
	public String getAbcValueClassification() {
		return abcValueClassification;
	}
	/**
	 * @param abcValueClassification the abcValueClassification to set
	 */
	public void setAbcValueClassification(String abcValueClassification) {
		this.abcValueClassification = abcValueClassification;
	}
	
}
