package com.genpact.cora.scm.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.genpact.cora.scm.entity.WeeklyForecast;

public interface WeeklyForecastRepository extends JpaRepository<WeeklyForecast, Integer> {

	@Query(value = "select distinct top (:weeks) fc.FinalWeekly as value,c.WeekstartDate as wsd,"
			+ " c.SCMYearWeek as weekNum from tbl_master_Calendar c left OUTER join tbl_WeeklyForecast fc"
			+ " on c.SCMYearWeek=fc.SCMYearWeek  AND fc.RegionID=:RegionID and fc.CountryID=:CountryID AND"
			+ " fc.HubID=:HubID and fc.Flag=1 where :firstWeekDateOfMonth < DATEADD(wk,:weeks,:firstWeekDateOfMonth) and Date > :firstWeekDateOfMonth "
			+ "and c.SCMYearWeek IS NOT NULL"
			+ " order by c.WeekstartDate asc", nativeQuery = true)
	List<Object[]> getForecast(@Param("weeks") Integer weeks, @Param("RegionID") Integer regionID,
			@Param("CountryID") Integer countryID, @Param("HubID") Integer hubID,@Param("firstWeekDateOfMonth") String firstWeekDateOfMonth);

	@Query(value = "select distinct TOP(:weeks) fc.value as value,c.WeekstartDate as wsd,c.SCMYearWeek "
			+ " from tbl_master_Calendar c left outer join  tbl_WeeklyAdjustment fc"
			+ " on  c.WeekStartDate=fc.WeekStartDate and fc.RegionID=:RegionID and fc.CountryID=:CountryID and"
			+ " fc.HubID=:HubID and fc.Flag=1 where :startdateOfWeek < DATEADD(wk,:weeks, :startdateOfWeek) and Date > :startdateOfWeek "
			+ "and c.SCMYearWeek IS NOT NULL "
			+ "order by c.WeekstartDate asc", nativeQuery = true)
	List<Object[]> getFogetWeeklyAdjustmentsrecast(@Param("RegionID") Integer regionID,
			@Param("CountryID") Integer countryID, @Param("HubID") Integer hubID, @Param("weeks") int weeks,
			@Param("startdateOfWeek") String startdateOfWeek);

	@Transactional
	@Modifying
	@Query(value = "update tbl_WeeklyAdjustment  set Flag=0"
			+ " where RegionID=:RegionID and CountryID=:CountryID and HubID=:HubID and WeekStartDate=:WeekStartDate", nativeQuery = true)
	int updateWeeklyAdjustments(@Param("RegionID") int regionId, @Param("CountryID") int countryId,
			@Param("HubID") int hubId, @Param("WeekStartDate") Date WeekStartDate);

	@Query(value = "select TOP(:weeks) count(l.SI) as count,c.WeekstartDate as wsdt, c.SCMYearWeek"
			+ " from tbl_master_Calendar c left outer join tbl_Lease l on  c.Date=l.orderDate and "
			+ " l.PossStartHubSC=:hubCode where  date > DATEADD(wk,-:weeks, GETDATE()) "
			+ " and date < GETDATE() and datepart(wk,date)!=datepart(wk,getdate())"
			+ "	group by  c.WeekstartDate,c.SCMYearWeek order by c.WeekstartDate asc", nativeQuery = true)
	List<Object[]> getBaselineDemand(@Param("hubCode") String hubCode, @Param("weeks") int weekNum);

	
	@Query(value = "select top(1) weekstartDate from tbl_master_Calendar where weekOfYear=:weekNum and year=:year", nativeQuery = true)
	Date getWeekStartDate(@Param("weekNum") int weekNum, @Param("year") int year);

	@Query(value = "select TOP(:weeks) count(l.SI) as count,c.WeekstartDate as wsdt,c.SCMYearWeek "
			+ " from tbl_master_Calendar c left outer join tbl_Lease l on "
			+ " c.Date=l.orderDate and  l.PossStartHubSC=:hubCode where :startdateOfWeek < DATEADD(wk,:weeks, :startdateOfWeek)"
			+ "	and date > :startdateOfWeek and c.SCMYearWeek IS NOT NULL "
			+ "group by  c.WeekstartDate,c.SCMYearWeek "
			+ "order by c.WeekstartDate,c.SCMYearWeek", nativeQuery = true)
	List<Object[]> getActuals(@Param("hubCode") String hubCode, @Param("weeks") int weeks,
			@Param("startdateOfWeek") String startdateOfWeek);

	@Query(value = "select distinct TOP(:weeks) c.WeekstartDate as wsd, c.SCMYearWeek as wk"
			+ " from tbl_master_Calendar c 	 where Date < DATEADD(wk,:weeks, GETDATE()) and"
			+ " Date > GETDATE()", nativeQuery = true)
	List<Object[]> getNextWeeks(@Param("weeks") Integer weeks);
}
