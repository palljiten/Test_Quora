package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.Part;
import com.genpact.cora.scm.entity.Region;

public class SparesStatisticalBaselineForecastCombo implements Serializable {

	private static final long serialVersionUID = 1L;

	private Region region;
	private Country country;
	private HubSc hub;
	private Part part;

	private List<String> monthYearMetaData = new ArrayList<>();
	private List<MonthYearDataUnit> baselineForecast = new ArrayList<>();
	
	private Map<String, Float> valueSummary = new HashMap<>();

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}

	public Part getPart() {
		return part;
	}

	public void setPart(Part part) {
		this.part = part;
	}

	public List<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(List<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}

	public List<MonthYearDataUnit> getBaselineForecast() {
		return baselineForecast;
	}

	public void setBaselineForecast(List<MonthYearDataUnit> baselineForecast) {
		this.baselineForecast = baselineForecast;
	}

	public Map<String, Float> getValueSummary() {
		return valueSummary;
	}

	public void setValueSummary(Map<String, Float> valueSummary) {
		this.valueSummary = valueSummary;
	}
}
