package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class SingleHubBudget implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer hubId;
	private String hubCode; 
	private String hubType;
	private String hubState;
	private Integer hubCountryId;
	private String hubCountryName;
	private float budgetPercentage;
	
	public Integer getHubId() {
		return hubId;
	}
	public void setHubId(Integer hubId) {
		this.hubId = hubId;
	}
	public String getHubCode() {
		return hubCode;
	}
	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}
	public String getHubType() {
		return hubType;
	}
	public void setHubType(String hubType) {
		this.hubType = hubType;
	}
	public String getHubState() {
		return hubState;
	}
	public void setHubState(String hubState) {
		this.hubState = hubState;
	}
	public Integer getHubCountryId() {
		return hubCountryId;
	}
	public void setHubCountryId(Integer hubCountryId) {
		this.hubCountryId = hubCountryId;
	}
	public String getHubCountryName() {
		return hubCountryName;
	}
	public void setHubCountryName(String hubCountryName) {
		this.hubCountryName = hubCountryName;
	}
	public float getBudgetPercentage() {
		return budgetPercentage;
	}
	public void setBudgetPercentage(float budgetPercentage) {
		this.budgetPercentage = budgetPercentage;
	}
}
