package com.genpact.cora.scm.dto;

import java.util.Date;

public class VALeaseEndData {

	private String serialNumber;

	private String status;
	
	private String origin;
	
	private String destination;
	
	private String alertDescription;
	
	private String alertType;
	
	private String notificationDate;
	
	private String estimatedReceivingDate;
	
	private String actualReceivingDate;
	
	private String dueDate;
	
	private String weekNo;

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getAlertDescription() {
		return alertDescription;
	}

	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public String getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(String notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getEstimatedReceivingDate() {
		return estimatedReceivingDate;
	}

	public void setEstimatedReceivingDate(String estimatedReceivingDate) {
		this.estimatedReceivingDate = estimatedReceivingDate;
	}

	public String getActualReceivingDate() {
		return actualReceivingDate;
	}

	public void setActualReceivingDate(String actualReceivingDate) {
		this.actualReceivingDate = actualReceivingDate;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}

}
