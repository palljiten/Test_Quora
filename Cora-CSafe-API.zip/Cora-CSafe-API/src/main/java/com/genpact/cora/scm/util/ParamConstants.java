package com.genpact.cora.scm.util;

public final class ParamConstants {
	
	public static final String FORECAST = "Forecast";
	public static final String HISTORIC = "Historic";
	public static final String PERIOD = "Period";
	public static final String WEIGHT = "Weight";
	public static final String ALPHA = "Alpha";
	public static final String BETA = "Beta";
	
	public static final String SIMPLE_AVERAGE = "SimpleAverage";
	public static final String WEIGHTED_AVERAGE = "WeightedAverage";
	public static final String MOVING_AVERAGE = "MovingAverage";
	public static final String SINGLE_EXPONENTIAL = "SingleExponential";
	public static final String DOUBLE_EXPONENTIAL = "DoubleExponential";
	public static final String ARIMA = "Arima";
	public static final String CROSTON_VARIANT = "CrostonVariant";
	public static final String LINEAR_REGRESSION = "LinearRegression";
	
}
