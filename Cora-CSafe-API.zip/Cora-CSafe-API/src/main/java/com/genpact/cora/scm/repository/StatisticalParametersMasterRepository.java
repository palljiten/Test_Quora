package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.StatisticalParametersMaster;

public interface StatisticalParametersMasterRepository extends JpaRepository<StatisticalParametersMaster, Integer> {

	@Query("SELECT f FROM StatisticalParametersMaster f WHERE f.model.modelId = :modelId")
	public List<StatisticalParametersMaster> findByModelId(@Param("modelId") int modelId);
}
