package com.genpact.cora.scm.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.CountryDetail;
import com.genpact.cora.scm.dto.FieldDetails;
import com.genpact.cora.scm.dto.RegionDetail;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.service.ContainerForecastService;
import com.genpact.cora.scm.service.CountryService;
import com.genpact.cora.scm.service.HubService;
import com.genpact.cora.scm.service.IContainerForecastService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
@Api(tags = {"containerForecast"} , description="describes the conroller")
public class ContainerForecastController {
	
	//@Autowired
	IContainerForecastService containerForecastService = new ContainerForecastService();
	
	@Autowired
	CountryService countryService;
	
	@Autowired
	HubService hubService;
	
	@GetMapping(value = "/forecast", produces = MediaType.TEXT_PLAIN_VALUE)
	@ApiOperation( value ="gets container value")
	public String welcomeForecast() {
		return "welcome to forecast";
	}
	
	@GetMapping(value="/countries", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves all countries")
	public ResponseEntity<Object> getAllCountries(){
		return new ResponseEntity<>(countryService.getAllCountries(),HttpStatus.OK);
	}

	@GetMapping(value="/hubs", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves all hubs")
	public ResponseEntity<Object> getAllHubs(){
		List<HubSc> hubList = hubService.getAllHubs();
		//System.out.println(createMap1(hubList));
		return new ResponseEntity<>(createMap1(hubList),HttpStatus.OK);
	}
	
	/*@GetMapping(value="/fields", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves fields according to the regions selected")
	public ResponseEntity getfields(){
		
		Map<String, Object> regions = new LinkedHashMap<String, Object>();
		
		List<String> regionNameList = new ArrayList<String>();
		regionNameList.add("Europe");
		regionNameList.add("APAC");
		regionNameList.add("UK");
		
		List<String> countriesList = new ArrayList<>();
		countriesList.add("Netherlands");
		countriesList.add("Bulgaria");
		
		List<Map<String, Object>> regionDetails = new ArrayList<>();
		
		Map<String, Object> regiondetail = new LinkedHashMap<String, Object>();
		regiondetail.put("regionName", "Europe");
		regiondetail.put("regionCode", "EU");
		regiondetail.put("countries", countriesList);
		
		List<Map<String, Object>> countryDetails = new ArrayList<>();
		
		Map<String, Object> countryHub = new LinkedHashMap<String, Object>();
		
		countryHub.put("countryName", "Netherlands");
		countryHub.put("countryCode", "NLD");
		
		List<String> hubList = new ArrayList<String>();
		hubList.add("ACS");
		hubList.add("AGP");
		hubList.add("AMS");
		hubList.add("ORD-C");
		hubList.add("TLV");
		hubList.add("DXB");
		
		countryHub.put("hubList", hubList);
		
		Map<String, Object> countryHub2 = new LinkedHashMap<String, Object>();
		
		countryHub2.put("countryName", "Bulgaria");
		countryHub2.put("countryCode", "BGR");
		
		List<String> hubList2 = new ArrayList<String>();
		hubList2.add("ACS");
		hubList2.add("AMS");
		hubList2.add("ORD-C");
		hubList2.add("TLV");
		countryHub2.put("hubList", hubList2);
		
		countryDetails.add(countryHub);
		countryDetails.add(countryHub2);
		
		regiondetail.put("countryDetails", countryDetails);
		regionDetails.add(regiondetail);
		
		*//**************** 2nd region ****************//*
		
		Map<String, Object> regiondetail2 = new LinkedHashMap<String, Object>();
		regiondetail2.put("regionName", "APAC");
		regiondetail2.put("regionCode", "APAC");
		
		List<String> countriesList2 = new ArrayList<>();
		countriesList2.add("Spain");
		countriesList2.add("Austria");
		
		regiondetail2.put("countries", countriesList2);
		
		Map<String, Object> countryHub3 = new LinkedHashMap<String, Object>();
		
		countryHub3.put("countryName", "Spain");
		countryHub3.put("countryCode", "SPN");
		
		List<String> hubList3 = new ArrayList<String>();
		hubList3.add("SP");
		hubList3.add("BAR");
		hubList3.add("MAD");
		hubList3.add("VLC");
		hubList3.add("SVL");

		countryHub3.put("hubList", hubList3);
		
		Map<String, Object> countryHub4 = new LinkedHashMap<String, Object>();
		
		countryHub4.put("countryName", "Austria");
		countryHub4.put("countryCode", "Atr");
		
		List<String> hubList4 = new ArrayList<String>();
		hubList4.add("VNA");
		hubList4.add("GRZ");
		hubList4.add("LNZ");
		hubList4.add("SLZ");
		
		countryHub4.put("hubList", hubList4);
		
		List<Map<String, Object>> countryDetails2 = new ArrayList<>();
		
		countryDetails2.add(countryHub3);
		countryDetails2.add(countryHub4);
		
		regiondetail2.put("countryDetails", countryDetails2);
		regionDetails.add(regiondetail2);
		
		regions.put("regionNames", regionNameList);
		regions.put("regionDetails", regionDetails);
		
		Map<String, Object> allRegions = new LinkedHashMap<String, Object>();
		allRegions.put("regions", regions);
		
		return new ResponseEntity<>(allRegions,HttpStatus.OK);
	}*/

	private FieldDetails createMap1(List<HubSc> hubList) {
		FieldDetails regions = new FieldDetails();
		Map<String,RegionDetail> regionDetailMap = new HashMap<>(); // Key: Region
		List<RegionDetail> regionList = new ArrayList<RegionDetail>();
		
		Map<String, CountryDetail> countryDetailMap = new HashMap<>(); // Key: regionname-countryname
		
		for(HubSc hub : hubList) {
			String regionName = hub.getRegion().getRegionName();
			String countryName = hub.getCountry().getCountryName();
			Integer regionId = hub.getRegion().getRegionId();
			regions.getRegionNames().add(regionName);
			
			RegionDetail regionDetail = regionDetailMap.get(regionName);
			String rcKey = regionName + "-" + countryName;
			
			if (regionDetail == null) {
				RegionDetail rd = new RegionDetail();
				rd.setRegionName(regionName);
				rd.setRegionID(hub.getRegion().getRegionId());
				rd.getCountries().add(countryName);
				
				CountryDetail cd = new CountryDetail();
				cd.setCountryId(hub.getCountry().getCountryId());
				cd.setCountryName(countryName);
				cd.getHubList().add(hub.getAccountName());
				cd.getHubDetails().add(hub);
				
				countryDetailMap.put(rcKey, cd);
				rd.getCountryDetails().add(cd);
				
				regionDetailMap.put(regionName, rd);
				regionList.add(rd);
			} else {
				regionDetail.getCountries().add(countryName);
				CountryDetail cd = countryDetailMap.get(rcKey);
				
				if (cd == null) {
					CountryDetail cdNew = new CountryDetail();
					cdNew.setCountryId(hub.getCountry().getCountryId());
					cdNew.setCountryName(countryName);
					cdNew.getHubList().add(hub.getAccountName());
					cdNew.getHubDetails().add(hub);
					countryDetailMap.put(rcKey, cdNew);
					regionDetail.getCountryDetails().add(cdNew);
				} else {
					cd.setCountryId(hub.getCountry().getCountryId());
					cd.setCountryName(countryName);
					cd.getHubList().add(hub.getAccountName());
					cd.getHubDetails().add(hub);
				}
			}
		}
		regions.setRegionDetails(regionList);
		return regions;
	}
	
	
	private FieldDetails createMap(List<HubSc> hubList) {
		FieldDetails regions = new FieldDetails();
		Map<String, Map<String,RegionDetail>> regionDetailMap = new HashMap<>(); // Key: Region
		Map<String, Map<String,CountryDetail>> countryDetailMap = new HashMap<>(); // Key: Region
		Map<String, List<HubSc>> hubDetailMap = new HashMap<>(); // Key: country
		
		List<RegionDetail> regionList = new ArrayList<>();
		
		for(HubSc hub : hubList) {
			String regionName = hub.getRegion().getRegionName();
			regions.getRegionNames().add(regionName);
			
			String countryName = hub.getCountry().getCountryName();
			
			Map<String,RegionDetail> regionDetail = regionDetailMap.get(regionName);
			if (regionDetail == null) {
				regionDetail = new HashMap<String, RegionDetail>();
				RegionDetail rd = new RegionDetail();
				rd.setRegionName(regionName);
				rd.setRegionID(hub.getRegion().getRegionId());
				rd.getCountries().add(countryName);
				
				CountryDetail cd = new CountryDetail();
				cd.setCountryId(hub.getCountry().getCountryId());
				cd.setCountryName(countryName);
				cd.getHubList().add(hub.getHubCode());
				cd.getHubDetails().add(hub);
				rd.getCountryDetails().add(cd);
				
				regionDetail.put("regionName", rd);
				regionList.add(rd);
			} else {
				regionDetail.get(regionName).getCountries().add(countryName);
				CountryDetail cd = new CountryDetail();
				cd.setCountryId(hub.getCountry().getCountryId());
				cd.setCountryName(countryName);
				cd.getHubList().add(hub.getHubCode());
				cd.getHubDetails().add(hub);
				regionDetail.get(regionName).getCountryDetails().add(cd);
			}
		}
		
		regions.setRegionDetails(regionList);
		/*for(HubSc hub : hubList) {
			String regionName = hub.getRegion().getRegionName();
			regions.getRegionNames().add(regionName);
			
			RegionDetail regionDetail = regionDetailMap.get(regionName);
			if (regionDetail == null) {
				regionDetail = new RegionDetail();
				regionDetailMap.put(regionName, regionDetail);
				regionDetail.setRegionID(hub.getRegion().getRegionId());
				regionDetail.setRegionName(hub.getRegion().getRegionName());
			}
			
			regionDetail.getCountries().add(hub.getCountry().getCountryName());
			
			CountryDetail cd  = countryDetailMap.get(hub.getCountry().getCountryName());
			
			if (cd == null) {
				cd = new CountryDetail();
				countryDetailMap.put(hub.getCountry().getCountryName(), cd);
				cd.setCountryId(hub.getCountry().getCountryId());
				cd.setCountryName(hub.getCountry().getCountryName());
			}

			cd.getHubList().add(hub.getHubCode());
			cd.getHubDetails().add(hub);
			
			regionDetail.getCountryDetails().add(cd);
			
			regions.getRegionDetails().add(regionDetail);
		}*/
		
		return regions;
	}
}
