package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.StatisticalAdjustments;

public interface StatisticalAdjustmentsRepository extends JpaRepository<StatisticalAdjustments, Integer> {

	@Query("SELECT a FROM StatisticalAdjustments a WHERE a.flag=1 AND a.hub.hubId = :hubId AND a.country.countryId = :countryId AND a.region.regionId = :regionId AND a.monthYear IN (:myList)")
	public List<StatisticalAdjustments> getStatisticalAdjustments(@Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("myList") List<String> myList);

	@Modifying
    @Query("UPDATE StatisticalAdjustments a SET a.flag = 0 "
    		+ "WHERE a.flag=1 AND a.hub.hubId = :hubId AND a.country.countryId = :countryId "
    		+ "AND a.region.regionId = :regionId AND monthYear = :monthYear")
    int updateStatisticalAdjustments(@Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("monthYear") String monthYear);

}
