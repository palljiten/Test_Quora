package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_master_Region]")
public class Region {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RegionID", unique = true, nullable = false)
    private Integer regionId;
     
    @Column(name = "RegionName", nullable = false, length = 100)
    private String regionName;

	public Integer getRegionId() {
		return regionId;
	}

	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
}
