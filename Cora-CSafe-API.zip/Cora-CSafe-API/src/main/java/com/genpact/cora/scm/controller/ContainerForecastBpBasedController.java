package com.genpact.cora.scm.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.BPDemandResponse;
import com.genpact.cora.scm.dto.HubBudgetUpdateDTO;
import com.genpact.cora.scm.dto.HubLavelPercentageResponse;
import com.genpact.cora.scm.dto.RegionHubBudgetResponse;
import com.genpact.cora.scm.dto.SparesConsensusCorrectionFactors;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.service.IContainerForecastService;
import com.genpact.cora.scm.service.TopDownConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
@Api(tags = { "Container Forecast - BP-Based" })
public class ContainerForecastBpBasedController {

	private static Logger logger = LoggerFactory.getLogger(ContainerForecastBpBasedController.class);

	@Autowired
	private ServletContext servletContext;

	@Autowired
	IContainerForecastService containerForecastService;

	@Autowired
	TopDownConfigService topDownConfigService;
	
	@Value("${csafe.default.region.id}")
	Integer defaultRegionId;

	@Value("${csafe.default.country.id}")
	Integer defaultCountryId;

	@Value("${csafe.default.hub.id}")
	Integer defaultHubId;

	@GetMapping(value = "/baselineDemand", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves BP-based baseline demand data for 18 months")
	public ResponseEntity<Object> getBaselineDemand(@RequestParam int regionId, @RequestParam int countryId,
			@RequestParam int hubId, @RequestParam(required = false) int months) {
		logger.info("ContainerForecastBpBasedController: Entering getBaselineDemand() method");

		if (regionId == defaultRegionId && countryId == defaultCountryId && hubId == defaultHubId) {
			Object cachedFields = servletContext.getAttribute("bpBasedDemand");
			if (cachedFields != null) {
				return new ResponseEntity<>(cachedFields, HttpStatus.OK);
			}
		}
		return new ResponseEntity<>(containerForecastService.getBaselineDemand(regionId, countryId, hubId, months),
				HttpStatus.OK);
	}

	@GetMapping(value = "/bpForecast", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves BP-based forecaset demand data for 6 months")
	public ResponseEntity<Object> getForecastData(@RequestParam int regionId, @RequestParam int countryId,
			@RequestParam int hubId, @RequestParam(required = false) int months) {
		logger.info("ContainerForecastBpBasedController: Entering getForecastData() method");
		if (regionId == defaultRegionId && countryId == defaultCountryId && hubId == defaultHubId) {
			Object cachedFields = servletContext.getAttribute("bpBasedForecast");
			if (cachedFields != null) {
				return new ResponseEntity<>(cachedFields, HttpStatus.OK);
			}
		}
		Map<Object, Object> forecastData = new LinkedHashMap<Object, Object>();
		forecastData = containerForecastService.getForecastData(regionId, hubId, months);
		logger.info("ContainerForecastBpBasedController: Exiting getForecastData() method");
		return new ResponseEntity<>(forecastData, HttpStatus.OK);
	}

	@GetMapping(value = "/bpBased/topdownConfig/regions", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves budget % for all regions")
	public ResponseEntity<Object> getBudgetForAllRegions() {
		logger.info("ContainerForecastBpBasedController: Entering getBudgetForAllRegions() method");

		HubLavelPercentageResponse hlpr = topDownConfigService.getRegionDetails();
		logger.info("ContainerForecastBpBasedController: Exiting getBudgetForAllRegions() method");
		return new ResponseEntity<>(hlpr, HttpStatus.OK);
	}

	@GetMapping(value = "/bpBased/topdownConfig/regions/hubs", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves budget % for all hubs for all regions")
	public ResponseEntity<Object> getHubBudgetsForAllRegions() {
		logger.info("ContainerForecastBpBasedController: Entering getHubBudgetsForAllRegions() method");

		RegionHubBudgetResponse rhbRes = topDownConfigService.getHubBudgetsForAllRegions();
		logger.info("ContainerForecastBpBasedController: Exiting getHubBudgetsForAllRegions() method");
		return new ResponseEntity<>(rhbRes, HttpStatus.OK);
	}

	@PutMapping(value = "/bpBased/topdownConfig/regions/hubs", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Updates budget % for all hubs for a region")
	public ResponseEntity<Object> updateBudgetsForAllHubsForARegion(@RequestBody HubBudgetUpdateDTO hubBudgets) {
		logger.info("ContainerForecastBpBasedController: Entering updateBudgetsForAllHubsForARegion() method");
		topDownConfigService.updateBudgetTopDownConfig(hubBudgets);
		SuccessResponse sr = new SuccessResponse();
		sr.setStatus("SUCCESS");
		logger.info("ContainerForecastBpBasedController: Exiting updateBudgetsForAllHubsForARegion() method");
		return new ResponseEntity<>(sr, HttpStatus.OK);
	}
}
