package com.genpact.cora.scm.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.InventoryPCCSubmitDto;
import com.genpact.cora.scm.dto.InventoryPlanningContainersDto;
import com.genpact.cora.scm.dto.InventoryPlanningSpareDto;
import com.genpact.cora.scm.dto.InventoryPlanningSparesConfigDto;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.entity.InventoryPCConfig;
import com.genpact.cora.scm.entity.InventoryPlanningContainers;
import com.genpact.cora.scm.entity.InventoryPlanningSpare;
import com.genpact.cora.scm.entity.InventoryPlanningSparesConfig;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.InventoryMPSConfigRepositoy;
import com.genpact.cora.scm.repository.InventoryPCConfigRepository;
import com.genpact.cora.scm.repository.InventoryPlanningRepository;

@Service
public class InventoryPlanningService {

	private static Logger logger= LoggerFactory.getLogger(InventoryPlanningService.class);
	@Autowired
	private InventoryPlanningRepository ipr;
	@Autowired
	private InventoryPCConfigRepository ipccr;
	@Autowired
	private InventoryMPSConfigRepositoy impscr;
	
	public List<InventoryPlanningContainersDto> getContainersInventoryPlanned(int regionId,int countryId,int hubId) throws CSafeServiceException{

		logger.info("SERVICE: InventoryPlanningService: Entering getContainersInventoryPlanned() method");
		List<InventoryPlanningContainersDto> containerInventoryPlan;
		List<InventoryPlanningContainers> ipcList ;
		try{
			ipcList = ipr.findContainersDetails(regionId, countryId, hubId);
			containerInventoryPlan = getIPCREntityToDto(ipcList);
		} catch(Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		
		logger.info("SERVICE: InventoryPlanningService: Exiting getContainersInventoryPlanned() method");
		return containerInventoryPlan;
	}
	
	public List<InventoryPlanningContainersDto> getIPCREntityToDto(List<InventoryPlanningContainers> ipcList){
		List<InventoryPlanningContainersDto> ipcdList= new ArrayList<InventoryPlanningContainersDto>();
		if(null !=ipcList){
			for(InventoryPlanningContainers ipc:ipcList){
				InventoryPlanningContainersDto ipcdObj = new InventoryPlanningContainersDto();
				ipcdObj.setHubCode(ipc.getHub().getHubCode());
				ipcdObj.setServiceLevel(ipc.getServiceLevel());
				ipcdObj.setInventoryLevel(ipc.getInventoryLevel());
				ipcdObj.setTotalLeadTime(ipc.getTotalLeadTime());
				ipcdObj.setDemandDuringLeadTime(ipc.getDemandDuringLeadTime());
				ipcdObj.setAverageMonthlyDemand(ipc.getAverageMonthlyDemand());
				ipcdObj.setStandardDeviation(ipc.getStandardDeviation());
				ipcdObj.setRop(ipc.getRop());
				ipcdObj.setCalcMinInventory(ipc.getCalcMinInventory());
				ipcdObj.setPriorityFlag(ipc.getPriorityFlag());
				
				ipcdList.add(ipcdObj);
			}
		}
		return ipcdList;
	}

	public List<InventoryPlanningSpareDto> getSparesInventoryPlan(int regionId,int countryId,int hubId, String partNumber) {
		// TODO Auto-generated method stub
		logger.info("SERVICE: InventoryPlanningService: Entering getsparesInventoryPlanned() method");
		List<InventoryPlanningSpareDto> ipsdList;
		List<InventoryPlanningSpare> ipsList;
		try{
			ipsList = ipr.findSparesInventoryPlan(regionId, countryId, hubId, partNumber);
			ipsdList = getIPSREntityToDto(ipsList);
			
		} catch(Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		
		logger.info("SERVICE: InventoryPlanningService: Exiting getSparesInventoryPlanned() method");
	    return ipsdList;
	
	}
	
	public List<InventoryPlanningSpareDto> getIPSREntityToDto(List<InventoryPlanningSpare> ipsList){
		List<InventoryPlanningSpareDto> ipsdList= new ArrayList<InventoryPlanningSpareDto>();
		if(null !=ipsList){
			for(InventoryPlanningSpare ips:ipsList){
				InventoryPlanningSpareDto ipsdObj = new InventoryPlanningSpareDto();
				ipsdObj.setServiceLevel(ips.getServiceLevel());
				ipsdObj.setInventoryLevel(ips.getInventoryLevel());
				ipsdObj.setTotalLeadTime(ips.getTotalLeadTime());
				ipsdObj.setDemandDuringLeadTime(ips.getDemandDuringLeadTime());
				ipsdObj.setAverageMonthlyDemand(ips.getAverageMonthlyDemand());
				ipsdObj.setStandardDiviation(ips.getStandardDeviation());
				ipsdObj.setRop(ips.getRop());
				ipsdObj.setPart(ips.getPart());
				ipsdObj.setCalculatedMinInventory(ips.getCalculatedMinInventory());
				ipsdObj.setPriorityFlag(ips.getPriorityFlag());
				
				ipsdList.add(ipsdObj);
			}
		}
		return ipsdList;
	}

	/**
	 * @param hubId
	 * @return
	 */
	public Map<String, String> getConfiguredCIPByHubId(Integer hubId) {
		// TODO Auto-generated method stub
		logger.info("SERVICE: InventoryPlanningService: Entering getConfiguredCIPByHubId() method");
		List<InventoryPCConfig> ipccDtoList;
		Map<String, String> configMap = new HashMap<String, String>();
		try{
			ipccDtoList= ipccr.findConfigDetailsByHubId(hubId);
			for(InventoryPCConfig ipcObj:ipccDtoList){
				configMap.put("hubId", ipcObj.getHub().getHubId().toString());
				configMap.put(ipcObj.getParameter(), ipcObj.getValue());
			}
			
		} catch(Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: InventoryPlanningService: Exiting getConfigContainersInventoryPlanned() method");
		return configMap;
	}
	
	
	/**
	 * To update Inventory planning container config details.
	 * @param inventoryPCCSubmitDto
	 * @return
	 */
	public SuccessResponse updateCCInventoryPlan(InventoryPCCSubmitDto inventoryPCCSubmitDto){
		SuccessResponse objSuccessResponse = new SuccessResponse();
		List<InventoryPCConfig> ipcDtoList = ipccr.findConfigDetailsByHubId(inventoryPCCSubmitDto.getHubId());
		for(InventoryPCConfig ipcConfigObj:ipcDtoList){
			InventoryPCConfig ipcc = new InventoryPCConfig();
			boolean isrequired = false;
			if(inventoryPCCSubmitDto.getLeadTime()!= null && ipcConfigObj.getParameter().toLowerCase().equalsIgnoreCase("leadtime") && !ipcConfigObj.getValue().equalsIgnoreCase(inventoryPCCSubmitDto.getLeadTime())){
				ipcc.setValue(inventoryPCCSubmitDto.getLeadTime());
				isrequired = true;
			}else if(inventoryPCCSubmitDto.getServiceLevel()!= null && ipcConfigObj.getParameter().toLowerCase().equalsIgnoreCase("servicelevel") &&  !ipcConfigObj.getValue().equalsIgnoreCase(inventoryPCCSubmitDto.getServiceLevel())){
				ipcc.setValue(inventoryPCCSubmitDto.getServiceLevel());
				isrequired = true;
			}else if(inventoryPCCSubmitDto.getSafetyRequired()!= null && ipcConfigObj.getParameter().toLowerCase().equals("safetyrequired") &&  !ipcConfigObj.getValue().trim().equalsIgnoreCase(inventoryPCCSubmitDto.getSafetyRequired().trim())){
				ipcc.setValue(inventoryPCCSubmitDto.getSafetyRequired());
				isrequired = true;
			}else if(inventoryPCCSubmitDto.getSKURequired()!= null && ipcConfigObj.getParameter().toLowerCase().equals("skurequired") &&  !ipcConfigObj.getValue().trim().equalsIgnoreCase(inventoryPCCSubmitDto.getSKURequired().trim())){
				ipcc.setValue(inventoryPCCSubmitDto.getSKURequired());
				isrequired = true;
			}
			
			if(isrequired){
				ipcc.setHub(ipcConfigObj.getHub());
				ipcc.setRegion(ipcConfigObj.getRegion());
				ipcc.setCountryId(ipcConfigObj.getCountryId());
				ipcc.setConfigId(ipcConfigObj.getConfigId());
				ipcc.setFlag(ipcConfigObj.getFlag());
				ipcc.setParameter(ipcConfigObj.getParameter());
				
				ipcc.setCreatedDate(new Date());
				
				//To soft deletion of existing column
				ipccr.updateFlag(new Integer(0),ipcc.getHub().getHubId(),ipcc.getParameter(),new Date());
				
				//To inserting new column.
				ipccr.save(ipcc);
				isrequired = false;
			}
		}
		objSuccessResponse.setStatus("Success");
		return objSuccessResponse;
		
	}
	
	
	
	/**
	 * @param regionId
	 * @param countryId
	 * @param hubId
	 * @param partNumber
	 * @return
	 */
	public Map<String, String> getConfiguredCIMSByPartNumber(int regionId,int countryId,int hubId,String partNumber) {
		// TODO Auto-generated method stub
		logger.info("SERVICE: InventoryPlanningService: Entering getConfiguredCIPByHubId() method");
		List<InventoryPlanningSparesConfig> ipscList;
		Map<String, String> configMap = new HashMap<String, String>();
		try{
			ipscList= impscr.findConfigDetailsByPartNumber(regionId,countryId,hubId,partNumber);
			for(InventoryPlanningSparesConfig ipscObj:ipscList){
				configMap.put("hubId", ipscObj.getHubId().toString());
				configMap.put("partNumber", ipscObj.getPartNumber());
				configMap.put(ipscObj.getParameter(), ipscObj.getValue());
			}
			
		} catch(Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: InventoryPlanningService: Exiting getConfigContainersInventoryPlanned() method");
		return configMap;
	}
	
	
	//updateIMPSConfig(ipsDtoRequest);
	
	public SuccessResponse updateIMPSConfig(InventoryPlanningSparesConfigDto ipsDtoRequest){
		SuccessResponse objSuccessResponse = new SuccessResponse();
		List<InventoryPlanningSparesConfig> ipscList = impscr.findConfigDetailsByPartNumber(ipsDtoRequest.getRegionId(),ipsDtoRequest.getCountryId(),ipsDtoRequest.getHubId(), ipsDtoRequest.getPartNumber());
		for(InventoryPlanningSparesConfig ipObj:ipscList){
			
			InventoryPlanningSparesConfig ipscObj = new InventoryPlanningSparesConfig();
			boolean isrequired = false;
			if(ipsDtoRequest.getServiceLevel()!= null && ipObj.getParameter().toLowerCase().equals("safetyrequired") &&  !ipObj.getValue().trim().equalsIgnoreCase(ipsDtoRequest.getServiceLevel().toString())){
				ipscObj.setValue(ipsDtoRequest.getServiceLevel().toString());
				isrequired = true;
			}
			
			if(isrequired){
				ipscObj.setHubId(ipObj.getHubId());
				ipscObj.setRegionId(ipObj.getRegionId());
				ipscObj.setCountryId(ipObj.getCountryId());
				ipscObj.setConfigId(ipObj.getConfigId());
				ipscObj.setFlag(ipObj.getFlag());
				ipscObj.setParameter(ipObj.getParameter());
				ipscObj.setCreatedDate(new Date());
				
				//To soft deletion of existing column
				impscr.updateFlag(new Integer(0),ipObj.getHubId(),ipObj.getParameter(),ipObj.getPartNumber(),new Date());
				
				//To inserting new column.
				impscr.save(ipscObj);
				isrequired = false;
			}
		}
		objSuccessResponse.setStatus("Success");
		return objSuccessResponse;
		
	}
}
