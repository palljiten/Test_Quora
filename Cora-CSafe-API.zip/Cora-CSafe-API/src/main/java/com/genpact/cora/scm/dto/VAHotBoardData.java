package com.genpact.cora.scm.dto;

public class VAHotBoardData {

}
