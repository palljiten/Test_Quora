package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class MonthYearDataUnit implements Serializable {

	private static final long serialVersionUID = 1L;

	private int monthValue; // e.g. 0 for January, 1 for February etc.
	private String monthYear; //e.g. January, February etc.
	private float value; // forecast value
	
	public int getMonthValue() {
		return monthValue;
	}
	
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
	
	public String getMonthYear() {
		return monthYear;
	}
	
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
	
	public float getValue() {
		return value;
	}
	
	public void setValue(float value) {
		this.value = value;
	}
}
