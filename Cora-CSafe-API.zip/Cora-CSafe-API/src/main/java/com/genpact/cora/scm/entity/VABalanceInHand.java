package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_VABalanceInHand]")
public class VABalanceInHand {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
	private int id;
	
	 @Column(name = "RegionName")
		private String regionName;
	
    @Column(name = "Code")
	private String code;
	
	@Column(name ="WeekNo")
	private String weekNo;
	
	@Column(name ="City")
	private String city;
	
	@Column(name ="CountryName" )
	private String countryName;
	
	@Column(name ="BalanceInHand")
	private Integer balanceInHand;
	
	@Column(name="SafetyStock")
	private int safetyStock;
	
	@Column(name ="Status")
	private Integer status;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Integer getBalanceInHand() {
		return balanceInHand;
	}

	public void setBalanceInHand(Integer balanceInHand) {
		this.balanceInHand = balanceInHand;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSafetyStock() {
		return safetyStock;
	}

	public void setSafetyStock(int safetyStock) {
		this.safetyStock = safetyStock;
	}

	
	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
}
