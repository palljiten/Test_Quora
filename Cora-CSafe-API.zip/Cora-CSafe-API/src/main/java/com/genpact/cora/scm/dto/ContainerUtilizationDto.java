/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.util.Map;
import java.util.TreeMap;

/**
 * @author 703158077
 *
 */
public class ContainerUtilizationDto {
	
	private Map<String, Integer> dataMap = new TreeMap<String, Integer>();
	/**
	 * @return the dataMap
	 */
	public Map<String, Integer> getDataMap() {
		return dataMap;
	}
	/**
	 * @param dataMap the dataMap to set
	 */
	public void setDataMap(Map<String, Integer> dataMap) {
		this.dataMap = dataMap;
	}
	
}
