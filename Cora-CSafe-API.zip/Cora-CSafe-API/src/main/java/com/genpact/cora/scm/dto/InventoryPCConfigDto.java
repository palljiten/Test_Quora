/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.io.Serializable;

/**
 * @author 703158077
 *
 */
public class InventoryPCConfigDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543221L;
	
	private Integer hubId;
	private String parameter;
	private String value;
	private Integer regionId;
	private Integer countryId;
	private Integer configId;
	
	
	public InventoryPCConfigDto(){
	}
	
	public InventoryPCConfigDto(Integer hubId, String parameter,String value,Integer regionId, Integer countryId, Integer configId){
		this.hubId = hubId;
		this.parameter = parameter;
		this.value = value;
		this.regionId = regionId;
		this.countryId = countryId;
		this.configId = configId;
	}
	
	
	/**
	 * @return the hubId
	 */
	public Integer getHubId() {
		return hubId;
	}
	/**
	 * @param hubId the hubId to set
	 */
	public void setHubId(Integer hubId) {
		this.hubId = hubId;
	}
	/**
	 * @return the parameter
	 */
	public String getParameter() {
		return parameter;
	}
	/**
	 * @param parameter the parameter to set
	 */
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the regionId
	 */
	public Integer getRegionId() {
		return regionId;
	}

	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}

	/**
	 * @return the countryId
	 */
	public Integer getCountryId() {
		return countryId;
	}

	/**
	 * @param countryId the countryId to set
	 */
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	/**
	 * @return the configId
	 */
	public Integer getConfigId() {
		return configId;
	}

	/**
	 * @param configId the configId to set
	 */
	public void setConfigId(Integer configId) {
		this.configId = configId;
	}
	
	
	
	
	
	

}
