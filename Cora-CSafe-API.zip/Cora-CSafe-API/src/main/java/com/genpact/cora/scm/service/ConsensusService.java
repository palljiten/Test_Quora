package com.genpact.cora.scm.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.controller.SparesForecastConsensusController;
import com.genpact.cora.scm.dto.AlignedForecastMonthData;
import com.genpact.cora.scm.dto.BaselineForecastResponse;
import com.genpact.cora.scm.dto.ConsensusAdjustmentValue;
import com.genpact.cora.scm.dto.ConsensusAdjustmentValueCombo;
import com.genpact.cora.scm.dto.ConsensusCorrectionFactorCombo;
import com.genpact.cora.scm.dto.ConsensusForecastCombo;
import com.genpact.cora.scm.dto.CorrectionFactor;
import com.genpact.cora.scm.dto.SimpleAverage;
import com.genpact.cora.scm.dto.StatisticalForecastResponse;
import com.genpact.cora.scm.dto.WeightedAverage;
import com.genpact.cora.scm.entity.ConsensusAdjustment;
import com.genpact.cora.scm.entity.ConsensusAverage;
import com.genpact.cora.scm.entity.ConsensusAverageValues;
import com.genpact.cora.scm.entity.ConsensusCorrectionFactor;
import com.genpact.cora.scm.entity.ConsensusCorrectionFactorSelected;
import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.Region;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.AlignedForecastRepository;
import com.genpact.cora.scm.repository.BPBasedForecastRepository;
import com.genpact.cora.scm.repository.ConsensusAdjustmentOverrideRepository;
import com.genpact.cora.scm.repository.ConsensusAdjustmentRepository;
import com.genpact.cora.scm.repository.ConsensusAverageRepository;
import com.genpact.cora.scm.repository.ConsensusAverageValueRepository;
import com.genpact.cora.scm.repository.ConsensusAveragevaluesRepository;
import com.genpact.cora.scm.repository.ConsensusCorrectionFactorRepository;
import com.genpact.cora.scm.repository.ConsensusCorrectionFactorSelectedRepository;
import com.genpact.cora.scm.repository.ConsensusForecastSPRepository;
import com.genpact.cora.scm.repository.ContainerForecastRepository;
import com.genpact.cora.scm.repository.CorrectionFactorRepository;
import com.genpact.cora.scm.repository.HubRepository;
import com.genpact.cora.scm.repository.StatisticalForecastRepository;
import com.genpact.cora.scm.repository.WeeklyForecastSPRepository;

@Service
public class ConsensusService {
	private static Logger logger = LoggerFactory.getLogger(SparesForecastConsensusController.class);
	@Autowired
	BPBasedForecastRepository bpBasedForecastRepository;
	@Autowired
	StatisticalForecastRepository statisticalForecastRepository;
	@Autowired
	ConsensusCorrectionFactorRepository consensusCorrectionFactorRepository;
	@Autowired
	ConsensusAdjustmentRepository consensusAdjustment;
	@Autowired
	CorrectionFactorRepository correctionFactorRepository;
	@Autowired
	ConsensusAverageRepository consensusAverageRepository;
	@Autowired
	ConsensusAdjustmentOverrideRepository consensusAdjustmentRepository;

	@Autowired
	HubRepository hubRepository;

	@Autowired
	ConsensusCorrectionFactorSelectedRepository oFactorSelectedRepository;

	@Autowired
	AlignedForecastRepository alignedForecastRepository;

	@Autowired
	ContainerForecastRepository containerForecastRepository;
	
	@Autowired
	ConsensusAveragevaluesRepository consensusAvgRepository;

	@Autowired
	ConsensusAverageValueRepository simpleWeightedRepository;
	
	@Autowired
	WeeklyForecastSPRepository weeklySpRepository;
	
	@Autowired
	ConsensusForecastSPRepository consensusSpRepository;
	
	public List<ConsensusForecastCombo> getBaselineStatisticalForecast(int regionId, int countryId, int hubId,
			String type) {

		// Tables involved: tbl_BPBasedForecast, tbl_StatisticalForecast
		List<ConsensusForecastCombo> forecastList = new ArrayList<ConsensusForecastCombo>();
		List<ConsensusForecastCombo> forecastListRs = new ArrayList<ConsensusForecastCombo>();
		List<Object[]> forecastListFetched = new ArrayList<>();
		if (type.equals("baseline")) {
			forecastListFetched = bpBasedForecastRepository.findBaselineForecast(countryId, hubId, regionId);
			forecastList = prepareResponseForConsensusForecast(forecastListFetched, type);
		} else if (type.equalsIgnoreCase("statistical")) {
			forecastListFetched = statisticalForecastRepository.findStatisticalForecast(countryId, hubId, regionId);
			forecastList = prepareResponseForConsensusForecast(forecastListFetched, type);
		}

		else if (type.length() <= 1) {
			forecastListFetched = bpBasedForecastRepository.findBaselineForecast(countryId, hubId, regionId);
			forecastList = prepareResponseForConsensusForecast(forecastListFetched, "baseline");
			List<Object[]> forecastListFetchedSt = statisticalForecastRepository.findStatisticalForecast(countryId,
					hubId, regionId);
			forecastListRs = prepareResponseForConsensusForecast(forecastListFetchedSt, "statistical");
			forecastList.get(0).setStatisticalForecast(forecastListRs.get(0).getStatisticalForecast());

			forecastList.get(0).setMonthYearMetaData(forecastListRs.get(0).getMonthYearMetaData());
		}

		return forecastList;
	}

	private List<ConsensusForecastCombo> prepareResponseForConsensusForecast(List<Object[]> forecastList, String type) {
		Iterator it = forecastList.iterator();
		String monthYear = "";
		String month = "";
		String year = "";
		BaselineForecastResponse baselineForecastResponse = null;
		List<BaselineForecastResponse> bpResponeList = new ArrayList<>();
		StatisticalForecastResponse statisticalForecastResponse = null;
		List<StatisticalForecastResponse> stResponeList = new ArrayList<>();
		List<ConsensusForecastCombo> consensusForecastComboLst = new ArrayList<ConsensusForecastCombo>();
		ConsensusForecastCombo consensusForecastCombo = new ConsensusForecastCombo();
		Set<String> monthYearMetaDataLst = new HashSet<>();
		List<ConsensusForecastCombo> consensusList = new ArrayList<>();
		while (it.hasNext()) {
			Object[] ConsensusForecast = (Object[]) it.next();

			if (type.equalsIgnoreCase("baseline")) {
				baselineForecastResponse = new BaselineForecastResponse();
				baselineForecastResponse.setValue((float) ConsensusForecast[0]);
				monthYear = (String) ConsensusForecast[1];
				month = monthYear.substring(0, monthYear.indexOf("-"));
				year = "20" + monthYear.substring(monthYear.indexOf("-") + 1, monthYear.length());
				Date date = null;
				try {
					date = new SimpleDateFormat("MMMM").parse(month);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				// System.out.println(cal.get(Calendar.MONTH));
				baselineForecastResponse.setMonthValue(cal.get(Calendar.MONTH));
				baselineForecastResponse.setMonth(month);
				baselineForecastResponse.setYear(year);
				bpResponeList.add(baselineForecastResponse);
			} else if (type.equalsIgnoreCase("statistical")) {
				statisticalForecastResponse = new StatisticalForecastResponse();
				statisticalForecastResponse.setValue((float) ConsensusForecast[0]);
				monthYear = (String) ConsensusForecast[1];
				month = monthYear.substring(0, monthYear.indexOf("-"));
				year = "20" + monthYear.substring(monthYear.indexOf("-") + 1, monthYear.length());
				Date date = null;
				try {
					date = new SimpleDateFormat("MMMM").parse(month);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				// System.out.println(cal.get(Calendar.MONTH));
				statisticalForecastResponse.setMonthValue(cal.get(Calendar.MONTH));
				statisticalForecastResponse.setMonth(month);
				statisticalForecastResponse.setYear(year);
				stResponeList.add(statisticalForecastResponse);
			}

			monthYearMetaDataLst.add(month + " " + year);

		}
		if (type.equalsIgnoreCase("baseline")) {
			consensusForecastCombo.setBaselineForecast(bpResponeList);
		} else if (type.equalsIgnoreCase("statistical")) {
			consensusForecastCombo.setStatisticalForecast(stResponeList);
		}
		consensusForecastCombo.setMonthYearMetaData(monthYearMetaDataLst);
		consensusList.add(consensusForecastCombo);
		return consensusList;
	}

	public ConsensusCorrectionFactorCombo getCorrectionFactors(int regionId, int countryId, int hubId) {

		
		/*
		 * List<Object> correctionFactorsObject =
		 * consensusCorrectionFactorRepository.findCorrectionFactor(regionId, countryId,
		 * hubId);
		 */
		//ConsensusAverage selectedAvgId = oFactorSelectedRepository.getSelectedAvergareId(regionId, countryId, hubId);
		List<ConsensusCorrectionFactor> correctionFactorsObject = new LinkedList<>();
		List<ConsensusAverageValues> simplWeightedcorrectionFactorsObject = new LinkedList<>();
		ConsensusCorrectionFactorCombo correctionFactorCombo = new ConsensusCorrectionFactorCombo();
		Integer aid= 0;
		
		ConsensusCorrectionFactorSelected consensusCorrectionFactorSelected = oFactorSelectedRepository.get(regionId,
				countryId, hubId);
		if (consensusCorrectionFactorSelected != null) {
			aid = consensusCorrectionFactorSelected.getAverage().getAid();
		}
			if(aid== 1 || aid == 2) {
				simplWeightedcorrectionFactorsObject = simpleWeightedRepository
						.getSimpleWeightedCorrectionFactor(regionId, countryId, hubId);
				correctionFactorCombo = populateDataInResponse(simplWeightedcorrectionFactorsObject,consensusCorrectionFactorSelected,aid);
			}
		
		else if(aid==3 || aid == 0) {
				correctionFactorsObject = correctionFactorRepository
						.getCorrectionFactor(regionId, countryId, hubId);
				ConsensusCorrectionFactorCombo consensusCorrectionFactorComboObject = prepareCorrectionFactorResponse(
						correctionFactorsObject);
				correctionFactorCombo = addTotalSixMonthsData(consensusCorrectionFactorComboObject, consensusCorrectionFactorSelected);
			}
		
		return correctionFactorCombo;
	}

	private ConsensusCorrectionFactorCombo populateDataInResponse(List<ConsensusAverageValues> simplWeightedcorrectionFactorsObject,
			ConsensusCorrectionFactorSelected consensusCorrectionFactorSelected,Integer aid) {
		ConsensusCorrectionFactorCombo consensusCorrectionFactorCombo = new ConsensusCorrectionFactorCombo();
		List<String> sixMonthYearValuesLst = prepareSixMonthYearList();
		Set<String> monthYearMetaData = new LinkedHashSet<>();
		List<CorrectionFactor> correctionValues = new LinkedList<>();
		CorrectionFactor monthDetailObj = null;
		Iterator it = simplWeightedcorrectionFactorsObject.iterator();
		
		monthYearMetaData.addAll(sixMonthYearValuesLst);
		consensusCorrectionFactorCombo.setMonthYearMetaData(monthYearMetaData);
		consensusCorrectionFactorCombo.setSelectedAverage(aid);
		float budgetVal = 0.0f;
		float statVal = 0.0f;		
		Date date = new Date();
		String month ="";
		String year = "";
		
		while(it.hasNext()) {
			Object[] obj = (Object[]) it.next();
			if (obj[1].toString().equalsIgnoreCase("Budget"))
				budgetVal = Float.parseFloat(obj[0].toString());
			else 
				statVal = Float.parseFloat(obj[0].toString());
		}
		if(aid==1) {
			WeightedAverage wgAvg = new WeightedAverage();
			wgAvg.setBaseline(budgetVal/100);
			wgAvg.setStatistical(statVal/100);
			consensusCorrectionFactorCombo.setWeightedAverage(wgAvg);
		}
		
		else if(aid==2) {
			SimpleAverage smAvg = new SimpleAverage();
			smAvg.setBaseline(0.5f);
			smAvg.setStatistical(0.5f);
			consensusCorrectionFactorCombo.setSimpleAverage(smAvg);
			budgetVal = 50f;
			statVal = 50f;	
		}
		
		for(String value : sixMonthYearValuesLst) {
			month = value.substring(0, value.indexOf(" "));
			year = value.substring(value.indexOf(" ") + 1, value.length());
					
			monthDetailObj = new CorrectionFactor();
			monthDetailObj.setBaseline(budgetVal);
			monthDetailObj.setStatistical(statVal);
			monthDetailObj.setMonth(month);
			monthDetailObj.setYear(year);
			try {
				date = new SimpleDateFormat("MMMM").parse(month);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			monthDetailObj.setMonthValue(cal.get(Calendar.MONTH));
			correctionValues.add(monthDetailObj);
		}
		consensusCorrectionFactorCombo.setCorrectionValues(correctionValues);
		return consensusCorrectionFactorCombo;
	}

	private ConsensusCorrectionFactorCombo addTotalSixMonthsData(
			ConsensusCorrectionFactorCombo consensusCorrectionFactorComboObject,
			ConsensusCorrectionFactorSelected consensusCorrectionFactorSelected) {
		List<CorrectionFactor> correctionValuesList = consensusCorrectionFactorComboObject.getCorrectionValues();
		List<String> sixMonthYearValuesLst = prepareSixMonthYearList();
		CorrectionFactor correctionFactor = null;
		int count = 0;
		String name = null;
		String year = null;
		Date date = null;
		ConsensusCorrectionFactorCombo correctionFactorCombo = new ConsensusCorrectionFactorCombo();
		List<CorrectionFactor> correctionValues = new LinkedList<>();
		Set<String> monthYearMetaData = new LinkedHashSet<>();
		monthYearMetaData.addAll(sixMonthYearValuesLst);

		for (String value : sixMonthYearValuesLst) {
			name = value.substring(0, value.indexOf(" "));
			year = value.substring(value.indexOf(" ") + 1, value.length());
			count = getCorrectionFactorObjectIndexFromList(correctionValuesList, name);
			if (count >= 0) {
				CorrectionFactor correctionFactorObj = correctionValuesList.get(count);
				correctionFactor = new CorrectionFactor();
				correctionFactor.setBaseline(correctionFactorObj.getBaseline());
				correctionFactor.setStatistical(correctionFactorObj.getStatistical());
				correctionFactor.setMonth(correctionFactorObj.getMonth());
				correctionFactor.setYear(correctionFactorObj.getYear());
				correctionFactor.setMonthValue(correctionFactorObj.getMonthValue());
				correctionValues.add(correctionFactor);
			} else if (count < 0) {
				correctionFactor = new CorrectionFactor();
				correctionFactor.setBaseline(50);
				correctionFactor.setStatistical(50);
				correctionFactor.setMonth(name);
				correctionFactor.setYear(year);
				try {
					date = new SimpleDateFormat("MMMM").parse(name);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				correctionFactor.setMonthValue(cal.get(Calendar.MONTH));
				correctionValues.add(correctionFactor);
			}

		}
		if (consensusCorrectionFactorSelected == null)
			correctionFactorCombo.setSelectedAverage(consensusCorrectionFactorComboObject.getSelectedAverage());
		else
			correctionFactorCombo.setSelectedAverage(consensusCorrectionFactorSelected.getAverage().getAid());
		correctionFactorCombo.setCorrectionValues(correctionValues);
		correctionFactorCombo.setMonthYearMetaData(monthYearMetaData);
		
		return correctionFactorCombo;
	}

	public List<String> prepareSixMonthYearList() {
		List<String> sixMonthYearValues = new LinkedList<>();
		Calendar now = Calendar.getInstance();
		int month = now.get(Calendar.MONTH);
		int year = now.get(Calendar.YEAR);
		int count = 0;

		/* preparing list */
		for (int i = 0; i <= 5; i++) {
			sixMonthYearValues
					.add(ContainerForecastConsensusService.getMonthValueMap().get(month + count) + " " + year);
			if (ContainerForecastConsensusService.getMonthValueMap().get(month + count).equals("Dec")) {
				year = now.get(Calendar.YEAR) + 1;
				month = 0;
				count = -1;
			}
			count++;
		}

		return sixMonthYearValues;
	}

	private ConsensusCorrectionFactorCombo prepareCorrectionFactorResponse(
			List<ConsensusCorrectionFactor> correctionFactorsObject) {

		Iterator it = correctionFactorsObject.iterator();
		String monthYear = "";
		String month = "";
		String year = "";
		//WeightedAverage weightedAvg = new WeightedAverage();
		ConsensusCorrectionFactorCombo correctionFactors = new ConsensusCorrectionFactorCombo();
		List<CorrectionFactor> correctionFactorList = new ArrayList<>();
		CorrectionFactor correctionFactor = null;
		Set<String> monthYearMetaDataLst = new HashSet<>();
		List<ConsensusForecastCombo> consensusList = new ArrayList<>();
		float baselineValue = 0.0f;
		float statisticalValue = 0.0f;
		Integer selectedAvg = null;
		while (it.hasNext()) {
			Object[] correction = (Object[]) it.next();
			correctionFactor = new CorrectionFactor();
			if (correction[0] != null)
				baselineValue = Float.parseFloat(correction[0].toString());
			else
				baselineValue = 50;

			statisticalValue = 100.0f - baselineValue;
			correctionFactor.setBaseline(baselineValue);
			correctionFactor.setStatistical(statisticalValue);
			monthYear = (String) correction[1];
			month = monthYear.substring(0, monthYear.indexOf("-"));
			year = monthYear.substring(monthYear.indexOf("-") + 1, monthYear.length());
			Date date = null;
			try {
				date = new SimpleDateFormat("MMMM").parse(month);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			// System.out.println(cal.get(Calendar.MONTH));
			correctionFactor.setMonthValue(cal.get(Calendar.MONTH));
			correctionFactor.setMonth(month);
			correctionFactor.setYear(year);
			monthYearMetaDataLst.add(month + " " + year);
			correctionFactorList.add(correctionFactor);
			/*if (correction[2] != null) {
				selectedAvg = (Integer) correction[2];
				if (selectedAvg == 1) {
					weightedAvg.setBaseline(correctionFactor.getBaseline() / 100);
					weightedAvg.setStatistical(correctionFactor.getStatistical() / 100);
				}
			}*/

		}
		if (selectedAvg != null)
			correctionFactors.setSelectedAverage(selectedAvg);
		else if (selectedAvg == null)
			correctionFactors.setSelectedAverage(2);
		correctionFactors.setCorrectionValues(correctionFactorList);
		correctionFactors.setMonthYearMetaData(monthYearMetaDataLst);
		//correctionFactors.setWeightedAverage(weightedAvg);
		return correctionFactors;
	}

	@Transactional
	public void updateCorrectionFactors(int regionId, int countryId, int hubId,
			ConsensusCorrectionFactorCombo correctionFactorCombo) {

		// Tables involved: tbl_ConcensusCorrectionFactor, tbl_master_ConsensusAverage
		// tbl_ConsensusAveragevalues

		// Tables involved: tbl_ConsensusAdjustment
		Date date = new Date();
		HubSc h = hubRepository.findById(hubId).get();
		ConsensusCorrectionFactor entity = null;
		ConsensusCorrectionFactor entity1 = null;
		ConsensusAverageValues entityObj = null;
		ConsensusAverageValues entityObj1 = null;
		String monthYear = "";
		int count = 0;
		
		ConsensusCorrectionFactorSelected conAverage = oFactorSelectedRepository.get(regionId, countryId, hubId);

		List<CorrectionFactor> correctionFactorValueLst = correctionFactorCombo.getCorrectionValues();
		ConsensusAverage average = consensusAverageRepository.getOne(correctionFactorCombo.getSelectedAverage());
		ConsensusCorrectionFactorSelected consensusCorrectionFactorSelected = new ConsensusCorrectionFactorSelected();
		consensusCorrectionFactorSelected.setAverage(average);
		consensusCorrectionFactorSelected.setCountry(h.getCountry());
		consensusCorrectionFactorSelected.setCreatedDate(date);
		consensusCorrectionFactorSelected.setFlag(1);
		consensusCorrectionFactorSelected.setHub(h);
		consensusCorrectionFactorSelected.setModifieddDate(date);
		consensusCorrectionFactorSelected.setRegion(h.getRegion());
		oFactorSelectedRepository.updateConsensusCorrectionFactorSelected(regionId, countryId, hubId);
		oFactorSelectedRepository.save(consensusCorrectionFactorSelected);
		
		/*check average id from getSelectedAvergareId*/
		
		Integer aId = conAverage.getAverage().getAid();
		
		for (CorrectionFactor correctionFactor : correctionFactorValueLst) {
			if(aId == 3) {
				monthYear = correctionFactor.getMonth() + "-" + correctionFactor.getYear();
				count = consensusCorrectionFactorRepository.updateCorrectionFactor(countryId, hubId, regionId,
						monthYear);
			}
				
			else if(aId == 1 || aId ==2) {
				count = consensusAvgRepository.updateCorrectionFactor(countryId, hubId, regionId);
				break;
			}
					
		}
		
		for (CorrectionFactor correctionFactor : correctionFactorValueLst) {
			if(correctionFactorCombo.getSelectedAverage() == 3) {
				entity = new ConsensusCorrectionFactor();
				
				monthYear = correctionFactor.getMonth() + "-" + correctionFactor.getYear();
				entity.setMonthYear(monthYear);
				entity.setModifiedDate(date);
				entity.setCreatedDate(date);
				entity.setModifiedBy("CsafeAdmin");
				entity.setCountry(h.getCountry());
				entity.setRegion(h.getRegion());
				entity.setHubsc(h);
				entity.setFlag(1);
				entity.setValue(correctionFactor.getBaseline());
				entity.setForecastType("Budget");
				
				entity1 = new ConsensusCorrectionFactor();
				entity1.setMonthYear(monthYear);
				entity1.setModifiedDate(date);
				entity1.setCreatedDate(date);
				entity1.setModifiedBy("CsafeAdmin");
				entity1.setCountry(h.getCountry());
				entity1.setRegion(h.getRegion());
				entity1.setHubsc(h);
				entity1.setFlag(1);
				entity1.setValue(correctionFactor.getStatistical());
				entity1.setForecastType("Statistical");

			SimpleDateFormat formatter = new SimpleDateFormat("MMM-yyyy");
			String strDate = formatter.format(date);
			entity.setCreatedMonth(strDate);
			entity.setAverage(average);
			
			entity1.setCreatedMonth(strDate);
			entity1.setAverage(average);
			
			consensusCorrectionFactorRepository.save(entity);
			consensusCorrectionFactorRepository.save(entity1);
			
			}
			else if (correctionFactorCombo.getSelectedAverage() == 1 || correctionFactorCombo.getSelectedAverage() == 2) {
				entityObj = new ConsensusAverageValues();
				
				monthYear = correctionFactor.getMonth() + "-" + correctionFactor.getYear();
				entityObj.setModifiedDate(date);
				entityObj.setCreatedDate(date);
				entityObj.setModifiedBy("CsafeAdmin");
				entityObj.setCountry(h.getCountry());
				entityObj.setRegion(h.getRegion());
				entityObj.setHub(h);
				entityObj.setFlag(1);
				entityObj.setValue(correctionFactor.getBaseline());
				entityObj.setForecastType("Budget");
				
				entityObj1 = new ConsensusAverageValues();
				entityObj1.setModifiedDate(date);
				entityObj1.setCreatedDate(date);
				entityObj1.setModifiedBy("CsafeAdmin");
				entityObj1.setCountry(h.getCountry());
				entityObj1.setRegion(h.getRegion());
				entityObj1.setHub(h);
				entityObj1.setFlag(1);
				entityObj1.setValue(correctionFactor.getStatistical());
				entityObj1.setForecastType("Statistical");

			SimpleDateFormat formatter = new SimpleDateFormat("MMM-yyyy");
			String strDate = formatter.format(date);
			entityObj.setCreatedtMonth(strDate);
			entityObj.setAverage(average);
			
			entityObj1.setCreatedtMonth(strDate);
			entityObj1.setAverage(average);
			
			consensusAvgRepository.save(entityObj);
			consensusAvgRepository.save(entityObj1);
			break;
			}
		}
		//Call to WeeklyForecastSP & ConsensusForecastSP Stored Procedure to make forecast same in weekly & consensus
		boolean consensusSPOutput = consensusSpRepository.callConsensusForecastSP();
		boolean weeklySPOutput = weeklySpRepository.callWeeklyForecastSP();
	}

	public ConsensusAdjustmentValueCombo getAdjustmentValues(int regionId, int countryId, int hubId) {

		// Tables involved: tbl_ConsensusAdjustment
		// List<Object> adjustmentsObject =
		// consensusAdjustment.findConsensusAdjustment(countryId, hubId, regionId);
		List<ConsensusAdjustmentValueCombo> adjustmentsObject = consensusAdjustmentRepository
				.getAdjustmentOverride(regionId, countryId, hubId);
		ConsensusAdjustmentValueCombo adjustmentValueCombo = prepareAdjustmentResponse(adjustmentsObject);
		return (prepareSixMonthDataForAdjustment(adjustmentValueCombo));
	}

	private int getAdjustmentObjectIndexFromList(List<ConsensusAdjustmentValue> ObjectValuesList, String month) {
		int index = 0;
		for (ConsensusAdjustmentValue obj : ObjectValuesList) {
			if (month.equalsIgnoreCase(obj.getMonth())) {
				return index;
			}
			index++;
		}
		return -1;
	}

	private int getCorrectionFactorObjectIndexFromList(List<CorrectionFactor> ObjectValuesList, String month) {
		int index = 0;
		for (CorrectionFactor obj : ObjectValuesList) {
			if (month.equalsIgnoreCase(obj.getMonth())) {
				return index;
			}
			index++;
		}
		return -1;
	}

	private ConsensusAdjustmentValueCombo prepareSixMonthDataForAdjustment(
			ConsensusAdjustmentValueCombo adjustmentValueCombo) {
		List<ConsensusAdjustmentValue> adjustmentValuesList = adjustmentValueCombo.getAdjustmentValues();
		List<String> sixMonthYearValuesLst = prepareSixMonthYearList();
		ConsensusAdjustmentValue adjustmentValue = null;
		int count = 0;
		String name = null;
		String year = null;
		Date date = null;
		ConsensusAdjustmentValueCombo consensusAdjustmentValueCombo = new ConsensusAdjustmentValueCombo();
		List<ConsensusAdjustmentValue> adjustmentValuesLst = new LinkedList<>();
		Set<String> monthYearMetaData = new LinkedHashSet<>();
		monthYearMetaData.addAll(sixMonthYearValuesLst);

		for (String value : sixMonthYearValuesLst) {
			name = value.substring(0, value.indexOf(" "));
			year = value.substring(value.indexOf(" ") + 1, value.length());
			count = getAdjustmentObjectIndexFromList(adjustmentValuesList, name);
			// if(adjustmentValuesList.size()>0) {
			if (count >= 0) {
				ConsensusAdjustmentValue adjustmentValueObj = adjustmentValuesList.get(count);

				adjustmentValue = new ConsensusAdjustmentValue();
				adjustmentValue.setValue(adjustmentValueObj.getValue());
				adjustmentValue.setMonth(adjustmentValueObj.getMonth());
				adjustmentValue.setYear(adjustmentValueObj.getYear());
				adjustmentValue.setMonthValue(adjustmentValueObj.getMonthValue());
				adjustmentValuesList.remove(adjustmentValueObj);
				adjustmentValuesLst.add(adjustmentValue);
			} else if (count < 0) {
				adjustmentValue = new ConsensusAdjustmentValue();
				adjustmentValue.setValue(0);
				adjustmentValue.setMonth(name);
				adjustmentValue.setYear(year);
				try {
					date = new SimpleDateFormat("MMMM").parse(name);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				adjustmentValue.setMonthValue(cal.get(Calendar.MONTH));
				adjustmentValuesLst.add(adjustmentValue);
			}

		}
		consensusAdjustmentValueCombo.setAdjustmentValues(adjustmentValuesLst);
		consensusAdjustmentValueCombo.setMonthYearMetaData(monthYearMetaData);

		return consensusAdjustmentValueCombo;
	}

	private ConsensusAdjustmentValueCombo prepareAdjustmentResponse(
			List<ConsensusAdjustmentValueCombo> adjustmentsList) {
		Iterator it = adjustmentsList.iterator();
		String monthYear = "";
		String month = "";
		String year = "";
		ConsensusAdjustmentValue consensusAdjustmentValue = null;
		List<ConsensusAdjustmentValue> adResponeList = new LinkedList<>();
		ConsensusAdjustmentValueCombo consensusAdjustmentCombo = new ConsensusAdjustmentValueCombo();
		Set<String> monthYearMetaDataLst = new LinkedHashSet<>();
		List<ConsensusForecastCombo> consensusList = new ArrayList<>();
		while (it.hasNext()) {
			Object[] adjustment = (Object[]) it.next();
			consensusAdjustmentValue = new ConsensusAdjustmentValue();
			if (adjustment[0] != null)
				consensusAdjustmentValue.setValue(Float.parseFloat(adjustment[0].toString()));
			else
				consensusAdjustmentValue.setValue(0);
			monthYear = (String) adjustment[1];
			month = monthYear.substring(0, monthYear.indexOf("-"));
			year = monthYear.substring(monthYear.indexOf("-") + 1, monthYear.length());
			Date date = null;
			try {
				date = new SimpleDateFormat("MMMM").parse(month);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			// System.out.println(cal.get(Calendar.MONTH));
			consensusAdjustmentValue.setMonthValue(cal.get(Calendar.MONTH));
			consensusAdjustmentValue.setMonth(month);
			consensusAdjustmentValue.setYear(year);
			monthYearMetaDataLst.add(month + " " + year);
			adResponeList.add(consensusAdjustmentValue);
		}
		consensusAdjustmentCombo.setAdjustmentValues(adResponeList);
		consensusAdjustmentCombo.setMonthYearMetaData(monthYearMetaDataLst);
		return consensusAdjustmentCombo;
	}

	@Transactional
	public void updateAdjustmentValues(int regionId, int countryId, int hubId,
			ConsensusAdjustmentValueCombo adjustmentValueCombo) {

		// Tables involved: tbl_ConsensusAdjustment
		ConsensusAdjustment entity = null;
		Date date = new Date();
		String monthYear = "";
		Country c = new Country();
		c.setCountryId(countryId);

		Region r = new Region();
		r.setRegionId(regionId);

		HubSc h = new HubSc();
		h.setHubId(hubId);
		h.setCountry(c);
		h.setRegion(r);

		List<ConsensusAdjustmentValue> consensusAdjustValueLst = adjustmentValueCombo.getAdjustmentValues();
		for (ConsensusAdjustmentValue consensusAdjustmentValue : consensusAdjustValueLst) {
			entity = new ConsensusAdjustment();
			monthYear = consensusAdjustmentValue.getMonth() + "-" + consensusAdjustmentValue.getYear();
			entity.setMonthYear(monthYear);
			entity.setModifiedDate(date);
			entity.setCreatedDate(date);
			entity.setModifiedBy("CsafeAdmin");
			entity.setCountry(c);
			entity.setRegion(r);
			entity.setHubsc(h);
			entity.setFlag(1);
			entity.setValue(consensusAdjustmentValue.getValue());

			int count = consensusAdjustment.updateConsensusAdjustment(countryId, hubId, regionId, monthYear);
			SimpleDateFormat formatter = new SimpleDateFormat("MMM-yyyy");
			String strDate = formatter.format(date);
			entity.setCreatedMonth(strDate);
			consensusAdjustment.save(entity);
		}

	}

	public List<AlignedForecastMonthData> getAlignedForecastData(int regionId, int countryId, int hubId)
			throws CSafeServiceException
	{

		List<Object[]> monthsMeta = containerForecastRepository.getNextMonth(6);
		List<Object[]> formattedMonthsMeta = getFormattedNextSixMonthsData(monthsMeta);
		List<AlignedForecastMonthData> forecastValuesLst = new ArrayList<>();

		AlignedForecastMonthData alignedForecastMonthData = null;

		ArrayList<String> uniqueMonths = new ArrayList<String>();

		for (int i = 0; i < formattedMonthsMeta.size(); i++) {

			Object data[] = formattedMonthsMeta.get(i);

			for (int j = 0; j < data.length; j++) {

				alignedForecastMonthData = new AlignedForecastMonthData();

				// alignedForecastMonthData.setMonth(data[2].toString().substring(0, 3));
				alignedForecastMonthData.setYear(data[0].toString().substring(data[0].toString().indexOf("-") + 1));
				alignedForecastMonthData.setMonthValue((int) data[2]);
				alignedForecastMonthData.setMonth(data[3].toString());

				if (!uniqueMonths.contains(alignedForecastMonthData.getMonth().trim())) {
					uniqueMonths.add(alignedForecastMonthData.getMonth());
					// System.out.println("Month --" + alignedForecastMonthData.getMonth());
					// System.out.println("hub --" + hubId);
					Float value = alignedForecastRepository.getAlignedForecastData(regionId, countryId, hubId,
							data[0].toString());

					if (value != null) {
						alignedForecastMonthData.setValue(value);
					} else {
						alignedForecastMonthData.setValue(0);
					}

					forecastValuesLst.add(alignedForecastMonthData);

				}

			}

		}

		System.out.println("uniqueMonths Values----" + uniqueMonths);

		return forecastValuesLst;
	}

	private List<Object[]> getFormattedNextSixMonthsData(List<Object[]> monthsMetaData) {
		List<Object[]> monthsMeta = new LinkedList<>();

		String str = null;
		for (Object[] month : monthsMetaData) {
			Object[] obj = new Object[4];
			str = (String) month[2];
			obj[0] = str.substring(0, 3) + "-" + month[0];
			obj[1] = month[0];
			obj[2] = month[1];
			obj[3] = month[2];
			monthsMeta.add(obj);

		}
		return monthsMeta;

	}

	public void callCorrectionWeeklySP(int regionId, int countryId, int hubId,
			ConsensusCorrectionFactorCombo correctionFactor) {
		
	}
}
