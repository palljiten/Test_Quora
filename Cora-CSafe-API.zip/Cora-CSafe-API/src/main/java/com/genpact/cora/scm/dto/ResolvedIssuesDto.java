package com.genpact.cora.scm.dto;

public class ResolvedIssuesDto 
{
	private String SerialNumber;
	private String Status;
	private String Origin;
	private String Destination;
	private String AlertDescription;
	private String Week;
	private String dueDate;
    private String notificationDate;
	private String estimatedReceivingDate;
	private String actualReceivingDate;	
	
	public String getSerialNumber() {
		return SerialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		SerialNumber = serialNumber;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getOrigin() {
		return Origin;
	}
	public void setOrigin(String origin) {
		Origin = origin;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public String getAlertDescription() {
		return AlertDescription;
	}
	public void setAlertDescription(String alertDescription) {
		AlertDescription = alertDescription;
	}
	public String getWeek() {
		return Week;
	}
	public void setWeek(String week) {
		Week = week;
	}
	public String getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(String notificationDate) {
		this.notificationDate = notificationDate;
	}
	public String getEstimatedReceivingDate() {
		return estimatedReceivingDate;
	}
	public void setEstimatedReceivingDate(String estimatedReceivingDate) {
		this.estimatedReceivingDate = estimatedReceivingDate;
	}
	public String getActualReceivingDate() {
		return actualReceivingDate;
	}
	public void setActualReceivingDate(String actualReceivingDate) {
		this.actualReceivingDate = actualReceivingDate;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

  
}
