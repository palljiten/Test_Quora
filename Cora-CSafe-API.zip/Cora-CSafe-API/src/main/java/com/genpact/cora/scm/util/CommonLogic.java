package com.genpact.cora.scm.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.genpact.cora.scm.controller.ContainerForecastBpBasedController;
import com.genpact.cora.scm.dto.CountryDetail;
import com.genpact.cora.scm.dto.CountryIDName;
import com.genpact.cora.scm.dto.FieldDetails;
import com.genpact.cora.scm.dto.HubDetails;
import com.genpact.cora.scm.dto.RegionDetail;
import com.genpact.cora.scm.dto.RegionIDName;
import com.genpact.cora.scm.entity.HubSc;

public class CommonLogic {
	
	private static Logger logger = LoggerFactory.getLogger(CommonLogic.class);
	
	public static FieldDetails createFieldMap(List<HubSc> hubList, Map<String, HubDetails> scMap) {
		
		FieldDetails regions = new FieldDetails();
		Map<String, RegionDetail> regionDetailMap = new HashMap<>(); // Key: Region
		Map<String, HubDetails> hubDetailsMap = new HashMap<>(); // Key: Region 
		List<RegionDetail> regionList = new ArrayList<RegionDetail>();
		List<HubDetails> hubDetailsList = new ArrayList<HubDetails>();
		
		Map<String, CountryDetail> countryDetailMap = new HashMap<>(); // Key: regionname-countryname

		for (HubSc hub : hubList) {
			String regionName = hub.getRegion().getRegionName();
			String countryName = hub.getCountry().getCountryName();
			regions.getRegionNames().add(regionName);

			HubDetails hubDetails = hubDetailsMap.get(hub.getHubId());
			if (hubDetails == null) {
				hubDetails = new HubDetails();
				regions.getHubIds().add(hub.getHubId());
				hubDetails.setHubID(hub.getHubId());
				hubDetails.setHubName(hub.getAccountName());
				hubDetails.setHubCode(hub.getHubCode());
				CountryIDName c = new CountryIDName();
				RegionIDName r = new RegionIDName();
				
				c.setCountryId(hub.getCountry().getCountryId());
				c.setCountryName(countryName);
				
				r.setRegionId(hub.getRegion().getRegionId());
				r.setRegionName(regionName);
				
				hubDetails.setCountry(c);
				hubDetails.setRegion(r);
				
				hubDetailsMap.put(hub.getHubId() + ":" + hub.getHubCode(), hubDetails);
				hubDetailsList.add(hubDetails);
				if (hub.getLocationType().equals("SC")) {
					scMap.put(hub.getHubCode().trim(), hubDetails);
				}
			}

			RegionDetail regionDetail = regionDetailMap.get(regionName);
			String rcKey = regionName + "-" + countryName;

			if (regionDetail == null) {
				RegionDetail rd = new RegionDetail();
				rd.setRegionName(regionName);
				rd.setRegionID(hub.getRegion().getRegionId());
				rd.getCountries().add(countryName);

				CountryDetail cd = new CountryDetail();
				cd.setCountryId(hub.getCountry().getCountryId());
				cd.setCountryName(countryName);
				cd.getHubList().add(hub.getAccountName());
				cd.getHubDetails().add(hub);
				
				countryDetailMap.put(rcKey, cd);
				rd.getCountryDetails().add(cd);

				regionDetailMap.put(regionName, rd);
				regionList.add(rd);
			} else {
				regionDetail.getCountries().add(countryName);
				CountryDetail cd = countryDetailMap.get(rcKey);

				if (cd == null) {
					CountryDetail cdNew = new CountryDetail();
					cdNew.setCountryId(hub.getCountry().getCountryId());
					cdNew.setCountryName(countryName);
					cdNew.getHubList().add(hub.getAccountName());
					cdNew.getHubDetails().add(hub);
					countryDetailMap.put(rcKey, cdNew);
					regionDetail.getCountryDetails().add(cdNew);
				} else {
					cd.setCountryId(hub.getCountry().getCountryId());
					cd.setCountryName(countryName);
					cd.getHubList().add(hub.getAccountName());
					cd.getHubDetails().add(hub);
				}
			}
		}
		regions.setRegionDetails(regionList);
		regions.setHubDetails(hubDetailsList);
		return regions;
	}
}
