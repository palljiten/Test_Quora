package com.genpact.cora.scm.dto;

public class ForecastAccuracyPercentageData {
	private int fromCM;
	private int fromLM;
	private int from2Months;
	private int from3Months;
	
	public int getFromCM() {
		return fromCM;
	}
	public void setFromCM(int fromCM) {
		this.fromCM = fromCM;
	}
	public int getFromLM() {
		return fromLM;
	}
	public void setFromLM(int fromLM) {
		this.fromLM = fromLM;
	}
	public int getFrom2Months() {
		return from2Months;
	}
	public void setFrom2Months(int from2Months) {
		this.from2Months = from2Months;
	}
	public int getFrom3Months() {
		return from3Months;
	}
	public void setFrom3Months(int from3Months) {
		this.from3Months = from3Months;
	}
}
