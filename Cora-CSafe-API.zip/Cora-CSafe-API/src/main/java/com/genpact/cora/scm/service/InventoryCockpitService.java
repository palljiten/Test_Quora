/**
 * 
 */
package com.genpact.cora.scm.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.ContainerUtilizationDto;
import com.genpact.cora.scm.dto.InventoryContainerDto;
import com.genpact.cora.scm.dto.SupplyCockpitActivityDto;
import com.genpact.cora.scm.dto.SupplyCockpitAlertDto;
import com.genpact.cora.scm.dto.SupplyCockpitConstrainedDto;
import com.genpact.cora.scm.dto.SupplyCockpitStokPolicyDto;
import com.genpact.cora.scm.exception.CSafeServiceException;

/**
 * @author 703158077
 *
 */
@Service
public class InventoryCockpitService {
	
	private static Logger logger = LoggerFactory.getLogger(InventoryCockpitService.class);
	
	
	/**
	 * @param activityId
	 * @return
	 */
	public SupplyCockpitActivityDto getCockpitActivity(Integer activityId){
		SupplyCockpitActivityDto activityDto = new SupplyCockpitActivityDto();
		try{
			
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getCockpitActivity service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for Supply cockpit >> activity API.",
					cse.getCause());
		}
		return activityDto;
	}
	
	/**
	 * @param id
	 * @return
	 */
	public SupplyCockpitStokPolicyDto getStokPolicyDetails(Integer id){
		SupplyCockpitStokPolicyDto supplyStokPolicy = new SupplyCockpitStokPolicyDto();
		try{
			
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getCockpitActivity service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for Supply cockpit >> stocking policy.",
					cse.getCause());
		}
		return supplyStokPolicy;
	}
	
	/**
	 * @return
	 */
	public InventoryContainerDto inventoryContainerDetails(){
		InventoryContainerDto inventoryContainerDto = new InventoryContainerDto();
		try{
			
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getCockpitActivity service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for Supply cockpit >> Inventory Container.",
					cse.getCause());
		}
		return inventoryContainerDto;
	}
	
	
	/**
	 * @return
	 */
	public ContainerUtilizationDto getContainerUtilizationPercentage(){
		ContainerUtilizationDto containerUtilizationDto = new ContainerUtilizationDto();
try{
			
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getCockpitActivity service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for Supply cockpit >> Contaainer utilization percent.",
					cse.getCause());
		}
		return containerUtilizationDto;
	}
	
	/**
	 * @param id
	 * @return
	 */
	public SupplyCockpitConstrainedDto getConstrained(Integer id){
	SupplyCockpitConstrainedDto supplyCockpitConstrainedDto = new SupplyCockpitConstrainedDto(id, id);
	try{
		
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getCockpitActivity service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for Supply cockpit >> Constrained.",
					cse.getCause());
		}
	return supplyCockpitConstrainedDto;
	}
	
	/**
	 * @param id
	 * @return
	 */
	public SupplyCockpitAlertDto getAlert(String id){
		SupplyCockpitAlertDto supplyCockpitAlertDto = new SupplyCockpitAlertDto();
		try{
			
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getCockpitActivity service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for Supply cockpit >> Constrained.",
					cse.getCause());
		}
	return supplyCockpitAlertDto;
		
	}

}
