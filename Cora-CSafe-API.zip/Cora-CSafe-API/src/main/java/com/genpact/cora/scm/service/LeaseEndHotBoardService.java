package com.genpact.cora.scm.service;

public class LeaseEndHotBoardService {

}
