package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class AlignedForecastMonthData implements Serializable {

	private static final long serialVersionUID = 1L;

	private int monthValue; // e.g. 0 for January, 1 for February etc.
	private String month; //e.g. January, February etc.
	private String year; // e.g. 2018
	private float value; // forecast value
	
	 
	public int getMonthValue() {
		return monthValue;
	}
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public float getValue() {
		return value;
	}
	public void setValue(float value) {
		this.value = value;
	}
}
