package com.genpact.cora.scm.service;

import java.util.Map;

public interface IContainerForecastStatisticalService {

}
