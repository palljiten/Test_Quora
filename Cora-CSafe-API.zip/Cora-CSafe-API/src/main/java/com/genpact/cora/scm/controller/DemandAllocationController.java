package com.genpact.cora.scm.controller;

import javax.validation.Valid;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.DemandAlloactionEditRequest;
import com.genpact.cora.scm.dto.DemandAllocationResponse;
import com.genpact.cora.scm.dto.FinalDemandForecastResponse;
import com.genpact.cora.scm.dto.InventoryStatusResponse;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.entity.DemandAllocationEdit;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.DemandAllocationService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
@Api(tags = { "Demand Allocation" })
public class DemandAllocationController {

	private static Logger logger = LoggerFactory.getLogger(SparesForecastStatisticalController.class);

	@Autowired
	DemandAllocationService demandAllocationService;

	@GetMapping(value = "/demandAllocation", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Forecast")
	public ResponseEntity<DemandAllocationResponse> getDemandAllocation(@RequestParam("regionID") Integer regionID,
			@RequestParam("countryID") Integer countryID, @RequestParam("hubID") Integer hubID) throws JSONException {
		DemandAllocationResponse demandAllocationResponse;
		try {
			demandAllocationResponse = demandAllocationService.getDemandAllocation(regionID, countryID, hubID, 13);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException("API error occured during get data for demand allocation (Demand Allocation)",
					e.getCause());
		}
		return new ResponseEntity<DemandAllocationResponse>(demandAllocationResponse, HttpStatus.OK);
	}

	@GetMapping(value = "/demandAllocation/demandForecast", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Current Inventory Status")
	public ResponseEntity<FinalDemandForecastResponse> getFinalDemandForecast(
			@RequestParam("regionID") Integer regionID, @RequestParam("countryID") Integer countryID,
			@RequestParam("hubID") Integer hubID) {
		FinalDemandForecastResponse oFinalDemandForecastResponse;
		try {
			oFinalDemandForecastResponse = demandAllocationService.getFinalDemandForecast(regionID, countryID, hubID,
					13);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException("API error occured during get data for final demand forecast (Demand Allocation)",
					e.getCause());
		}
		return new ResponseEntity<>(oFinalDemandForecastResponse, HttpStatus.OK);
	}

	@GetMapping(value = "/demandAllocation/currentInvStatus", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Current Inventory Status")
	public ResponseEntity<InventoryStatusResponse> getCurrentInventoryStatus(@RequestParam("regionID") Integer regionID,
			@RequestParam("countryID") Integer countryID, @RequestParam("hubID") Integer hubId) {
		InventoryStatusResponse oInventoryStatusResponse;
		try
		{
			oInventoryStatusResponse=demandAllocationService.getCurrentInventoryStatus(regionID,countryID,hubId);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException("API error occured during get data for Current Inventory status (Demand Allocation)",
					e.getCause());
		}
		return new ResponseEntity<>(oInventoryStatusResponse, HttpStatus.OK);
	}
	
	@PutMapping(value = "/demandAllocation", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Details Allocation of Forecast")
	public ResponseEntity<SuccessResponse> updateDemandAllocation(@RequestBody DemandAlloactionEditRequest demandAlloactionEditRequest) throws JSONException {
		try {
			demandAllocationService.updateDemandAllocation(demandAlloactionEditRequest);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException("API error occured during Update data for demand allocation (Demand Allocation)",
					e.getCause());
		}
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("CONTROLLER: DemandAllocationController: Exiting updateDemandAllocation() method (Demand Allocation)");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}
}
