package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.entity.RepairWorkOrderParts;

public interface RepairWorkOrderPartsRepository extends JpaRepository<RepairWorkOrderParts, Integer>{
	
	@Query("SELECT w FROM RepairWorkOrderParts w WHERE w.sc = :hubCode AND w.partNumber = :partNum AND DATEDIFF(MONTH, w.createDate, CURRENT_DATE()) <= :months")
	List<RepairWorkOrderParts> getRepairWorkOrderParts(@Param("hubCode") String hubCode, @Param("partNum") String partNumber, @Param("months") int months);
	
	@Query("select new RepairWorkOrderParts(p.partNumber, p.sc) from RepairWorkOrderParts p")
	List<RepairWorkOrderParts> findParts();
	
	@Query("SELECT rwp.quantity FROM RepairWorkOrderParts rwp where rwp.currentlyInStock=0 AND rwp.partNumber  = :partNumber")
	RepairWorkOrderParts findQuatity(@Param("partNumber") String partNumber );

}
 