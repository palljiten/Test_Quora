package com.genpact.cora.scm.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.MonthDataUnit;
import com.genpact.cora.scm.dto.SingleModelOutput;
import com.genpact.cora.scm.dto.SparesStatisticalForecastModelOutput;
import com.genpact.cora.scm.dto.StatisticalForecastModelOutput;
import com.genpact.cora.scm.dto.TempBestFitModel;
import com.genpact.cora.scm.dto.TempConfigModel;
import com.genpact.cora.scm.dto.TempModelOutput;
import com.genpact.cora.scm.entity.StatisticalModelMaster;
import com.genpact.cora.scm.repository.SpecialForecastModelRepository;
import com.genpact.cora.scm.repository.StatisticalModelRepository;

@Service
public class StatisticalModelService {

	private static Map<Integer, String> monthValueMap = new HashMap<>();
	private static Map<String, Integer> monthValueReverseMap = new HashMap<>();

	static {
		monthValueMap.put(0, "Jan");
		monthValueMap.put(1, "Feb");
		monthValueMap.put(2, "Mar");
		monthValueMap.put(3, "Apr");
		monthValueMap.put(4, "May");
		monthValueMap.put(5, "Jun");
		monthValueMap.put(6, "Jul");
		monthValueMap.put(7, "Aug");
		monthValueMap.put(8, "Sep");
		monthValueMap.put(9, "Oct");
		monthValueMap.put(10, "Nov");
		monthValueMap.put(11, "Dec");

		monthValueReverseMap.put("Jan", 0);
		monthValueReverseMap.put("Feb", 1);
		monthValueReverseMap.put("Mar", 2);
		monthValueReverseMap.put("Apr", 3);
		monthValueReverseMap.put("May", 4);
		monthValueReverseMap.put("Jun", 5);
		monthValueReverseMap.put("Jul", 6);
		monthValueReverseMap.put("Aug", 7);
		monthValueReverseMap.put("Sep", 8);
		monthValueReverseMap.put("Oct", 9);
		monthValueReverseMap.put("Nov", 10);
		monthValueReverseMap.put("Dec", 11);
	}

	@Autowired
	StatisticalModelRepository smRepository;

	@Autowired
	SpecialForecastModelRepository specialForecastRepository;

	@Autowired
	SparesForecastStatisticalService sparesForecastStatisticalService;

	public SparesStatisticalForecastModelOutput getSparesForecastModels(int regionId, int countryId, int hubId,
			String partId) {

		SparesStatisticalForecastModelOutput data = new SparesStatisticalForecastModelOutput();
		try {
			List<String> monthYearList = getMonthYearList();
			
			for (String givenMY : monthYearList) {
				data.getMonthYearMetaData().add(getProperMonthYear(givenMY));
			}
			
			System.out.println("\n\n*************** INPUT PARAMETERS for SPARES FORECAST MODEL ***********************\n\n");
			System.out.println("RegionID = " + regionId);
			System.out.println("RegionID = " + regionId);
			System.out.println("CountryID = " + countryId);
			System.out.println("HubID = " + hubId);
			System.out.println("PartID = " + partId);
			System.out.println("MonthYearList = " + monthYearList);
			List<TempModelOutput> modelOuput = specialForecastRepository.getTempSparesForecastModels(regionId,
					countryId, hubId, partId, monthYearList);

			System.out.println("\n\n >>>>> " + modelOuput + "\n\n");
			List<TempConfigModel> configModel = specialForecastRepository.getTempSparesConfigModels(regionId, countryId,
					hubId, partId, monthYearList);

			List<TempBestFitModel> bestFitModel = specialForecastRepository.getTempSparesBestFitModels(regionId,
					countryId, hubId, partId, monthYearList);
			System.out.println("\n\n*************** INPUT PARAMETERS ***********************\n\n");
			
			Integer configuredModelId = 0;
			Integer bestFitModelId = 0;
			if (!configModel.isEmpty()) {
				configuredModelId = configModel.get(0).getConfigModelId();
				for (TempConfigModel cm : configModel) {
					if (cm.getConfigModelId() != null) {
						configuredModelId = cm.getConfigModelId();
						break;
					}
				}
			}
			if (!bestFitModel.isEmpty()) {
				for (TempBestFitModel bft : bestFitModel) {
					if (bft.getBestFitModelId() != null) {
						bestFitModelId = bft.getBestFitModelId();
						break;
					}
				}
			}

			Map<Integer, SingleModelOutput> modelOutMap = new HashMap<>();
			Map<String, MonthDataUnit> monthDataMap = new HashMap<>();

			for (TempModelOutput tmOutput : modelOuput) {
				String monthYear = getProperMonthYear(tmOutput.getMonthYear());
				//data.getMonthYearMetaData().add(monthYear);

				SingleModelOutput smo = modelOutMap.get(tmOutput.getModelId());

				if (smo == null) {
					smo = new SingleModelOutput();
					smo.setModelId(tmOutput.getModelId());
					smo.setModelName(tmOutput.getModelName());
					List<MonthDataUnit> monthData = new ArrayList<>();
					smo.setMonthData(monthData);
					data.getModelOutput().add(smo);
					modelOutMap.put(tmOutput.getModelId(), smo);
				}

				MonthDataUnit mdu = monthDataMap.get(tmOutput.getMonthYear() + tmOutput.getModelId());
				if (mdu == null) {
					mdu = new MonthDataUnit();
					String[] parts = tmOutput.getMonthYear().split("-");
					mdu.setMonth(parts[0]);
					mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
					mdu.setYear(Integer.parseInt(parts[1]));
					mdu.setValue(tmOutput.getForecastValue());
					smo.getMonthData().add(mdu);
					monthDataMap.put(tmOutput.getMonthYear() + tmOutput.getModelId(), mdu);
				}

				String techniqueName = tmOutput.getTechniqueName();
				if (techniqueName.equals("MAPE")) {
					smo.setMapePercent(tmOutput.getValue());
				} else if (techniqueName.equals("MAD")) {
					smo.setMadPercent(tmOutput.getValue());
				} else if (techniqueName.equals("RMSE")) {
					smo.setRmsePercent(tmOutput.getValue());
				}

				if (tmOutput.getModelId() == configuredModelId) {
					smo.setConfigured(true);
				}

				if (tmOutput.getModelId() == bestFitModelId) {
					smo.setBestFit(true);
				}
			}
			
			/*if modelOutput is blank then add 0 for all models*/
			if(modelOuput.size() <=0 && configModel.size() <=0)
				populateDefaultValueForAllModel(data);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return data;
	}

	private String getProperMonthYear(String my) {
		StringBuffer properMonthYear = new StringBuffer("");
		String[] parts = my.split("-");
		properMonthYear.append(parts[0]);
		properMonthYear.append(" ");
		properMonthYear.append(parts[1]);
		return properMonthYear.toString();
	}

	private List<String> getNext6MonthYearList() {
		List<String> monthYearList = new ArrayList<>();

		Calendar c = Calendar.getInstance();

		// 10, 11, 0, 1, 2, 3

		int startingMonth = c.get(Calendar.MONTH) + 1;
		int nextMonth = startingMonth;
		boolean isChangeInYear = false;

		for (int i = 0; i < 6; i++) {
			int mod = nextMonth % 11;
			if ((nextMonth > 11) && mod > 0) {
				isChangeInYear = true;
				nextMonth = mod - 1;
			}
			System.out.println(nextMonth);
			String year = isChangeInYear ? ("" + (c.get(Calendar.YEAR) + 1)) : ("" + c.get(Calendar.YEAR));
			monthYearList.add(monthValueMap.get(nextMonth) + "-" + year);
			nextMonth = nextMonth + 1;

		}

		return monthYearList;
	}
	
	private List<String> getMonthYearList() {
		List<String> monthYearList = new ArrayList<>();

		Calendar c = Calendar.getInstance();
		System.out.println(c.get(Calendar.MONTH));
		System.out.println(c.get(Calendar.YEAR));

		// 10, 11, 0, 1, 2, 3

		int startingMonth = c.get(Calendar.MONTH);
		int nextMonth = startingMonth;
		boolean isChangeInYear = false;

		for (int i = 0; i < 6; i++) {
			System.out.println(nextMonth);
			String year = isChangeInYear ? ("" + (c.get(Calendar.YEAR) + 1)) : ("" + c.get(Calendar.YEAR));
			monthYearList.add(monthValueMap.get(nextMonth) + "-" + year);
			nextMonth = nextMonth + 1;
			int mod = nextMonth % 11;
			if ((nextMonth > 11) && mod > 0) {
				isChangeInYear = true;
				nextMonth = mod - 1;
			}
		}

		return monthYearList;
	}
	
	private void populateDefaultValueForAllModel(SparesStatisticalForecastModelOutput data) {
		List<SingleModelOutput> modelOutput = new ArrayList<>();
		List<String> monthMetaData = data.getMonthYearMetaData();
		List<MonthDataUnit> monthData = new ArrayList<>();
		MonthDataUnit monthObj = null;
		List<StatisticalModelMaster> modelList = specialForecastRepository.getModels();
		Iterator it = modelList.iterator();
		int index =0;
		
		for(int i=0;i<8;i++) {
			SingleModelOutput singleModelOutput = new SingleModelOutput();
			singleModelOutput.setBestFit(false);
			singleModelOutput.setConfigured(false);
			singleModelOutput.setMadPercent(0);
			singleModelOutput.setMapePercent(0);
			singleModelOutput.setRmsePercent(0);
			
			modelOutput.add(singleModelOutput);
		}
		
		while(it.hasNext()) {
			SingleModelOutput singleModelOutput = new SingleModelOutput();
			Object[] object = (Object[]) it.next();
			singleModelOutput = modelOutput.get(index);
			singleModelOutput.setModelId(Integer.parseInt(object[0].toString()));
			singleModelOutput.setModelName(object[1].toString());
			index++;
		}
		
			for(String month : monthMetaData) {
				monthObj = new MonthDataUnit();
				String[] parts = month.split(" ");
				monthObj.setMonth(parts[0]);
				monthObj.setMonthValue(monthValueReverseMap.get(parts[0]));
				monthObj.setYear(Integer.parseInt(parts[1]));
				monthObj.setValue(0);
				
				monthData.add(monthObj);
			}
			
			for(SingleModelOutput singleModelOutput : modelOutput) {
			 singleModelOutput.setMonthData(monthData);
		}
		data.setModelOutput(modelOutput);
		
	}
}
