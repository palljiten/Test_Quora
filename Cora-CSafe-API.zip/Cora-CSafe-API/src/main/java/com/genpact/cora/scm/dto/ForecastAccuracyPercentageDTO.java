package com.genpact.cora.scm.dto;

public class ForecastAccuracyPercentageDTO {

	private int regionId;
	private int countryId;
	private int hubId;
	private String partId;
	private String month;
	private int monthValue;
	private int year;
	private String type;
	
	private ForecastAccuracyPercentageData statistical;
	private ForecastAccuracyPercentageData bpBased;
	private ForecastAccuracyPercentageData aligned;
	private ForecastAccuracyPercentageData consensus;
	
	public int getRegionId() {
		return regionId;
	}
	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}
	public int getCountryId() {
		return countryId;
	}
	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}
	public int getHubId() {
		return hubId;
	}
	public void setHubId(int hubId) {
		this.hubId = hubId;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getMonthValue() {
		return monthValue;
	}
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public ForecastAccuracyPercentageData getStatistical() {
		return statistical;
	}
	public void setStatistical(ForecastAccuracyPercentageData statistical) {
		this.statistical = statistical;
	}
	public ForecastAccuracyPercentageData getBpBased() {
		return bpBased;
	}
	public void setBpBased(ForecastAccuracyPercentageData bpBased) {
		this.bpBased = bpBased;
	}
	public ForecastAccuracyPercentageData getAligned() {
		return aligned;
	}
	public void setAligned(ForecastAccuracyPercentageData aligned) {
		this.aligned = aligned;
	}
	public ForecastAccuracyPercentageData getConsensus() {
		return consensus;
	}
	public String getPartId() {
		return partId;
	}
	public void setPartId(String partId) {
		this.partId = partId;
	}
	public void setConsensus(ForecastAccuracyPercentageData consensus) {
		this.consensus = consensus;
	}
}
