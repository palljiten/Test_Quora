/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author 703158077
 *
 */
public class InventoryPlanningSparesConfigDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543224L;
	
	
	private Integer hubId;
	private String partNumber;
	private Integer ServiceLevel;
	private Integer countryId;
	private Integer regionId;
	
	
	
	
	

	/**
	 * @return the countryId
	 */
	public Integer getCountryId() {
		return countryId;
	}

	/**
	 * @param countryId the countryId to set
	 */
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	/**
	 * @return the regionId
	 */
	public Integer getRegionId() {
		return regionId;
	}

	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}

	/**
	 * @return the hubId
	 */
	public Integer getHubId() {
		return hubId;
	}

	/**
	 * @param hubId the hubId to set
	 */
	public void setHubId(Integer hubId) {
		this.hubId = hubId;
	}

	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * @return the safetyRequired
	 */
	public Integer getServiceLevel() {
		return ServiceLevel;
	}

	/**
	 * @param safetyRequired the safetyRequired to set
	 */
	public void setServiceLevel(Integer serviceLevel) {
		ServiceLevel = serviceLevel;
	}
	
	
	
	
	
	

}
