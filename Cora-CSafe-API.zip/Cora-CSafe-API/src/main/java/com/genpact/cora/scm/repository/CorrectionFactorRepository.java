package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.entity.ConsensusCorrectionFactor;

@Repository
public class CorrectionFactorRepository {
	
	@PersistenceContext
    private EntityManager entityManager;
	
	public List<ConsensusCorrectionFactor> getCorrectionFactor(int regionId, int countryId,int hubId){
		@SuppressWarnings("unchecked")			
		List<ConsensusCorrectionFactor> correctionFactorsObject = entityManager.createNativeQuery("select distinct b.value as v ,concat(substring(c.MonthName,1,3),'-',c.Year) as my, b.AID"
					+ "  from tbl_master_Calendar c left outer join tbl_ConsensusCorrectionFactor b"
					+ "	 on concat(substring(c.MonthName,1,3),'-',c.Year)=b.MonthYear and b.Flag=1 "
					+ " and b.RegionID=:regionId and b.CountryID=:countryId and b.HubID=:hubId and forecastType='Budget'"
					+ " where date < dateadd(m,6, getdate()) and date > getdate()")
										.setParameter("regionId", regionId)
										.setParameter("countryId", countryId)
										.setParameter("hubId", hubId)
										.getResultList();
										
		return correctionFactorsObject;
	}

}
