package com.genpact.cora.scm.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.genpact.cora.scm.dto.PythonRequestObject;
import com.genpact.cora.scm.dto.PythonResponseObject;
import com.genpact.cora.scm.exception.CSafeServiceException;

@Service
public class ExternalServiceCaller {

	private static Logger logger = LoggerFactory.getLogger(ExternalServiceCaller.class);
	
	@Value("${csafe.flask-service.on-demand-container.url}")
	private String onDemandContainerURL;

	@Value("${csafe.flask-service.on-demand-spares.url}")
	private String onDemandSparesURL;

	@Value("${csafe.flask-service.dummy.url}")
	private String dummyServiceURL;

	@Autowired
	RestTemplate restTemplate;

	public PythonResponseObject callOnDemandContainerService(PythonRequestObject pythonRequestObject) {
		PythonResponseObject result = callExternalFlaskService(pythonRequestObject, onDemandContainerURL);
		return result;
	}
	
	public PythonResponseObject callOnDemandSparesService(PythonRequestObject pythonRequestObject) {
		PythonResponseObject result = callExternalFlaskService(pythonRequestObject, onDemandSparesURL);
		return result;
	}
	
	private PythonResponseObject callExternalFlaskService(PythonRequestObject pythonRequestObject, String restURL) {
		PythonResponseObject result = null;

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<PythonRequestObject> entity = new HttpEntity<>(pythonRequestObject, headers);
		try {
			logger.info("Calling Flask REST API: " + restURL);
			result = restTemplate.postForObject(restURL, entity, PythonResponseObject.class);
		} catch (HttpStatusCodeException e) {
			String errorpayload = e.getResponseBodyAsString();
			logger.error("Error caught: " + errorpayload, e);
			throw new CSafeServiceException("Pythong module is facing issue during processing", e);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException("Pythong module is facing issue during processing", e);
		}
		return result;
	}
}
