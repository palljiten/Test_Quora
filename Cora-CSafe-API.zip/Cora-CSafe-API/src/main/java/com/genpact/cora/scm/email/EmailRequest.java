package com.genpact.cora.scm.email;

import java.io.Serializable;
import java.util.Map;

public class EmailRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String fromMailId;
	private String toMailList;
	private String ccMailList;
	private String subject;
	private String contentDescription;
	private Object dynamicContent;
	private String destinationHub;
	private String mailTemplateId;
	private String serialNumber;
	private String partNumber;
	
	public String getFromMailId() {
		return fromMailId;
	}
	public void setFromMailId(String fromMailId) {
		this.fromMailId = fromMailId;
	}
	public String getToMailList() {
		return toMailList;
	}
	public void setToMailList(String toMailList) {
		this.toMailList = toMailList;
	}
	public String getCcMailList() {
		return ccMailList;
	}
	public void setCcMailList(String ccMailList) {
		this.ccMailList = ccMailList;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContentDescription() {
		return contentDescription;
	}
	public void setContentDescription(String contentDescription) {
		this.contentDescription = contentDescription;
	}
	public Object getDynamicContent() {
		return dynamicContent;
	}
	public void setDynamicContent(Object dynamicContent) {
		this.dynamicContent = dynamicContent;
	}
	public String getDestinationHub() {
		return destinationHub;
	}
	public void setDestinationHub(String destinationHub) {
		this.destinationHub = destinationHub;
	}
	public String getMailTemplateId() {
		return mailTemplateId;
	}
	public void setMailTemplateId(String mailTemplateId) {
		this.mailTemplateId = mailTemplateId;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
}
