package com.genpact.cora.scm.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.BPDemandResponse;
import com.genpact.cora.scm.dto.BaselineForecastResponse;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.repository.ContainerForecastRepository;
import com.genpact.cora.scm.repository.HubRepository;

@Service("containerForecastService")
public class ContainerForecastService implements IContainerForecastService {

	@Autowired
	ContainerForecastRepository containerForecastRepository;

	@Autowired
	HubRepository hubRepository;

	@Override
	public BPDemandResponse getBaselineDemand(int regionId, int countryId, int hubId, int months) {
		HubSc hubSc = hubRepository.findById(hubId).get();
		BPDemandResponse bpDemandResponse=new BPDemandResponse();
		Map<String, Object> region = new HashMap<>();
		region.put("regionID", hubSc.getRegion().getRegionId());
		region.put("regionName", hubSc.getRegion().getRegionName());
		Map<String, Object> country = new HashMap<>();
		country.put("countryID", hubSc.getCountry().getCountryId());
		country.put("countryName", hubSc.getCountry().getCountryName());
		Map<String, Object> hub = new HashMap<>();
		hub.put("hubID", hubSc.getHubId());
		hub.put("hubCode", hubSc.getHubCode());
		bpDemandResponse.setRegion(region);
		bpDemandResponse.setCountry(country);
		bpDemandResponse.setHub(hub);
		List<Object[]> monthData=containerForecastRepository.getPrivoustMonth(months);
		List<BaselineForecastResponse> baselineForecasts=new ArrayList<>();
		BaselineForecastResponse baselineForecast;
		for(Object[] objects:monthData)
		{
			baselineForecast=new BaselineForecastResponse();
			baselineForecast.setMonth(objects[2].toString().substring(0, 3));
			baselineForecast.setMonthValue((int)objects[1]);
			baselineForecast.setYear(objects[0].toString());
			Integer value= containerForecastRepository.getBaselineDemand(hubSc.getHubCode(),(int) objects[1],(int)objects[0]);
			if(value!=null)
				baselineForecast.setValue(value);
			else
				baselineForecast.setValue(0);
			
			bpDemandResponse.getMonthYearMetaData().add(objects[2].toString().substring(0, 3)+"-"+ objects[0].toString());
			baselineForecasts.add(baselineForecast);
		}
		bpDemandResponse.setDemandValues(baselineForecasts);
	
		return bpDemandResponse;
	}
	private List<Object[]> getFormattedNextSixMonthsData(List<Object[]> monthsMetaData){
		List<Object[]> monthsMeta = new ArrayList<>();
		
		String str = null;
		for(Object[] month : monthsMetaData) {
			Object[] obj = new Object[4];
			str = (String)month[2];
			obj[0] = str.substring(0, 3)+"-"+month[0];
			obj[1] = month[0];
			obj[2] = month[1];
			obj[3] = month[2];
			monthsMeta.add(obj);
			
		}
		return monthsMeta;
		
	}
	
public Map<Object,Object> getForecastData(int regionId,int hubId, int months){
		
		Map<Object,Object> responseData = new LinkedHashMap<Object,Object>();
		List<Object[]> regionResult = containerForecastRepository.getForecastRegionData(regionId,months);
		List<Object[]> hubResult = containerForecastRepository.getForecastHubData(hubId,months);
		List<String> monthYearMetaData = new ArrayList<>();
		
		List<Map<String,Object>> regionData = new ArrayList<>();
		List<Map<String,Object>> countryData = new ArrayList<>();
		List<Map<String,Object>> hubData = new ArrayList<>();
		Map<String,Integer> monthValue = new LinkedHashMap<String,Integer>();
		monthValue.put("JAN", 1);
		monthValue.put("FEB", 2);
		monthValue.put("MAR", 3);
		monthValue.put("APR", 4);
		monthValue.put("MAY", 5);
		monthValue.put("JUN", 6);
		monthValue.put("JUL", 7);
		monthValue.put("AUG", 8);
		monthValue.put("SEP", 9);
		monthValue.put("OCT", 10);
		monthValue.put("NOV", 11);
		monthValue.put("DEC", 12);
		for(Object[]rowData :regionResult) {
			
			monthYearMetaData.add(rowData[0].toString());
			Map<String,Object> regionLevel = new LinkedHashMap<>();
			regionLevel.put("regionID", rowData[2]);
			regionLevel.put("regionName", rowData[3]);
			Map<String,Object> regionvalue = new LinkedHashMap<>();
			if(monthValue.containsKey(rowData[0].toString().substring(0, 3).toUpperCase())) {
			regionvalue.put("monthValue", monthValue.get(rowData[0].toString().substring(0, 3).toUpperCase()));
		}
			regionvalue.put("monthYear",  rowData[0]);
			if(rowData[1]== null) {
				regionvalue.put("value",  rowData[1]);
			}
			else {
			regionvalue.put("value",  rowData[1]);
			}
			regionData.add(regionvalue);
			regionLevel.put("data", regionData);
			responseData.put("regionLevel",regionLevel);
			
		}
				
		for(Object[]rowData :hubResult) {
			Map<String,Object> hubLevel = new LinkedHashMap<>();
			hubLevel.put("hubID", rowData[2]);
			hubLevel.put("hubName", rowData[3]);
			Map<String,Object> hubvalue = new LinkedHashMap<>();
			if(monthValue.containsKey(rowData[0].toString().substring(0, 3).toUpperCase())) {
			hubvalue.put("monthValue", monthValue.get(rowData[0].toString().substring(0, 3).toUpperCase()));
			}
			hubvalue.put("monthYear",  rowData[0]);
			if(rowData[1]== null) {
				hubvalue.put("value",  0);
			}
			else {
				hubvalue.put("value",  rowData[1]);
			}
			hubData.add(hubvalue);
			hubLevel.put("data", hubData);
			responseData.put("hubLevel",hubLevel);
		}
		responseData.put("monthYearMetaData",monthYearMetaData);
		return responseData;
	}

}
