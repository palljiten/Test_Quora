package com.genpact.cora.scm.dto;

public class HotBoard {
	
	private String weekNo;
	private Long serialNumber;
	private String origin;
	
	public HotBoard(String weekNo ,Long serialNumber,String origin) {
		this.weekNo = weekNo;
		this.serialNumber=serialNumber;
		this.origin = origin;
	}
	
	public String getWeekNo() {
		return weekNo;
	}
	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}
	public Long getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(Long serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}
	

}
