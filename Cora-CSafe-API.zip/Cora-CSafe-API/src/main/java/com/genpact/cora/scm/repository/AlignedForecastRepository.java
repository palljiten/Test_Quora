package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.AlignedForecast;

public interface AlignedForecastRepository extends JpaRepository<AlignedForecast, Integer>{
	
		 
	@Query(value="SELECT SUM(AlignedForecast) as alignedForecast from tbl_ConsensusForecast where HubId=:hubId and CountryID=:countryId and RegionID=:regionId and MonthYear=:monthYear  and flag='1' group by HubId ",nativeQuery=true)
	public Float getAlignedForecastData(@Param("regionId")int regionId,@Param("countryId")int countryId,@Param("hubId")int hubId,@Param("monthYear") String monthYear);
	
	

}
 