package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class InventoryStatusResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Set<String> weekMetaData;
	private Map<String,WeekStartDate> values;
	private Map<String,Integer> currentInventoryStatus;
	
	public Set<String> getWeekMetaData() {
		return weekMetaData;
	}
	public void setWeekMetaData(Set<String> weekMetaData) {
		this.weekMetaData = weekMetaData;
	}
	public Map<String, WeekStartDate> getValues() {
		return values;
	}
	public void setValues(Map<String, WeekStartDate> values) {
		this.values = values;
	}
	public Map<String, Integer> getCurrentInventoryStatus() {
		return currentInventoryStatus;
	}
	public void setCurrentInventoryStatus(Map<String, Integer> currentInventoryStatus) {
		this.currentInventoryStatus = currentInventoryStatus;
	}
	
	
}

