/**
 * 
 */
package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author 703158077
 *
 */
@Entity
@Table(name="tbl_VAInboundRepairEnd")
public class VAInboundRepairEnd {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;
	private long containerId;
	private String serialNumber;
	
	@Column(name="Tname", nullable=false)
	private String tName;
	
	@Column(name="Status", nullable=false)
	private String status;
	private String origin;
	private String containerLocation;
	private Date actualReceivingDate;
	private Date arrivalDate;
	private Date dueDate;
	private Date notificationDate;
	private Date estimatedReceivingDate;
	
	@Column(name="Alert Type", nullable=false)
	private String alertType;
	private int workWorderId;
	private Date wODate;
	private String partNumber;
	private String description;
	private int currentlyInStock;
	
	@Column(name="AlertDescription", nullable=false)
	private String alertDescription;
	
	@Column(name="WeekNo", nullable=false)
	private String weekNo;
	
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the containerId
	 */
	public long getContainerId() {
		return containerId;
	}
	/**
	 * @param containerId the containerId to set
	 */
	public void setContainerId(long containerId) {
		this.containerId = containerId;
	}
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the tName
	 */
	public String gettName() {
		return tName;
	}
	/**
	 * @param tName the tName to set
	 */
	public void settName(String tName) {
		this.tName = tName;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the origin
	 */
	public String getOrigin() {
		return origin;
	}
	/**
	 * @param origin the origin to set
	 */
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	/**
	 * @return the containerLocation
	 */
	public String getContainerLocation() {
		return containerLocation;
	}
	/**
	 * @param containerLocation the containerLocation to set
	 */
	public void setContainerLocation(String containerLocation) {
		this.containerLocation = containerLocation;
	}
	/**
	 * @return the actualReceivingDate
	 */
	public Date getActualReceivingDate() {
		return actualReceivingDate;
	}
	/**
	 * @param actualReceivingDate the actualReceivingDate to set
	 */
	public void setActualReceivingDate(Date actualReceivingDate) {
		this.actualReceivingDate = actualReceivingDate;
	}
	/**
	 * @return the arivalDate
	 */
	public Date getArivalDate() {
		return arrivalDate;
	}
	/**
	 * @param arivalDate the arivalDate to set
	 */
	public void setArivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	/**
	 * @return the dueDate
	 */
	public Date getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	/**
	 * @return the notificationDate
	 */
	public Date getNotificationDate() {
		return notificationDate;
	}
	/**
	 * @param notificationDate the notificationDate to set
	 */
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	/**
	 * @return the estimatedReceivingDate
	 */
	public Date getEstimatedReceivingDate() {
		return estimatedReceivingDate;
	}
	/**
	 * @param estimatedReceivingDate the estimatedReceivingDate to set
	 */
	public void setEstimatedReceivingDate(Date estimatedReceivingDate) {
		this.estimatedReceivingDate = estimatedReceivingDate;
	}
	/**
	 * @return the alertType
	 */
	public String getAlertType() {
		return alertType;
	}
	/**
	 * @param alertType the alertType to set
	 */
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	/**
	 * @return the workWorderId
	 */
	public int getWorkWorderId() {
		return workWorderId;
	}
	/**
	 * @param workWorderId the workWorderId to set
	 */
	public void setWorkWorderId(int workWorderId) {
		this.workWorderId = workWorderId;
	}
	/**
	 * @return the wODate
	 */
	public Date getwODate() {
		return wODate;
	}
	/**
	 * @param wODate the wODate to set
	 */
	public void setwODate(Date wODate) {
		this.wODate = wODate;
	}
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the currentlyInStock
	 */
	public int getCurrentlyInStock() {
		return currentlyInStock;
	}
	/**
	 * @param currentlyInStock the currentlyInStock to set
	 */
	public void setCurrentlyInStock(int currentlyInStock) {
		this.currentlyInStock = currentlyInStock;
	}
	/**
	 * @return the alertDescription
	 */
	public String getAlertDescription() {
		return alertDescription;
	}
	/**
	 * @param alertDescription the alertDescription to set
	 */
	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}
	/**
	 * @return the weekNo
	 */
	public String getWeekNo() {
		return weekNo;
	}
	/**
	 * @param weekNo the weekNo to set
	 */
	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}
	
	
	
	
}
