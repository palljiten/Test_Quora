package com.genpact.cora.scm.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;
import java.lang.annotation.RetentionPolicy;

import javax.validation.Constraint;
import javax.validation.Payload;

@Target({ ElementType.METHOD, ElementType.FIELD, ElementType.ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = ValidMonthYearValidator.class)
public @interface ValidMonthYear {
   String message() default "MonthYear is not valid. It should follow this pattern: "
   		+ "MMM-yyyy";

   Class<?>[] groups() default {};

   Class<? extends Payload>[] payload() default {};
}
