package com.genpact.cora.scm.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.ContainerInventoryStatus;
import com.genpact.cora.scm.entity.SpareInventoryStatus;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.InventoryStatusRepository;

@Service
public class InventoryStatusService {

	private static Logger logger = LoggerFactory.getLogger(InventoryStatusService.class);

/*	@Autowired
	HubRepository hubRepository;*/
	@Autowired
	InventoryStatusRepository iSRepository;
	
	
	public Map<String,Object> getContainersInventoryStatus(Date selectedDate,int regionId,int countryId,int hubId) throws CSafeServiceException {
		logger.info("SERVICE: InventoryStatusService: Entering getContainersInventoryStatus() method");
		Map<String,Object> responseMap = new LinkedHashMap<>();
		List<String> statusList ;
		if(null ==selectedDate){
			selectedDate = new Date();
		}
		try {
			Map<String,Map<String,String>> containerInventoryMap = convertInventoryStatusMap(iSRepository.getInventoryStatus(selectedDate,regionId,countryId,hubId));
			responseMap.put("inventory_details", containerInventoryMap.values());
			statusList = iSRepository.getAllContainerStatus();
			responseMap.put("status_list", statusList);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: InventoryStatusService: Exiting getContainersInventoryStatus() method");
		return responseMap;
	}
	
	private Map<String,Map<String,String>> convertInventoryStatusMap(List<ContainerInventoryStatus> isList){
		Map<String,Map<String,String>> mapData =  new LinkedHashMap<String,Map<String,String>>();
		Map<String, String> rowMap = null;
		for(ContainerInventoryStatus cis:isList){
			if(!mapData.containsKey(cis.getHubCode())){
				rowMap = new LinkedHashMap<>();
				rowMap.put("country", cis.getCountry());
				rowMap.put("city", cis.getCity());
				rowMap.put("hubCode", cis.getHubCode());
				rowMap.put("longitude", String.valueOf(cis.getLongitude()));
				rowMap.put("latitude", String.valueOf(cis.getLatitude()));
				mapData.put(cis.getHubCode(), rowMap);
			}
			rowMap = mapData.get(cis.getHubCode());
			rowMap.put(cis.getStatus(), Long.toString(cis.getContainerCount()));
			mapData.put(cis.getHubCode(), rowMap);
		}
		return mapData;
	}
	
	
	/**
	 * @return
	 * @throws CSafeServiceException
	 */
	public List<Map<String, Object>> getSparesInventoryStatus(int regionId,int countryId,int hubId,String partNumber) throws CSafeServiceException {
		logger.info("SERVICE: InventoryStatusService: Entering getSparesInventoryStatus() method");
		List<Map<String, Object>> responseList;
		try {
			List<SpareInventoryStatus> sisList = iSRepository.getSparesByHubIdAndPartNumber(regionId,countryId, hubId, partNumber);
			responseList = convertToPartNumberMap(sisList);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: InventoryStatusService: Exiting getSparesInventoryStatus() method");
		return responseList;
	}
	
	private List<Map<String, Object>> convertToPartNumberMap(List<SpareInventoryStatus> sisList) {
		
		Map<String, Map<String, Integer>> partNumberMap = new LinkedHashMap<>();
		Map<String, Integer> hubQtyMap = null;
		for (SpareInventoryStatus sis : sisList) {
			if (!partNumberMap.containsKey(sis.getPartNumber())) {
				hubQtyMap = new TreeMap<>();
				hubQtyMap.put(sis.getHub().getHubCode(), sis.getInventoryQty());
				partNumberMap.put(sis.getPartNumber(), hubQtyMap);
			} else {
				hubQtyMap = partNumberMap.get(sis.getPartNumber());
				hubQtyMap.put(sis.getHub().getHubCode(), sis.getInventoryQty());
			}
		}
		
		 List<Map<String, Object>> responseList = new ArrayList<>();
		 partNumberMap.forEach((key, value) -> {
			 Map<String, Object> rowDataMap = new LinkedHashMap<>();
			 rowDataMap.put("partNumber", key);
			 rowDataMap.put("hub_qty", value);
			 responseList.add(rowDataMap);
			});
			 
		return responseList;
	}
	
	
}