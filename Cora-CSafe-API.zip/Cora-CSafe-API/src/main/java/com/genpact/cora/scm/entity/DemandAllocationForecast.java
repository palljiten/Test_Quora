package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.OneToOne;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_DemandAllocationForecast]")
@NamedStoredProcedureQueries({
	   @NamedStoredProcedureQuery(name = "SP_DemandAllocationForecast", 
	                              procedureName = "DemandAllocationForecastSP",
	                              parameters = {
	                                 @StoredProcedureParameter(mode = ParameterMode.IN, name = "InpParam", type = String.class)
	                              })
	})

public class DemandAllocationForecast {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RegionID")
	private Region region;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CountryID")
	private Country country;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "HubID")
	private HubSc hub;

	@Column(name = "CreatedMonth")
	private String createdMonth;

	@Column(name = "MonthYear")
	private String monthYear;

	@Column(name = "SCMYearWeek")
	private Integer sCMYearWeek;

	@Column(name = "Year")
	private Integer year;

	@Column(name ="ParentShipper")
	private String parentShipper;

	@Column(name ="Lane")
	private String lane;

	@Column(name ="FinalWeekly")
	private float finalWeekly;

	@Column(name ="HubProfile")
	private float hubProfile;

	@Column(name ="Flag")
	private int flag;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CreatedDate", nullable = true)
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ModifiedDate", nullable = true)
	private Date modifiedDate;
	
	public DemandAllocationForecast(String parentShipper) {
		this.parentShipper = parentShipper;
	}

	public DemandAllocationForecast(String parentShipper, String lane) {
		super();
		this.parentShipper = parentShipper;
		this.lane = lane;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}

	public String getCreatedMonth() {
		return createdMonth;
	}

	public void setCreatedMonth(String createdMonth) {
		this.createdMonth = createdMonth;
	}

	public String getMonthYear() {
		return monthYear;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	public Integer getsCMYearWeek() {
		return sCMYearWeek;
	}

	public void setsCMYearWeek(Integer sCMYearWeek) {
		this.sCMYearWeek = sCMYearWeek;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public String getParentShipper() {
		return parentShipper;
	}

	public void setParentShipper(String parentShipper) {
		this.parentShipper = parentShipper;
	}

	public String getLane() {
		return lane;
	}

	public void setLane(String lane) {
		this.lane = lane;
	}

	public float getFinalWeekly() {
		return finalWeekly;
	}

	public void setFinalWeekly(float finalWeekly) {
		this.finalWeekly = finalWeekly;
	}

	public float getHubProfile() {
		return hubProfile;
	}

	public void setHubProfile(float hubProfile) {
		this.hubProfile = hubProfile;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
