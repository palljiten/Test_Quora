package com.genpact.cora.scm.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.genpact.cora.scm.validation.MonthNameEnum;

public class SparesStatisticalAdjustmentRequestUnit {

	private int monthValue; // e.g. 0 for January, 1 for February etc.
	private MonthNameEnum month; //e.g. Jan, Feb etc.
	
	@NotNull
	@Min(value = 1900)
	@Max(value = 9999)
	private Integer year; // e.g. 2018
	
	private float value; // forecast value
	
	public int getMonthValue() {
		return monthValue;
	}
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
	public MonthNameEnum getMonth() {
		return month;
	}
	public void setMonth(MonthNameEnum month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public float getValue() {
		return value;
	}
	public void setValue(float value) {
		this.value = value;
	}
}
