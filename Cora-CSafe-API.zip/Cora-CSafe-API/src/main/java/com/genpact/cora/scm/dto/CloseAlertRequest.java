package com.genpact.cora.scm.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class CloseAlertRequest {

	@NotNull
	private Integer hubId;
	
	@NotNull
	@NotBlank
	private String comment;
	
	@NotNull
	@NotBlank
	private String closedBy;
	
	
	public int getHubId() {
		return hubId;
	}
	public void setHubId(int hubId) {
		this.hubId = hubId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getClosedBy() {
		return closedBy;
	}
	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}
}
