package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HotBoardOnClickTable implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String cityName;
	private List<String> metrics = new ArrayList<>();
	private List<String> weeks = new ArrayList<>();
	//private Ma

}
