package com.genpact.cora.scm.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;
import java.lang.annotation.RetentionPolicy;

import javax.validation.Constraint;
import javax.validation.Payload;

@Target({ ElementType.METHOD, ElementType.FIELD, ElementType.ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = ValidParamListValidator.class)
public @interface ValidParamList {
   String message() default "Parameter list is not valid. It should contain six parameters: "
   		+ "Historic, Forecast, Period, Weight, Alpha, Beta";

   Class<?>[] groups() default {};

   Class<? extends Payload>[] payload() default {};
}
