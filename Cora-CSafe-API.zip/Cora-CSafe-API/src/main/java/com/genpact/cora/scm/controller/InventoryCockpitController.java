/**
 * 
 */
package com.genpact.cora.scm.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.ContainerUtilizationDto;
import com.genpact.cora.scm.dto.InventoryContainerDto;
import com.genpact.cora.scm.dto.SupplyCockpitActivityDto;
import com.genpact.cora.scm.dto.SupplyCockpitAlertDto;
import com.genpact.cora.scm.dto.SupplyCockpitConstrainedDto;
import com.genpact.cora.scm.dto.SupplyCockpitStokPolicyDto;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.InventoryCockpitService;

/**
 * @author 703158077
 *
 */
@RestController
@RequestMapping(value="/scm")
@Api("Inventory Management Supply Cockpit")
public class InventoryCockpitController {
	
	public static Logger logger = LoggerFactory.getLogger(InventoryCockpitController.class);
	
	@Autowired
	InventoryCockpitService inventoryCockpitService;
	
	
	@GetMapping(value="/supplyCockpit/activity", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Inventory Management of Supply Cockpit Activity")
	public ResponseEntity<SupplyCockpitActivityDto> getActivity(@RequestParam("activityId") Integer activityId){
		SupplyCockpitActivityDto activityDto;
		try{
			activityDto = inventoryCockpitService.getCockpitActivity(activityId);
		}catch(CSafeServiceException csse){
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> activity API.",
					csse.getCause());
		}
		return new ResponseEntity<SupplyCockpitActivityDto>(activityDto, HttpStatus.OK);
	}
	
	
	@GetMapping(value="/supplyCockpit/stockPolicy", produces =  MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Fetching Inventory Management of Supply Cockpit conformation to stocking policy")
	public ResponseEntity<SupplyCockpitStokPolicyDto> getStokPolicyDetails(@RequestParam("id") Integer id){
		SupplyCockpitStokPolicyDto supplyStokPolicy;
		try{
			supplyStokPolicy = inventoryCockpitService.getStokPolicyDetails(id);
		}catch(CSafeServiceException csse){
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> stocking policy.",
					csse.getCause());
		}
		return new ResponseEntity<SupplyCockpitStokPolicyDto>(supplyStokPolicy, HttpStatus.OK);
		
	}
	
	
	/**
	 * @return
	 */
	@GetMapping(value="/supplyCockpit/inventoryContainer", produces= MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation("")
	public ResponseEntity<InventoryContainerDto> getInventoryContainersDetails(){
		InventoryContainerDto inventoryContainerDto;
		try{
			inventoryContainerDto = inventoryCockpitService.inventoryContainerDetails();
		}catch(CSafeServiceException csse){
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> Inventory container.",
					csse.getCause());
		}
		return new ResponseEntity<InventoryContainerDto>(inventoryContainerDto, HttpStatus.OK);
	}
	
	/**
	 * @return
	 */
	@GetMapping(value="/supplyCockpit/containerUtilizationPercent", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation("")
	public ResponseEntity<ContainerUtilizationDto> getContainerUtilizationPercentage(){
		ContainerUtilizationDto containerUtilizationDto;
		try{
			containerUtilizationDto = inventoryCockpitService.getContainerUtilizationPercentage();
		}catch(CSafeServiceException csse){
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> Container utilization percentage.",
					csse.getCause());
		}
		return new ResponseEntity<ContainerUtilizationDto>(containerUtilizationDto, HttpStatus.OK);
		
	}
	
	
	@GetMapping(value="/supplyCockpit/constrained", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation("")
	public ResponseEntity<SupplyCockpitConstrainedDto> getConstrained(@RequestParam("id") Integer id){
		SupplyCockpitConstrainedDto supplyCockpitConstrainedDto;
		try{
			supplyCockpitConstrainedDto = inventoryCockpitService.getConstrained(id);
		}catch(CSafeServiceException csse){
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> Inventory container.",
					csse.getCause());
		}
		return new ResponseEntity<SupplyCockpitConstrainedDto>(supplyCockpitConstrainedDto, HttpStatus.OK);
		
	}
	
	
	@GetMapping(value="/supplyCockpit/alert", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation("")
	public ResponseEntity<SupplyCockpitAlertDto> getAlert(@RequestParam("id") String id){
		SupplyCockpitAlertDto supplyCockpitAlertDto;
		try{
			supplyCockpitAlertDto = inventoryCockpitService.getAlert(id);
		}catch(CSafeServiceException csse){
			logger.error("Error caught: " + csse.getMessage(), csse);
			throw new CSafeApiException("API error occured during get data for demand cockpit >> Alert.",
					csse.getCause());
		}
		return new ResponseEntity<SupplyCockpitAlertDto>(supplyCockpitAlertDto, HttpStatus.OK);
		
	}
	
}
