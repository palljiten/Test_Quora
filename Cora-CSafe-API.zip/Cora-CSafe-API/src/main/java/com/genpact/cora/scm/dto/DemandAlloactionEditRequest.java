package com.genpact.cora.scm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DemandAlloactionEditRequest {
	
	@JsonProperty("hub")
	private HubDAEdit hub=null;

	public HubDAEdit getHub() {
		return hub;
	}

	public void setHub(HubDAEdit hub) {
		this.hub = hub;
	}
}
