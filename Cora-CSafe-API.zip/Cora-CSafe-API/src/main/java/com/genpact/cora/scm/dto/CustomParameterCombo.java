package com.genpact.cora.scm.dto;

import java.util.List;

public class CustomParameterCombo {
	private int modelId;
	private List<CustomParameter> modelParams;
	private boolean normalForecast = true;
	private boolean baselinePercentageAdjustment = false;
	private Float percentage;

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	public List<CustomParameter> getModelParams() {
		return modelParams;
	}

	public void setModelParams(List<CustomParameter> modelParams) {
		this.modelParams = modelParams;
	}

	public boolean isNormalForecast() {
		return normalForecast;
	}

	public void setNormalForecast(boolean normalForecast) {
		this.normalForecast = normalForecast;
		if (this.normalForecast) {
			this.baselinePercentageAdjustment = false;
		}
	}

	public boolean isBaselinePercentageAdjustment() {
		return baselinePercentageAdjustment;
	}

	public void setBaselinePercentageAdjustment(boolean baselinePercentageAdjustment) {
		this.baselinePercentageAdjustment = baselinePercentageAdjustment;
		if (this.baselinePercentageAdjustment) {
			this.normalForecast = false;
		}
	}

	public Float getPercentage() {
		return percentage;
	}

	public void setPercentage(Float percentage) {
		this.percentage = percentage;
	}
}
