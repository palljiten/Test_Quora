package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;

public class HubDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private int hubID;
	private String hubCode;
	private String hubName;
	private CountryIDName country;
	private RegionIDName region;
	private Set<String> partNumbers = new TreeSet<>();

	public int getHubID() {
		return hubID;
	}

	public void setHubID(int hubID) {
		this.hubID = hubID;
	}

	public String getHubCode() {
		return hubCode;
	}

	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}

	public String getHubName() {
		return hubName;
	}

	public void setHubName(String hubName) {
		this.hubName = hubName;
	}

	public CountryIDName getCountry() {
		return country;
	}

	public void setCountry(CountryIDName country) {
		this.country = country;
	}

	public RegionIDName getRegion() {
		return region;
	}

	public void setRegion(RegionIDName region) {
		this.region = region;
	}

	public Set<String> getPartNumbers() {
		return partNumbers;
	}

	public void setPartNumbers(Set<String> partNumbers) {
		this.partNumbers = partNumbers;
	}
}
