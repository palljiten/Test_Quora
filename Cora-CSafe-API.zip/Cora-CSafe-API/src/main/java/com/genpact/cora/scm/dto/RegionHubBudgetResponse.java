package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class RegionHubBudgetResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Set<String> regionNames = new TreeSet<>();
	private Map<String, HubBudgetResponse> regionHubBudgets = new HashMap<>();
	
	public Set<String> getRegionNames() {
		return regionNames;
	}
	public void setRegionNames(Set<String> regionNames) {
		this.regionNames = regionNames;
	}
	public Map<String, HubBudgetResponse> getRegionHubBudgets() {
		return regionHubBudgets;
	}
	public void setRegionHubBudgets(Map<String, HubBudgetResponse> regionHubBudgets) {
		this.regionHubBudgets = regionHubBudgets;
	}
}
