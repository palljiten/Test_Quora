package com.genpact.cora.scm.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.genpact.cora.scm.validation.ValidParamList;

public class PythonRequestObject {

	/*
	 * {
    "hubId": 1,
    "countryId": COUNTRY_ID,
    "regionId": REGION-ID,
    "partNumber": PART-NUMBER,
    "modelName": MODEL-NAME,
    "modelID": 1,
    "SCID": 1,
	"parameters": [
        {
            "History": 12
        },
        {
            "Forecast": 6
        },
        {
            "Period": -1
        },
        {
            "Weight": -1
        },
        {
            "Alpha": -1
        },
        {
            "Beta": -1
        }
    ]             
}
	 */
	private int hubId;
	private int SCID;
	private int countryId;
	private int regionId;
	private String partNumber;
	private String modelName;
	private int modelID;
	private float mapPercent;
	private float madPercent;
	private float rmsePercent;
	@ValidParamList
	private List<Object> parameters = new ArrayList<>();
	
	public PythonRequestObject() {
		parameters.add(new HashMap<>().put("History", -1));
		parameters.add(new HashMap<>().put("Forecast", -1));
		parameters.add(new HashMap<>().put("Period", -1));
		parameters.add(new HashMap<>().put("Weight", -1));
		parameters.add(new HashMap<>().put("Alpha", -1));
		parameters.add(new HashMap<>().put("Beta", -1));
	}
	
	public int getSCID() {
		return SCID;
	}
	public void setSCID(int sCID) {
		SCID = sCID;
	}
	public int getCountryId() {
		return countryId;
	}
	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}
	public int getRegionId() {
		return regionId;
	}
	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public int getModelID() {
		return modelID;
	}
	public void setModelID(int modelId) {
		this.modelID = modelId;
	}
	public List<Object> getParameters() {
		return parameters;
	}
	public void setParameters(List<Object> parameters) {
		this.parameters = parameters;
	}

	public int getHubId() {
		return hubId;
	}

	public void setHubId(int hubId) {
		this.hubId = hubId;
	}
}
