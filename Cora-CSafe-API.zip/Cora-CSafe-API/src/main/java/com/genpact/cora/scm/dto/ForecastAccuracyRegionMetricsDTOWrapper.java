package com.genpact.cora.scm.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ForecastAccuracyRegionMetricsDTOWrapper {

	private List<String> regionMetaData = new ArrayList<>();
	private String type;
	private Map<String, ForecastAccuracyRegionMetricsDTO> regionMap = new HashMap<>();
	
	public List<String> getRegionMetaData() {
		return regionMetaData;
	}
	public void setRegionMetaData(List<String> regionMetaData) {
		this.regionMetaData = regionMetaData;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Map<String, ForecastAccuracyRegionMetricsDTO> getRegionMap() {
		return regionMap;
	}
	public void setRegionMap(Map<String, ForecastAccuracyRegionMetricsDTO> regionMap) {
		this.regionMap = regionMap;
	}
}
