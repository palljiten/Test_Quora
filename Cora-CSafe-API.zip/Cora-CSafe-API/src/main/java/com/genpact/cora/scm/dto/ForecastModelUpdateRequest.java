package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class ForecastModelUpdateRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@NotNull
	private Float mapPercent;
	
	@NotNull
	private Float madPercent;
	
	@NotNull
	private Float rmsePercent;
	
	@Valid
	@NotNull
	@NotEmpty
	private List<SparesStatisticalAdjustmentRequestUnit> monthValues;
	
	@Valid
	@NotNull
	@NotEmpty
	private List<ModelParam> modelParams;
	
	public float getMapPercent() {
		return mapPercent;
	}
	
	public void setMapPercent(float mapPercent) {
		this.mapPercent = mapPercent;
	}
	
	public float getMadPercent() {
		return madPercent;
	}
	
	public void setMadPercent(float madPercent) {
		this.madPercent = madPercent;
	}
	
	public float getRmsePercent() {
		return rmsePercent;
	}
	
	public void setRmsePercent(float rmsePercent) {
		this.rmsePercent = rmsePercent;
	}
	
	public List<SparesStatisticalAdjustmentRequestUnit> getMonthValues() {
		return monthValues;
	}
	
	public void setMonthValues(List<SparesStatisticalAdjustmentRequestUnit> monthValues) {
		this.monthValues = monthValues;
	}
	
	public List<ModelParam> getModelParams() {
		return modelParams;
	}
	
	public void setModelParams(List<ModelParam> modelParams) {
		this.modelParams = modelParams;
	}
}
