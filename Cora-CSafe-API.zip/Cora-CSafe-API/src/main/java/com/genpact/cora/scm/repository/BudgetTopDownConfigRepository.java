package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.genpact.cora.scm.entity.BudgetTopDownConfig;

public interface BudgetTopDownConfigRepository  extends JpaRepository<BudgetTopDownConfig, Integer>{


}
