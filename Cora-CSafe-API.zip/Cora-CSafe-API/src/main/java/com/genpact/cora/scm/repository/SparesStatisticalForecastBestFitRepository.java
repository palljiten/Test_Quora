package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.SparesStatisticalForecastBestFit;

public interface SparesStatisticalForecastBestFitRepository extends JpaRepository<SparesStatisticalForecastBestFit, Integer>{
	
	@Query("SELECT f FROM SparesStatisticalForecastBestFit f "
			+ "WHERE f.hub.hubId = :hubId AND f.country.countryId = :countryId "
			+ "AND f.region.regionId = :regionId AND f.partId = :partId")
	public List<SparesStatisticalForecastBestFit> getBestFitModel(@Param("regionId") int regionId, @Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId);
}
