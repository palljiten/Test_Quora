package com.genpact.cora.scm.logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.ApplicationLogDto;
import com.genpact.cora.scm.entity.ApplicationLog;
import com.genpact.cora.scm.repository.ApplicationLogRepository;

/**
 * To log request, response and exception details in logs.
 * @author nirmal kamila
 *
 */
@Service
public class ApplicationLoggerImpl implements ApplicationLogger {
	
	/**
	 * Application repository instance
	 */
	@Autowired
	private ApplicationLogRepository appLogRepo;

	
	/**
	 * Will log request, response and exception
	 *  details in Application logger table.
	 */
	
	@Override
	public void log(ApplicationLogDto applicationLogDto ) {
		ApplicationLog applicationLogEntity = new ApplicationLog();
		applicationLogEntity.setModuleName(applicationLogDto.getModuleName());
		applicationLogEntity.setRequestBody(applicationLogDto.getRequestBody());
		applicationLogEntity.setRequestMethod(applicationLogDto.getRequestMethod());
		applicationLogEntity.setRequestUrl(applicationLogDto.getRequestUrl());
		applicationLogEntity.setResponseBody(applicationLogDto.getResponseBody());
		applicationLogEntity.setResponseCode(applicationLogDto.getResponseCode());
		applicationLogEntity.setUsername(applicationLogDto.getUsername());
		applicationLogEntity.setUiid(applicationLogDto.getUuid());
		appLogRepo.save(applicationLogEntity);
		
	}

}
