package com.genpact.cora.scm.dto;

import java.util.List;

public class PythonUpdatedForecastModelUpdateRequest {

	private int hubId;
	private int countryId;
	private int regionId;
	private String partNumber;
	private int modelId;
	
	private float mapePercent;
	private float madPercent;
	private float rmsePercent;
	private boolean isConfigured;
	List<ModelParam> parameters;
	private List<MonthDataUnit> monthData;
	
	private boolean normalForecast;
	private boolean baselinePercentageAdjustment;
	private float percentage;

	public int getHubId() {
		return hubId;
	}

	public void setHubId(int hubId) {
		this.hubId = hubId;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public int getRegionId() {
		return regionId;
	}

	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelID) {
		this.modelId = modelID;
	}

	public float getMapePercent() {
		return mapePercent;
	}

	public void setMapePercent(float mapPercent) {
		this.mapePercent = mapPercent;
	}

	public float getMadPercent() {
		return madPercent;
	}

	public void setMadPercent(float madPercent) {
		this.madPercent = madPercent;
	}

	public float getRmsePercent() {
		return rmsePercent;
	}

	public void setRmsePercent(float rmsePercent) {
		this.rmsePercent = rmsePercent;
	}

	public List<ModelParam> getParameters() {
		return parameters;
	}

	public void setParameters(List<ModelParam> parameters) {
		this.parameters = parameters;
	}

	public List<MonthDataUnit> getMonthData() {
		return monthData;
	}

	public void setMonthData(List<MonthDataUnit> monthData) {
		this.monthData = monthData;
	}

	public boolean isConfigured() {
		return isConfigured;
	}

	public void setConfigured(boolean isConfigured) {
		this.isConfigured = isConfigured;
	}

	public boolean isNormalForecast() {
		return normalForecast;
	}

	public void setNormalForecast(boolean normalForecast) {
		this.normalForecast = normalForecast;
	}

	public boolean isBaselinePercentageAdjustment() {
		return baselinePercentageAdjustment;
	}

	public void setBaselinePercentageAdjustment(boolean baselinePercentageAdjustment) {
		this.baselinePercentageAdjustment = baselinePercentageAdjustment;
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

}
