package com.genpact.cora.scm.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidMonthYearValidator implements
ConstraintValidator<ValidMonthYear, String> {

  @Override
  public void initialize(ValidMonthYear monthYearField) {
  }

  @Override
  public boolean isValid(String monthYearField,
    ConstraintValidatorContext cxt) {
      return monthYearField != null && monthYearField.matches("^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\-\\d{4}$");
  }

}