package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author 703158077
 *
 */
public class HubLavelPercentage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543211L;
	Integer regionId =0; 
	String regionName =""; 
	String budgetPercentage="";
	
	
	/**
	 * @return the regionId
	 */
	public Integer getRegionId() {
		return regionId;
	}
	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the budgetPercentage
	 */
	public String getBudgetPercentage() {
		return budgetPercentage;
	}
	/**
	 * @param budgetPercentage the budgetPercentage to set
	 */
	public void setBudgetPercentage(String budgetPercentage) {
		this.budgetPercentage = budgetPercentage;
	}
	
	
	
	

}
