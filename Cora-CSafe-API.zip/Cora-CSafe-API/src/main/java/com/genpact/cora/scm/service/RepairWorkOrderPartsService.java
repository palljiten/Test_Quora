package com.genpact.cora.scm.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.HubDetails;
import com.genpact.cora.scm.entity.RepairWorkOrderParts;
import com.genpact.cora.scm.repository.RepairWorkOrderPartsRepository;

@Service
public class RepairWorkOrderPartsService {

	private static Logger logger = LoggerFactory.getLogger(RepairWorkOrderPartsService.class);
	
	@Autowired
	RepairWorkOrderPartsRepository partsRepository;
	
	public List<RepairWorkOrderParts> getAllPartNumbers(Map<String, HubDetails> scMap) {
		List<RepairWorkOrderParts> parts = partsRepository.findParts();
		
		for (RepairWorkOrderParts part : parts) {
			
			HubDetails hub = scMap.get(part.getSc());
			if (hub != null) {
				if (part.getPartNumber() != null) {
					hub.getPartNumbers().add(part.getPartNumber());
				}
			}
		}
		
		return parts;
	}
	
	public int findQtyofPart(String partNumber){
		
		RepairWorkOrderParts rwp = new RepairWorkOrderParts(); //partsRepository.findQuatity(partNumber);
		int returnVal = rwp.getQuantity();
		System.out.println("findQtyofPart QTY:: "+returnVal);
		return returnVal;
	}
	
	
}
