package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_SparesStatisticalForecastConfig]")
public class SparesStatisticalForecastConfig {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
	private int id;	
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ModelID")
	private StatisticalModel configuredModel;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RegionID")
	private Region region;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CountryID")
	private Country country;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "HubID")
	private HubSc hub;
	
	@Column(name = "PartID")
	private String partId;
	
    @Column(name = "CreatedMonth", nullable = true)
    private String createdMonth;

	@Column(name = "Flag")
	private Integer flag;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public StatisticalModel getConfiguredModel() {
		return configuredModel;
	}

	public void setConfiguredModel(StatisticalModel configuredModel) {
		this.configuredModel = configuredModel;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}

	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId;
	}

	public String getCreatedMonth() {
		return createdMonth;
	}

	public void setCreatedMonth(String createdMonth) {
		this.createdMonth = createdMonth;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}
}
