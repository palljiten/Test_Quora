package com.genpact.cora.scm.dto;

import io.swagger.annotations.ApiModel;

@ApiModel
public class WeekMetaData {

	private int weekNum;

	private String weekStartDate;

	public int getWeekNum() {
		return weekNum;
	}

	public void setWeekNum(int weekNum) {
		this.weekNum = weekNum;
	}

	public String getWeekStartDate() {
		return weekStartDate;
	}

	public void setWeekStartDate(String weekStartDate) {
		this.weekStartDate = weekStartDate;
	}
}
