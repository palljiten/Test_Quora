package com.genpact.cora.scm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.repository.CountryRepository;

@Service
public class CountryService {

	@Autowired
	CountryRepository countryRepository;
	
	public List<Country> getAllCountries() {
		return countryRepository.findAll();
	}
}
