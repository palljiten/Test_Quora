package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.entity.BPBasedForeCast;

@Repository
public interface ContainerForecastRepository extends JpaRepository<BPBasedForeCast, Integer> {

	@Query(value = "select count(SerialNumber) as serialNumber from "
			+ " tbl_Lease tl WHERE  DATEPART(month, OrderDate)= :month and DATEPART(year, OrderDate)=:year and "
			+ "  tl.PossStartHubSC= :hubId group by  DATEPART(month,tl.OrderDate),DATEPART(year, tl.OrderDate)", nativeQuery = true)
	public Integer getBaselineDemand(@Param("hubId") String hubId, @Param("month") int month, @Param("year")int year);

	@Query(value = "select monthyear ,sum(bbf.[Value]) value,bbf.[RegionID],reg.[RegionName]\n" + 
			"				from [dbo].[tbl_BudgetBasedForecast] bbf inner join [dbo].[tbl_master_Region] reg on bbf.[RegionID] = reg.[RegionID]" + 
			"				WHERE (MONTH(GETDATE()) < DATEADD(mm, :months, GETDATE())) and flag='1' and bbf.[RegionID]=:RegionID\n" + 
			"				 group by bbf.[RegionID] ,monthyear ,reg.[RegionName]", nativeQuery = true)
	public List<Object[]> getForecastRegionData(@Param("RegionID")int regionId,@Param("months") int months);
	
	@Query(value = "select monthyear ,(bbf.[Value]) value,bbf.[HubID],hs.[Code]\n" + 
			"				from [dbo].[tbl_BudgetBasedForecast] bbf  inner join [dbo].[tbl_master_HUBSC] hs on bbf.[HubID] = hs.[HubID]" + 
			"				WHERE (MONTH(GETDATE()) < DATEADD(mm, :months, GETDATE())) and flag='1' and bbf.[HubID]=:hubId", nativeQuery = true)
	public List<Object[]> getForecastHubData(@Param("hubId")int hubId,@Param("months") int months);
	
	/*@Query(value="SELECT DISTINCT TOP(6) mc.MONTHYEAR as my,year as y , datepart(M,DATE) as month,MonthName as mName FROM [dbo].[tbl_master_Calendar] mc" + 
			",[dbo].[tbl_ForecastRunDate] fd" + 
			" WHERE  DATE>GETDATE() and mc.[Date] >fd.[StartDate] and mc.[Date] <fd.[EndDate]", nativeQuery=true)*/
	@Query(value="select distinct top(6)  DATEPART(year,Date) as year,DATEPART(mm,Date) as month" + 
			",monthname from tbl_master_Calendar where (getdate() < DATEADD(mm,6,date) and Date > getdate()) " + 
			"order by  DATEPART(year,Date), DATEPART(mm,Date) asc", nativeQuery=true)
	public List<Object[]> getNextMonth(@Param("months")int months);

	@Query(value="SELECT value from tbl_BudgetBasedForecast where HubId=:hubId and countryId=:countryId and regionId=:regionId and MonthYear=:monthYear and flag='1'",nativeQuery=true)
	public Long getForecastDataHubLevel(@Param("regionId")int regionId,@Param("countryId")int countryId,@Param("hubId")int hubId,@Param("monthYear") String monthYear);
	
	@Query(value="SELECT sum(value) from tbl_BudgetBasedForecast where CountryID=:countryId and MonthYear=:monthYear  and flag='1' group by CountryID",nativeQuery=true)
	public Long getForecastDataCountryLevel(@Param("countryId")int countryId,@Param("monthYear") String monthYear);

	@Query(value="SELECT sum(value) from tbl_BudgetBasedForecast where RegionID=:RegionID and MonthYear=:monthYear and flag='1' group by RegionID", nativeQuery=true)
	public Long getForecastDataRegionLevel(@Param("RegionID")int regionId,@Param("monthYear") String monthYear);

	@Query(value="select distinct top(:months)  DATEPART(year,c.Date) as year,DATEPART(month,c.Date) as month, MonthName as mName "
			+ " from tbl_master_Calendar c where Date > DATEADD(month,-:months, GETDATE()) "
			+ " and Date < GETDATE() order by  DATEPART(year,Date),DATEPART(month,Date) asc", nativeQuery=true)
	public List<Object[]> getPrivoustMonth(@Param("months")int months);
	
	////////
	
	@Query(value="SELECT value from tbl_BudgetBasedForecast where HubId=:hubId and countryId=:countryId and regionId=:regionId and MonthYear=:monthYear and flag='1'",nativeQuery=true)
	public Long getForecastDataHubLevelData(@Param("regionId")int regionId,@Param("countryId")int countryId,@Param("hubId")int hubId,@Param("monthYear") String monthYear);
	
	@Query(value="SELECT sum(value) from tbl_BudgetBasedForecast where RegionID=:RegionID and MonthYear=:monthYear and flag='1' group by RegionID", nativeQuery=true)
	public Long getForecastDataRegionLevelData(@Param("RegionID")int regionId,@Param("monthYear") String monthYear);

}
