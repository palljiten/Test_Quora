/**
 * 
 */
package com.genpact.cora.scm.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.genpact.cora.scm.dto.ContainerInventoryStatus;
import com.genpact.cora.scm.dto.HotBoard;
import com.genpact.cora.scm.entity.InventoryStatus;
import com.genpact.cora.scm.entity.SpareInventoryStatus;



/**
 * @author 703158077
 *
 */
@Repository
public class InventoryStatusRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	

	public List<ContainerInventoryStatus> getInventoryStatus(@Param("inputDate") Date inputDate, @Param("regionId") int regionId,
								@Param("countryId") int countryId, @Param("hubId") int hubId){
		String extendedWhere = "";
		extendedWhere += (regionId != -1) ? " and ist.hubSc.region.regionId="+regionId : "";
		extendedWhere += (countryId != -1) ? " and ist.hubSc.country.countryId="+countryId : "";
		extendedWhere += (hubId != -1) ? " and ist.hubSc.hubId="+hubId : "";
		String hql = "select new com.genpact.cora.scm.dto.ContainerInventoryStatus( ist.hubSc.hubCode, ist.hubSc.city, ist.hubSc.country.countryName, "
				+ "ist.status, sum(ist.containerCount)as containerCount, ist.hubSc.longitude, ist.hubSc.latitude) "
				+ "from InventoryStatus ist where ist.inputDate = :inputDate "+ extendedWhere 
				+" group by ist.hubSc.hubCode,ist.hubSc.city, ist.status, ist.hubSc.longitude, ist.hubSc.latitude,ist.hubSc.country.countryName";
		
		Query query = entityManager.createQuery(hql);
		query.setParameter("inputDate", inputDate);
		return query.getResultList();
	}
	
	public List<String> getAllContainerStatus(){
		Query query = entityManager.createNativeQuery("select status from tbl_master_IMInventoryStatusList");
		return query.getResultList();
	}

	public List<SpareInventoryStatus> getSparesByHubIdAndPartNumber( @Param("regionId") int regionId, @Param("countryId") int countryId, 
								@Param("hubId") int hubId, @Param("partNumber") String partNumber){
		String extendedWhere = "";
		extendedWhere += (regionId != -1) ? " and sis.region.regionId="+regionId : "";
		extendedWhere += (countryId != -1) ? " and sis.hub.country.countryId="+countryId : "";
		extendedWhere += (hubId != -1) ? " and sis.hub.hubId="+hubId+" " : "";
		extendedWhere += (!partNumber.equalsIgnoreCase("all")) ? " and sis.partNumber='"+partNumber+"'" : "";
		
		String hql = "SELECT sis FROM SpareInventoryStatus sis WHERE 1=1 "+extendedWhere;
		
		Query query = entityManager.createQuery(hql);
		return query.getResultList();
	}

}
