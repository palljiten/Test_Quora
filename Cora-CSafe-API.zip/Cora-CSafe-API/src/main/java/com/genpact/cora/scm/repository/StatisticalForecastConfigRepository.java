package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.TempConfigModel;
import com.genpact.cora.scm.entity.StatisticalForecastConfig;

public interface StatisticalForecastConfigRepository extends JpaRepository<StatisticalForecastConfig, Integer>{
	
	@Query("SELECT f FROM StatisticalForecastConfig f "
			+ "WHERE f.hub.hubId = :hubId AND f.country.countryId = :countryId "
			+ "AND f.region.regionId = :regionId AND f.flag = 1")
	public List<StatisticalForecastConfig> getConfiguredModel(@Param("regionId") int regionId, @Param("countryId") int countryId, @Param("hubId") int hubId);


	/*SELECT m.ModelId, c.ModelID as ConfigModelID, c.MonthYear 
	FROM tbl_master_statisticalModel as m LEFT OUTER JOIN [tbl_StatisticalForecastConfig] as c
	ON m.ModelID = c.ModelID
	WHERE c.MonthYear IN ('Nov-2018', 'Dec-2018', 'Jan-2019', 'Feb-2019', 'Mar-2019', 'Apr-2019')
	AND c.RegionID = 2 AND c.CountryID = 13 AND c.HubID = 14 AND Flag = 1*/
	
	
	@Query("SELECT new com.genpact.cora.scm.dto.TempConfigModel(m.modelId, c.configuredModel.modelId) FROM StatisticalModel m, StatisticalForecastConfig c "
			+ "WHERE m.modelId = c.configuredModel.modelId "
			+ "AND c.region.regionId = :regionId AND c.country.countryId = :countryId "
			+ "AND c.hub.hubId = :hubId AND c.flag = 1")
	public List<TempConfigModel> getTempConfigModels(@Param("regionId") int regionId, @Param("countryId") int countryId, 
			@Param("hubId") int hubId);
	
	@Modifying
    @Query("UPDATE StatisticalForecastConfig sp SET sp.flag = 0 "
    		+ "WHERE sp.flag=1 AND sp.hub.hubId = :hubId AND sp.country.countryId = :countryId "
    		+ "AND sp.region.regionId = :regionId AND sp.configuredModel.modelId = :modelId")
    int updateStatisticalForecastConfigModel(@Param("modelId") int modelId, @Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId);
	
}
