package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "[dbo].[tbl_VASpareParts]")
public class SpareParts {

	

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
	private int id;

	@Column(name = "partNumber", nullable = true)
	String partNumber;
	@Column(name = "Description", nullable = true)
	String partDesc;
	@Column(name = "MaximumStockLevel", nullable = true)
	Integer maxInvLevel;
	@Column(name = "ReorderLevel", nullable = true)
	Integer minInvLevel;
	@Column(name = "ROP", nullable = true)
	Integer rop;
	@Column(name = "Quantity", nullable = true)
	Integer consumedQty;
	@Column(name = "ActualQty", nullable = true)
	Integer actualQty;
	@Column(name = "AlertType", nullable = true)
	String alertDesc;

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getPartDesc() {
		return partDesc;
	}

	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}

	public Integer getMaxInvLevel() {
		return maxInvLevel;
	}

	public void setMaxInvLevel(Integer maxInvLevel) {
		this.maxInvLevel = maxInvLevel;
	}

	public Integer getMinInvLevel() {
		return minInvLevel;
	}

	public void setMinInvLevel(Integer minInvLevel) {
		this.minInvLevel = minInvLevel;
	}

	public Integer getRop() {
		return rop;
	}

	public void setRop(Integer rop) {
		this.rop = rop;
	}

	public Integer getConsumedQty() {
		return consumedQty;
	}

	public void setConsumedQty(Integer consumedQty) {
		this.consumedQty = consumedQty;
	}

	public Integer getActualQty() {
		return actualQty;
	}

	public void setActualQty(Integer actualQty) {
		this.actualQty = actualQty;
	}

	public String getAlertDesc() {
		return alertDesc;
	}

	public void setAlertDesc(String alertDesc) {
		this.alertDesc = alertDesc;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
