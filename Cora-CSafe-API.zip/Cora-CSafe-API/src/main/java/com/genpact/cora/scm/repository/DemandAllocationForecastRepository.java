package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.NamedStoredProcedureQuery;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.genpact.cora.scm.entity.DemandAllocationForecast;

@Repository
@EnableTransactionManagement
public interface DemandAllocationForecastRepository extends CrudRepository<DemandAllocationForecast, Integer> {

	@Query("Select distinct new DemandAllocationForecast( b.parentShipper) from DemandAllocationForecast b where "
			+ "b.region.regionId = :regionId and b.country.countryId = :countryId AND b.hub.hubId = :hubId AND b.parentShipper IS NOT NULL")
	List<DemandAllocationForecast> getParentShippers(@Param("regionId") Integer regionID,
			@Param("countryId") Integer countryID, @Param("hubId") Integer hubID);

	@Query(value="select distinct top(:weeks) fc.HubProfile as value,c.WeekstartDate as wsd, c.SCMYearWeek as weekNum from "
			+ " tbl_master_Calendar c left outer join  tbl_DemandAllocationForecast fc on  c.SCMYearWeek=fc.SCMYearWeek   "
			+ " and fc.RegionID=:regionId and fc.CountryID=:countryId and fc.HubID=:hubId and"
			+ "  fc.Flag=1 and 	fc.ParentShipper=:parentShipper and fc.Lane='' where :startWeekOfMonth < DATEADD(wk,:weeks, :startWeekOfMonth) and "
			+ " Date > :startWeekOfMonth  order by c.WeekstartDate asc", nativeQuery = true) 
	List<Object[]> getParentShippersValue(@Param("regionId") Integer regionID, @Param("countryId") Integer countryID,
			@Param("hubId") Integer hubID, @Param("parentShipper") String parentShipper, @Param("weeks") Integer weeks,
			@Param("startWeekOfMonth") String startWeekOfMonth);


	@Query("Select distinct new DemandAllocationForecast(b.parentShipper,b.lane) from DemandAllocationForecast b where "
			+ " b.region.regionId = :regionId and b.country.countryId = :countryId AND b.hub.hubId = :hubId and"
			+ " b.parentShipper=:parentShipper and b.lane!=''")
	List<DemandAllocationForecast> getLanes(@Param("regionId") Integer regionID, @Param("countryId") Integer countryID,
			@Param("hubId") Integer hubID, @Param("parentShipper") String parentShipper);


	@Query(value="select distinct top(:weeks) fc.HubProfile as value,c.WeekstartDate as wsd, c.SCMYearWeek as weekNum from "
			+ " tbl_master_Calendar c left outer join  tbl_DemandAllocationForecast fc on  c.SCMYearWeek=fc.SCMYearWeek  "
			+ " and fc.RegionID=:regionId and fc.CountryID=:countryId and fc.HubID=:hubId and"
			+ " fc.Flag=1 and 	fc.ParentShipper=:parentShipper and  fc.Lane=:lane where :startWeekOfMonth < DATEADD(wk,:weeks, :startWeekOfMonth) and "
			+ " Date > :startWeekOfMonth  order by c.WeekstartDate asc", nativeQuery = true) 
	List<Object[]> getLanesValue(@Param("regionId") Integer regionID, @Param("countryId") Integer countryID,
			@Param("hubId") Integer hubID, @Param("parentShipper") String parentShipper,
			@Param("lane")String lane, @Param("weeks") Integer weeks,
			@Param("startWeekOfMonth") String startWeekOfMonth);

/*	@Procedure(name="DemandAllocationForecastSP")
	void DemandAllocationForecastSP(String InpParam);*/
	
	@Query(value="{call DemandAllocationForecastSP (:@InpParam)}", nativeQuery=true)
	void DemandAllocationForecastSP(@Param("@InpParam")String InpParam);
}
