package com.genpact.cora.scm.dto;

public class InventoryContainerDto {

	
	private Integer numberOfContainer;
	private Integer excessInventory;
	private Integer repair;
	private Integer utilized;
	
	
	
	/**
	 * @return the numberOfContainer
	 */
	public Integer getNumberOfContainer() {
		return numberOfContainer;
	}
	/**
	 * @param numberOfContainer the numberOfContainer to set
	 */
	public void setNumberOfContainer(Integer numberOfContainer) {
		this.numberOfContainer = numberOfContainer;
	}
	/**
	 * @return the excessInventory
	 */
	public Integer getExcessInventory() {
		return excessInventory;
	}
	/**
	 * @param excessInventory the excessInventory to set
	 */
	public void setExcessInventory(Integer excessInventory) {
		this.excessInventory = excessInventory;
	}
	/**
	 * @return the repair
	 */
	public Integer getRepair() {
		return repair;
	}
	/**
	 * @param repair the repair to set
	 */
	public void setRepair(Integer repair) {
		this.repair = repair;
	}
	/**
	 * @return the utilized
	 */
	public Integer getUtilized() {
		return utilized;
	}
	/**
	 * @param utilized the utilized to set
	 */
	public void setUtilized(Integer utilized) {
		this.utilized = utilized;
	}
	
	
	
	
	
}
