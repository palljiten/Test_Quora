package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_VARepair]")
public class VARepair {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
	private int id;
	
	@Column(name = "ContainerID")
	private Long containeerId;
	
	@Column(name ="SerialNumber")
	private String serialNumber;
	
	@Column(name ="Tname")
	private String tName;
	
	
	@Column(name ="Status")
	private String status;
	
	@Column(name ="Origin")
	private String origin;
	
	@Column(name = "ContainerLocation")
	private String containerLocation;
	
	@Column(name ="ActualReceivingdate")
	private Date actualReceivingDate;
	
	@Column(name = "ArrivalDate")
	private Date arrivalDate;
	
	@Column(name ="DueDate")
	private Date dueDate;
	
	@Column(name ="Notificationdate")
	private Date notificationDate;
	
	@Column(name ="EstimatedReceivingDate")
	private Date estimatedReceivingDate;
	
	@Column(name ="AlertType")
	private String alertType;
	
	@Column(name = "WorkOrderID")
	private Integer workOrderId;
	
	@Column(name ="WODate")
	private Date woDate;
	
	@Column(name ="PartNumber")
	private String partNumber;
	
	@Column(name ="Description")
	private String description;
	
	@Column(name ="CurrentlyInStock")
	private Boolean currentlyInStock;
	
	@Column(name ="AlertDescription")
	private String alertDescription;
	
	@Column(name = "WeekNo")
	private String weekNo;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Long getContaineerId() {
		return containeerId;
	}

	public void setContaineerId(Long containeerId) {
		this.containeerId = containeerId;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String gettName() {
		return tName;
	}

	public void settName(String tName) {
		this.tName = tName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getContainerLocation() {
		return containerLocation;
	}

	public void setContainerLocation(String containerLocation) {
		this.containerLocation = containerLocation;
	}

	public Date getActualReceivingDate() {
		return actualReceivingDate;
	}

	public void setActualReceivingDate(Date actualReceivingDate) {
		this.actualReceivingDate = actualReceivingDate;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}

	public Date getEstimatedReceivingDate() {
		return estimatedReceivingDate;
	}

	public void setEstimatedReceivingDate(Date estimatedReceivingDate) {
		this.estimatedReceivingDate = estimatedReceivingDate;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public Integer getWorkOrderId() {
		return workOrderId;
	}

	public void setWorkOrderId(Integer workOrderId) {
		this.workOrderId = workOrderId;
	}

	public Date getWoDate() {
		return woDate;
	}

	public void setWoDate(Date woDate) {
		this.woDate = woDate;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getCurrentlyInStock() {
		return currentlyInStock;
	}

	public void setCurrentlyInStock(Boolean currentlyInStock) {
		this.currentlyInStock = currentlyInStock;
	}

	public String getAlertDescription() {
		return alertDescription;
	}

	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}

	public String getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}
	

	
	
	
	
	

}
