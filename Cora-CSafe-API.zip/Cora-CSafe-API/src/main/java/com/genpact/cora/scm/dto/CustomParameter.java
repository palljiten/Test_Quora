package com.genpact.cora.scm.dto;

public class CustomParameter {

	private int paramId;
	private String paramName;
	private float paramValue;

	public CustomParameter() {}
	
	public CustomParameter(int paramId, String paramName, float paramValue) {
		this.paramId = paramId;
		this.paramName = paramName;
		this.paramValue = paramValue;
	}
	
	public int getParamId() {
		return paramId;
	}

	public void setParamId(int paramId) {
		this.paramId = paramId;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public float getParamValue() {
		return paramValue;
	}

	public void setParamValue(float paramValue) {
		this.paramValue = paramValue;
	}
}
