package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.SparesStatisticalForecast;
import com.genpact.cora.scm.entity.StatisticalForecast;

public interface StatisticalForecastRepository extends JpaRepository<StatisticalForecast, Integer>{
	
	@Query("SELECT forecastValue as foreCastValue, forecastMonth as year "
			+ "FROM StatisticalForecast WHERE (MONTH(GETDATE()) < DATEADD(mm, 6, GETDATE()) "
			+ " and flag='1' and country.countryId=:countryId "
			+ " and hubsc.hubId=:hubId and region.regionId=:regionId)")
	public List<Object[]> findStatisticalForecast(@Param("countryId") int countryId,@Param("hubId") int hubId,@Param("regionId") int regionId);
	
	@Query("SELECT f FROM StatisticalForecast f "
			+ "WHERE (MONTH(GETDATE()) < DATEADD(mm, :months, GETDATE()) AND flag=1 "
			+ "AND f.hubsc.hubId = :hubId AND f.country.countryId = :countryId "
			+ "AND f.region.regionId = :regionId AND f.model.modelId = :modelId)")
	public List<StatisticalForecast> getStatisticalForecast(@Param("regionId") int regionId, 
			@Param("countryId") int countryId, @Param("hubId") int hubId,
			@Param("modelId") int modelId, @Param("months") int months);
	
	
	@Modifying
    @Query("UPDATE StatisticalForecast sp SET sp.flag = 0 "
    		+ "WHERE sp.flag=1 AND sp.hubsc.hubId = :hubId AND sp.country.countryId = :countryId "
    		+ "AND sp.region.regionId = :regionId AND sp.model.modelId = :modelId")
    int updateModel(@Param("modelId") int modelId, @Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId);
}