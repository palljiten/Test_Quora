package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.TempBestFitModel;
import com.genpact.cora.scm.entity.StatisticalForecastBestFit;

public interface StatisticalForecastBestFitRepository extends JpaRepository<StatisticalForecastBestFit, Integer> {
	
	@Query("SELECT f FROM StatisticalForecastBestFit f "
			+ "WHERE f.hub.hubId = :hubId AND f.country.countryId = :countryId "
			+ "AND f.region.regionId = :regionId")
	public List<StatisticalForecastBestFit> getBestFitModel(@Param("regionId") int regionId, @Param("countryId") int countryId, @Param("hubId") int hubId);

	/*SELECT m.ModelId, b.ModelID as ConfigModelID, b.MonthYear 
FROM tbl_master_statisticalModel as m LEFT OUTER JOIN [tbl_StatisticalForecastBestFit] as b
ON m.ModelID = b.ModelID
WHERE b.MonthYear IN ('Nov-2018', 'Dec-2018', 'Jan-2019', 'Feb-2019', 'Mar-2019', 'Apr-2019')
AND b.RegionID = 2 AND b.CountryID = 13 AND b.HubID = 14 AND FLAG = 1*/
	
	
	@Query("SELECT new com.genpact.cora.scm.dto.TempBestFitModel(m.modelId, b.bestFitModel.modelId) FROM StatisticalModel m, StatisticalForecastBestFit b "
			+ "WHERE m.modelId = b.bestFitModel.modelId "
			+ "AND b.region.regionId = :regionId AND b.country.countryId = :countryId "
			+ "AND b.hub.hubId = :hubId AND b.flag = 1")
	public List<TempBestFitModel> getTempBestfitModels(@Param("regionId") int regionId, @Param("countryId") int countryId, 
			@Param("hubId") int hubId);
}
