package com.genpact.cora.scm.dto;

public class DemandCockpitExceptionsAlerts {

	private String hubCode;
	private int hubId;
	private int underConsumedForecast20;
	private int overConsumedForecast20;
	private int mtdWarning;
	private int monthConsumptionWarning3;
	private int monthConsumptionWarning4;
	private int earlyWarningSignal;
	private int past3MonthsFacLess60;
	private int ytdAvgSaleVsAvgForecast;
	private int zeroActualsButForecasted;
	
	public String getHubCode() {
		return hubCode;
	}
	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}
	public int getHubId() {
		return hubId;
	}
	public void setHubId(int hubId) {
		this.hubId = hubId;
	}
	public int getUnderConsumedForecast20() {
		return underConsumedForecast20;
	}
	public void setUnderConsumedForecast20(int underConsumedForecast20) {
		this.underConsumedForecast20 = underConsumedForecast20;
	}
	public int getOverConsumedForecast20() {
		return overConsumedForecast20;
	}
	public void setOverConsumedForecast20(int overConsumedForecast20) {
		this.overConsumedForecast20 = overConsumedForecast20;
	}
	public int getMtdWarning() {
		return mtdWarning;
	}
	public void setMtdWarning(int mtdWarning) {
		this.mtdWarning = mtdWarning;
	}
	public int getMonthConsumptionWarning3() {
		return monthConsumptionWarning3;
	}
	public void setMonthConsumptionWarning3(int monthConsumptionWarning3) {
		this.monthConsumptionWarning3 = monthConsumptionWarning3;
	}
	public int getMonthConsumptionWarning4() {
		return monthConsumptionWarning4;
	}
	public void setMonthConsumptionWarning4(int monthConsumptionWarning4) {
		this.monthConsumptionWarning4 = monthConsumptionWarning4;
	}
	public int getEarlyWarningSignal() {
		return earlyWarningSignal;
	}
	public void setEarlyWarningSignal(int earlyWarningSignal) {
		this.earlyWarningSignal = earlyWarningSignal;
	}
	public int getPast3MonthsFacLess60() {
		return past3MonthsFacLess60;
	}
	public void setPast3MonthsFacLess60(int past3MonthsFacLess60) {
		this.past3MonthsFacLess60 = past3MonthsFacLess60;
	}
	public int getYtdAvgSaleVsAvgForecast() {
		return ytdAvgSaleVsAvgForecast;
	}
	public void setYtdAvgSaleVsAvgForecast(int ytdAvgSaleVsAvgForecast) {
		this.ytdAvgSaleVsAvgForecast = ytdAvgSaleVsAvgForecast;
	}
	public int getZeroActualsButForecasted() {
		return zeroActualsButForecasted;
	}
	public void setZeroActualsButForecasted(int zeroActualsButForecasted) {
		this.zeroActualsButForecasted = zeroActualsButForecasted;
	}
}
