package com.genpact.cora.scm.validation;

import java.util.Arrays;

public enum ContainerSparesTypeEnum {
	
	Container("Container"), Spares("Spares");
	private String value;

	private ContainerSparesTypeEnum(String value) {
		this.value = value;
	}

	public static ContainerSparesTypeEnum fromValue(String value) {
		for (ContainerSparesTypeEnum csType : values()) {
			if (csType.value.equalsIgnoreCase(value)) {
				return csType;
			}
		}
		throw new IllegalArgumentException(
				"Unknown enum type " + value + ", Allowed values are " + Arrays.toString(values()));
	}
	
	public String getValue() {
		return value;
	}
}
