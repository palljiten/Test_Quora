/**
 * 
 */
package com.genpact.cora.scm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author 703158077
 *
 */
@Entity
@Table(name="tbl_IMInventoryPlanningSpares")
public class InventoryPlanningSpare implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543220L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID", unique= true, nullable = false )
	private Integer id;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="RegionID")
	private Region region;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CountryID")
	private Country country;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="HubID")
	private HubSc hub;
	
	@Column(name="PartID")
	private String part;
	
	@Column(name="ServiceLevel")
	private Float serviceLevel;
	@Column(name="InventoryLevel")
	private Float inventoryLevel;
	@Column(name="TotalLeadTime")
	private Float totalLeadTime;
	@Column(name="DemandDuringLeadTime")
	private Float demandDuringLeadTime;
	@Column(name="AverageMonthlyDemand")
	private Float averageMonthlyDemand;
	@Column(name="StandardDeviation")
	private Float standardDeviation;
	@Column(name="OpenOrders")
	private Integer openOrder;
	@Column(name="ROP")
	private Float rop;
	@Column(name="SafetyStock")
	private Integer calculatedMinInventory;
	@Column(name="PriorityFlag")
	private Float priorityFlag;
	@Column(name="Flag")
	private Integer flag;
	
	
	
	
	
	/**
	 * @return the flag
	 */
	public Integer getFlag() {
		return flag;
	}
	/**
	 * @param flag the flag to set
	 */
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the region
	 */
	public Region getRegion() {
		return region;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(Region region) {
		this.region = region;
	}
	/**
	 * @return the country
	 */
	public Country getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(Country country) {
		this.country = country;
	}
	/**
	 * @return the hub
	 */
	public HubSc getHub() {
		return hub;
	}
	/**
	 * @param hub the hub to set
	 */
	public void setHub(HubSc hub) {
		this.hub = hub;
	}
	/**
	 * @return the part
	 */
	public String getPart() {
		return part;
	}
	/**
	 * @param part the part to set
	 */
	public void setPart(String part) {
		this.part = part;
	}
	/**
	 * @return the serviceLevel
	 */
	public Float getServiceLevel() {
		return serviceLevel;
	}
	/**
	 * @param serviceLevel the serviceLevel to set
	 */
	public void setServiceLevel(Float serviceLevel) {
		this.serviceLevel = serviceLevel;
	}
	/**
	 * @return the inventoryLevel
	 */
	public Float getInventoryLevel() {
		return inventoryLevel;
	}
	/**
	 * @param inventoryLevel the inventoryLevel to set
	 */
	public void setInventoryLevel(Float inventoryLevel) {
		this.inventoryLevel = inventoryLevel;
	}
	/**
	 * @return the totalLeadTime
	 */
	public Float getTotalLeadTime() {
		return totalLeadTime;
	}
	/**
	 * @param totalLeadTime the totalLeadTime to set
	 */
	public void setTotalLeadTime(Float totalLeadTime) {
		this.totalLeadTime = totalLeadTime;
	}
	/**
	 * @return the demandDuringLeadTime
	 */
	public Float getDemandDuringLeadTime() {
		return demandDuringLeadTime;
	}
	/**
	 * @param demandDuringLeadTime the demandDuringLeadTime to set
	 */
	public void setDemandDuringLeadTime(Float demandDuringLeadTime) {
		this.demandDuringLeadTime = demandDuringLeadTime;
	}
	/**
	 * @return the averageMonthlyDemand
	 */
	public Float getAverageMonthlyDemand() {
		return averageMonthlyDemand;
	}
	/**
	 * @param averageMonthlyDemand the averageMonthlyDemand to set
	 */
	public void setAverageMonthlyDemand(Float averageMonthlyDemand) {
		this.averageMonthlyDemand = averageMonthlyDemand;
	}
	/**
	 * @return the standardDiviation
	 */
	public Float getStandardDeviation() {
		return standardDeviation;
	}
	/**
	 * @param standardDiviation the standardDiviation to set
	 */
	public void setStandardDeviation(Float standardDiviation) {
		this.standardDeviation = standardDiviation;
	}
	/**
	 * @return the openOrder
	 */
	public Integer getOpenOrder() {
		return openOrder;
	}
	/**
	 * @param openOrder the openOrder to set
	 */
	public void setOpenOrder(Integer openOrder) {
		this.openOrder = openOrder;
	}
	/**
	 * @return the rop
	 */
	public Float getRop() {
		return rop;
	}
	/**
	 * @param rop the rop to set
	 */
	public void setRop(Float rop) {
		this.rop = rop;
	}
	/**
	 * @return the calculatedMinInventory
	 */
	public Integer getCalculatedMinInventory() {
		return calculatedMinInventory;
	}
	/**
	 * @param calculatedMinInventory the calculatedMinInventory to set
	 */
	public void setCalculatedMinInventory(Integer calculatedMinInventory) {
		this.calculatedMinInventory = calculatedMinInventory;
	}
	/**
	 * @return the priorityFlag
	 */
	public Float getPriorityFlag() {
		return priorityFlag;
	}
	/**
	 * @param priorityFlag the priorityFlag to set
	 */
	public void setPriorityFlag(Float priorityFlag) {
		this.priorityFlag = priorityFlag;
	}
	
	
	
	
	

}
