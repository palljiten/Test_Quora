/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 703158077
 *
 */
public class HubLavelPercentageResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543212L;
	
	
	List<HubLavelPercentage> regionBudgets = new ArrayList<HubLavelPercentage>();


	/**
	 * @return the regionBudgets
	 */
	public List<HubLavelPercentage> getRegionBudgets() {
		return regionBudgets;
	}


	/**
	 * @param regionBudgets the regionBudgets to set
	 */
	public void setRegionBudgets(List<HubLavelPercentage> regionBudgets) {
		this.regionBudgets = regionBudgets;
	}

	
	
}
