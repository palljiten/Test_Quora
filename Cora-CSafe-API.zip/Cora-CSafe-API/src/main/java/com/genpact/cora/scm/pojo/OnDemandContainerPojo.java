package com.genpact.cora.scm.pojo;

public class OnDemandContainerPojo {
	
	private int SCID;

    private int modelID;

    private String modelName;

    private int hubId;

    private int partNumber;

    private int regionId;

    private ModelParameters[] parameters;

    private int countryId;

	public int getSCID() {
		return SCID;
	}

	public void setSCID(int sCID) {
		SCID = sCID;
	}

	public int getModelID() {
		return modelID;
	}

	public void setModelID(int modelID) {
		this.modelID = modelID;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public int getHubId() {
		return hubId;
	}

	public void setHubId(int hubId) {
		this.hubId = hubId;
	}

	public int getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(int partNumber) {
		this.partNumber = partNumber;
	}

	public int getRegionId() {
		return regionId;
	}

	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}

	public ModelParameters[] getParameters() {
		return parameters;
	}

	public void setParameters(ModelParameters[] parameters) {
		this.parameters = parameters;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

}
