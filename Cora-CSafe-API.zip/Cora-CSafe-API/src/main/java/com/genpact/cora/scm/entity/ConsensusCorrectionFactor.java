package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_ConsensusCorrectionFactor]")
public class ConsensusCorrectionFactor {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private Integer id;
     
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "hubId")
	private HubSc hubsc;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CountryId")
    private Country country;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RegionId")
    private Region region;

    @Column(name = "monthYear", nullable = false, length = 100)
    private String monthYear;
    
    @Column(name = "value", nullable = false, length = 100)
    private float value;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "createdDate", nullable = false, length = 100)
    private Date createdDate;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modifiedDate", nullable = false, length = 100)
    private Date modifiedDate;
    
    @Column(name = "modifiedBy", nullable = false, length = 100)
    private String modifiedBy;
    
    @Column(name = "flag", nullable = false, length = 100)
    private Integer flag;

    @Column(name = "CreatedMonth")
    private String createdMonth;
    
    @Column(name="ForecastType")
    private String forecastType;
    
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="AID")
    private ConsensusAverage average;
    
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public String getMonthYear() {
		return monthYear;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		this.value = value;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	public HubSc getHubsc() {
		return hubsc;
	}

	public void setHubsc(HubSc hubsc) {
		this.hubsc = hubsc;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCreatedMonth() {
		return createdMonth;
	}

	public void setCreatedMonth(String createdMonth) {
		this.createdMonth = createdMonth;
	}

	public ConsensusAverage getAverage() {
		return average;
	}

	public void setAverage(ConsensusAverage average) {
		this.average = average;
	}

	public String getForecastType() {
		return forecastType;
	}

	public void setForecastType(String forecastType) {
		this.forecastType = forecastType;
	}
}
