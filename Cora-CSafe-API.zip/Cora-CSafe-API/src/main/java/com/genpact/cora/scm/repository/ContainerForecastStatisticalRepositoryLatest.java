package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.StatisticalForecast;

public interface ContainerForecastStatisticalRepositoryLatest extends JpaRepository<StatisticalForecast, Integer> {
	
	@Query("SELECT f FROM StatisticalForecast f "
			+ "WHERE flag=1 AND f.hubsc.hubId = :hubId AND f.country.countryId = :countryId "
			+ "AND f.region.regionId = :regionId AND f.model.modelId = :modelId AND f.forecastMonth IN (:myList)")
	public List<StatisticalForecast> getStatisticalBaseForecast(@Param("regionId") int regionId, 
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("modelId")int modelId, @Param("myList") List<String> myList);
}