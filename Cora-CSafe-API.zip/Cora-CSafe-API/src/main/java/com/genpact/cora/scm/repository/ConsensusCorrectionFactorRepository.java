package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.genpact.cora.scm.entity.ConsensusCorrectionFactor;

public interface ConsensusCorrectionFactorRepository extends JpaRepository<ConsensusCorrectionFactor, Integer>{
	
	/*@Query(value="select distinct top(6)  b.value as v ,concat(substring(c.MonthName,1,3),'-',c.Year) as my, b.AID"
			+ "  from tbl_master_Calendar c left outer join tbl_ConsensusCorrectionFactor b"
			+ "	 on concat(substring(c.MonthName,1,3),'-',c.Year)=b.MonthYear and b.Flag=1 "
			+ " and b.RegionID=:regionId and b.CountryID=:countryId and b.HubID=:hubId"
			+ " where date < dateadd(m,6, getdate()) and date > getdate()",nativeQuery=true )
	public List<Object> findCorrectionFactor(@Param("regionId") int regionId,@Param("countryId") int countryId,@Param("hubId") int hubId);*/
	 
	@Transactional
	@Modifying
	@Query(value="UPDATE tbl_ConsensusCorrectionFactor SET flag=0 WHERE (countryId=:countryId and hubId=:hubId and regionId=:regionId and monthyear=:monthYear and flag=1)" , nativeQuery = true)
	public int updateCorrectionFactor(@Param("countryId") int countryId,@Param("hubId") int hubId,@Param("regionId") int regionId,@Param("monthYear") String monthYear);
}
