package com.genpact.cora.scm.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.ConfigurationInventoryClassificationDto;
import com.genpact.cora.scm.dto.SparesInventoryClassification;
import com.genpact.cora.scm.entity.InventoryClassification;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.SpareClassificationRepository;

@Service
public class SparesInventoryClassificationService {
	
	private static Logger logger= LoggerFactory.getLogger(SparesInventoryClassificationService.class);
	
	@Autowired
	SpareClassificationRepository scr;
	
	public List<SparesInventoryClassification> getSparesInventoryClassification(int regionId, int countryId,int hubId, String partNumber) throws CSafeServiceException{
		logger.info("SparesInventoryClassificationService : Entering getSparesInventoryClassification() method");
		List<SparesInventoryClassification> responseList = new ArrayList<>();
		SparesInventoryClassification responseRow=null;
		try{
			List<InventoryClassification> result = scr.getSparesClassificationDetails(regionId, countryId, hubId, partNumber);
			for(InventoryClassification icObj : result) {
				responseRow = new SparesInventoryClassification();
				responseRow.setPartNumber(icObj.getPartNumber());
				responseRow.setServiceCenter(icObj.getServiceCenter());
				responseRow.setAbcDemand(icObj.getAbcDemand()+"");
				responseRow.setAbcDemandClassification(icObj.getAbcDemandVolume());
				responseRow.setAbcValue(icObj.getAbcValue()+"");
				responseRow.setAbcValueClassification(icObj.getAbcValueVolume());
				responseRow.setFsn(icObj.getFsn());
				responseRow.setHits(icObj.getDemandCount()+"");
				responseRow.setHml(icObj.getHml());
				responseRow.setCost(icObj.getUnitCost()+"");
				responseList.add(responseRow);
			}
		} catch(Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SparesInventoryClassificationService : Exiting getSparesInventoryClassification() method");
		return responseList;
}
	
	public List<ConfigurationInventoryClassificationDto> getSparesInventoryConfigurationInventoryManagement(ConfigurationInventoryClassificationDto configurationInventoryClassificationDto) throws CSafeServiceException{
		logger.info("SparesInventoryClassificationService : Entering getSparesInventoryConfigurationInventoryManagement() method");
		List<ConfigurationInventoryClassificationDto> configurationInventoryClassificationDtoList = new ArrayList<>();

		try{
			
		} catch(Exception e) {
			logger.error("Error caught: " + e.getMessage(), e); 
			throw new CSafeServiceException(e);
		}
		logger.info("SparesInventoryClassificationService : Exiting getSparesInventoryConfigurationInventoryManagement() method");
		return configurationInventoryClassificationDtoList;
}
}