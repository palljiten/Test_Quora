package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class RegionDetail implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String regionName;
	private int regionID;
	private Set<String> countries  = new TreeSet<>();
	private List<CountryDetail> countryDetails = new ArrayList<>();

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public int getRegionID() {
		return regionID;
	}

	public void setRegionID(int regionID) {
		this.regionID = regionID;
	}

	public Set<String> getCountries() {
		return countries;
	}

	public void setCountries(Set<String> countries) {
		this.countries = countries;
	}

	public List<CountryDetail> getCountryDetails() {
		return countryDetails;
	}

	public void setCountryDetails(List<CountryDetail> countryDetails) {
		this.countryDetails = countryDetails;
	}
}
