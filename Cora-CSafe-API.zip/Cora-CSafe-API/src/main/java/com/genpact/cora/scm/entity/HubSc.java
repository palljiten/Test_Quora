package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "[dbo].[tbl_master_HUBSC]")
public class HubSc {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "HubID", unique = true, nullable = false)
    private Integer hubId;
     
    @Column(name = "Code", nullable = false, length = 100)
    private String hubCode;
    
    @Column(name = "AccountName", nullable = false, length = 100)
    private String accountName;
    
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CountryID")
    @JsonProperty(access = Access.WRITE_ONLY)
    private Country country;
    
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RegionID")
    @JsonProperty(access = Access.WRITE_ONLY)
    private Region region;
    
    @Column(name = "LocationType")
    private String locationType;
    
    @Column(name = "State")
    private String state;
    
    @Column(name = "City")
    private String city;
    
    @Column(name = "Lat")
    private Float latitude;
    
    @Column(name = "Long")
    private Float longitude;
    
	public Integer getHubId() {
		return hubId;
	}

	public void setHubId(Integer hubId) {
		this.hubId = hubId;
	}

	public String getHubCode() {
		return hubCode;
	}

	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getLocationType() {
		return locationType;
	}

	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	public Float getLatitude() {
		return latitude;
	}

	public void setLatitude(Float latitude) {
		this.latitude = latitude;
	}

	public Float getLongitude() {
		return longitude;
	}

	public void setLongitude(Float longitude) {
		this.longitude = longitude;
	}
}
