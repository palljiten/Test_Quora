package com.genpact.cora.scm.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.ContainerConsensusForecastCombo;
import com.genpact.cora.scm.dto.ContainerStatisticalBaselineForecastCombo;
import com.genpact.cora.scm.dto.MonthDataUnit;
import com.genpact.cora.scm.dto.StatisticalAdjustmentCombo;
import com.genpact.cora.scm.entity.BPBasedForeCast;
import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.Region;
import com.genpact.cora.scm.entity.StatisticalForecast;
import com.genpact.cora.scm.entity.StatisticalForecastConfig;
import com.genpact.cora.scm.repository.BPBasedForecastRepository;
import com.genpact.cora.scm.repository.StatisticalForecastConfigRepository;
import com.genpact.cora.scm.repository.StatisticalForecastRepository;

@Service
public class ContainerForecastConsensusService {

	private static Logger logger = LoggerFactory.getLogger(ContainerForecastConsensusService.class);
	private static Map<Integer, String> monthValueMap = new HashMap<>();
	private static Map<String, Integer> monthValueReverseMap = new HashMap<>();
	private static Map<String, String> yearMap = new HashMap<>();
	private static Map<String, String> yearReverseMap = new HashMap<>();
	
	static {
		monthValueMap.put(0, "Jan");
		monthValueMap.put(1, "Feb");
		monthValueMap.put(2, "Mar");
		monthValueMap.put(3, "Apr");
		monthValueMap.put(4, "May");
		monthValueMap.put(5, "Jun");
		monthValueMap.put(6, "Jul");
		monthValueMap.put(7, "Aug");
		monthValueMap.put(8, "Sep");
		monthValueMap.put(9, "Oct");
		monthValueMap.put(10, "Nov");
		monthValueMap.put(11, "Dec");
		
		monthValueReverseMap.put("Jan", 0);
		monthValueReverseMap.put("Feb", 1);
		monthValueReverseMap.put("Mar", 2);
		monthValueReverseMap.put("Apr", 3);
		monthValueReverseMap.put("May", 4);
		monthValueReverseMap.put("Jun", 5);
		monthValueReverseMap.put("Jul", 6);
		monthValueReverseMap.put("Aug", 7);
		monthValueReverseMap.put("Sep", 8);
		monthValueReverseMap.put("Oct", 9);
		monthValueReverseMap.put("Nov", 10);
		monthValueReverseMap.put("Dec", 11);
		
		yearMap.put("15", "2015");
		yearMap.put("16", "2016");
		yearMap.put("17", "2017");
		yearMap.put("18", "2018");
		yearMap.put("19", "2019");
		yearMap.put("20", "2020");
		yearMap.put("21", "2021");
		yearMap.put("22", "2022");
		
		yearReverseMap.put("2015", "15");
		yearReverseMap.put("2016", "16");
		yearReverseMap.put("2017", "17");
		yearReverseMap.put("2018", "18");
		yearReverseMap.put("2019", "19");
		yearReverseMap.put("2020", "20");
		yearReverseMap.put("2021", "21");
		yearReverseMap.put("2022", "22");
	}
	
	@Autowired
	StatisticalForecastRepository forecastRepository;
	
	@Autowired
	StatisticalForecastConfigRepository configRepository;
	
	@Autowired
	BPBasedForecastRepository bpBasedForecastRepository;
	
	@Autowired
	ContainerForecastStatisticalService cfService;
	
	@Autowired
	ConsensusService consensusService;
	
	public ContainerConsensusForecastCombo getContainerConsensusForecast(int regionId, int countryId, int hubId) {
		ContainerConsensusForecastCombo data = new ContainerConsensusForecastCombo();
		List<StatisticalForecast> list = new LinkedList<StatisticalForecast>();
		//List<StatisticalForecast> lists = new LinkedList<StatisticalForecast>();
		
		List<BPBasedForeCast> baselineList = bpBasedForecastRepository.getBaselineForecast(countryId,hubId,regionId);
		
		/*Calling to ContainerForecastStatisticalService to get total forecast of Statistical*/
		ContainerStatisticalBaselineForecastCombo statisticalData = cfService.getBaseForecast(regionId, countryId, hubId, 6);
		StatisticalAdjustmentCombo adjustmentData = cfService.getAdjustments(regionId, countryId, hubId, 6);
		List<MonthDataUnit> lists = calculateStatisticalForecastInConsensus(statisticalData,adjustmentData);
		List<BPBasedForeCast> baselineLists = prepareSixMonthDataForBP(baselineList);
		
		List<StatisticalForecastConfig> configuredModel = configRepository.getConfiguredModel(regionId, countryId, hubId);
		if (configuredModel.size()<=0)	{
			/*list = forecastRepository.getStatisticalForecast(regionId, countryId, hubId, 
					0, 6);
			lists = prepareSixMonthDataForStatistical(list,new StatisticalForecastConfig());*/
			populate(data, lists, baselineLists,new StatisticalForecastConfig());
		}
		else {
			/*list = forecastRepository.getStatisticalForecast(regionId, countryId, hubId, 
					configuredModel.get(0).getConfiguredModel().getModelId(), 6);
			lists = prepareSixMonthDataForStatistical(list,configuredModel.get(0));*/
			populate(data, lists, baselineLists,configuredModel.get(0));
		}
		   
		
		
		return data;
	}
	
	private List<MonthDataUnit> calculateStatisticalForecastInConsensus(ContainerStatisticalBaselineForecastCombo statisticalData,
			StatisticalAdjustmentCombo adjustmentData) {
		List<MonthDataUnit> baseValueList = statisticalData.getBaselineForecast();
		List<MonthDataUnit> adjustmentValueList = adjustmentData.getAdjustmentValues();
		MonthDataUnit baseObj = null;
		MonthDataUnit adjustObj = null;
		List<MonthDataUnit> list = new LinkedList<MonthDataUnit>();
		MonthDataUnit monthDataUnit = null;
		if(baseValueList.size() > 0 && adjustmentValueList.size()> 0) {
			for(int i=0; i<baseValueList.size();i++) {
				baseObj = baseValueList.get(i);
				for(MonthDataUnit adjustObj1 : adjustmentValueList) {
					if(baseObj.getMonth().equalsIgnoreCase(adjustObj1.getMonth())) {
						monthDataUnit = new MonthDataUnit();
						monthDataUnit.setMonth(baseObj.getMonth());
						monthDataUnit.setMonthValue(baseObj.getMonthValue());
						monthDataUnit.setValue(baseObj.getValue()+adjustObj1.getValue());
						monthDataUnit.setYear(baseObj.getYear());
						
						list.add(monthDataUnit);
						break;
					}
				}
				//adjustObj = adjustmentValueList.get(i);
				/*if(baseObj.getMonth().equalsIgnoreCase(adjustObj.getMonth())) {
					monthDataUnit = new MonthDataUnit();
					monthDataUnit.setMonth(baseObj.getMonth());
					monthDataUnit.setMonthValue(baseObj.getMonthValue());
					monthDataUnit.setValue(baseObj.getValue()+adjustObj.getValue());
					monthDataUnit.setYear(baseObj.getYear());
				}
				list.add(monthDataUnit);*/
			}
		} return list;
	}

	/*private List<StatisticalForecast> prepareSixMonthDataForStatistical(
			List<StatisticalForecast> list,StatisticalForecastConfig configModel) {
		List<String> sixMonthYearValuesLst = new ConsensusService().prepareSixMonthYearList();
		StatisticalForecast statisticalForecast = null;
		int count = 0;
		String name = null;
		String year = null;
		Date date = null;
		Country country = null;
		Region region = null;
		HubSc hubsc = null;
		List<StatisticalForecast> statisticalValuesLst = new LinkedList<>();
		if(configModel != null) {
			 country = configModel.getCountry();
			 region = configModel.getRegion();
			 hubsc = configModel.getHub();
		}
		
		
			for(String value : sixMonthYearValuesLst) {
				name = value.substring(0, value.indexOf(" "));
				year = value.substring(value.indexOf(" ")+1,value.length());
				count = getStatisticalObjectIndexFromList(list,name);
				//if(adjustmentValuesList.size()>0) {
				if(count >= 0) {
					StatisticalForecast statisticalValueObj = list.get(count);
					
					statisticalForecast = new StatisticalForecast();
					statisticalForecast.setCountry(statisticalValueObj.getCountry());
					statisticalForecast.setRegion(statisticalValueObj.getRegion());
					statisticalForecast.setHubsc(statisticalValueObj.getHubsc());
					statisticalForecast.setForecastValue(statisticalValueObj.getForecastValue());
					statisticalForecast.setForecastMonth(statisticalValueObj.getForecastMonth());
					statisticalForecast.setForecastId(statisticalValueObj.getForecastId());
					statisticalValuesLst.add(statisticalForecast);
				}
				else if (count <0) {
					statisticalForecast = new StatisticalForecast();
					statisticalForecast.setCountry(country);
					statisticalForecast.setRegion(region);
					statisticalForecast.setHubsc(hubsc);
					statisticalForecast.setForecastValue(0);
					statisticalForecast.setForecastMonth(name+"-"+year);
					statisticalForecast.setForecastId(0);
					try {
						date = new SimpleDateFormat("MMMM").parse(name);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					statisticalValuesLst.add(statisticalForecast);
				}
				
			}
			
		return statisticalValuesLst;
	}*/
	
	/*private int getStatisticalObjectIndexFromList(List<StatisticalForecast> ObjectValuesList,String month) {
		int index = 0;
		String monthName = "";
		String name = "";
		for(StatisticalForecast obj : ObjectValuesList) {
			name = getProperMonthYear(obj.getForecastMonth());
			monthName = name.substring(0, name.indexOf(" "));
			if(month.equalsIgnoreCase(monthName)){
				return index;
			}
			index++;
		}
		return -1;
	}*/
	
	private int getBPObjectIndexFromList(List<BPBasedForeCast> ObjectValuesList,String month) {
		int index = 0;
		String monthName = "";
		String name = "";
		for(BPBasedForeCast obj : ObjectValuesList) {
			name = getProperMonthYear(obj.getMonthYear());
			monthName = name.substring(0, name.indexOf(" "));
			if(month.equalsIgnoreCase(monthName)){
				return index;
			}
			index++;
		}
		return -1;
	}
	
	private List<BPBasedForeCast> prepareSixMonthDataForBP(
			List<BPBasedForeCast> list) {
		List<String> sixMonthYearValuesLst = new ConsensusService().prepareSixMonthYearList();
		BPBasedForeCast BPForecast = null;
		int count = 0;
		String name = null;
		String year = null;
		Date date = null;
		List<BPBasedForeCast> bpValuesLst = new LinkedList<>();
		
			for(String value : sixMonthYearValuesLst) {
				name = value.substring(0, value.indexOf(" "));
				year = value.substring(value.indexOf(" ")+1,value.length());
				count = getBPObjectIndexFromList(list,name);
				//if(adjustmentValuesList.size()>0) {
				if(count >= 0) {
					BPBasedForeCast bpValueObj = list.get(count);
					
					BPForecast = new BPBasedForeCast(bpValueObj.getValue(),bpValueObj.getMonthYear());
					bpValuesLst.add(BPForecast);
				}
				else if (count <0) {
					BPForecast = new BPBasedForeCast(0,name+"-"+year);
					try {
						date = new SimpleDateFormat("MMMM").parse(name);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					bpValuesLst.add(BPForecast);
				}
				
			}
		return bpValuesLst;
	}
	
	private void populate(ContainerConsensusForecastCombo data, List<MonthDataUnit> list, List<BPBasedForeCast> bpList,StatisticalForecastConfig config) {		
		/*for(StatisticalForecast sca : list) {
			data.setCountry(sca.getCountry());
			data.setHub(sca.getHubsc());
			data.setRegion(sca.getRegion());
			
			String monthYear = getProperMonthYear(sca.getForecastMonth());
			data.getMonthYearMetaData().add(monthYear);
			
			MonthDataUnit mdu = new MonthDataUnit();
			
			String[] parts = monthYear.split(" ");
			mdu.setMonth(parts[0]);
			mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
			mdu.setYear(Integer.parseInt(parts[1]));
			mdu.setValue(sca.getForecastValue());
			
			data.getStatisticalForecast().add(mdu);
		}	*/
		data.setCountry(config.getCountry());
		data.setHub(config.getHub());
		data.setRegion(config.getRegion());
		data.setStatisticalForecast(list);
		data.setMonthYearMetaData(consensusService.prepareSixMonthYearList());
		
		for(BPBasedForeCast bp : bpList) {
			String monthYear = getProperMonthYear(bp.getMonthYear());
			
			MonthDataUnit mdu = new MonthDataUnit();
			
			String[] parts = monthYear.split(" ");
			mdu.setMonth(parts[0]);
			mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
			mdu.setYear(Integer.parseInt(parts[1]));
			mdu.setValue(bp.getValue());
			
			data.getBaselineForecast().add(mdu);
		}
	}
	
	private String getProperMonthYear(String my) {
		StringBuffer properMonthYear = new StringBuffer("");
		String[] parts = my.split("-");
		properMonthYear.append(parts[0]);
		properMonthYear.append(" ");
		if (parts[1].length() == 2)
			properMonthYear.append(yearMap.get(parts[1]));
		else
			properMonthYear.append(parts[1].trim());
		return properMonthYear.toString();
	}

	public static Map<Integer, String> getMonthValueMap() {
		return monthValueMap;
	}

	public static void setMonthValueMap(Map<Integer, String> monthValueMap) {
		ContainerForecastConsensusService.monthValueMap = monthValueMap;
	}

	
	
	
}
