package com.genpact.cora.scm.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.ConsensusAdjustmentValueCombo;
import com.genpact.cora.scm.dto.ConsensusCorrectionFactorCombo;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.ConsensusService;
import com.genpact.cora.scm.service.ContainerForecastConsensusService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
@Api(tags = { "Container Forecast - Consensus" })

public class ContainerForecastConsensusController {

	private static final Logger logger = LoggerFactory.getLogger(ContainerForecastConsensusController.class);

	@Autowired
	ConsensusService concensusService;

	@Autowired
	ContainerForecastConsensusService ccService;

	@GetMapping(value = "/forecast/consensus", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Baseline / Statistical Forecast")
	public ResponseEntity<Object> getBaselineStatisticalForecast(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId) {
		// return new
		// ResponseEntity<>(concensusService.getBaselineStatisticalForecast(regionId,
		// countryId, hubId),HttpStatus.OK);
		return new ResponseEntity<>(ccService.getContainerConsensusForecast(regionId, countryId, hubId), HttpStatus.OK);
	}

	@GetMapping(value = "/forecast/concensus/correction-factors", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Correction Factors")
	public ResponseEntity<Object> getCorrectionFactors(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId) {
		return new ResponseEntity<>(concensusService.getCorrectionFactors(regionId, countryId, hubId), HttpStatus.OK);
	}

	@PutMapping(value = "/csafe/forecast/correction-factors", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update Correction Factors")
	public ResponseEntity<Object> updateCorrectionFactors(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestBody ConsensusCorrectionFactorCombo correctionFactors) {
		logger.info("ContainerForecastConsensusController: Exiting updateCorrectionFactors() method");
		concensusService.updateCorrectionFactors(regionId, countryId, hubId, correctionFactors);
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("ContainerForecastConsensusController: Exiting updateCorrectionFactors() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}

	@GetMapping(value = "/forecast/adjustments", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Adjustment Values")
	public ResponseEntity<Object> getAdjustmentValues(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId) {
		return new ResponseEntity<>(concensusService.getAdjustmentValues(regionId, countryId, hubId), HttpStatus.OK);
	}

	@PutMapping(value = "/forecast/adjustments", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Adjustment Values")
	public ResponseEntity<Object> updateAdjustmentValues(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId,
			@RequestBody ConsensusAdjustmentValueCombo adjustment) {
		logger.info("ContainerForecastConsensusController: Exiting updateAdjustmentValues() method");
		try {
			concensusService.updateAdjustmentValues(regionId, countryId, hubId, adjustment);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.toString());
		}
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("ContainerForecastConsensusController: Exiting updateAdjustmentValues() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}

	@GetMapping(value = "/forecast/alignedForecast", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Aligned Forecast Values")

	public ResponseEntity<Object> getAlignedForecastData(@RequestParam("regionId") int regionId,
			@RequestParam("countryId") int countryId, @RequestParam("hubId") int hubId) {

		try {
			logger.info("ContainerForecastConsensusController: Exiting getAlignedForecastData() method");
			return new ResponseEntity<>(concensusService.getAlignedForecastData(regionId, countryId, hubId),
					HttpStatus.OK);
		    } catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getAlignedForecastData in ContainerForecastConsensusController :",
					e.getCause());
		   }

	}
}
