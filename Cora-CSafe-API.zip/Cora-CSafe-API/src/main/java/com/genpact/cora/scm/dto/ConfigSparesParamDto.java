package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.List;

public class ConfigSparesParamDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	//Planning Parameters
	private PlanningParam planningParam;
	//Service Strategy Set-up
	
	//Policy Set-up
	private List<PolicySetup> listPolicySetup;
	
}
