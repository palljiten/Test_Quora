package com.genpact.cora.scm.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Repository;

@Repository
public class WeeklyForecastSPRepository {
	
	@PersistenceContext
    private EntityManager entityManager;
	
	public boolean callWeeklyForecastSP(){
		
		StoredProcedureQuery query  = entityManager.createStoredProcedureQuery("WeeklyForecastSP");
		return query.execute();
		
	}

}
