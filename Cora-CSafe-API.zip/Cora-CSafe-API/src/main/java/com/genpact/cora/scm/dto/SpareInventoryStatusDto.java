package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class SpareInventoryStatusDto implements Serializable {

	private static final long serialVersionUID = 1L;

	//private String region;
	//private String country;
	private String hub;
	//private String partNumber;
	private int quantity;
	
	
	public String getHub() {
		return hub;
	}
	public void setHub(String hub) {
		this.hub = hub;
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
