package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_StatisticalWeightedAvgTechnique]")
public class StatisticalWeightedAvgTechnique {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
	private int ID;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ModelID")
	private StatisticalModel model;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ATID")
	private StatisticalTechnique technique;
	
	@Column(name = "Value")
	private float value;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RegionId")
    private Region region;
    
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CountryId")
    private Country country;
    
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HubId")
    private HubSc hubsc;
    
    @Column(name = "CreatedMonth", nullable = true, length = 100)
    private String createdMonth;

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public StatisticalModel getModel() {
		return model;
	}

	public void setModel(StatisticalModel model) {
		this.model = model;
	}

	public StatisticalTechnique getTechnique() {
		return technique;
	}

	public void setTechnique(StatisticalTechnique technique) {
		this.technique = technique;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHubsc() {
		return hubsc;
	}

	public void setHubsc(HubSc hubsc) {
		this.hubsc = hubsc;
	}

	public String getCreatedMonth() {
		return createdMonth;
	}

	public void setCreatedMonth(String createdMonth) {
		this.createdMonth = createdMonth;
	}

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		this.value = value;
	}
}
