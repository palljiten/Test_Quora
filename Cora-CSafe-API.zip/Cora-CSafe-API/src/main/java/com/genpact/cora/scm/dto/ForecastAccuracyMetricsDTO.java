package com.genpact.cora.scm.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ForecastAccuracyMetricsDTO {

	private int regionId;
	private int countryId;
	private int hubId;
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String partId;
	private String month;
	private int monthValue;
	private int year;
	private String type;
	
	private Integer statistical;
	private Integer bpbased;
	private Integer aligned;
	private Integer consensus;
	
	public int getRegionId() {
		return regionId;
	}
	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}
	public int getCountryId() {
		return countryId;
	}
	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}
	public int getHubId() {
		return hubId;
	}
	public void setHubId(int hubId) {
		this.hubId = hubId;
	}
	public String getPartId() {
		return partId;
	}
	public void setPartId(String partId) {
		this.partId = partId;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getMonthValue() {
		return monthValue;
	}
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getStatistical() {
		return statistical;
	}
	public void setStatistical(int statistical) {
		this.statistical = statistical;
	}
	public Integer getBpbased() {
		return bpbased;
	}
	public void setBpbased(int bpbased) {
		this.bpbased = bpbased;
	}
	public Integer getAligned() {
		return aligned;
	}
	public void setAligned(Integer aligned) {
		this.aligned = aligned;
	}
	public Integer getConsensus() {
		return consensus;
	}
	public void setConsensus(Integer consensus) {
		this.consensus = consensus;
	}
}
