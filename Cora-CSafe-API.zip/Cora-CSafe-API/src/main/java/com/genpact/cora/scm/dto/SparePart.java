package com.genpact.cora.scm.dto;

import javax.persistence.Column;

public class SparePart {

	String partNumber;
	String partDesc;
	Integer maxInvLevel;
	Integer minInvLevel;
	Integer rop;
	Integer consumedQty;
	Integer actualQty;
	String alertDesc;

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getPartDesc() {
		return partDesc;
	}

	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}

	public Integer getMaxInvLevel() {
		return maxInvLevel;
	}

	public void setMaxInvLevel(Integer maxInvLevel) {
		this.maxInvLevel = maxInvLevel;
	}

	public Integer getMinInvLevel() {
		return minInvLevel;
	}

	public void setMinInvLevel(Integer minInvLevel) {
		this.minInvLevel = minInvLevel;
	}

	public Integer getRop() {
		return rop;
	}

	public void setRop(Integer rop) {
		this.rop = rop;
	}

	public Integer getConsumedQty() {
		return consumedQty;
	}

	public void setConsumedQty(Integer consumedQty) {
		this.consumedQty = consumedQty;
	}

	public Integer getActualQty() {
		return actualQty;
	}

	public void setActualQty(Integer actualQty) {
		this.actualQty = actualQty;
	}

	public String getAlertDesc() {
		return alertDesc;
	}

	public void setAlertDesc(String alertDesc) {
		this.alertDesc = alertDesc;
	}

}
