package com.genpact.cora.scm.service;

import java.util.Comparator;

import com.genpact.cora.scm.dto.MonthDataUnit;

public class ForecastMonthValueComparator implements Comparator<MonthDataUnit> 
{ 
    // Used for sorting in ascending order of month value
	public int compare(MonthDataUnit a, MonthDataUnit b) 
    { 
        return a.getMonthValue() - b.getMonthValue();
    } 
}  