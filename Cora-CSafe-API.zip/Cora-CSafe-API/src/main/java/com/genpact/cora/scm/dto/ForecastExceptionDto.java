/**
 * 
 */
package com.genpact.cora.scm.dto;

/**
 * @author 703158077
 *
 */
public class ForecastExceptionDto {

}
