package com.genpact.cora.scm.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;

import com.genpact.cora.scm.dto.RegionBudget;
import com.genpact.cora.scm.entity.BudgetHubLevelPercentage;

public interface BudgetHubLevelPercentageRepository  extends JpaRepository<BudgetHubLevelPercentage, Integer> {

	@Query("SELECT w FROM BudgetHubLevelPercentage w WHERE w.flag = 1")
	List<BudgetHubLevelPercentage> getBudgetHubLevelPercentage();
	
	@Query("SELECT new com.genpact.cora.scm.dto.RegionBudget(v.region.regionId,v.region.regionName, SUM(v.hubValue)) " +
	           "FROM BudgetHubLevelPercentage v WHERE v.flag = 1 GROUP BY v.region.regionId,v.region.regionName")
	public List<RegionBudget> findRegionBudgetValues();
	
	@Transactional
	@Procedure(procedureName = "BudgetForecastSP")
	public void callBudgetForecastSP();
}