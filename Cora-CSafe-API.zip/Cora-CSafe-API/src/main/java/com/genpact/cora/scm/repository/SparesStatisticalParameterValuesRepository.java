package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.CustomParameter;
import com.genpact.cora.scm.entity.SparesStatisticalParameterValues;

public interface SparesStatisticalParameterValuesRepository  extends JpaRepository<SparesStatisticalParameterValues, Integer> {

	//@Query("SELECT new com.genpact.cora.scm.dto.CustomParameter(a.parameter.id, a.parameter.parameterName, a.value) FROM SparesStatisticalParameterValues a WHERE a.parameter.model.modelId = :modelId")
	@Query("SELECT new com.genpact.cora.scm.dto.CustomParameter(sp.id, sp.parameterName, spv.value) "
			+ "FROM SparesStatisticalParameterValues spv INNER JOIN spv.parameter sp ON spv.parameter.id = sp.id "
			+ "INNER JOIN sp.model sm ON sp.model.modelId = sm.modelId "
			+ "WHERE sm.modelId = :modelId AND spv.region.regionId = :regionId AND spv.country.countryId = :countryId "
			+ "AND spv.hubsc.hubId = :hubId AND spv.partId = :partId AND spv.flag = 1")
	public List<CustomParameter> getParamValuesForModelId(@Param("modelId") int modelId, @Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId);
	
	@Modifying
    @Query("UPDATE SparesStatisticalParameterValues spv SET spv.flag = 0 "
    		+ "WHERE spv.flag=1 AND spv.hubsc.hubId = :hubId AND spv.country.countryId = :countryId "
    		+ "AND spv.region.regionId = :regionId AND spv.parameter.id = :paramId AND spv.partId = :partId")
    int updateParams(@Param("paramId") int paramId, @Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId);
}
