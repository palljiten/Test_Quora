package com.genpact.cora.scm.dto;

public class CustomForecastModel {

	private Integer modelId; //tbl_master_StatisticalModel.ModelID
	private String modelName; //tbl_master_StatisticalModel.ModelName
	private String techniqueName; //tbl_master_StatisticalTechnique.TechniqueName
	private String value; //tbl_StatisticalWeightedAvgTechnique.Value
	private String forecastMonth; //tbl_SparesStatisticalForecast.ForecastMonth
	private float forecastValue; //tbl_SparesStatisticalForecast.ForecastValue
	private Integer bestfitModel; //tbl_SparesStatisticalForecastBestFit.BestFit
	private Integer configuredModel; //tbl_SparesStatisticalForecastConfig.Config
	
	public CustomForecastModel(Integer modelId, String modelName, String techniqueName, String value,
			String forecastMonth, float forecastValue, Integer bestfitModel, Integer configuredModel) {
		
		this.modelId = modelId;
		this.modelName = modelName;
		this.techniqueName = techniqueName;
		this.value = value;
		this.forecastMonth = forecastMonth;
		this.forecastValue = forecastValue;
		this.bestfitModel = bestfitModel;
		this.configuredModel = configuredModel;
	}
	
	public Integer getModelId() {
		return modelId;
	}
	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getTechniqueName() {
		return techniqueName;
	}
	public void setTechniqueName(String techniqueName) {
		this.techniqueName = techniqueName;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getForecastMonth() {
		return forecastMonth;
	}
	public void setForecastMonth(String forecastMonth) {
		this.forecastMonth = forecastMonth;
	}
	public float getForecastValue() {
		return forecastValue;
	}
	public void setForecastValue(float forecastValue) {
		this.forecastValue = forecastValue;
	}
	public Integer getBestfitModel() {
		return bestfitModel;
	}
	public void setBestfitModel(Integer bestfitModel) {
		this.bestfitModel = bestfitModel;
	}
	public Integer getConfiguredModel() {
		return configuredModel;
	}
	public void setConfiguredModel(Integer configuredModel) {
		this.configuredModel = configuredModel;
	}
}
