package com.genpact.cora.scm;

import java.util.TimeZone;
import java.util.concurrent.Executor;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;

import com.genpact.cora.scm.controller.ContainerForecastBpBasedController;
import com.genpact.cora.scm.controller.SparesForecastCommonController;
import com.genpact.cora.scm.util.InitialCacheLoader;

@org.springframework.boot.autoconfigure.SpringBootApplication
//@EnableScheduling
public class SpringBootApplication extends SpringBootServletInitializer {

	@Autowired
	private ServletContext servletContext;

	@Autowired
	SparesForecastCommonController sfcController;

	@Autowired
	ContainerForecastBpBasedController cfbbController;

	@Value("${csafe.default.region.id}")
	Integer defaultRegionId;

	@Value("${csafe.default.country.id}")
	Integer defaultCountryId;

	@Value("${csafe.default.hub.id}")
	Integer defaultHubId;

	@Value("${csafe.default.part.number}")
	String defaultPartNumber;

	@Value("${csafe.default.forecast.months}")
	Integer forecastMonths; // 6

	@Value("${csafe.default.demand.months}")
	Integer demandMonths; // 18

	@PostConstruct
	void started() {
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		servletContext.setAttribute("testing", "It is cached testing message");
		servletContext.setAttribute("fields", sfcController.getFields().getBody());
		InitialCacheLoader.loadBpBasedData(cfbbController, servletContext, defaultRegionId, defaultCountryId,
				defaultHubId, forecastMonths, demandMonths);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(SpringBootApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringBootApplication.class, args);

	}

	@Bean
	public TaskScheduler taskScheduler() {
		return new ConcurrentTaskScheduler();
	}

	@Bean
	public Executor taskExecutor() {
		return new SimpleAsyncTaskExecutor();
	}
	/*
	 * @Bean public DataSource jndiDataSource() throws IllegalArgumentException,
	 * NamingException { JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
	 * bean.setJndiName("java:/comp/env/jdbc/csafe");
	 * bean.setProxyInterface(DataSource.class); bean.setLookupOnStartup(false);
	 * bean.afterPropertiesSet(); return (DataSource) bean.getObject(); }
	 */

}