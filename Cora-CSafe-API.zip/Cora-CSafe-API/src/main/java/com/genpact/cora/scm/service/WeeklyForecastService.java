package com.genpact.cora.scm.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.ContainerForecastWeek;
import com.genpact.cora.scm.dto.ContainerForecastWeeklyAdjustments;
import com.genpact.cora.scm.dto.WeekData;
import com.genpact.cora.scm.dto.WeekMetaData;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.WeeklyAdjustment;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.CountryRepository;
import com.genpact.cora.scm.repository.HubRepository;
import com.genpact.cora.scm.repository.WeeklyAdjustmentRepository;
import com.genpact.cora.scm.repository.WeeklyForecastRepository;

@Service
public class WeeklyForecastService {

	@Autowired
	WeeklyForecastRepository weeklyForecastRepository;

	@Autowired
	HubRepository hubRepository;

	@Autowired
	CountryRepository countryRepository;

	@Autowired
	WeeklyAdjustmentRepository adjustmentRepository;
	
	@Autowired
	DemandAllocationService demandAllocationService;

	public ContainerForecastWeek getBaselineDemand(Integer regionID, Integer countryID, Integer hubID, Integer weeks)
			throws CSafeServiceException {
		ContainerForecastWeek containerForecastWeek = new ContainerForecastWeek();
		HubSc hubSc = hubRepository.findById(hubID).get();// getHub(regionID, countryID, hubID);
		String hubCode = hubSc.getHubCode();
		List<WeekMetaData> weekMetaDatas = new ArrayList<>();
		List<WeekData> weekDatas = new ArrayList<>();
		SimpleDateFormat sm = new SimpleDateFormat("dd MMM yyyy");
		List<Object[]> objects = weeklyForecastRepository.getBaselineDemand(hubCode, weeks);
		for (Object[] object : objects) {
			WeekData weekData = new WeekData();
			WeekMetaData weekMetaData = new WeekMetaData();
			//weekData.setWeekNum(weeks);
			weekData.setWeekNum(Integer.parseInt(object[2].toString()));
			weekData.setWeekStartDate(sm.format((Date) object[1]));
			weekMetaData.setWeekNum(Integer.parseInt(object[2].toString()));
			weekMetaData.setWeekStartDate(weekData.getWeekStartDate());
			if (object[0] != null) {
				weekData.setValue(Math.round(Float.valueOf(object[0].toString())));
			} else
				weekData.setValue(0);
			weekDatas.add(weekData);
			weekMetaDatas.add(weekMetaData);
			weeks--;
		}
		

		Map<String, Object> region = new HashMap<>();
		region.put("regionID", hubSc.getRegion().getRegionId());
		region.put("regionName", hubSc.getRegion().getRegionName());
		containerForecastWeek.setRegion(region);
		Map<String, Object> country = new HashMap<>();
		country.put("countryID", hubSc.getCountry().getCountryId());
		country.put("countryName", hubSc.getCountry().getCountryName());
		containerForecastWeek.setCountry(country);
		Map<String, Object> hub = new HashMap<>();
		hub.put("hubID", hubSc.getHubId());
		hub.put("hubCode", hubSc.getHubCode());
		containerForecastWeek.setHub(hub);
		containerForecastWeek.setCountry(country);
		containerForecastWeek.setDemandValues(weekDatas);
		containerForecastWeek.setWeekMetaData(weekMetaDatas);
		return containerForecastWeek;
	}

	public ContainerForecastWeek getForecast(Integer regionID, Integer countryID, Integer hubID, Integer weeks)
			throws CSafeServiceException {
		ContainerForecastWeek containerForecastWeek = new ContainerForecastWeek();
		HubSc hubSc = hubRepository.findById(hubID).get();// getHub(regionID,countryID,hubID);
		// List<Object[]> calMaster =
		// weeklyForecastRepository.getNextWeekDetails(weeks);
		List<WeekMetaData> weekMetaDatas = new ArrayList<>();
		List<WeekData> weekDatas = new ArrayList<>();
		SimpleDateFormat sm = new SimpleDateFormat("dd MMM yyyy");
		String startDateOfWeek = demandAllocationService.getStartDateOfAWeekForCurrentMonth();
		List<Object[]> forecastData = weeklyForecastRepository.getForecast(weeks, regionID, countryID, hubID,startDateOfWeek);
		int i = 1;
		for (Object[] object : forecastData) {
			if(object[2] == null)
				continue;
			WeekData weekData = new WeekData();
			WeekMetaData weekMetaData = new WeekMetaData();
			//weekData.setWeekNum(i);
			weekData.setWeekNum(Integer.parseInt(object[2].toString()));
			weekData.setWeekStartDate(sm.format((Date) object[1]));
			weekMetaData.setWeekNum(Integer.parseInt(object[2].toString()));
			weekMetaData.setWeekStartDate(weekData.getWeekStartDate());
			if (object[0] != null) {
				weekData.setValue(Math.round(Float.valueOf(object[0].toString())));
			} else
				weekData.setValue( 0);
			weekDatas.add(weekData);
			weekMetaDatas.add(weekMetaData);
			i++;
		}

		Map<String, Object> region = new HashMap<>();
		region.put("regionID", hubSc.getRegion().getRegionId());
		region.put("regionName", hubSc.getRegion().getRegionName());
		containerForecastWeek.setRegion(region);
		Map<String, Object> country = new HashMap<>();
		country.put("countryID", hubSc.getCountry().getCountryId());
		country.put("countryName", hubSc.getCountry().getCountryName());
		containerForecastWeek.setCountry(country);
		Map<String, Object> hub = new HashMap<>();
		hub.put("hubID", hubSc.getHubId());
		hub.put("hubCode", hubSc.getHubCode());
		containerForecastWeek.setHub(hub);
		containerForecastWeek.setCountry(country);
		containerForecastWeek.setDemandValues(weekDatas);
		containerForecastWeek.setWeekMetaData(weekMetaDatas);
		return containerForecastWeek;
	}

	public ContainerForecastWeeklyAdjustments getFogetWeeklyAdjustmentsrecast(Integer regionID, Integer countryID,
			Integer hubID, int weeks) throws CSafeServiceException {
		ContainerForecastWeeklyAdjustments adjustments = new ContainerForecastWeeklyAdjustments();
		HubSc hubSc = hubRepository.findById(hubID).get();// getHub(regionID, countryID, hubID);
		// List<Object[]> calMaster =
		// weeklyForecastRepository.getNextWeekDetails(weeks);
		List<WeekMetaData> weekMetaDatas = new ArrayList<>();
		List<WeekData> weekDatas = new ArrayList<>();
		SimpleDateFormat sm = new SimpleDateFormat("dd MMM yyyy");
		int i = 1;
		String startdateOfWeek = demandAllocationService.getStartDateOfAWeekForCurrentMonth();
		List<Object[]> oWeeklyAdjustmentsrecas = weeklyForecastRepository.getFogetWeeklyAdjustmentsrecast(regionID,
				countryID, hubID, weeks,startdateOfWeek);
		for (Object[] object : oWeeklyAdjustmentsrecas) {
			if(object[2] == null)
				continue;
			WeekData weekData = new WeekData();
			WeekMetaData weekMetaData = new WeekMetaData();
			//weekData.setWeekNum(i);
			weekData.setWeekNum(Integer.parseInt(object[2].toString()));
			weekData.setWeekStartDate(sm.format((Date) object[1]));
			weekMetaData.setWeekNum(Integer.parseInt(object[2].toString()));
			weekMetaData.setWeekStartDate(weekData.getWeekStartDate());
			if (object[0] != null) {
				weekData.setValue(Math.round(Float.valueOf(object[0].toString())));
			} else
				weekData.setValue(0);
			weekDatas.add(weekData);
			weekMetaDatas.add(weekMetaData);
			i++;
		}

		Map<String, Object> region = new HashMap<>();
		region.put("regionID", hubSc.getRegion().getRegionId());
		region.put("regionName", hubSc.getRegion().getRegionName());
		adjustments.setRegion(region);
		Map<String, Object> country = new HashMap<>();
		country.put("countryID", hubSc.getCountry().getCountryId());
		country.put("countryName", hubSc.getCountry().getCountryName());
		adjustments.setCountry(country);
		Map<String, Object> hub = new HashMap<>();
		hub.put("hubID", hubSc.getHubId());
		hub.put("hubCode", hubSc.getHubCode());
		adjustments.setHub(hub);
		adjustments.setCountry(country);
		adjustments.setAdjustmentValues(weekDatas);
		adjustments.setWeekMetaData(weekMetaDatas);
		return adjustments;
	}

	public boolean updateWeeklyAdjustments(ContainerForecastWeeklyAdjustments containerForecastWeek)
			throws CSafeServiceException {
		int regionId = (int) containerForecastWeek.getRegion().get("regionID");
		int countryId = (int) containerForecastWeek.getCountry().get("countryID");
		int hubId = (int) containerForecastWeek.getHub().get("hubID");
		HubSc hubSc = hubRepository.findById(hubId).get();// getHub(regionId, countryId, hubId);
		SimpleDateFormat sm = new SimpleDateFormat("dd MMM yyyy");
		containerForecastWeek.getAdjustmentValues().forEach((v) -> {
			try {

				WeeklyAdjustment adjustment = new WeeklyAdjustment();
				adjustment.setCountry(hubSc.getCountry());
				adjustment.setRegion(hubSc.getRegion());
				adjustment.setHub(hubSc);
				adjustment.setValue(v.getValue());
				adjustment.setWeekStartdate(sm.parse((v.getWeekStartDate())));
				adjustment.setCreatedDate(new Date());
				adjustment.setModifiedDate(new Date());
				adjustment.setFlag(1);
				Calendar cal = Calendar.getInstance();
				cal.setTime(sm.parse((v.getWeekStartDate())));
				int week = cal.get(Calendar.WEEK_OF_YEAR);
				adjustment.setWeek(week);
				weeklyForecastRepository.updateWeeklyAdjustments(regionId, countryId, hubId,
						sm.parse((v.getWeekStartDate())));
				adjustmentRepository.save(adjustment);

			} catch (ParseException e) {
				throw new CSafeServiceException(e.getMessage(), e.getCause());
			}
		});
		return true;
	}

	public ContainerForecastWeek getActuals(Integer regionID, Integer countryID, Integer hubID, int weeks)
			throws CSafeServiceException {
		ContainerForecastWeek containerForecastWeek = new ContainerForecastWeek();
		HubSc hubSc = hubRepository.findById(hubID).get();
		String hubCode = hubSc.getHubCode();
		// List<Object[]> calMaster =
		// weeklyForecastRepository.getNextWeekDetails(weeks);
		List<WeekMetaData> weekMetaDatas = new ArrayList<>();
		List<WeekData> weekDatas = new ArrayList<>();
		SimpleDateFormat sm = new SimpleDateFormat("dd MMM yyyy");
		int i = 1;
		String firstWeekDateOfMonth = demandAllocationService.getStartDateOfAWeekForCurrentMonth();
		List<Object[]> actuals = weeklyForecastRepository.getActuals(hubCode, weeks,firstWeekDateOfMonth);
		for (Object[] object : actuals) {
			if(object[2]==null)
				continue;
			WeekData weekData = new WeekData();
			WeekMetaData weekMetaData = new WeekMetaData();
			//weekData.setWeekNum(i);
			weekData.setWeekNum(Integer.parseInt(object[2].toString()));
			weekData.setWeekStartDate(sm.format((Date) object[1]));
			weekMetaData.setWeekNum(Integer.parseInt(object[2].toString()));
			weekMetaData.setWeekStartDate(weekData.getWeekStartDate());

			if (object[0] != null) {
					weekData.setValue(Math.round(Float.valueOf(object[0].toString())));
			} else
				weekData.setValue(0);
			weekDatas.add(weekData);
			weekMetaDatas.add(weekMetaData);
			i++;
		}

		Map<String, Object> region = new HashMap<>();
		region.put("regionID", hubSc.getRegion().getRegionId());
		region.put("regionName", hubSc.getRegion().getRegionName());
		containerForecastWeek.setRegion(region);
		Map<String, Object> country = new HashMap<>();
		country.put("countryID", hubSc.getCountry().getCountryId());
		country.put("countryName", hubSc.getCountry().getCountryName());
		containerForecastWeek.setCountry(country);
		Map<String, Object> hub = new HashMap<>();
		hub.put("hubID", hubSc.getHubId());
		hub.put("hubCode", hubSc.getHubCode());
		containerForecastWeek.setHub(hub);
		containerForecastWeek.setCountry(country);
		containerForecastWeek.setDemandValues(weekDatas);
		containerForecastWeek.setWeekMetaData(weekMetaDatas);
		return containerForecastWeek;
	}
}
