package com.genpact.cora.scm.service;

import java.util.Map;

import com.genpact.cora.scm.dto.BPDemandResponse;

public interface IContainerForecastService {
	
	public BPDemandResponse getBaselineDemand(int regionId, int countryId, int hubId, int months);
	public Map<Object, Object> getForecastData(int regionId, int hubId, int months);
}
