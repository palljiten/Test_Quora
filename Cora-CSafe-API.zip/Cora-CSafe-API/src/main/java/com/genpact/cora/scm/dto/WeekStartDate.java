package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class WeekStartDate implements Serializable {

	private static final long serialVersionUID = 1L;
	private String startDate;
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
}
