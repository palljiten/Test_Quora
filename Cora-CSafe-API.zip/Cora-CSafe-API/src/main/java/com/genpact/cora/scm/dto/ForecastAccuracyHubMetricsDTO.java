package com.genpact.cora.scm.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ForecastAccuracyHubMetricsDTO {
	private int hubId;
	private String hubCode;
	private Integer statistical;
	private Integer bpbased;
	private Integer aligned;
	private Integer consensus;
	
	public int getHubId() {
		return hubId;
	}
	public void setHubId(int hubId) {
		this.hubId = hubId;
	}
	public String getHubCode() {
		return hubCode;
	}
	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}
	public Integer getStatistical() {
		return statistical;
	}
	public void setStatistical(Integer statistical) {
		this.statistical = statistical;
	}
	public Integer getBpbased() {
		return bpbased;
	}
	public void setBpbased(Integer bpbased) {
		this.bpbased = bpbased;
	}
	public Integer getAligned() {
		return aligned;
	}
	public void setAligned(Integer aligned) {
		this.aligned = aligned;
	}
	public Integer getConsensus() {
		return consensus;
	}
	public void setConsensus(Integer consensus) {
		this.consensus = consensus;
	}
}
