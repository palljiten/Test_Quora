package com.genpact.cora.scm.dto;

public class ActivityDto {
	
	private Integer containerReviewPending;
	private Integer containerReviewCompleted;
	private Integer sparesReviewPending;
	private Integer sparesReviewCompleted;
	
	public Integer getContainerReviewPending() {
		return containerReviewPending;
	}
	public void setContainerReviewPending(Integer containerReviewPending) {
		this.containerReviewPending = containerReviewPending;
	}
	public Integer getContainerReviewCompleted() {
		return containerReviewCompleted;
	}
	public void setContainerReviewCompleted(Integer containerReviewCompleted) {
		this.containerReviewCompleted = containerReviewCompleted;
	}
	public Integer getSparesReviewPending() {
		return sparesReviewPending;
	}
	public void setSparesReviewPending(Integer sparesReviewPending) {
		this.sparesReviewPending = sparesReviewPending;
	}
	public Integer getSparesReviewCompleted() {
		return sparesReviewCompleted;
	}
	public void setSparesReviewCompleted(Integer sparesReviewCompleted) {
		this.sparesReviewCompleted = sparesReviewCompleted;
	}
}
