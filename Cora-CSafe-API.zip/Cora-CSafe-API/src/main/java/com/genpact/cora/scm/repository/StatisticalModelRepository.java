package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.genpact.cora.scm.entity.StatisticalModel;

public interface StatisticalModelRepository  extends JpaRepository<StatisticalModel, Integer>{
	
/*	@Query("select new com.genpact.cora.scm.dto.CustomForecastModel(sm.modelId, sm.modelName, st.techniqueName, swat.value, "
			+ "ssf.monthYear, ssf.forecastValue, ssfb.bestFitModel.modelId, ssfc.configuredModel.modelId) "
			+ "from StatisticalModel sm, StatisticalTechnique st, "
			+ "SparesStatisticalWeightedAvgTechnique swat, SparesStatisticalForecast ssf, "
			+ "SparesStatisticalForecastBestFit ssfb, SparesStatisticalForecastConfig ssfc "
			+ "WHERE ssf.model.modelId = sm.modelId AND swat.model.modelId = sm.modelId "
			+ "AND swat.technique.atId = st.atId AND ssfb.bestFitModel.modelId = sm.modelId "
			+ "AND ssf.hub.hubId = :hubId AND ssf.country.countryId = :countryId "
			+ "AND ssf.region.regionId = :regionId AND ssf.partId = :partId "
			+ "AND ssfc.configuredModel.modelId = sm.modelId AND (MONTH(GETDATE()) < DATEADD(mm, 6, GETDATE()))")
	List<CustomForecastModel> findForecastModels(@Param("regionId") int regionId, @Param("countryId") int countryId, 
			@Param("hubId") int hubId,  @Param("partId") String partId);*/

}
