package com.genpact.cora.scm.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"hubId","hubCode","hubData","parentShippers"})
public class DemandAllocationHub {
	
	@JsonProperty("hubId")
	private int hubId;
	
	@JsonProperty("hubCode")
	private String hubCode;
	
	@JsonProperty("hubData")
	private Map<String,Integer> hubData=new HashMap<>();
	
	@JsonProperty("parentShippers")
	private List<String> parentShippers=new ArrayList<>();
	
	
	private Map<String, Object> otherProperties = new HashMap<>();
	
	public int getHubId() {
		return hubId;
	}

	public void setHubId(int hubId) {
		this.hubId = hubId;
	}

	public String getHubCode() {
		return hubCode;
	}

	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}

	public List<String> getParentShippers() {
		return parentShippers;
	}

	public void setParentShippers(List<String> parentShippers) {
		this.parentShippers = parentShippers;
	}

	public Map<String, Integer> getHubData() {
		return hubData;
	}

	public void setHubData(Map<String, Integer> hubData) {
		this.hubData = hubData;
	}

	@JsonAnyGetter
	public Map<String, Object> any() {
		return otherProperties;
	}

	@JsonAnySetter
	public void set(Map<String, Object> value) {
		this.otherProperties = value;
	}
}
