/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.io.Serializable;

/**
 * @author 703158077
 *
 */
public class InventoryPCCSubmitDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543222L;
	
	private Integer hubId;

	private String LeadTime;
	private String SafetyRequired;
	private String ServiceLevel;
	private String SKURequired;
	
	
	
	
	/**
	 * @return the hubId
	 */
	public Integer getHubId() {
		return hubId;
	}
	/**
	 * @param hubId the hubId to set
	 */
	public void setHubId(Integer hubId) {
		this.hubId = hubId;
	}
	/**
	 * @return the leadTime
	 */
	public String getLeadTime() {
		return LeadTime;
	}
	/**
	 * @param leadTime the leadTime to set
	 */
	public void setLeadTime(String leadTime) {
		LeadTime = leadTime;
	}
	/**
	 * @return the safetyRequired
	 */
	public String getSafetyRequired() {
		return SafetyRequired;
	}
	/**
	 * @param safetyRequired the safetyRequired to set
	 */
	public void setSafetyRequired(String safetyRequired) {
		SafetyRequired = safetyRequired;
	}
	/**
	 * @return the serviceLevel
	 */
	public String getServiceLevel() {
		return ServiceLevel;
	}
	/**
	 * @param serviceLevel the serviceLevel to set
	 */
	public void setServiceLevel(String serviceLevel) {
		ServiceLevel = serviceLevel;
	}
	/**
	 * @return the sKURequired
	 */
	public String getSKURequired() {
		return SKURequired;
	}
	/**
	 * @param sKURequired the sKURequired to set
	 */
	public void setSKURequired(String sKURequired) {
		SKURequired = sKURequired;
	}
	
	

}
