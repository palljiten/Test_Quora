package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_master_Calendar]")
public class MasterCalendar {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id", unique = true, nullable = false)
	private int id;
	@Column(name ="Date")
	private Date date;
	@Column(name = "WeekOfYear")
	private int weekOfTheYear;
	@Column(name = "WeekstartDate")
	private Date weekStartDate;
	
	public int getId() {
		return id;
	}
	/**
	 * @return the weekStartDate
	 */
	public Date getWeekStartDate() {
		return weekStartDate;
	}
	/**
	 * @param weekStartDate the weekStartDate to set
	 */
	public void setWeekStartDate(Date weekStartDate) {
		this.weekStartDate = weekStartDate;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getWeekOfTheYear() {
		return weekOfTheYear;
	}
	public void setWeekOfTheYear(int weekOfTheYear) {
		this.weekOfTheYear = weekOfTheYear;
	}

}
