package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.SparesStatisticalForecast;

public interface SparesStatisticalForecastRepository extends JpaRepository<SparesStatisticalForecast, Integer>{
	
	@Query("SELECT f FROM SparesStatisticalForecast f "
			+ "WHERE (MONTH(CURRENT_DATE()) < DATEADD(mm, :months, CURRENT_DATE()) AND flag=1 "
			+ "AND f.hub.hubId = :hubId AND f.country.countryId = :countryId "
			+ "AND f.region.regionId = :regionId AND f.model.modelId = :modelId AND f.partId = :partId)")
	public List<SparesStatisticalForecast> getSparesStatisticalForecast(@Param("regionId") int regionId, 
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId, 
			@Param("modelId") int modelId, @Param("months") int months);
	
	@Query("SELECT f FROM SparesStatisticalForecast f "
			+ "WHERE flag=1 AND f.hub.hubId = :hubId AND f.country.countryId = :countryId "
			+ "AND f.region.regionId = :regionId AND f.partId = :partId AND f.model.modelId = :modelId AND f.monthYear IN (:myList)")
	public List<SparesStatisticalForecast> getSparesStatisticalForecast1(@Param("regionId") int regionId, 
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId, 
			@Param("myList") List<String> myList, @Param("modelId") int modelId);
	
	@Modifying
    @Query("UPDATE SparesStatisticalForecast spv SET spv.flag = 0 "
    		+ "WHERE spv.flag=1 AND spv.model.modelId = :modelId AND spv.hub.hubId = :hubId AND spv.country.countryId = :countryId "
    		+ "AND spv.region.regionId = :regionId AND spv.partId = :partId AND spv.monthYear = :monthYear")
    int updateExistingRecord(@Param("modelId") int modelId, @Param("regionId") int regionId, @Param("countryId") int countryId, 
    		@Param("hubId") int hubId, @Param("partId") String partId, @Param("monthYear") String monthYear);
}