package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

public class FinalDemandForecastResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	private Set<String> weekMetaData;
	private Map<String,WeekStartDate> values;
	private Map<String,Integer> finalDemandForecast;
	
	public Set<String> getWeekMetaData() {
		return weekMetaData;
	}
	public void setWeekMetaData(Set<String> weekMetaData) {
		this.weekMetaData = weekMetaData;
	}
	public Map<String, WeekStartDate> getValues() {
		return values;
	}
	public void setValues(Map<String, WeekStartDate> values) {
		this.values = values;
	}
	public Map<String,Integer> getFinalDemandForecast() {
		return finalDemandForecast;
	}
	public void setFinalDemandForecast(Map<String,Integer> finalDemandForecast) {
		this.finalDemandForecast = finalDemandForecast;
	}
	
}
