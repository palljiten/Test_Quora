package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.VABalanceInHand;

public interface VABalanceInHandRepository extends JpaRepository<VABalanceInHand, Integer> {
	
	@Query("Select Sum(balanceInHand) as totalBalance From VABalanceInHand Where weekNo=:weekNo and code=:hubCode")
	public Float getCurrentInventoryStatus(@Param("weekNo") String weekNo,@Param("hubCode") String hubCode);
	
	@Query(value = "select distinct top(14)  DATEPART(wk,Date) as weekNum, DATEPART(year,Date) as year," + 
						"WeekstartDate as wsdt,WeekendDate as wedt from tbl_master_Calendar where " + 
						"(:firstWeekDateOfMonth < DATEADD(wk,14, :firstWeekDateOfMonth) and Date > :firstWeekDateOfMonth) " + 
						"order by  DATEPART(year,Date),DATEPART(wk,Date) asc", nativeQuery = true)
	public List<Object[]> getThirteenWeeksDetail(@Param("firstWeekDateOfMonth") String firstWeekDateOfMonth);
}
