package com.genpact.cora.scm.dto;

public class BaselinePercentageAdjustment {

	private int monthValue; 
	private String month; 
	private int year; 
	private float percentage;
	
	public int getMonthValue() {
		return monthValue;
	}
	
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
	
	public String getMonth() {
		return month;
	}
	
	public void setMonth(String month) {
		this.month = month;
	}
	
	public int getYear() {
		return year;
	}
	
	public void setYear(int year) {
		this.year = year;
	}
	
	public float getPercentage() {
		return percentage;
	}
	
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

}
