package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.genpact.cora.scm.entity.HubSc;

public class CountryDetail implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String countryName;
	private int countryId;
	private Set<String> hubList = new TreeSet<>();
	private List<HubSc> hubDetails = new ArrayList<>();
	
	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public Set<String> getHubList() {
		return hubList;
	}

	public void setHubList(Set<String> hubList) {
		this.hubList = hubList;
	}

	public List<HubSc> getHubDetails() {
		return hubDetails;
	}

	public void setHubDetails(List<HubSc> hubDetails) {
		this.hubDetails = hubDetails;
	}
	
}
