package com.genpact.cora.scm.controller;

import java.time.LocalDate;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.core.config.plugins.validation.constraints.Required;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.BalanceInHandDto;
import com.genpact.cora.scm.dto.RepairEnd;
import com.genpact.cora.scm.dto.RepairEndData;
import com.genpact.cora.scm.dto.ResolvedIssuesDto;
import com.genpact.cora.scm.dto.VAInboundData;
import com.genpact.cora.scm.dto.VALeaseEndData;
import com.genpact.cora.scm.dto.VARepairData;
import com.genpact.cora.scm.entity.ResolvedIssues;
import com.genpact.cora.scm.entity.SpareParts;
import com.genpact.cora.scm.entity.VABalanceInHand;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.RepairWorkOrderPartsService;
import com.genpact.cora.scm.service.VAInboundRepairService;
import com.genpact.cora.scm.service.VisibilityHotBoardService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "scm")
@Api(tags = { "Visibility HotBoard" })
public class VisibilityHotBoardController {

	private static Logger logger = LoggerFactory.getLogger(VisibilityHotBoardController.class);

	@Autowired
	VisibilityHotBoardService visibilityHotBoardService;

	@Autowired
	VAInboundRepairService vair;
	@Autowired
	RepairWorkOrderPartsService rwops;

	@GetMapping(value = "/hotBoard", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves hotboard data")
	public ResponseEntity<Object> getHotBoardData() {
		Map<String, Object> hotBoardData = null;
		try
		{
			hotBoardData = visibilityHotBoardService.getHotBoardData();
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getHotBoardData in VisibilityHotBoardController :",
					e.getCause());
		}

		return new ResponseEntity<>(hotBoardData, HttpStatus.OK);
	}

	@GetMapping(value = "/hotBoard/inbound", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves inbound hotboard data")
	public ResponseEntity<Object> getInboundHotBoardData() {
		List<VAInboundData> inboundData = null;
		try
		{
			inboundData = visibilityHotBoardService.getInboundHotBoard();
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getInboundHotBoardData in VisibilityHotBoardController :",
					e.getCause());
		}

		return new ResponseEntity<>(inboundData, HttpStatus.OK);
	}

	@GetMapping(value = "/hotBoard/leaseEnd", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves LeaseEnd hotboard data")
	public ResponseEntity<Object> getLeaseEndHotBoardData() {

		List<VALeaseEndData> leaseData = null;
		try
		{
			leaseData = visibilityHotBoardService.getLeaseEndHotBoard();
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getLeaseEndHotBoardData in VisibilityHotBoardController :",
					e.getCause());
		}

		return new ResponseEntity<>(leaseData, HttpStatus.OK);
	}

	@GetMapping(value = "/hotBoard/repair", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves repair hotboard and analyse data on the basis of Alert Description")
	public ResponseEntity<Object> getRepairHotBoardData(@RequestParam(value= "serialNumber" , required=false) String serialNumber,@RequestParam(value = "alertDesc" , required = false) String alertDesc) {
		// VARepairData repairData = new VARepairData();
		List<VARepairData> repairData = null;
		try
		{ 
			if( serialNumber == null) {
				
				repairData = visibilityHotBoardService.getRepairHotBoardData();
			return new ResponseEntity<>(repairData, HttpStatus.OK);
			
			}
			
			else if( serialNumber != null )  {

				List<RepairEndData> repairAnalyseData = visibilityHotBoardService.getRepairEndAnalyseData(serialNumber, alertDesc);

				return new ResponseEntity<>(repairAnalyseData, HttpStatus.OK);

			}
			
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getRepairHotBoardData in VisibilityHotBoardController :",
					e.getCause());
		}

		return new ResponseEntity<>("Inaapropriate Selection", HttpStatus.OK);
	}

	@GetMapping(value = "/hotBoard/spareParts", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves spareParts  data")
	public ResponseEntity<Object> getSpareParts() {
		List<SpareParts> listSparePart = null;
		try
		{
			listSparePart = visibilityHotBoardService.getSpareParts();

		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getSpareParts in VisibilityHotBoardController :",
					e.getCause());
		}
		return new ResponseEntity<>(listSparePart, HttpStatus.OK);

	}

	@GetMapping(value = "/hotBoard/balanceInHand", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves balanceInHand  data")
	public ResponseEntity<Object> getbalanceInHand() {
		List<BalanceInHandDto> listSparePart = null;
		try 
		{
			listSparePart = visibilityHotBoardService.getBalanceInHand();
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getbalanceInHand in VisibilityHotBoardController :",
					e.getCause());
		}
		return new ResponseEntity<>(listSparePart, HttpStatus.OK);

	}

	@GetMapping(value = "/hotBoard/resolvedIssues", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Resolved Issues  data")
	public ResponseEntity<Object> getResolvedIssues() {
		List<ResolvedIssuesDto> listSparePart = null;
		try
		{
			listSparePart = visibilityHotBoardService.getResolvedIssues();
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getResolvedIssues in VisibilityHotBoardController :",
					e.getCause());
		}
		return new ResponseEntity<>(listSparePart, HttpStatus.OK);

	}

	@GetMapping(value = "/hotBoard/analyze/", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves analyze data for LeaseEnd , RepairEnd or Repositioning based on the selection")
	public ResponseEntity<Object> getAnalyzerValue(@RequestParam(value = "serialNumber") String serialNumber,
			@RequestParam(value = "status", required = false) String status, @RequestParam(value = "alertDesc" , required = false) String alertDesc) {

		try
		{
			if (null != status && status.equalsIgnoreCase("leaseEnd")) {

				Map<String, Object> leaseEndMap = visibilityHotBoardService.getLeaseEndDetails(serialNumber);
				return new ResponseEntity<>(leaseEndMap, HttpStatus.OK);

			} else if (null != status && status.equalsIgnoreCase("repositioning")) {

				Map<String, Object> repositionData = visibilityHotBoardService.getRepositioningData(serialNumber);
				return new ResponseEntity<>(repositionData, HttpStatus.OK);

			} else if (null != status && status.equalsIgnoreCase("repairEnd")) {

				List<RepairEndData> repairEndData = visibilityHotBoardService.getRepairEndAnalyseData(serialNumber, alertDesc);

				return new ResponseEntity<>(repairEndData, HttpStatus.OK);

			}

		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during fetching data for getAnalyzerValue in VisibilityHotBoardController :",
					e.getCause());
		}
		return new ResponseEntity<>("Wrong selection", HttpStatus.OK);
	}

	@GetMapping(value = "/hotBoard/filter/", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Applies filter option conditions on HotBoard modules")
	public ResponseEntity<Object> getHotBoardFilterData(@RequestParam("visibilityType") String visibilityType,
			  @RequestParam(name ="startDate yyyy-MM-dd",required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE ,pattern="yyyy-MM-dd") Date startDate ,
	        @RequestParam(name ="endDate yyyy-MM-dd", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE ,pattern="yyyy-MM-dd") Date endDate  ) {

		Map<String, Object> filterData = new LinkedHashMap<String, Object>();
		if ( visibilityType.equalsIgnoreCase(visibilityType)) {

			filterData = visibilityHotBoardService.getVisibilityHotBoardFilter(visibilityType,startDate,endDate);
			
		}
		return new ResponseEntity<>(filterData, HttpStatus.OK);
	}

}
