package com.genpact.cora.scm.repository;


import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public class IDemandAllocationForecastSP {

	@PersistenceContext
	private EntityManager entityManager;

	public void DemandAllocationForecastSP(@Param("InpParam") String InpParam) {
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery("DemandAllocationForecastSP");
			query.registerStoredProcedureParameter("InpParam", String.class, ParameterMode.IN);
			query.setParameter("InpParam", InpParam);
			query.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
} 
