package com.genpact.cora.scm.service;

import java.util.Comparator;

import com.genpact.cora.scm.dto.MonthYearDataUnit;

public class SparesForecastMonthValueComparator implements Comparator<MonthYearDataUnit> 
{ 
    // Used for sorting in ascending order of month value
	public int compare(MonthYearDataUnit a, MonthYearDataUnit b) 
    { 
        return a.getMonthValue() - b.getMonthValue();
    } 
}  