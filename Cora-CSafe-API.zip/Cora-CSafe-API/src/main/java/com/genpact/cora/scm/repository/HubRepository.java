package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.HubSc;

public interface HubRepository extends JpaRepository<HubSc, Integer> {

	@Query("select h from HubSc h left join fetch h.region left join fetch h.country")
	public List<HubSc> getAllHubs();

	@Query("select h from HubSc h where h.region.regionId=:regionId and h.country.countryId=:countryID and h.hubId=:hubId")
	public HubSc getHub(@Param("regionId") Integer regionID, @Param("countryID") Integer countryID,
			@Param("hubId") Integer hubID);
}
