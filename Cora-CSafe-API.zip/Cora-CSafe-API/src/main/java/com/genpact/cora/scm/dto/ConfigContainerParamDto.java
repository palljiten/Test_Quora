package com.genpact.cora.scm.dto;

import java.io.Serializable;

import com.genpact.cora.scm.validation.MonthNameEnum;

public class ConfigContainerParamDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	//Safety Stock
	private String isSafetyRequired;
	private int minSafetyStock;
	private float serviceLevelRequired;
	
	//Scopping Criteria
	private String isSKUReuired;
	
	//Supply constrain Information
	private int minOrderQuantiy;
	private int maxOrderQuantiy;
	private int fixedOrderQuantiy;
	private int numberOfDays;
	
	private int reviewFrequency;
	private int nextReplenishmentNumber;
	
	//forcast Run Rate;
	private MonthNameEnum forcastRunRate; //e.g. Jan, Feb etc.
	
	//Confirmed Future Order
	
	private MonthNameEnum confirmFutureOrder; //e.g. Jan, Feb etc.

	public String getIsSafetyRequired() {
		return isSafetyRequired;
	}

	public void setIsSafetyRequired(String isSafetyRequired) {
		this.isSafetyRequired = isSafetyRequired;
	}

	public int getMinSafetyStock() {
		return minSafetyStock;
	}

	public void setMinSafetyStock(int minSafetyStock) {
		this.minSafetyStock = minSafetyStock;
	}

	public float getServiceLevelRequired() {
		return serviceLevelRequired;
	}

	public void setServiceLevelRequired(float serviceLevelRequired) {
		this.serviceLevelRequired = serviceLevelRequired;
	}

	public String getIsSKUReuired() {
		return isSKUReuired;
	}

	public void setIsSKUReuired(String isSKUReuired) {
		this.isSKUReuired = isSKUReuired;
	}

	public int getMinOrderQuantiy() {
		return minOrderQuantiy;
	}

	public void setMinOrderQuantiy(int minOrderQuantiy) {
		this.minOrderQuantiy = minOrderQuantiy;
	}

	public int getMaxOrderQuantiy() {
		return maxOrderQuantiy;
	}

	public void setMaxOrderQuantiy(int maxOrderQuantiy) {
		this.maxOrderQuantiy = maxOrderQuantiy;
	}

	public int getFixedOrderQuantiy() {
		return fixedOrderQuantiy;
	}

	public void setFixedOrderQuantiy(int fixedOrderQuantiy) {
		this.fixedOrderQuantiy = fixedOrderQuantiy;
	}

	public int getNumberOfDays() {
		return numberOfDays;
	}

	public void setNumberOfDays(int numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

	public int getReviewFrequency() {
		return reviewFrequency;
	}

	public void setReviewFrequency(int reviewFrequency) {
		this.reviewFrequency = reviewFrequency;
	}

	public int getNextReplenishmentNumber() {
		return nextReplenishmentNumber;
	}

	public void setNextReplenishmentNumber(int nextReplenishmentNumber) {
		this.nextReplenishmentNumber = nextReplenishmentNumber;
	}

	public MonthNameEnum getForcastRunRate() {
		return forcastRunRate;
	}

	public void setForcastRunRate(MonthNameEnum forcastRunRate) {
		this.forcastRunRate = forcastRunRate;
	}

	public MonthNameEnum getConfirmFutureOrder() {
		return confirmFutureOrder;
	}

	public void setConfirmFutureOrder(MonthNameEnum confirmFutureOrder) {
		this.confirmFutureOrder = confirmFutureOrder;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
