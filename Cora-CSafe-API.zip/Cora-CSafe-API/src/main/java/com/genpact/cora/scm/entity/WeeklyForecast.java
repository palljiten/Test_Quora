package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_WeeklyForecast]")
public class WeeklyForecast {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private Integer Id;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RegionID")
	private Region region;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CountryID")
	private Country country;
    
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HubID")
    private HubSc hub;
    
    @Column(name = "WeekNumber", nullable = false)
    private Integer forecastWeek;
    
    @Column(name="WeeklyForecast",nullable=false)
    private float forecastValue;
    
    @Column(name="SCMYearWeek")
    private Integer sCMYearWeek;
    
    @Column(name="CreatedMonth")
    private String createdMonth;
    
    @Column(name="MonthYear")
    private String monthYear;
    
    @Column(name="Year")
    private Integer year;
    
    @Column(name="FinalWeekly")
    private float finalWeekly;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CreatedDate", nullable = true)
    private Date createdDate;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ModifiedDate", nullable = true)
    private Date modifiedDate;
    
    @Column(name = "Flag", nullable = false)
    private Integer flag;
    
    
	public WeeklyForecast(Integer forecastWeek, float finalWeekly, Date createdDate) {
		super();
		this.forecastWeek = forecastWeek;
		this.finalWeekly = finalWeekly;
		this.createdDate = createdDate;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}

	public Integer getForecastWeek() {
		return forecastWeek;
	}

	public void setForecastWeek(Integer forecastWeek) {
		this.forecastWeek = forecastWeek;
	}

	public float getForecastValue() {
		return forecastValue;
	}

	public void setForecastValue(float forecastValue) {
		this.forecastValue = forecastValue;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	public Integer getsCMYearWeek() {
		return sCMYearWeek;
	}

	public void setsCMYearWeek(Integer sCMYearWeek) {
		this.sCMYearWeek = sCMYearWeek;
	}

	public String getCreatedMonth() {
		return createdMonth;
	}

	public void setCreatedMonth(String createdMonth) {
		this.createdMonth = createdMonth;
	}

	public String getMonthYear() {
		return monthYear;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public float getFinalWeekly() {
		return finalWeekly;
	}

	public void setFinalWeekly(float finalWeekly) {
		this.finalWeekly = finalWeekly;
	}
}
