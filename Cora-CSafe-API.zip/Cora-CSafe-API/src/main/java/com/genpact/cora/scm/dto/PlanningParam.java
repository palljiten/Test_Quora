package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class PlanningParam implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private float CovCapping;//In percentage
	private String supplyVariability; 
	private int numberDays;
	private float carringCost;//In percentage
	private float oreringCost;
	private int leadTimeDays;//5 or 7 days
	private int workDaysInYear;
	private int monthsForPlanning;
	
	public float getCovCapping() {
		return CovCapping;
	}
	public void setCovCapping(float covCapping) {
		CovCapping = covCapping;
	}
	public String getSupplyVariability() {
		return supplyVariability;
	}
	public void setSupplyVariability(String supplyVariability) {
		this.supplyVariability = supplyVariability;
	}
	public int getNumberDays() {
		return numberDays;
	}
	public void setNumberDays(int numberDays) {
		this.numberDays = numberDays;
	}
	public float getCarringCost() {
		return carringCost;
	}
	public void setCarringCost(float carringCost) {
		this.carringCost = carringCost;
	}
	public float getOreringCost() {
		return oreringCost;
	}
	public void setOreringCost(float oreringCost) {
		this.oreringCost = oreringCost;
	}
	public int getLeadTimeDays() {
		return leadTimeDays;
	}
	public void setLeadTimeDays(int leadTimeDays) {
		this.leadTimeDays = leadTimeDays;
	}
	public int getWorkDaysInYear() {
		return workDaysInYear;
	}
	public void setWorkDaysInYear(int workDaysInYear) {
		this.workDaysInYear = workDaysInYear;
	}
	public int getMonthsForPlanning() {
		return monthsForPlanning;
	}
	public void setMonthsForPlanning(int monthsForPlanning) {
		this.monthsForPlanning = monthsForPlanning;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
