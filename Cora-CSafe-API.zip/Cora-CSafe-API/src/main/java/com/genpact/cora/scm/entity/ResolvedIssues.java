package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_VAResolvedIssue]") 
public class ResolvedIssues {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
	private Integer id;
	
	@Column(name = "SerialNumber", nullable = true)
	private String SerialNumber;
	
	@Column(name = "Status", nullable = true)
	private String status;
	
	@Column(name = "Origin", nullable = true)
	private String origin;
	
	@Column(name = "Destination", nullable = true)
	private String Destination;
	
	@Column(name = "AlertDescription", nullable = true)
	private String AlertDescription;
	
	@Column(name = "WeekNo", nullable = true)
	private String Week;
	
	@Column(name = "NotificationDate", nullable = true)
    private Date notificationDate;
	
	@Column(name = "EstimatedReceivingDate", nullable = true)
	private Date estimatedReceivingDate;
	
	@Column(name = "ActualReceivingDate", nullable = true)
	private Date actualReceivingDate;	
	
	@Column(name = "DueDate", nullable = true)
	private Date dueDate;
	
	@Column(name = "CreatedDate", nullable = true)
	private Date createDate;
	
	@Column(name = "ModifiedDate", nullable = true)
	private Date modifiedDate;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSerialNumber() {
		return SerialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		SerialNumber = serialNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		status = status;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		origin = origin;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public String getAlertDescription() {
		return AlertDescription;
	}
	public void setAlertDescription(String alertDescription) {
		AlertDescription = alertDescription;
	}
	public String getWeek() {
		return Week;
	}
	public void setWeek(String week) {
		Week = week;
	}
	public Date getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	public Date getEstimatedReceivingDate() {
		return estimatedReceivingDate;
	}
	public void setEstimatedReceivingDate(Date estimatedReceivingDate) {
		this.estimatedReceivingDate = estimatedReceivingDate;
	}
	public Date getActualReceivingDate() {
		return actualReceivingDate;
	}
	public void setActualReceivingDate(Date actualReceivingDate) {
		this.actualReceivingDate = actualReceivingDate;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
}
