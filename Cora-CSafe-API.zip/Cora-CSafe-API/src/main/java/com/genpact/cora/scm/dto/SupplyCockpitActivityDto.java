/**
 * 
 */
package com.genpact.cora.scm.dto;

/**
 * @author 703158077
 *
 */
public class SupplyCockpitActivityDto {

	private Integer containerCompleted; 
	private Integer containerPending;
	private Integer sparesCompleted;
	private Integer sparesPending;
	
	
	
	/**
	 * @return the containerCompleted
	 */
	public Integer getContainerCompleted() {
		return containerCompleted;
	}
	/**
	 * @param containerCompleted the containerCompleted to set
	 */
	public void setContainerCompleted(Integer containerCompleted) {
		this.containerCompleted = containerCompleted;
	}
	/**
	 * @return the containerPending
	 */
	public Integer getContainerPending() {
		return containerPending;
	}
	/**
	 * @param containerPending the containerPending to set
	 */
	public void setContainerPending(Integer containerPending) {
		this.containerPending = containerPending;
	}
	/**
	 * @return the sparesCompleted
	 */
	public Integer getSparesCompleted() {
		return sparesCompleted;
	}
	/**
	 * @param sparesCompleted the sparesCompleted to set
	 */
	public void setSparesCompleted(Integer sparesCompleted) {
		this.sparesCompleted = sparesCompleted;
	}
	/**
	 * @return the sparesPending
	 */
	public Integer getSparesPending() {
		return sparesPending;
	}
	/**
	 * @param sparesPending the sparesPending to set
	 */
	public void setSparesPending(Integer sparesPending) {
		this.sparesPending = sparesPending;
	}
	
	
	
}
