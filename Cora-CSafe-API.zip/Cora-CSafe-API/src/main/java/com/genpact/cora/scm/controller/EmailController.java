package com.genpact.cora.scm.controller;

import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.email.EmailConfigurationRequest;
import com.genpact.cora.scm.email.EmailRequest;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.EmailService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "scm")
@Api(tags = { "Email" })
public class EmailController {

	private static Logger logger = LoggerFactory.getLogger(EmailController.class);
	
	@Autowired
	EmailService emailService;
	
	@GetMapping(value = "/alertConfigarion", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get email alert configuration data")
	public ResponseEntity<Object> getEmailAlertConfigurationData(@RequestParam String hubName, @RequestParam String kpi) {
		logger.info("EmailController: Entering getEmailAlertConfigurationData() method");
		Map<String, Object> responseMap = null;
		try 
		{
			responseMap = emailService.getEmailAlertConfigurationData(hubName, kpi.toUpperCase());
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			CSafeApiException cae = new CSafeApiException(
					"API error occured during fetching email alert configuration in EmailController :",
					e.getCause());
			cae.setStatus(e.getStatus());
			throw cae;
		}
		
		logger.info("EmailController: Exiting getEmailAlertConfigurationData() method");
		return new ResponseEntity<>(responseMap, HttpStatus.OK);
	}
	
	@PostMapping(value = "/alertConfigarion", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Save email alert configuration data")
	public ResponseEntity<Object> saveEmailAlertConfigurationData(@Valid @RequestBody EmailConfigurationRequest configurationData) {
		logger.info("EmailController: Entering saveEmailAlertConfigurationData() method");
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		try 
		{
			emailService.saveEmailAlertConfigurationData(configurationData);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			CSafeApiException cae = new CSafeApiException(
					"API error occured during saving email alert configuration in EmailController :",
					e.getCause());
			cae.setStatus(e.getStatus());
			throw cae;
		}
		
		logger.info("EmailController: Exiting saveEmailAlertConfigurationData() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}
	
	@GetMapping(value = "/emailAlertContent/container", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get email content")
	public ResponseEntity<Object> getContainerEmailContent(@RequestParam String serialNumber, @RequestParam String status, @RequestParam(defaultValue = "false") boolean isLeaseEndHotboard) {
		logger.info("EmailController: Entering getEmailContent() method");
		Map<String, Object> responseMap = null;
		try 
		{
			responseMap = emailService.getEmailContent(serialNumber, status,  isLeaseEndHotboard);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			CSafeApiException cae = new CSafeApiException(
					"API error occured during fetching mail content in EmailController :",
					e.getCause());
			cae.setStatus(e.getStatus());
			throw cae;
		}
		
		logger.info("EmailController: Exiting getEmailContent() method");
		return new ResponseEntity<>(responseMap, HttpStatus.OK);
	}
	
	@PostMapping(value = "/email", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Send email")
	public ResponseEntity<Object> sendEmail(@Valid @RequestBody EmailRequest emailRequest) {
		logger.info("EmailController: Entering sendEmail() method");
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		try 
		{
			boolean isSuccess = emailService.sendMail(emailRequest);
			if (!isSuccess) {
				s.setStatus("FAILURE");
			}
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			CSafeApiException cae = new CSafeApiException(
					"API error occured during sending alert email in EmailController :",
					e.getCause());
			cae.setStatus(e.getStatus());
			throw cae;
		}
		
		logger.info("EmailController: Exiting sendEmail() method");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}
}
