package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.VALeaseEnd;

public interface LeaseEndHotBoardRepository extends JpaRepository<VALeaseEnd, Integer>{
	@Query("SELECT notificationDate, estimatedReceivingDate, actualReceivingDate, origin, destination FROM VALeaseEnd where serialNumber = :serialNumber") 
    public List<Object[]> findLeaseEndDetailsBySerialNumber(@Param("serialNumber") String serialNumber);
    
    
    @Query(value = "select distinct [SerialNumber],[Status],[Origin],[Destination],[AlertDescription],weekno,[DueDate],[NotificationDate], " + 
    		"[EstimatedReceivingDate],[ActualReceivingdate],[AlertType] from [dbo].[tbl_VALeaseEnd] A\r\n" + 
    		"   LEFT JOIN tbl_master_Calendar B ON (CONVERT(DATE,A.duedate) =CONVERT(DATE,B.Date)) \r\n" + 
    		"   where B.WeekstartDate >= (SELECT WeekStartdate FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE())) " + 
    		"   AND B.WeekstartDate<=(SELECT DATEADD(Day,21,WeekStartdate) FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE())) " ,nativeQuery = true)
    public List<Object[]> getLeaseEndHotBoardData();
    
 // temorary fix  query .... commented because of QA testing only need to be reverted back once get proper data
    
/*    @Query(value = "  select distinct [SerialNumber],[Status],[Origin],[Destination],[AlertDescription],weekno,[DueDate],[NotificationDate],  \r\n" + 
    		"    [EstimatedReceivingDate],[ActualReceivingdate],[AlertType] from [dbo].[tbl_VALeaseEnd] where\r\n" + 
    		"  weekno  between '2018-48' and '2018-51' " ,nativeQuery = true)
    	public List<Object[]> getLeaseEndHotBoardData();*/ 
}
