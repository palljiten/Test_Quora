/**
 * 
 */
package com.genpact.cora.scm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.RepairEnd;
import com.genpact.cora.scm.entity.VAInboundRepairEnd;

/**
 * @author 703158077
 *
 */
public interface VAInboundRepairRepository extends JpaRepository<VAInboundRepairEnd, Integer>  {

	
	@Query("Select v from VAInboundRepairEnd v where v.serialNumber = :serialNumber")
	public RepairEnd findbySerialNumber(@Param("serialNumber") String serialNumber);
}
