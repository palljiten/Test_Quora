/**
 * 
 */
package com.genpact.cora.scm.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.genpact.cora.scm.dto.ActivityDto;
import com.genpact.cora.scm.dto.ForecastAccuracyChartDTO;
import com.genpact.cora.scm.dto.ForecastAccuracyMetricsDTO;
import com.genpact.cora.scm.dto.ForecastAccuracyMetricsSixMonthsDTO;
import com.genpact.cora.scm.dto.ForecastAccuracyPercentageDTO;
import com.genpact.cora.scm.dto.ForecastAccuracyPercentageData;
import com.genpact.cora.scm.dto.ForecastAccuracyRegionMetricsDTOWrapper;
import com.genpact.cora.scm.dto.ForecastExceptionDto;
import com.genpact.cora.scm.dto.ForecastWaterfallContainer;
import com.genpact.cora.scm.dto.MonthDataUnit;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.GenericSPCaller;
import com.genpact.cora.scm.validation.ContainerSparesTypeEnum;

/**
 * @author 703158077
 *
 */
@Service
public class DemandCockpitService {
	
	private static Logger logger = LoggerFactory.getLogger(DemandCockpitService.class);
	private static Map<Integer, String> monthValueMap = new HashMap<>();
	private static Map<String, Integer> monthValueReverseMap = new HashMap<>();
	
	@Autowired
	private GenericSPCaller spCaller;
	
	static {
		monthValueMap.put(0, "Jan");
		monthValueMap.put(1, "Feb");
		monthValueMap.put(2, "Mar");
		monthValueMap.put(3, "Apr");
		monthValueMap.put(4, "May");
		monthValueMap.put(5, "Jun");
		monthValueMap.put(6, "Jul");
		monthValueMap.put(7, "Aug");
		monthValueMap.put(8, "Sep");
		monthValueMap.put(9, "Oct");
		monthValueMap.put(10, "Nov");
		monthValueMap.put(11, "Dec");
		
		monthValueReverseMap.put("Jan", 0);
		monthValueReverseMap.put("Feb", 1);
		monthValueReverseMap.put("Mar", 2);
		monthValueReverseMap.put("Apr", 3);
		monthValueReverseMap.put("May", 4);
		monthValueReverseMap.put("Jun", 5);
		monthValueReverseMap.put("Jul", 6);
		monthValueReverseMap.put("Aug", 7);
		monthValueReverseMap.put("Sep", 8);
		monthValueReverseMap.put("Oct", 9);
		monthValueReverseMap.put("Nov", 10);
		monthValueReverseMap.put("Dec", 11);
	}

	public static void main(String[] args) {
		DemandCockpitService ds = new DemandCockpitService();
		System.out.println(ds.getMonthList());
	}
	
	public ActivityDto getCockpitActivity(Integer activityId){
		ActivityDto activityDto = new ActivityDto();
		try{
			
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getCockpitActivity service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for demand cockpit >> activity API.",
					cse.getCause());
		}
		return activityDto;
	}

	
	public ForecastAccuracyChartDTO getForecastAccuracyChart(String type){
		ForecastAccuracyChartDTO forecastAccuracyChartDTO = new ForecastAccuracyChartDTO();
		try{
			List<String> monthList = this.getMonthList();
			forecastAccuracyChartDTO.setColumnMetaData(monthList);
			forecastAccuracyChartDTO.setType(type);
			List<Map<String, MonthDataUnit>> chartData = new ArrayList<>();
			
			// If DB call returns data
			
			// If DB call does not return data
			Map<String, MonthDataUnit> dataMap = new HashMap<>();
			populateForecastAccuracyChartDataMap(dataMap);
			forecastAccuracyChartDTO.setChartData(dataMap);
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getForecastAccuracy service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for demand cockpit >>  accuracy graph API.",
					cse.getCause());
		}
		return forecastAccuracyChartDTO;
	}

	public ForecastAccuracyPercentageDTO getForecastAccuracyPercentage(String type, Integer regionId,
			Integer countryId, Integer hubId, String partId){
		ForecastAccuracyPercentageDTO forecastAccuracyPercentageDTO = new ForecastAccuracyPercentageDTO();
		try{
			
			// If DB call returns data
			
			// If DB call does not return data
			populate(type, regionId, countryId, hubId, partId, forecastAccuracyPercentageDTO);
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getForecastAccuracy service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for demand cockpit >>  accuracy graph API.",
					cse.getCause());
		}
		return forecastAccuracyPercentageDTO;
	}
	
	public ForecastAccuracyMetricsSixMonthsDTO getForecastAccuracyMetricsForSixMonths(String type, Integer regionId,
			Integer countryId, Integer hubId, String partId) {
		
		ForecastAccuracyMetricsSixMonthsDTO data = new ForecastAccuracyMetricsSixMonthsDTO();
		
		data.setType(type);
		
		List<String> monthList = this.getMonthList();
		data.setMonthMetaData(monthList);
		
		List<String> lineMetaData = new ArrayList<>();
		lineMetaData.add("statistical");
		if (type.equals("Container")) {
			lineMetaData.add("bpbased");
			lineMetaData.add("aligned");
			lineMetaData.add("consensus");
		} 
		data.setLineMetaData(lineMetaData);
		
		Map<String, Object> lineMap = new HashMap<>();
		Map<String,Object> monthMap = new HashMap<>();
		
		for (int i = 0; i < monthList.size(); i++) {
			Map<String, Object> monthInnerMap = new HashMap<>();
			monthInnerMap.put(lineMetaData.get(0), -1);
			if (type.equals("Container")) {
				monthInnerMap.put(lineMetaData.get(1), -1);
				monthInnerMap.put(lineMetaData.get(2), -1);
				monthInnerMap.put(lineMetaData.get(3), -1);
			}
			monthMap.put(monthList.get(i), monthInnerMap);
		}
		
		for(int i = 0; i < lineMetaData.size(); i++) {
			Map<String, Object> lineInnerMap = new HashMap<>();
			lineInnerMap.put(monthList.get(0), -1);
			lineInnerMap.put(monthList.get(1), -1);
			lineInnerMap.put(monthList.get(2), -1);
			lineInnerMap.put(monthList.get(3), -1);
			lineInnerMap.put(monthList.get(4), -1);
			lineInnerMap.put(monthList.get(5), -1);
			lineMap.put(lineMetaData.get(i), lineInnerMap);
			if (type.equals("Spares")) {
				break;
			}
		}		
		
		data.setLineMap(lineMap);
		data.setMonthMap(monthMap);
		return data;
		
	}
	
	public ForecastAccuracyMetricsDTO getForecastAccuracyMetrics(String type, Integer regionId,
			Integer countryId, Integer hubId, String partId, String monthYear){
		ForecastAccuracyMetricsDTO forecastAccuracyMetricsDTO = new ForecastAccuracyMetricsDTO();
		try{
			
			// If DB call returns data
			
			// If DB call does not return data
			populate(type, regionId, countryId, hubId, partId, monthYear, forecastAccuracyMetricsDTO);
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getForecastAccuracy service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for demand cockpit >>  accuracy graph API.",
					cse.getCause());
		}
		return forecastAccuracyMetricsDTO;
	}	
	
	public ForecastExceptionDto getExceptions(Integer id){
		ForecastExceptionDto forecastExceptionDto = new ForecastExceptionDto();
		try{
			
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getExceptions service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for demand cockpit >>  exception API.",
					cse.getCause());
		}
		return forecastExceptionDto;
		
	}
	
	public ForecastAccuracyRegionMetricsDTOWrapper getForecastAccuracyRegionMetrics(String type, String monthYear){
		ForecastAccuracyRegionMetricsDTOWrapper wrapper = new ForecastAccuracyRegionMetricsDTOWrapper();
		try{
			
			// If DB call returns data
			
			// If DB call does not return data
			populate(type, monthYear, wrapper);
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getForecastAccuracyRegionMetrics service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for demand cockpit >>  accuracy graph API.",
					cse.getCause());
		}
		return wrapper;
	}	
	
	public ForecastWaterfallContainer getForeCastWaterfallContainer(){
		ForecastWaterfallContainer forecastWFContainer = new ForecastWaterfallContainer();
		try{
			
		}catch(CSafeServiceException cse){
			logger.error("Error caught in getForeCastWaterfallContainer service method: " + cse.getMessage(), cse);
			throw new CSafeServiceException("API error occured during get data for demand cockpit >>  WaterfallContainer API.",
					cse.getCause());
		}
		return forecastWFContainer;
	}

	private String getCurrentMonth() {
		Calendar c = Calendar.getInstance();
		return monthValueMap.get(c.get(Calendar.MONTH));
	}

	
	private String getCurrentMonthYear() {
		Calendar c = Calendar.getInstance();
		return monthValueMap.get(c.get(Calendar.MONTH)) + "-" + c.get(Calendar.YEAR);
	}

	private List<String> getMonthList() {
		List<String> monthList = new ArrayList<>();

		Calendar c = Calendar.getInstance();
		int startingMonth = c.get(Calendar.MONTH);
		int nextMonth = startingMonth;
		boolean isChangeInYear = false;

		for (int i = 0; i < 6; i++) {
			String year = isChangeInYear ? ("" + (c.get(Calendar.YEAR) + 1)) : ("" + c.get(Calendar.YEAR));
			monthList.add(monthValueMap.get(nextMonth));
			nextMonth = nextMonth + 1;
			int mod = nextMonth % 11;
			if ((nextMonth > 11) && mod > 0) {
				isChangeInYear = true;
				nextMonth = mod - 1;
			}
		}

		return monthList;
	}

	private List<String> getPreviousMonthYearList(int months) {
		List<String> monthYearList = new ArrayList<>();

		Calendar c = Calendar.getInstance();
		int startingMonth = c.get(Calendar.MONTH) - 1;
		int nextMonth = startingMonth;
		boolean isChangeInYear = false;
		// If current MonthYear is Nov-2018, the output should be as follows:
		// Oct-2018, Sep-2018, Aug-2018, Jul-2018, Jun-2018, May-2018, Apr-2018,
		// Mar-2018, Feb-2018, Jan-2018
		// Dec-2017, Nov-2017, Oct-2017, Sep-2017, Aug-2017, Jul-2017, Jun-2017,
		// May-2017

		for (int i = 0; i < months; i++) {
			String year = isChangeInYear ? ("" + (c.get(Calendar.YEAR) - 1)) : ("" + c.get(Calendar.YEAR));
			monthYearList.add(monthValueMap.get(nextMonth) + "-" + year);
			nextMonth = nextMonth - 1;
			int mod = nextMonth % 11;
			if (nextMonth < 0 && nextMonth == -1) {
				nextMonth = 11;
				isChangeInYear = true;
			}
		}

		return monthYearList;
	}
	
	private List<String> getMonthYearList() {
		List<String> monthYearList = new ArrayList<>();

		Calendar c = Calendar.getInstance();
		int startingMonth = c.get(Calendar.MONTH);
		int nextMonth = startingMonth;
		boolean isChangeInYear = false;

		for (int i = 0; i < 6; i++) {
			String year = isChangeInYear ? ("" + (c.get(Calendar.YEAR) + 1)) : ("" + c.get(Calendar.YEAR));
			monthYearList.add(monthValueMap.get(nextMonth) + "-" + year);
			nextMonth = nextMonth + 1;
			int mod = nextMonth % 11;
			if ((nextMonth > 11) && mod > 0) {
				isChangeInYear = true;
				nextMonth = mod - 1;
			}
		}

		return monthYearList;
	}
	
	private void populateForecastAccuracyChartDataMap(Map<String, MonthDataUnit> dataMap) {
		List<String> monthYearList = this.getMonthYearList();
		
		for (int i = 0; i < monthYearList.size(); i++) {
			MonthDataUnit mdu = new MonthDataUnit();
			String monthYear = monthYearList.get(i);
			String month = monthYear.split("-")[0];
			int year = Integer.parseInt(monthYear.split("-")[1]);
			mdu.setMonth(month);
			mdu.setMonthValue(monthValueReverseMap.get(month));
			mdu.setValue(0);
			mdu.setYear(year);
			dataMap.put(month, mdu);
		}
	}
	
	private void populate(String type, Integer regionId, Integer countryId, Integer hubId, 
			String partId, String monthYear, ForecastAccuracyMetricsDTO forecastAccuracyMetricsDTO) {
		
		// dd-MMM-yyyy: ^(([0-9])|([0-2][0-9])|([3][0-1]))\-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\-\d{4}$
		
		String month = monthYear.split("-")[0];
		int year = Integer.parseInt(monthYear.split("-")[1]);
		forecastAccuracyMetricsDTO.setRegionId(regionId);
		forecastAccuracyMetricsDTO.setCountryId(countryId);
		forecastAccuracyMetricsDTO.setHubId(hubId);
		forecastAccuracyMetricsDTO.setMonth(month);
		forecastAccuracyMetricsDTO.setMonthValue(monthValueReverseMap.get(month));
		forecastAccuracyMetricsDTO.setYear(year);
		forecastAccuracyMetricsDTO.setType(type);
		forecastAccuracyMetricsDTO.setStatistical(-1);
		if (type.equals("Spares")) {
			forecastAccuracyMetricsDTO.setPartId(partId);
			return;
		}
		
		forecastAccuracyMetricsDTO.setBpbased(-1);
		forecastAccuracyMetricsDTO.setAligned(-1);
		forecastAccuracyMetricsDTO.setConsensus(-1);
	}
	
	private void populate(String type, Integer regionId, Integer countryId, Integer hubId, 
			String partId, ForecastAccuracyPercentageDTO forecastAccuracyPercentageDTO) {
		
		forecastAccuracyPercentageDTO.setRegionId(regionId);
		forecastAccuracyPercentageDTO.setCountryId(countryId);
		forecastAccuracyPercentageDTO.setHubId(hubId);
		forecastAccuracyPercentageDTO.setMonth("-1");
		forecastAccuracyPercentageDTO.setMonthValue(-1);
		forecastAccuracyPercentageDTO.setYear(-1);
		forecastAccuracyPercentageDTO.setType(type);
		ForecastAccuracyPercentageData statistical = new ForecastAccuracyPercentageData();
		statistical.setFrom2Months(-1);
		statistical.setFrom3Months(-1);
		statistical.setFromCM(-1);
		statistical.setFromLM(-1);
		forecastAccuracyPercentageDTO.setStatistical(statistical);
		
		if (type.equals("Container")) {
			forecastAccuracyPercentageDTO.setPartId("-1");
		} else {
			forecastAccuracyPercentageDTO.setPartId(partId);
			return;
		}
		
		ForecastAccuracyPercentageData bpBased = new ForecastAccuracyPercentageData();
		bpBased.setFrom2Months(-1);
		bpBased.setFrom3Months(-1);
		bpBased.setFromCM(-1);
		bpBased.setFromLM(-1);
		forecastAccuracyPercentageDTO.setBpBased(bpBased);
		
		ForecastAccuracyPercentageData aligned = new ForecastAccuracyPercentageData();
		aligned.setFrom2Months(-1);
		aligned.setFrom3Months(-1);
		aligned.setFromCM(-1);
		aligned.setFromLM(-1);
		forecastAccuracyPercentageDTO.setAligned(aligned);
		
		ForecastAccuracyPercentageData concensus = new ForecastAccuracyPercentageData();
		concensus.setFrom2Months(-1);
		concensus.setFrom3Months(-1);
		concensus.setFromCM(-1);
		concensus.setFromLM(-1);
		forecastAccuracyPercentageDTO.setConsensus(concensus);
	}
	
	private void populate(String type, String monthYear, ForecastAccuracyRegionMetricsDTOWrapper wrapper) {
		
		String month = monthYear.split("-")[0];
	}
}
