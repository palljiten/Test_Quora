package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.SparesConsensusCorrectionFactor;

public interface SparesConsensusCorrectionFactorRepository
		extends JpaRepository<SparesConsensusCorrectionFactor, Integer> {

	@Query("SELECT a FROM SparesConsensusCorrectionFactor a WHERE (MONTH(CURRENT_DATE()) < DATEADD(mm, :months, CURRENT_DATE()) "
			+ "AND a.flag=1 AND a.hub.hubId = :hubId AND a.country.countryId = :countryId "
			+ "AND a.region.regionId = :regionId AND a.partId = :partId)")
	public List<SparesConsensusCorrectionFactor> getSparesConsensusCorrectionFactor(@Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId,
			@Param("months") int months);

	@Modifying
	@Query("UPDATE SparesConsensusCorrectionFactor a SET a.flag = 0 "
			+ "WHERE monthYear = :monthYear AND a.flag=1 AND a.hub.hubId = :hubId "
			+ "AND a.country.countryId = :countryId AND a.region.regionId = :regionId AND a.partId = :partId")
	int updateSparesConsensusCorrectionFactor(@Param("monthYear") String monthYear, @Param("regionId") int regionId, @Param("countryId") int countryId,
			@Param("hubId") int hubId, @Param("partId") String partId);
}
