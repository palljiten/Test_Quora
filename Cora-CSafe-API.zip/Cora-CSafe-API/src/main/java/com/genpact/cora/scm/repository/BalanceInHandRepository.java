package com.genpact.cora.scm.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.dto.BalanceHotBoard;
import com.genpact.cora.scm.entity.VABalanceInHand;

public interface BalanceInHandRepository extends JpaRepository<VABalanceInHand, Integer>{
	
	@Query("select new com.genpact.cora.scm.dto.BalanceHotBoard(count(bal.balanceInHand),bal.weekNo,hs.city) from VABalanceInHand bal inner join HubSc hs on bal.code =hs.hubCode where bal.weekNo in (:weeksList) group by bal.weekNo ,hs.city")
	public List<BalanceHotBoard> getBalanceInHandData(@Param("weeksList") List<Object> weeksList);
	
	
	
	
	 @Query(value = "select RegionName,Code,City,CountryName,WeekNo,BalanceInHand,SafetyStock,Status from tbl_VABalanceInHand A " + 
		   		"LEFT JOIN tbl_master_Calendar B ON (CONVERT(DATE,A.duedate) =CONVERT(DATE,B.Date))\r\n" + 
		   		"where B.WeekstartDate >= (SELECT WeekStartdate FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE()))\r\n" + 
		   		"AND B.WeekstartDate<=(SELECT DATEADD(Day,21,WeekStartdate) FROM tbl_master_Calendar WHERE CONVERT(DATE,Date)=CONVERT(DATE,GETDATE()))" ,nativeQuery = true)
	 public List<Object[]> getBalanceInHandData();
	 
	 
			
			
}
  