package com.genpact.cora.scm.dto;

import java.util.List;
import java.util.Map;

public class ForecastAccuracyMetricsSixMonthsDTO {

	private List<String> monthMetaData; 
	private List<String> lineMetaData;
	private String type;
	
	private Map<String, Object> lineMap;
	private Map<String,Object> monthMap;
	
	public List<String> getMonthMetaData() {
		return monthMetaData;
	}
	public void setMonthMetaData(List<String> monthMetaData) {
		this.monthMetaData = monthMetaData;
	}
	public List<String> getLineMetaData() {
		return lineMetaData;
	}
	public void setLineMetaData(List<String> lineMetaData) {
		this.lineMetaData = lineMetaData;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Map<String, Object> getLineMap() {
		return lineMap;
	}
	public void setLineMap(Map<String, Object> lineMap) {
		this.lineMap = lineMap;
	}
	public Map<String, Object> getMonthMap() {
		return monthMap;
	}
	public void setMonthMap(Map<String, Object> monthMap) {
		this.monthMap = monthMap;
	}
}
