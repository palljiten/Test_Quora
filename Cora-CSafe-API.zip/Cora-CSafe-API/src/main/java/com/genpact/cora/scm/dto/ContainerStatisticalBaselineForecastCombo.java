package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContainerStatisticalBaselineForecastCombo implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<String> monthYearMetaData = new ArrayList<>();
	private List<MonthDataUnit> baselineForecast = new ArrayList<>();

	public List<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}

	public void setMonthYearMetaData(List<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}

	public List<MonthDataUnit> getBaselineForecast() {
		return baselineForecast;
	}

	public void setBaselineForecast(List<MonthDataUnit> baselineForecast) {
		this.baselineForecast = baselineForecast;
	}

}
