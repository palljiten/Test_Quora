package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.SparesStatisticalAdjustments;

public interface SparesStatisticalAdjustmentsRepository extends JpaRepository<SparesStatisticalAdjustments, Integer> {

	@Query("SELECT a FROM SparesStatisticalAdjustments a WHERE a.flag=1 AND a.hub.hubId = :hubId AND a.country.countryId = :countryId AND a.region.regionId = :regionId AND a.partId = :partId AND a.monthYear IN (:myList)")
	public List<SparesStatisticalAdjustments> getSparesStatisticalAdjustments(@Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId,
			@Param("myList") List<String> myList);

	@Modifying
    @Query("UPDATE SparesStatisticalAdjustments a SET a.flag = 0 "
    		+ "WHERE a.flag=1 AND a.hub.hubId = :hubId AND a.country.countryId = :countryId "
    		+ "AND a.region.regionId = :regionId AND a.partId = :partId AND monthYear = :monthYear")
    int updateSparesStatisticalAdjustments(@Param("regionId") int regionId,
			@Param("countryId") int countryId, @Param("hubId") int hubId, @Param("partId") String partId, @Param("monthYear") String monthYear);

}
