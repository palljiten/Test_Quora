package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class ConsensusForecastCombo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<BaselineForecastResponse> baselineForecast;
	private List<StatisticalForecastResponse> statisticalForecast;
	private Set<String> monthYearMetaData;
	
	public List<BaselineForecastResponse> getBaselineForecast() {
		return baselineForecast;
	}
	public void setBaselineForecast(List<BaselineForecastResponse> baselineForecast) {
		this.baselineForecast = baselineForecast;
	}
	public List<StatisticalForecastResponse> getStatisticalForecast() {
		return statisticalForecast;
	}
	public void setStatisticalForecast(List<StatisticalForecastResponse> statisticalForecast) {
		this.statisticalForecast = statisticalForecast;
	}
	public Set<String> getMonthYearMetaData() {
		return monthYearMetaData;
	}
	public void setMonthYearMetaData(Set<String> monthYearMetaData) {
		this.monthYearMetaData = monthYearMetaData;
	}
	
	
	
	/*private Region region;
	private Country country;
	private HubSc hub;*/

	

	

}
