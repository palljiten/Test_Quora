package com.genpact.cora.scm.dto;

import java.util.List;

public class PythonResponseObject {

	private int HubId;
	private float mapPercent;
	private float madPercent;
	private float rmsePercent;
	private int modelId;
	private String partNumber;
	private String modelName;
	private List<MonthDataUnit> monthData;
	

	public float getMadPercent() {
		return madPercent;
	}
	public void setMadPercent(float madPercent) {
		this.madPercent = madPercent;
	}
	public float getRmsePercent() {
		return rmsePercent;
	}
	public void setRmsePercent(float rmsePercent) {
		this.rmsePercent = rmsePercent;
	}
	public int getModelId() {
		return modelId;
	}
	public void setModelId(int modelId) {
		this.modelId = modelId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public List<MonthDataUnit> getMonthData() {
		return monthData;
	}
	public void setMonthData(List<MonthDataUnit> monthData) {
		this.monthData = monthData;
	}
	public float getMapPercent() {
		return mapPercent;
	}
	public void setMapPercent(float mapPercent) {
		this.mapPercent = mapPercent;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public int getHubId() {
		return HubId;
	}
	public void setHubId(int hubId) {
		HubId = hubId;
	}
	
	
	/*Response JSON:

	  {
	    "madPercent": 32.09,
	    "mapPercent": 76.18,
		"rmsePercent": 66.18,
	    "modelId": 1,
	    "modelName": "SimpleAverage",
	    "monthData": [
			{
				"month":"Jan",
				"monthValue":1,
				"value":43.0,
				"year":2019
			},
			{
				"month":"Feb",
				"monthValue":2,
				"value":43.0,
				"year":2019
			},
			{
				"month":"Mar",
				"monthValue":3,
				"value":43.0,
				"year":2019
			},
			{
				"month":"Apr",
				"monthValue":4,
				"value":43.0,
				"year":2019
			},
			{
				"month":"May",
				"monthValue":5,
				"value":43.0,
				"year":2019
			},
			{
				"month":"Jun",
				"monthValue":6,
				"value":43.0,
				"year":2019
			}
		]
	  } */
}
