package com.genpact.cora.scm.email;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class EmailScheduledTasks {

    private static final Logger log = LoggerFactory.getLogger(EmailScheduledTasks.class);

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

    @Scheduled(fixedRate = 5000)
    //@Scheduled(cron = "0 10 10 10 * ?" zone="Asia/Calcutta")
    public void reportCurrentTime() {
    	log.info("Current Thread : {}", Thread.currentThread().getName());
        log.info("The time is now {}", dateFormat.format(new Date()));
    }
    
    // Cron expression consists of six fields::
    // <second> <minute> <hour> <day-of-month> <month> <day-of-week> <year> <command>
    // * From these, <year> field is optional.
    //
    // At 13:00 pm (noon) every day during the year 2018:
    // 0 0 13 * * ? 2018
    //
    // At 9:30 am every Monday, Tuesday, Wednesday, Thursday, and Friday:
    // 0 30 9 ? * MON-FRI
    //
    // At 9:30 am on 15th day of every month:
    // 0 30 9 15 * ?
}
