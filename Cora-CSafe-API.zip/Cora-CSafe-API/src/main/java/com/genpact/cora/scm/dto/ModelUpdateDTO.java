package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.List;

public class ModelUpdateDTO  implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private int modelId;
	private String modelName;
	private List<ModelParam> modelParams;
	private ModelValues modelValues;
	
	public int getModelId() {
		return modelId;
	}
	public void setModelId(int modelId) {
		this.modelId = modelId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public List<ModelParam> getModelParams() {
		return modelParams;
	}
	public void setModelParams(List<ModelParam> modelParams) {
		this.modelParams = modelParams;
	}
	public ModelValues getModelValues() {
		return modelValues;
	}
	public void setModelValues(ModelValues modelValues) {
		this.modelValues = modelValues;
	}
}
