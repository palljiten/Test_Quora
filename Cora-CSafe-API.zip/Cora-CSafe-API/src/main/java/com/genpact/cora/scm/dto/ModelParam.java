package com.genpact.cora.scm.dto;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ModelParam implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private int modelId;
	
	@Min(value = 1)
	@NotNull
	private Integer paramId;
	
	private String paramName;
	
	@NotNull
	private Float paramValue;

	public ModelParam() {}
	
	public ModelParam(int modelId, int paramId, String paramName, float paramValue) {
		this.modelId = modelId;
		this.paramId = paramId;
		this.paramName = paramName;
		this.paramValue = paramValue;
	}
	
	public ModelParam(int modelId, int paramId, String paramName, Double paramValue) {
		this.modelId = modelId;
		this.paramId = paramId;
		this.paramName = paramName;
		this.paramValue = paramValue.floatValue();
	}
	
	public int getParamId() {
		return paramId;
	}

	public void setParamId(int paramId) {
		this.paramId = paramId;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public float getParamValue() {
		return paramValue;
	}

	public void setParamValue(float paramValue) {
		this.paramValue = paramValue;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}
}
