package com.genpact.cora.scm.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.cora.scm.dto.ContainerForecastWeek;
import com.genpact.cora.scm.dto.ContainerForecastWeeklyAdjustments;
import com.genpact.cora.scm.dto.SuccessResponse;
import com.genpact.cora.scm.exception.CSafeApiException;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.service.WeeklyForecastService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/scm")
@Api(tags = { "ContainerForecastWeekly" }, description = "Container Forecast weekly conroller")
public class ContainerForecastWeeklyController {

	private static Logger logger = LoggerFactory.getLogger(SparesForecastStatisticalController.class);

	@Autowired
	WeeklyForecastService weeklyForecastService;

	@GetMapping(value = "/baselineDemand/weekly", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves weekly baseline demand according to the regions selected")
	public ResponseEntity<ContainerForecastWeek> getBaselineDemand(@RequestParam("weeks") Integer weeks,
			@RequestParam("regionID") Integer regionID, @RequestParam("countryID") Integer countryID,
			@RequestParam("hubID") Integer hubID) {
		ContainerForecastWeek oContainerForecastWeek;
		try {
			oContainerForecastWeek = weeklyForecastService.getBaselineDemand(regionID, countryID, hubID, weeks);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during get data for baseline demand weekly (Container Forecast Weekly)", e.getCause());
		}
		return new ResponseEntity<ContainerForecastWeek>(oContainerForecastWeek, HttpStatus.OK);
	}

	@GetMapping(value = "/forecast/weekly", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves weekly forecast values according to the regions selected")
	public ResponseEntity<ContainerForecastWeek> getForecast(@RequestParam("weeks") int weeks,
			@RequestParam("regionID") Integer regionID, @RequestParam("countryID") Integer countryID,
			@RequestParam("hubID") Integer hubID) {
		ContainerForecastWeek oContainerForecastWeek;
		try {
			oContainerForecastWeek = weeklyForecastService.getForecast(regionID, countryID, hubID, weeks);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException("API error occured during get data for forecast weekly (Container Forecast Weekly)",
					e.getCause());
		}
		return new ResponseEntity<ContainerForecastWeek>(oContainerForecastWeek, HttpStatus.OK);
	}

	@GetMapping(value = "/csafe/weeklyAdjustments", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves weekly Adjustments according to the regions selected")
	public ResponseEntity<ContainerForecastWeeklyAdjustments> getWeeklyAdjustments(@RequestParam("weeks") int weeks,
			@RequestParam("regionID") Integer regionID, @RequestParam("countryID") Integer countryID,
			@RequestParam("hubID") Integer hubID) {
		ContainerForecastWeeklyAdjustments oContainerForecastWeeklyAdjustments;
		try {
			oContainerForecastWeeklyAdjustments = weeklyForecastService.getFogetWeeklyAdjustmentsrecast(regionID,
					countryID, hubID, weeks);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException("API error occured during get data for adjustments weekly (Container Forecast Weekly)",
					e.getCause());
		}
		return new ResponseEntity<ContainerForecastWeeklyAdjustments>(oContainerForecastWeeklyAdjustments,
				HttpStatus.OK);
	}

	@PutMapping(value = "/csafe/weeklyAdjustments", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "API for Updating Adjustment/Override Values (Weekly)")
	public ResponseEntity<SuccessResponse> updateWeeklyAdjustments(
			@Valid @RequestBody ContainerForecastWeeklyAdjustments containerForecastWeek) {
		try {
			weeklyForecastService.updateWeeklyAdjustments(containerForecastWeek);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException(
					"API error occured during updating data for adjustments weekly", e.getCause());
		}
		SuccessResponse s = new SuccessResponse();
		s.setStatus("SUCCESS");
		logger.info("CONTROLLER: ContainerForecastWeeklyController: Exiting updateWeeklyAdjustments() method (Container Forecast Weekly)");
		return new ResponseEntity<>(s, HttpStatus.OK);
	}

	@GetMapping(value = "/container/actuals", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves actuals according to the regions selected")
	public ResponseEntity<ContainerForecastWeek> getActuals(@RequestParam("weeks") int weeks,
			@RequestParam("regionID") Integer regionID, @RequestParam("countryID") Integer countryID,
			@RequestParam("hubID") Integer hubID) {
		ContainerForecastWeek oContainerForecastWeek;
		try {
			oContainerForecastWeek = weeklyForecastService.getActuals(regionID, countryID, hubID, weeks);
		} catch (CSafeServiceException e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeApiException("API error occured during get data for actuals weekly (Container Forecast Weekly)",
					e.getCause());
		}
		return new ResponseEntity<ContainerForecastWeek>(oContainerForecastWeek, HttpStatus.OK);
	}

}
