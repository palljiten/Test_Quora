/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ForecastAccuracyChartDTO {

	private List<String> columnMetaData = new ArrayList<>();
	private String type;
	private Map<String, MonthDataUnit> chartData = new HashMap<>();
	
	public List<String> getColumnMetaData() {
		return columnMetaData;
	}
	public void setColumnMetaData(List<String> columnMetaData) {
		this.columnMetaData = columnMetaData;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Map<String, MonthDataUnit> getChartData() {
		return chartData;
	}
	public void setChartData(Map<String, MonthDataUnit> chartData) {
		this.chartData = chartData;
	}

}
