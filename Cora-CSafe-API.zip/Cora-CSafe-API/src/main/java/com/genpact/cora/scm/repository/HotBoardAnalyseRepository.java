package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public class HotBoardAnalyseRepository {
	
	@PersistenceContext
    private EntityManager entityManager;
	
	public List<Object[]> getLeaseEndDrillDownData(@Param("SerialNumber") String serialNumber){
		
		StoredProcedureQuery query  = entityManager.createStoredProcedureQuery("InboundLeaseEndDrillDownSP");
		query.registerStoredProcedureParameter("SerialNumber", String.class, ParameterMode.IN);
		
		query.setParameter("SerialNumber", serialNumber);
		
		return query.getResultList();
		
	}
	
	public List<Object[]>getRepositioningData(String serialNumber){
		
		StoredProcedureQuery query  = entityManager.createStoredProcedureQuery("InboundRepositioningDrillDownSP");
		query.registerStoredProcedureParameter("SerialNumber", String.class, ParameterMode.IN);
		
		query.setParameter("SerialNumber", serialNumber);
		
		return query.getResultList();
		
	}
}
