package com.genpact.cora.scm.dto;

public class TempBestFitModel {

	private Integer modelId; 
	private Integer bestFitModelId; 
	private String monthYear;
	
	public TempBestFitModel(Integer modelId, Integer bestFitModelId, String monthYear) {
		this.modelId = modelId;
		this.bestFitModelId = bestFitModelId;
		this.monthYear = monthYear;
	}
	
	public TempBestFitModel(Integer modelId, Integer bestFitModelId) {
		this.modelId = modelId;
		this.bestFitModelId = bestFitModelId;
	}
	
	public Integer getModelId() {
		return modelId;
	}
	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}
	public Integer getBestFitModelId() {
		return bestFitModelId;
	}
	public void setBestFitModelId(Integer bestFitModelId) {
		this.bestFitModelId = bestFitModelId;
	}
	public String getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
}
