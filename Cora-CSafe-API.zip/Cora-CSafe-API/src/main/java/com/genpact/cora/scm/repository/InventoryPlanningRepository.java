/**
 * 
 */
package com.genpact.cora.scm.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.genpact.cora.scm.entity.InventoryPlanningContainers;
import com.genpact.cora.scm.entity.InventoryPlanningSpare;



/**
 * @author 703158077
 *
 */
@Repository
public class InventoryPlanningRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public List<InventoryPlanningContainers> findContainersDetails(@Param("regionId") int regionId, @Param("countryId") int countryId, @Param("hubId") int  hubId){
		String extendedWhere = "";
		extendedWhere += (regionId != -1) ? " and ipc.region.regionId="+regionId : "";
		extendedWhere += (countryId != -1) ? " and ipc.country.countryId="+countryId : "";
		extendedWhere += (hubId != -1) ? " and ipc.hub.hubId="+hubId : "";
		String hql = "SELECT ipc FROM InventoryPlanningContainers ipc WHERE ipc.flag=1 "+extendedWhere;
		
		Query query = entityManager.createQuery(hql);
		return query.getResultList();
	}
	
	public List<InventoryPlanningSpare> findSparesInventoryPlan(@Param("regionId") int regionId, @Param("countryId") int  countryId, 
			@Param("hubId") int  hubId, @Param("partNumber") String partNumber){

		String extendedWhere = "";
		extendedWhere += (regionId != -1) ? " and ips.region.regionId="+regionId : "";
		extendedWhere += (countryId != -1) ? " and ips.country.countryId="+countryId : "";
		extendedWhere += (hubId != -1) ? " and ips.hub.hubId="+hubId+" " : "";
		extendedWhere += (!partNumber.equalsIgnoreCase("all")) ? " and ips.part='"+partNumber+"'" : "";
		
		String hql = "SELECT ips FROM InventoryPlanningSpare ips WHERE ips.flag=1 "+extendedWhere;
		
		Query query = entityManager.createQuery(hql);
		return query.getResultList();
	}

}
