package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_VALeaseEnd]")
public class VALeaseEnd {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
	private int id;
	
	@Column(name ="SerialNumber")
	private String serialNumber;
	
	@Column(name ="Status")
	private String status;
	
	@Column(name ="Origin")
	private String origin;
	
	@Column(name ="Destination")
	private String destination;
	
	@Column(name ="AlertDescription")
	private String alertDescription;
	
	@Column(name ="AlertType")
	private String alertType;
	
	@Column(name ="NotificationDate")
	private Date notificationDate;
	
	@Column(name ="EstimatedReceivingDate")
	private Date estimatedReceivingDate;
	
	@Column(name ="ActualReceivingdate")
	private Date actualReceivingDate;
	
	@Column(name ="DueDate")
	private Date dueDate;
	
	@Column(name = "WeekNo")
	private String weekNo;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getAlertDescription() {
		return alertDescription;
	}
	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}
	public String getAlertType() {
		return alertType;
	}
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	public Date getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	public Date getEstimatedReceivingDate() {
		return estimatedReceivingDate;
	}
	public void setEstimatedReceivingDate(Date estimatedReceivingDate) {
		this.estimatedReceivingDate = estimatedReceivingDate;
	}
	public Date getActualReceivingDate() {
		return actualReceivingDate;
	}
	public void setActualReceivingDate(Date actualReceivingDate) {
		this.actualReceivingDate = actualReceivingDate;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	public String getWeekNo() {
		return weekNo;
	}
	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}

}
