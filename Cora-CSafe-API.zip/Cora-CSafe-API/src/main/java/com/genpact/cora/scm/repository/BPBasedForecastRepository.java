package com.genpact.cora.scm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.genpact.cora.scm.entity.BPBasedForeCast;


public interface BPBasedForecastRepository extends JpaRepository<BPBasedForeCast, Integer>{
	
	@Query("SELECT value as value,monthYear as year FROM BPBasedForeCast WHERE (MONTH(GETDATE()) < DATEADD(mm, 6, GETDATE()) and flag='1' and country.countryId=:countryId and hubSc.hubId=:hubId and region.regionId=:regionId)")
	public List<Object[]> findBaselineForecast(@Param("countryId") int countryId,@Param("hubId") int hubId,@Param("regionId") int regionId);
	
	@Query("SELECT new BPBasedForeCast(b.value, b.monthYear) FROM BPBasedForeCast b WHERE (MONTH(GETDATE()) < DATEADD(mm, 6, GETDATE()) AND b.flag='1' AND b.country.countryId = :countryId AND b.hubSc.hubId = :hubId AND b.region.regionId = :regionId)")
	public List<BPBasedForeCast> getBaselineForecast(@Param("countryId") int countryId,@Param("hubId") int hubId,@Param("regionId") int regionId);
}
