package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_WeeklyAdjustment]")
public class WeeklyAdjustment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer Id;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RegionID")
	private Region region;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CountryID")
	private Country country;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "HubID")
	private HubSc hub;

	@Column(name = "WeekNumber", nullable = false)
	private Integer week;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "WeekStartdate", nullable = true)
	private Date weekStartdate;

	@Column(name = "Value", nullable = false)
	private float value;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CreatedDate", nullable = true)
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ModifiedDate", nullable = true)
	private Date modifiedDate;

	@Column(name = "ModifiedBy", nullable = false)
	private String modifiedBy;

	@Column(name = "Flag", nullable = false)
	private Integer flag;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public HubSc getHub() {
		return hub;
	}

	public void setHub(HubSc hub) {
		this.hub = hub;
	}

	public Integer getWeek() {
		return week;
	}

	public void setWeek(Integer week) {
		this.week = week;
	}

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		this.value = value;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	public Date getWeekStartdate() {
		return weekStartdate;
	}

	public void setWeekStartdate(Date weekStartdate) {
		this.weekStartdate = weekStartdate;
	}
}
