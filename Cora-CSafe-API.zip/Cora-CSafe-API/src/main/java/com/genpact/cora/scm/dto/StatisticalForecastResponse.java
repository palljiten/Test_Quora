package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class StatisticalForecastResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	private int monthValue;
	private String month;
	private String year;
	private float value;
	
	public int getMonthValue() {
		return monthValue;
	}
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public float getValue() {
		return value;
	}
	public void setValue(float value) {
		this.value = value;
	}
	

}
