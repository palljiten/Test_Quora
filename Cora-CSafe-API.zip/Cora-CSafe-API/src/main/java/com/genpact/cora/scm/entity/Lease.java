package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_Lease]")
public class Lease {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SI", unique = true, nullable = false)
    private Integer leasePk;
     
    @Column(name = "LeaseIDSerial", nullable = false, length = 100)
    private String leaseIdSerial;
    
    @Column(name = "LeaseId", nullable = false, length = 100)
    private String leaseId;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "OrderDate", nullable = true)
    private Date orderDate;
    
    @Column(name = "SerialNumber", nullable = true)
    private String serialNumber;
    
    @Column(name ="PossStartHubSC" , nullable= true)
    private String possStartHubSC;
    
	public Integer getLeasePk() {
		return leasePk;
	}

	public void setLeasePk(Integer leasePk) {
		this.leasePk = leasePk;
	}

	public String getLeaseIdSerial() {
		return leaseIdSerial;
	}

	public void setLeaseIdSerial(String leaseIdSerial) {
		this.leaseIdSerial = leaseIdSerial;
	}

	public String getLeaseId() {
		return leaseId;
	}

	public void setLeaseId(String leaseId) {
		this.leaseId = leaseId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getPossStartHubSC() {
		return possStartHubSC;
	}

	public void setPossStartHubSC(String possStartHubSC) {
		this.possStartHubSC = possStartHubSC;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	  
}
