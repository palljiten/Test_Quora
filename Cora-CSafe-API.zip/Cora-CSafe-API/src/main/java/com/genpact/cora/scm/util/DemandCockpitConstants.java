package com.genpact.cora.scm.util;

public class DemandCockpitConstants {

	public static final String CONTAINER_TYPE = "Container";
	public static final String SPARES_TYPE = "Spares";
	
	public static final String CONTAINER_EXCEPTIONS_CHART_SP = "Container_Exceptions_Chart_SP";
	public static final String SPARES_EXCEPTIONS_CHART_SP = "Spares_Exceptions_Chart_SP";
		
	public static final String CONTAINER_EXCEPTIONS_ALERTS_SP = "Container_Exceptions_Alerts_SP";
	public static final String SPARES_EXCEPTIONS_ALERTS_SP = "Spares_Exceptions_Alerts_SP";
	
	public static final String CONTAINER_EXCEPTIONS_REPORT_SP = "Container_Exceptions_Report_SP";
	public static final String SPARES_EXCEPTIONS_REPORT_SP = "Spares_Exceptions_Report_SP";
	
	public static final String CONTAINER_EXCEPTIONS_REPORT_DOWNLOAD_SP = "Container_Exceptions_Report_Download_SP";
	public static final String SPARES_EXCEPTIONS_REPORT_DOWNLOAD_SP = "Spares_Exceptions_Report_Download_SP";
	
	public static final String CONTAINER_REVIEW_SUMMARY_SP = "Container_Activity_SP";
	public static final String SPARES_REVIEW_SUMMARY_SP = "Spares_Activity_SP";
	
	public static final String CONTAINER_CLOSE_ALERT_SP = "Container_Close_Alert_SP";
	public static final String SPARES_CLOSE_ALERT_SP = "Spares_Close_Alert_SP";
	
	public static final String CONTAINER_ACTIVITY_CHART_SP = "Container_Activity_SP";
	public static final String SPARES_ACTIVITY_CHART_SP = "Spares_Activity_SP";	
	
	public static final String CONTAINER_FA_REGION_METRICS_SP = "Container_ForecastAccuracy_Metrics_RegionLevel_Chart_sp";
	public static final String SPARES_FA_REGION_METRICS_SP = "Spares_ForecastAccuracy_Metrics_RegionLevel_Chart_sp";		

	public static final String CONTAINER_FA_HUB_METRICS_SP = "Container_ForecastAccuracy_Metrics_HubLevel_Chart_sp";
	public static final String SPARES_FA_HUB_METRICS_SP = "Spares_ForecastAccuracy_Metrics_HubLevel_Chart_sp";
	
	public static final String CONTAINER_FA_REPORT_DOWNLOAD_SP = "Container_ForecastAccuracy_Report_Download_sp";
	public static final String SPARES_FA_REPORT_DOWNLOAD_SP = "Spares_ForecastAccuracy_Report_Download_sp";
	
	public static final String SP_RESULT_SET_1 = "#result-set-1";
	
	public static final String SP_PARAM_REGION_ID = "RegionID";
	public static final String SP_PARAM_COUNTRY_ID = "CountryID";
	public static final String SP_PARAM_HUB_ID = "HubID";
	public static final String SP_PARAM_PART_ID = "PartID";
	public static final String SP_PARAM_PART_NUMBER = "PartNumber";
	public static final String SP_PARAM_COMMENT = "Comment";
	public static final String SP_PARAM_CLOSEDBY = "ClosedBy";
	public static final String SP_PARAM_MONTH_YEAR = "MonthYear";
	
	public static final String HUBID = "HubID";
	public static final String HUBCODE = "Hub";
	public static final String REGION_NAME= "RegionName";
	public static final String COUNTRY_NAME= "CountryName";	
	public static final String UNDER_CONSUMED_FORECAST20 = "UnderConsumedForecast20";
	public static final String OVER_CONSUMED_FORECAST20 = "OverConsumedForecast20";
	public static final String MTD_WARNING = "MTDWarning";
	public static final String MONTH_CONSUMPTION_WARNING3 = "MonthConsumptionWarning3";
	public static final String MONTH_CONSUMPTION_WARNING4 = "MonthConsumptionWarning4";
	public static final String EARLY_WARNING_SIGNAL = "EarlyWarningSignal";
	public static final String PAST_3MONTHS_FAC_LESS60 = "Past3MonthsFACLess60";
	public static final String YTD_AVGSALES_VS_AVGFORECAST = "YTDAvgSalevsAvgForecast";
	public static final String ZERO_ACTUALS_BUT_FORECASTED = "ZeroActualsbutForecasted";
	public static final String ALERT = "Alert";
	
	public static final String REVIEW_PENDING = "ReviewPending";
	public static final String REVIEW_COMPLETED = "ReviewCompleted";
}
