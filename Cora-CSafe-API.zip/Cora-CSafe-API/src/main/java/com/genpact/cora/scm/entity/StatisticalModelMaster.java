package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "[dbo].[tbl_master_StatisticalModel]")
public class StatisticalModelMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ModelID", unique = true, nullable = false)
	private int modelId;
	
	@Column(name ="ModelName" , nullable = false)
	private String modelName;
	
	@Column(name = "CreatedDate" , nullable = false)
	private Date createdDate;
	
	public int getModelId() {
		return modelId;
	}
	public void setModelId(int modelId) {
		this.modelId = modelId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	

}
