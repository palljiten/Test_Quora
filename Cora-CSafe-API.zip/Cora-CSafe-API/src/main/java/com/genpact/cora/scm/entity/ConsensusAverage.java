package com.genpact.cora.scm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "[dbo].[tbl_master_ConsensusAverage]")
public class ConsensusAverage {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AID", unique = true, nullable = false)
    private Integer aid;
	
    @Column(name = "AvgName")
    private String avgName;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "createdDate")
    private Date createdDate;

	public Integer getAid() {
		return aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public String getAvgName() {
		return avgName;
	}

	public void setAvgName(String avgName) {
		this.avgName = avgName;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
    
    
}
