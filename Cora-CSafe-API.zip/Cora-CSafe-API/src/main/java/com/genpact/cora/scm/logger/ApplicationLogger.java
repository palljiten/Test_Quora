package com.genpact.cora.scm.logger;

import com.genpact.cora.scm.dto.ApplicationLogDto;

/**
 * Interface of ApplicationLogger
 * To log request, response and exception details in application logger table.
 * @author nirmal kamila
 *
 */
public interface ApplicationLogger {
	
	/**
	 * Log method to store  request, response and exception details in application logger table.
	 * 
	 * @param applicationLogDto
	 */
	public void  log(ApplicationLogDto applicationLogDto );

}
