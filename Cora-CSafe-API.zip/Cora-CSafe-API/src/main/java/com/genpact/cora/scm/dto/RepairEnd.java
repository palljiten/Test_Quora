/**
 * 
 */
package com.genpact.cora.scm.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;


/**
 * @author 703158077
 *
 */
public class RepairEnd implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9876543216L;
	
	private int id;
	private long containerId;
	private String serialNumber;
	private String tName;
	private String status;
	private String origin;
	private String containerLocation;
	private Date actualReceivingDate;
	private Date arrivalDate;
	private Date dueDate;
	private Date notificationDate;
	private Date estimatedReceivingDate;
	private String alertType;
	private int workWorderId;
	private Date wODate;
	private String partNumber;
	private String description;
	private int currentlyInStock;
	private String alertDescription;
	private String weekNo;
	private int quentity;
	
	public RepairEnd() {}
	
	public RepairEnd(String weekNo, String serialNumber, String status, String containerLocation, String alertDescription, Date dueDate,
	Date notificationDate, Date estimatedReceivingDate, Date actualReceivingDate, String alertType ) {
		
		this.weekNo = weekNo;
		this.serialNumber = serialNumber;
		this.status = status;
		this.containerLocation = containerLocation;
		this.alertDescription = alertDescription;
		this.dueDate = dueDate;
		this.notificationDate = notificationDate;
		this.estimatedReceivingDate = estimatedReceivingDate;
		this.actualReceivingDate = actualReceivingDate;
		this.alertType = alertType;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the containerId
	 */
	public long getContainerId() {
		return containerId;
	}
	/**
	 * @param containerId the containerId to set
	 */
	public void setContainerId(long containerId) {
		this.containerId = containerId;
	}
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the tName
	 */
	public String gettName() {
		return tName;
	}
	/**
	 * @param tName the tName to set
	 */
	public void settName(String tName) {
		this.tName = tName;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the origin
	 */
	public String getOrigin() {
		return origin;
	}
	/**
	 * @param origin the origin to set
	 */
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	/**
	 * @return the containerLocation
	 */
	public String getContainerLocation() {
		return containerLocation;
	}
	/**
	 * @param containerLocation the containerLocation to set
	 */
	public void setContainerLocation(String containerLocation) {
		this.containerLocation = containerLocation;
	}
	/**
	 * @return the actualReceivingDate
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
	public Date getActualReceivingDate() {
		return actualReceivingDate;
	}
	/**
	 * @param actualReceivingDate the actualReceivingDate to set
	 */
	public void setActualReceivingDate(Date actualReceivingDate) {
		this.actualReceivingDate = actualReceivingDate;
	}
	/**
	 * @return the arrivalDate
	 */
	@JsonFormat(pattern = "MM/dd/yyyy")
	public Date getArrivalDate() {
		return arrivalDate;
	}
	/**
	 * @param arrivalDate the arrivalDate to set
	 */
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	/**
	 * @return the dueDate
	 */
	@JsonFormat(pattern = "MM/dd/yyyy")
	public Date getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	/**
	 * @return the notificationDate
	 */
	@JsonFormat(pattern = "MM/dd/yyyy")
	public Date getNotificationDate() {
		return notificationDate;
	}
	/**
	 * @param notificationDate the notificationDate to set
	 */
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	/**
	 * @return the estimatedReceivingDate
	 */
	@JsonFormat(pattern = "MM/dd/yyyy")
	public Date getEstimatedReceivingDate() {
		return estimatedReceivingDate;
	}
	/**
	 * @param estimatedReceivingDate the estimatedReceivingDate to set
	 */
	public void setEstimatedReceivingDate(Date estimatedReceivingDate) {
		this.estimatedReceivingDate = estimatedReceivingDate;
	}
	/**
	 * @return the alertType
	 */
	public String getAlertType() {
		return alertType;
	}
	/**
	 * @param alertType the alertType to set
	 */
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	/**
	 * @return the workWorderId
	 */
	public int getWorkWorderId() {
		return workWorderId;
	}
	/**
	 * @param workWorderId the workWorderId to set
	 */
	public void setWorkWorderId(int workWorderId) {
		this.workWorderId = workWorderId;
	}
	/**
	 * @return the wODate
	 */
	public Date getwODate() {
		return wODate;
	}
	/**
	 * @param wODate the wODate to set
	 */
	public void setwODate(Date wODate) {
		this.wODate = wODate;
	}
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the currentlyInStock
	 */
	public int getCurrentlyInStock() {
		return currentlyInStock;
	}
	/**
	 * @param currentlyInStock the currentlyInStock to set
	 */
	public void setCurrentlyInStock(int currentlyInStock) {
		this.currentlyInStock = currentlyInStock;
	}
	/**
	 * @return the alertDescription
	 */
	public String getAlertDescription() {
		return alertDescription;
	}
	/**
	 * @param alertDescription the alertDescription to set
	 */
	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}
	/**
	 * @return the weekNo
	 */
	public String getWeekNo() {
		return weekNo;
	}
	/**
	 * @param weekNo the weekNo to set
	 */
	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}
	/**
	 * @return the quentity
	 */
	public int getQuentity() {
		return quentity;
	}
	/**
	 * @param quentity the quentity to set
	 */
	public void setQuentity(int quentity) {
		this.quentity = quentity;
	}
	

}
