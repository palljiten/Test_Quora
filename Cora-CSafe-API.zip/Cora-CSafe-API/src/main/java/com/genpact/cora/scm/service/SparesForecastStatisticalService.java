package com.genpact.cora.scm.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.cora.scm.dto.ModelParam;
import com.genpact.cora.scm.dto.ModelParams;
import com.genpact.cora.scm.dto.MonthDataUnit;
import com.genpact.cora.scm.dto.MonthDataUnitInt;
import com.genpact.cora.scm.dto.MonthYearDataUnit;
import com.genpact.cora.scm.dto.PythonRequestObject;
import com.genpact.cora.scm.dto.PythonResponseObject;
import com.genpact.cora.scm.dto.PythonUpdatedForecastModelUpdateRequest;
import com.genpact.cora.scm.dto.SingleModelOutput;
import com.genpact.cora.scm.dto.SparesStatisticalAdjustmentCombo;
import com.genpact.cora.scm.dto.SparesStatisticalAdjustmentRequest;
import com.genpact.cora.scm.dto.SparesStatisticalAdjustmentRequestUnit;
import com.genpact.cora.scm.dto.SparesStatisticalBaselineDemandCombo;
import com.genpact.cora.scm.dto.SparesStatisticalBaselineForecastCombo;
import com.genpact.cora.scm.dto.SparesStatisticalForecastModelOutput;
import com.genpact.cora.scm.dto.TempBestFitModel;
import com.genpact.cora.scm.dto.TempConfigModel;
import com.genpact.cora.scm.entity.Country;
import com.genpact.cora.scm.entity.HubSc;
import com.genpact.cora.scm.entity.Part;
import com.genpact.cora.scm.entity.Region;
import com.genpact.cora.scm.entity.RepairWorkOrderParts;
import com.genpact.cora.scm.entity.SparesModelEditConfig;
import com.genpact.cora.scm.entity.SparesStatisticalAdjustments;
import com.genpact.cora.scm.entity.SparesStatisticalForecast;
import com.genpact.cora.scm.entity.SparesStatisticalForecastConfig;
import com.genpact.cora.scm.entity.SparesStatisticalParameterValues;
import com.genpact.cora.scm.entity.StatisticalForecastConfig;
import com.genpact.cora.scm.entity.StatisticalModel;
import com.genpact.cora.scm.entity.StatisticalModelMaster;
import com.genpact.cora.scm.entity.StatisticalParametersMaster;
import com.genpact.cora.scm.exception.CSafeServiceException;
import com.genpact.cora.scm.repository.HubRepository;
import com.genpact.cora.scm.repository.RepairWorkOrderPartsRepository;
import com.genpact.cora.scm.repository.SparesModelEditConfigRepository;
import com.genpact.cora.scm.repository.SparesStatisticalAdjustmentsRepository;
import com.genpact.cora.scm.repository.SparesStatisticalForecastConfigRepository;
import com.genpact.cora.scm.repository.SparesStatisticalForecastRepository;
import com.genpact.cora.scm.repository.SparesStatisticalParameterValuesRepository;
import com.genpact.cora.scm.repository.SpecialForecastModelRepository;

@Service
public class SparesForecastStatisticalService {

	private static Logger logger = LoggerFactory.getLogger(SparesForecastStatisticalService.class);
	private static Map<Integer, String> monthValueMap = new HashMap<>();
	private static Map<String, Integer> monthValueReverseMap = new HashMap<>();
	private static Map<String, String> yearMap = new HashMap<>();
	private static Map<String, String> yearReverseMap = new HashMap<>();

	static {
		monthValueMap.put(0, "Jan");
		monthValueMap.put(1, "Feb");
		monthValueMap.put(2, "Mar");
		monthValueMap.put(3, "Apr");
		monthValueMap.put(4, "May");
		monthValueMap.put(5, "Jun");
		monthValueMap.put(6, "Jul");
		monthValueMap.put(7, "Aug");
		monthValueMap.put(8, "Sep");
		monthValueMap.put(9, "Oct");
		monthValueMap.put(10, "Nov");
		monthValueMap.put(11, "Dec");

		monthValueReverseMap.put("Jan", 0);
		monthValueReverseMap.put("Feb", 1);
		monthValueReverseMap.put("Mar", 2);
		monthValueReverseMap.put("Apr", 3);
		monthValueReverseMap.put("May", 4);
		monthValueReverseMap.put("Jun", 5);
		monthValueReverseMap.put("Jul", 6);
		monthValueReverseMap.put("Aug", 7);
		monthValueReverseMap.put("Sep", 8);
		monthValueReverseMap.put("Oct", 9);
		monthValueReverseMap.put("Nov", 10);
		monthValueReverseMap.put("Dec", 11);

		yearMap.put("15", "2015");
		yearMap.put("16", "2016");
		yearMap.put("17", "2017");
		yearMap.put("18", "2018");
		yearMap.put("19", "2019");
		yearMap.put("20", "2020");
		yearMap.put("21", "2021");
		yearMap.put("22", "2022");

		yearReverseMap.put("2015", "15");
		yearReverseMap.put("2016", "16");
		yearReverseMap.put("2017", "17");
		yearReverseMap.put("2018", "18");
		yearReverseMap.put("2019", "19");
		yearReverseMap.put("2020", "20");
		yearReverseMap.put("2021", "21");
		yearReverseMap.put("2022", "22");
	}

	@Autowired
	HubRepository hubRepository;
	@Autowired
	RepairWorkOrderPartsRepository rwpRepository;
	@Autowired
	SparesStatisticalForecastRepository ssfRepository;
	@Autowired
	SparesStatisticalAdjustmentsRepository ssaRepository;
	@Autowired
	SparesStatisticalParameterValuesRepository sspRepository;
	@Autowired
	SpecialForecastModelRepository specialForecastRepository;
	@Autowired
	ExternalServiceCaller externalService;
	@Autowired
	SparesStatisticalForecastConfigRepository configRepository;

	@Autowired
	SparesModelEditConfigRepository modelEditConfigRepo;

	public SparesStatisticalBaselineDemandCombo getBaselineDemand(int regionId, int countryId, int hubId,
			String partNum, int months) throws CSafeServiceException {
		logger.info("SERVICE: SparesForecastStatisticalService: Entering getBaselineDemand() method");
		SparesStatisticalBaselineDemandCombo data = new SparesStatisticalBaselineDemandCombo();

		try {
			HubSc hub = hubRepository.findById(hubId).get();

			List<String> monthYearList = getPreviousMonthYearList(months);

			List<RepairWorkOrderParts> rwpList = rwpRepository.getRepairWorkOrderParts(hub.getHubCode(), partNum,
					months);
			data.setHub(hub);
			data.setCountry(hub.getCountry());
			data.setRegion(hub.getRegion());
			Part p = new Part();
			p.setPartNumber(partNum);
			data.setPart(p);

			for (String givenMY : monthYearList) {
				data.getMonthYearMetaData().add(getProperMonthYear(givenMY));
			}

			populate(data, rwpList, monthYearList);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: SparesForecastStatisticalService: Exiting getBaselineDemand() method");
		return data;
	}

	public SparesStatisticalBaselineForecastCombo getBaselineForecast(int regionId, int countryId, int hubId,
			String partId, int months) throws CSafeServiceException {
		logger.info("SERVICE: SparesForecastStatisticalService: Entering getBaselineForecast() method");
		SparesStatisticalBaselineForecastCombo data = new SparesStatisticalBaselineForecastCombo();
		try {
			List<String> monthYearList = getMonthYearList();
			List<SparesStatisticalForecast> ssfList = null;
			
			List<TempConfigModel> configModel = specialForecastRepository.getTempSparesConfigModels(regionId, countryId,
					hubId, partId, monthYearList);

			Integer configuredModelId = 0;
			Integer bestFitModelId = 0;
			if (!configModel.isEmpty()) {
				for (TempConfigModel cm : configModel) {
					if (cm.getConfigModelId() != null) {
						configuredModelId = cm.getConfigModelId();
						break;
					}
				}
				ssfList = ssfRepository.getSparesStatisticalForecast1(regionId, countryId, hubId, partId, monthYearList,
						configuredModelId);
			} else {
				List<TempBestFitModel> bestFitModel = specialForecastRepository.getTempSparesBestFitModels(regionId,
						countryId, hubId, partId, monthYearList);
				if (!bestFitModel.isEmpty()) {
					for (TempBestFitModel bft : bestFitModel) {
						if (bft.getBestFitModelId() != null) {
							bestFitModelId = bft.getBestFitModelId();
							break;
						}
					}
					ssfList = ssfRepository.getSparesStatisticalForecast1(regionId, countryId, hubId, partId, monthYearList,
							bestFitModelId);
				}
			}
			
			for (String givenMY : monthYearList) {
				data.getMonthYearMetaData().add(getProperMonthYear(givenMY));
			}

			populate(data, partId, ssfList);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: SparesForecastStatisticalService: Exiting getBaselineForecast() method");

		/*
		 * List<MonthYearDataUnit> dec = new ArrayList<>(); MonthYearDataUnit mdu = new
		 * MonthYearDataUnit(); mdu.setMonthValue(11); mdu.setMonthYear("Dec 2018"); //
		 * Temporary Fix only - for UAT mdu.setValue(0.0f); dec.add(mdu);
		 */

		Collections.sort(data.getBaselineForecast(), new SparesForecastMonthValueComparator());

		if (data.getBaselineForecast().size() == 6) {
			int fifthYear = Integer.parseInt(data.getBaselineForecast().get(4).getMonthYear().split(" ")[1]);
			int sixthYear = Integer.parseInt(data.getBaselineForecast().get(5).getMonthYear().split(" ")[1]);
			if (fifthYear > sixthYear) {
				List<MonthYearDataUnit> dec = new ArrayList<>();
				MonthYearDataUnit existing = data.getBaselineForecast().get(5);
				MonthYearDataUnit mdu = new MonthYearDataUnit();
				mdu.setMonthValue(existing.getMonthValue());
				mdu.setMonthYear(existing.getMonthYear());
				mdu.setValue(existing.getValue());
				data.getBaselineForecast().add(0, mdu);
				data.getBaselineForecast().remove(6);
			}
		}
		// dec.addAll(data.getBaselineForecast());
		// data.setBaselineForecast(dec);
		return data;
	}

	public SparesStatisticalAdjustmentCombo getIntelligenceOrAdjustment(int regionId, int countryId, int hubId,
			String partId, int months) throws CSafeServiceException {
		logger.info("SERVICE: SparesForecastStatisticalService: Entering getIntelligenceOrAdjustment() method");
		SparesStatisticalAdjustmentCombo data = new SparesStatisticalAdjustmentCombo();
		try {
			List<String> monthYearList = getMonthYearList();
			List<SparesStatisticalAdjustments> ssaList = ssaRepository.getSparesStatisticalAdjustments(regionId,
					countryId, hubId, partId, monthYearList);

			data.setCountryId(countryId);
			data.setRegionId(regionId);
			data.setHubId(hubId);
			data.setPartId(partId);

			for (String givenMY : monthYearList) {
				data.getMonthYearMetaData().add(getProperMonthYear(givenMY));
			}

			populate(data, partId, ssaList, monthYearList);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: SparesForecastStatisticalService: Exiting getIntelligenceOrAdjustment() method");
		return data;
	}

	@Transactional
	public void updateIntelligenceOrAdjustment(int regionId, int countryId, int hubId, String partId,
			SparesStatisticalAdjustmentRequest adjustments) throws CSafeServiceException {
		logger.info("SERVICE: SparesForecastStatisticalService: Entering updateIntelligenceOrAdjustment() method");
		try {
			SparesStatisticalAdjustments entity = null;
			Country c = new Country();
			c.setCountryId(countryId);

			Region r = new Region();
			r.setRegionId(regionId);

			HubSc h = new HubSc();
			h.setHubId(hubId);
			h.setCountry(c);
			h.setRegion(r);

			List<SparesStatisticalAdjustmentRequestUnit> newValues = adjustments.getAdjustmentValues();
			for (SparesStatisticalAdjustmentRequestUnit newValue : newValues) {
				entity = new SparesStatisticalAdjustments();
				entity.setRegion(r);
				entity.setCountry(c);
				entity.setHub(h);
				entity.setPartId(partId);
				entity.setFlag(1);
				entity.setValue(newValue.getValue());

				String month = newValue.getMonth().getValue();
				int year = newValue.getYear();
				entity.setMonthYear(month + "-" + year);
				entity.setCreatedDate(new Date());
				entity.setModifiedDate(new Date());

				ssaRepository.updateSparesStatisticalAdjustments(regionId, countryId, hubId, partId,
						month + "-" + year);
				ssaRepository.save(entity);
			}
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: SparesForecastConsensusService: Exiting updateIntelligenceOrAdjustment() method");
	}

	public SparesStatisticalForecastModelOutput getForecastModels(int regionId, int countryId, int hubId, String partId)
			throws CSafeServiceException {
		logger.info("SERVICE: SparesForecastConsensusService: Entering getForecastModels() method");
		SparesStatisticalForecastModelOutput data = new SparesStatisticalForecastModelOutput();
		try {
			populate(data);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: SparesForecastConsensusService: Exiting getForecastModels() method");
		return data;
	}

	public ModelParams getForecastModelParams(int modelId) throws CSafeServiceException {
		ModelParams data = new ModelParams();
		logger.info("SERVICE: SparesForecastConsensusService: Entering getForecastModelParams() method");
		try {
			data.setModelId(modelId);
			populate(data);
		} catch (Exception e) {
			logger.error("Error caught: " + e.getMessage(), e);
			throw new CSafeServiceException(e);
		}
		logger.info("SERVICE: SparesForecastConsensusService: Exiting getForecastModelParams() method");
		return data;
	}

	public PythonResponseObject updateStatistcalModelParams(PythonRequestObject pythonRequestObject) {
		return (externalService.callOnDemandSparesService(pythonRequestObject));
	}

	@Transactional
	public void updateForecastModel(int modelId, int regionId, int countryId, int hubId, String partId,
			PythonUpdatedForecastModelUpdateRequest data) {
		logger.info("SparesForecastStatisticalService: Entering updateForecastModel() method");
		try {
			List<MonthDataUnit> monthData = data.getMonthData();
			if (monthData == null || monthData.size() < 6) {
				throw new CSafeServiceException("You should provide 6 month data for forecast model update");
			}

			SparesStatisticalParameterValues spv = null;
			Country c = new Country();
			c.setCountryId(countryId);

			Region r = new Region();
			r.setRegionId(regionId);

			HubSc h = new HubSc();
			h.setHubId(hubId);
			h.setCountry(c);
			h.setRegion(r);

			StatisticalModelMaster sm = new StatisticalModelMaster();
			sm.setModelId(modelId);

			List<ModelParam> params = data.getParameters();
			System.out.println("\n\nUpdating/saving Parameters...");
			for (ModelParam mp : params) {
				spv = new SparesStatisticalParameterValues();
				spv.setCountry(c);
				spv.setRegion(r);
				spv.setHubsc(h);
				StatisticalParametersMaster sp = new StatisticalParametersMaster();
				sp.setId(mp.getParamId());
				sp.setModel(sm);
				spv.setParameter(sp);
				spv.setCreatedMonth(getCurrentMothYear());
				spv.setValue(mp.getParamValue());
				spv.setFlag(1);
				spv.setPartId(data.getPartNumber());
				System.out.println("paramId = " + mp.getParamId());
				System.out.println("paramName = " + mp.getParamName());
				System.out.println("paramValue = " + mp.getParamValue());
				System.out.println("\n");
				sspRepository.updateParams(mp.getParamId(), regionId, countryId, hubId, partId);
				sspRepository.save(spv);
			}

			// update configRepository

			List<String> monthYearList = getMonthYearList();
			List<TempConfigModel> configModel = specialForecastRepository.getTempSparesConfigModels(regionId, countryId,
					hubId, partId, monthYearList);
			Integer configuredModelId = 0;
			if (!configModel.isEmpty()) {
				configuredModelId = configModel.get(0).getConfigModelId();
				for (TempConfigModel cm : configModel) {
					if (cm.getConfigModelId() != null) {
						configuredModelId = cm.getConfigModelId();
						break;
					}
				}
			}
			System.out.println("configuredModelId = " + configuredModelId);
			System.out.println("\n");
			if (configuredModelId > 0) {
				configRepository.updateStatisticalForecastConfigModel(configuredModelId, regionId, countryId, hubId,
						partId);
			}

			SparesStatisticalForecastConfig stForecastConfig = new SparesStatisticalForecastConfig();
			stForecastConfig.setCountry(c);
			stForecastConfig.setRegion(r);
			stForecastConfig.setHub(h);
			stForecastConfig.setCreatedMonth(getCurrentMothYear());
			StatisticalModel configuredModel = new StatisticalModel();
			configuredModel.setModelId(modelId);
			stForecastConfig.setConfiguredModel(configuredModel);
			stForecastConfig.setFlag(1);
			stForecastConfig.setPartId(partId);
			System.out.println("Saving statistical config...");
			configRepository.save(stForecastConfig);

			SparesStatisticalForecast entity = null;

			System.out.println("Updating/saving forecast values...");
			for (MonthDataUnit mv : monthData) {
				entity = new SparesStatisticalForecast();
				entity.setCountry(c);
				entity.setCreatedMonth(getCurrentMonthYear());
				entity.setFlag(1);
				entity.setHub(h);
				entity.setModel(sm);
				String month = mv.getMonth();
				int year = mv.getYear();
				entity.setMonthYear(month + "-" + year);
				entity.setPartId(partId);
				entity.setRegion(r);
				entity.setForecastValue(mv.getValue());

				ssfRepository.updateExistingRecord(modelId, regionId, countryId, hubId, partId, month + "-" + year);
				ssfRepository.save(entity);
			}

			System.out.println("Updating model edit config...");
			modelEditConfigRepo.updateModelEditConfig(modelId, regionId, countryId, hubId, partId);
			SparesModelEditConfig mec = new SparesModelEditConfig();
			mec.setBaselineAdjustment(data.isBaselinePercentageAdjustment());
			mec.setCountry(c);
			mec.setCreatedBy("CSafeAdmin");
			mec.setCreatedDate(new Date());
			mec.setFlag(1);
			mec.setHubsc(h);
			mec.setModel(configuredModel);
			mec.setNormalForecast(data.isNormalForecast());
			mec.setPercentage(data.getPercentage());
			mec.setRegion(r);
			mec.setPartId(partId);
			System.out.println("Saving model edit config...");
			modelEditConfigRepo.save(mec);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("SparesForecastStatisticalService: Exiting updateForecastModel() method");
	}

	private String getCurrentMothYear() {
		Calendar c = Calendar.getInstance();
		return monthValueMap.get(c.get(Calendar.MONTH)) + "-" + c.get(Calendar.YEAR);
	}

	private void populate(ModelParams data) {
		List<ModelParam> modelParams = new ArrayList<>();
		ModelParam mp = new ModelParam();
		mp.setParamId(1);
		mp.setParamName("P-1");
		mp.setParamValue(3.0f);
		modelParams.add(mp);

		mp = new ModelParam();
		mp.setParamId(2);
		mp.setParamName("P-2");
		mp.setParamValue(4.2f);
		modelParams.add(mp);

		mp = new ModelParam();
		mp.setParamId(3);
		mp.setParamName("P-3");
		mp.setParamValue(5f);
		modelParams.add(mp);

		data.setModelParams(modelParams);
	}

	private void populate(SparesStatisticalForecastModelOutput data) {
		List<String> monthYearMetaData = new ArrayList<>();
		monthYearMetaData.add("Aug 2018");
		monthYearMetaData.add("Sep 2018");
		monthYearMetaData.add("Oct 2018");
		monthYearMetaData.add("Nov 2018");
		monthYearMetaData.add("Dec 2018");
		monthYearMetaData.add("Jan 2019");

		data.setMonthYearMetaData(monthYearMetaData);

		List<SingleModelOutput> smoList = new ArrayList<>();

		SingleModelOutput smo = new SingleModelOutput();
		smo.setModelId(1);
		smo.setModelName("Croston Variant");
		smo.setBestFit(true);
		smo.setConfigured(false);
		smo.setMadPercent(4);
		smo.setMapePercent(0);
		smo.setRmsePercent(0);

		List<MonthDataUnit> monthData = new ArrayList<>();

		MonthDataUnit mdu = new MonthDataUnit();
		mdu.setMonth("Aug");
		mdu.setMonthValue(7);
		mdu.setYear(2018);
		mdu.setValue(65);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Sep");
		mdu.setMonthValue(8);
		mdu.setYear(2018);
		mdu.setValue(68);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Oct");
		mdu.setMonthValue(9);
		mdu.setYear(2018);
		mdu.setValue(71);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Nov");
		mdu.setMonthValue(10);
		mdu.setYear(2018);
		mdu.setValue(74);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Dec");
		mdu.setMonthValue(11);
		mdu.setYear(2018);
		mdu.setValue(77);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Jan");
		mdu.setMonthValue(0);
		mdu.setYear(2019);
		mdu.setValue(80);

		monthData.add(mdu);

		smo.setMonthData(monthData);

		smoList.add(smo);

		smo = new SingleModelOutput();
		smo.setModelId(2);
		smo.setModelName("Moving Average");
		smo.setBestFit(false);
		smo.setConfigured(false);
		smo.setMadPercent(2);
		smo.setMapePercent(0);
		smo.setRmsePercent(0);

		monthData = new ArrayList<>();

		mdu = new MonthDataUnit();
		mdu.setMonth("Aug");
		mdu.setMonthValue(7);
		mdu.setYear(2018);
		mdu.setValue(65);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Sep");
		mdu.setMonthValue(8);
		mdu.setYear(2018);
		mdu.setValue(68);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Oct");
		mdu.setMonthValue(9);
		mdu.setYear(2018);
		mdu.setValue(71);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Nov");
		mdu.setMonthValue(10);
		mdu.setYear(2018);
		mdu.setValue(74);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Dec");
		mdu.setMonthValue(11);
		mdu.setYear(2018);
		mdu.setValue(77);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Jan");
		mdu.setMonthValue(0);
		mdu.setYear(2019);
		mdu.setValue(80);

		monthData.add(mdu);

		smo.setMonthData(monthData);

		smoList.add(smo);

		smo = new SingleModelOutput();
		smo.setModelId(3);
		smo.setModelName("Simple Average");
		smo.setBestFit(false);
		smo.setConfigured(false);
		smo.setMadPercent(2);
		smo.setMapePercent(0);
		smo.setRmsePercent(0);

		monthData = new ArrayList<>();

		mdu = new MonthDataUnit();
		mdu.setMonth("Aug");
		mdu.setMonthValue(7);
		mdu.setYear(2018);
		mdu.setValue(65);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Sep");
		mdu.setMonthValue(8);
		mdu.setYear(2018);
		mdu.setValue(68);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Oct");
		mdu.setMonthValue(9);
		mdu.setYear(2018);
		mdu.setValue(71);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Nov");
		mdu.setMonthValue(10);
		mdu.setYear(2018);
		mdu.setValue(74);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Dec");
		mdu.setMonthValue(11);
		mdu.setYear(2018);
		mdu.setValue(77);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Jan");
		mdu.setMonthValue(0);
		mdu.setYear(2019);
		mdu.setValue(80);

		monthData.add(mdu);

		smo.setMonthData(monthData);

		smoList.add(smo);

		smo = new SingleModelOutput();
		smo.setModelId(4);
		smo.setModelName("Single Exponential");
		smo.setBestFit(false);
		smo.setConfigured(false);
		smo.setMadPercent(2);
		smo.setMapePercent(0);
		smo.setRmsePercent(0);

		monthData = new ArrayList<>();

		mdu = new MonthDataUnit();
		mdu.setMonth("Aug");
		mdu.setMonthValue(7);
		mdu.setYear(2018);
		mdu.setValue(65);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Sep");
		mdu.setMonthValue(8);
		mdu.setYear(2018);
		mdu.setValue(68);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Oct");
		mdu.setMonthValue(9);
		mdu.setYear(2018);
		mdu.setValue(71);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Nov");
		mdu.setMonthValue(10);
		mdu.setYear(2018);
		mdu.setValue(74);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Dec");
		mdu.setMonthValue(11);
		mdu.setYear(2018);
		mdu.setValue(77);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Jan");
		mdu.setMonthValue(0);
		mdu.setYear(2019);
		mdu.setValue(80);

		monthData.add(mdu);

		smo.setMonthData(monthData);

		smoList.add(smo);

		smo = new SingleModelOutput();
		smo.setModelId(5);
		smo.setModelName("Weighted Average");
		smo.setBestFit(false);
		smo.setConfigured(false);
		smo.setMadPercent(0);
		smo.setMapePercent(0);
		smo.setRmsePercent(0);

		monthData = new ArrayList<>();

		mdu = new MonthDataUnit();
		mdu.setMonth("Aug");
		mdu.setMonthValue(7);
		mdu.setYear(2018);
		mdu.setValue(65);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Sep");
		mdu.setMonthValue(8);
		mdu.setYear(2018);
		mdu.setValue(68);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Oct");
		mdu.setMonthValue(9);
		mdu.setYear(2018);
		mdu.setValue(71);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Nov");
		mdu.setMonthValue(10);
		mdu.setYear(2018);
		mdu.setValue(74);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Dec");
		mdu.setMonthValue(11);
		mdu.setYear(2018);
		mdu.setValue(77);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Jan");
		mdu.setMonthValue(0);
		mdu.setYear(2019);
		mdu.setValue(80);

		monthData.add(mdu);

		smo.setMonthData(monthData);

		smoList.add(smo);

		smo = new SingleModelOutput();
		smo.setModelId(6);
		smo.setModelName("Linear Regression");
		smo.setBestFit(false);
		smo.setConfigured(false);
		smo.setMadPercent(2);
		smo.setMapePercent(0);
		smo.setRmsePercent(0);

		monthData = new ArrayList<>();

		mdu = new MonthDataUnit();
		mdu.setMonth("Aug");
		mdu.setMonthValue(7);
		mdu.setYear(2018);
		mdu.setValue(65);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Sep");
		mdu.setMonthValue(8);
		mdu.setYear(2018);
		mdu.setValue(68);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Oct");
		mdu.setMonthValue(9);
		mdu.setYear(2018);
		mdu.setValue(71);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Nov");
		mdu.setMonthValue(10);
		mdu.setYear(2018);
		mdu.setValue(74);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Dec");
		mdu.setMonthValue(11);
		mdu.setYear(2018);
		mdu.setValue(77);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Jan");
		mdu.setMonthValue(0);
		mdu.setYear(2019);
		mdu.setValue(80);

		monthData.add(mdu);

		smo.setMonthData(monthData);

		smoList.add(smo);

		smo = new SingleModelOutput();
		smo.setModelId(7);
		smo.setModelName("ARIMA");
		smo.setBestFit(false);
		smo.setConfigured(false);
		smo.setMadPercent(2);
		smo.setMapePercent(0);
		smo.setRmsePercent(0);

		monthData = new ArrayList<>();

		mdu = new MonthDataUnit();
		mdu.setMonth("Aug");
		mdu.setMonthValue(7);
		mdu.setYear(2018);
		mdu.setValue(65);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Sep");
		mdu.setMonthValue(8);
		mdu.setYear(2018);
		mdu.setValue(68);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Oct");
		mdu.setMonthValue(9);
		mdu.setYear(2018);
		mdu.setValue(71);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Nov");
		mdu.setMonthValue(10);
		mdu.setYear(2018);
		mdu.setValue(74);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Dec");
		mdu.setMonthValue(11);
		mdu.setYear(2018);
		mdu.setValue(77);

		monthData.add(mdu);

		mdu = new MonthDataUnit();
		mdu.setMonth("Jan");
		mdu.setMonthValue(0);
		mdu.setYear(2019);
		mdu.setValue(80);

		monthData.add(mdu);

		smo.setMonthData(monthData);

		smoList.add(smo);

		data.setModelOutput(smoList);
	}

	private void populate(SparesStatisticalAdjustmentCombo data, String partId,
			List<SparesStatisticalAdjustments> ssaList, List<String> monthYearList) {

		Map<String, MonthDataUnit> monthYearMap = new HashMap<>();
		data.setPartId(partId);

		for (SparesStatisticalAdjustments ssa : ssaList) {
			String monthYear = getProperMonthYear(ssa.getMonthYear());
			// data.getMonthYearMetaData().add(monthYear);

			MonthDataUnit mdu = new MonthDataUnit();

			String[] parts = monthYear.split(" ");
			mdu.setMonth(parts[0]);
			mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
			mdu.setYear(Integer.parseInt(parts[1]));
			mdu.setValue(ssa.getValue());
			monthYearMap.put(ssa.getMonthYear(), mdu);
			data.getValueSummary().put(monthYear, ssa.getValue());
			data.getAdjustmentValues().add(mdu);
		}

		List<String> remainingMonths = new ArrayList<>();
		Set<String> keySet = monthYearMap.keySet();

		for (String myKey : monthYearList) {
			if (!keySet.contains(myKey)) {
				remainingMonths.add(myKey);
			}
		}

		for (String monthYear : remainingMonths) {
			MonthDataUnit mdu = new MonthDataUnit();
			String[] parts = monthYear.split("-");
			mdu.setMonth(parts[0]);
			mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
			mdu.setYear(Integer.parseInt(parts[1]));
			mdu.setValue(0);
			data.getValueSummary().put(monthYear, 0.0f);
			data.getAdjustmentValues().add(mdu);
		}
	}

	private String getProperMonthYear(String my) {
		StringBuffer properMonthYear = new StringBuffer("");
		String[] parts = my.split("-");
		properMonthYear.append(parts[0]);
		properMonthYear.append(" ");
		properMonthYear.append(parts[1]);
		return properMonthYear.toString();
	}

	private void populate(SparesStatisticalBaselineForecastCombo data, String partId,
			List<SparesStatisticalForecast> ssfList) {

		Map<String, Float> monthYearValueMap = new HashMap<>();
		Map<String, Integer> monthYearMonthValueMap = new HashMap<>();

		for (SparesStatisticalForecast ssf : ssfList) {

			data.setCountry(ssf.getCountry());
			data.setHub(ssf.getHub());
			data.setRegion(ssf.getRegion());

			String monthYear = getProperMonthYear(ssf.getMonthYear());
			Float value = monthYearValueMap.get(monthYear);
			logger.info("\n\n\nValue: " + value + "\n\n\n");
			if (value == null) {
				monthYearValueMap.put(monthYear, ssf.getForecastValue());
			} else {
				monthYearValueMap.put(monthYear, value + ssf.getForecastValue());
			}

			// TO=DO: Value is coming 0.0. Need to be fixed.

			String[] parts = monthYear.split(" ");
			int monthValue = monthValueReverseMap.get(parts[0]);
			monthYearMonthValueMap.put(monthYear, monthValue);

		}

		Part p = new Part();
		p.setPartNumber(partId);
		data.setPart(p);

		MonthYearDataUnit mdu = null;
		for (String monthYear : monthYearValueMap.keySet()) {
			mdu = new MonthYearDataUnit();
			mdu.setMonthValue(monthYearMonthValueMap.get(monthYear));
			mdu.setMonthYear(monthYear);
			mdu.setValue(monthYearValueMap.get(monthYear));

			// data.getMonthYearMetaData().add(monthYear);
			data.getBaselineForecast().add(mdu);
			data.getValueSummary().put(monthYear, mdu.getValue());
		}
		data.getValueSummary().put("Dec 2018", 0.0f);
	}

	private void populate(SparesStatisticalBaselineDemandCombo data, List<RepairWorkOrderParts> rwpList,
			List<String> monthYearList) {
		List<MonthDataUnitInt> demandValues = new ArrayList<>();
		Map<String, MonthDataUnitInt> monthYearMap = new HashMap<>();
		Calendar c = Calendar.getInstance();
		for (RepairWorkOrderParts rwp : rwpList) {
			c.setTime(rwp.getCreateDate());
			int monthValue = c.get(Calendar.MONTH);
			String month = monthValueMap.get(monthValue);
			int year = c.get(Calendar.YEAR);
			String myKey = month + "-" + year;
			MonthDataUnitInt mdu = monthYearMap.get(myKey);
			if (mdu == null) {
				mdu = new MonthDataUnitInt();
				mdu.setMonth(month);
				mdu.setMonthValue(monthValue);
				mdu.setYear(year);
				mdu.setValue(rwp.getQuantity());
				demandValues.add(mdu);
				monthYearMap.put(myKey, mdu);
			} else {
				int value = mdu.getValue() + rwp.getQuantity();
				mdu.setValue(value);
			}
		}

		List<String> remainingMonths = new ArrayList<>();
		Set<String> keySet = monthYearMap.keySet();

		for (String myKey : monthYearList) {
			MonthDataUnitInt tempMdu = monthYearMap.get(myKey);
			if (tempMdu != null) {
				data.getValueSummary().put(tempMdu.getMonth() + " " + tempMdu.getYear(), tempMdu.getValue());
			}

			if (!keySet.contains(myKey)) {
				remainingMonths.add(myKey);
			}
		}

		for (String monthYear : remainingMonths) {
			MonthDataUnitInt mdu = new MonthDataUnitInt();
			String[] parts = monthYear.split("-");
			mdu.setMonth(parts[0]);
			mdu.setMonthValue(monthValueReverseMap.get(parts[0]));
			mdu.setYear(Integer.parseInt(parts[1]));
			mdu.setValue(0);
			data.getValueSummary().put(parts[0] + " " + Integer.parseInt(parts[1]), 0);
			demandValues.add(mdu);
		}

		data.setDemandValues(demandValues);
	}

	private String getCurrentMonthYear() {
		Calendar c = Calendar.getInstance();
		return monthValueMap.get(c.get(Calendar.MONTH)) + "-" + c.get(Calendar.YEAR);
	}

	private List<String> getMonthYearList() {
		List<String> monthYearList = new ArrayList<>();

		Calendar c = Calendar.getInstance();
		int startingMonth = c.get(Calendar.MONTH);
		int nextMonth = startingMonth;
		boolean isChangeInYear = false;

		for (int i = 0; i < 6; i++) {
			String year = isChangeInYear ? ("" + (c.get(Calendar.YEAR) + 1)) : ("" + c.get(Calendar.YEAR));
			monthYearList.add(monthValueMap.get(nextMonth) + "-" + year);
			nextMonth = nextMonth + 1;
			int mod = nextMonth % 11;
			if ((nextMonth > 11) && mod > 0) {
				isChangeInYear = true;
				nextMonth = mod - 1;
			}
		}

		return monthYearList;
	}

	private List<String> getPreviousMonthYearList(int months) {
		List<String> monthYearList = new ArrayList<>();

		Calendar c = Calendar.getInstance();
		int startingMonth = c.get(Calendar.MONTH) - 1;
		int nextMonth = startingMonth;
		boolean isChangeInYear = false;
		// If current MonthYear is Nov-2018, the output should be as follows:
		// Oct-2018, Sep-2018, Aug-2018, Jul-2018, Jun-2018, May-2018, Apr-2018,
		// Mar-2018, Feb-2018, Jan-2018
		// Dec-2017, Nov-2017, Oct-2017, Sep-2017, Aug-2017, Jul-2017, Jun-2017,
		// May-2017

		for (int i = 0; i < months; i++) {
			String year = isChangeInYear ? ("" + (c.get(Calendar.YEAR) - 1)) : ("" + c.get(Calendar.YEAR));
			monthYearList.add(monthValueMap.get(nextMonth) + "-" + year);
			nextMonth = nextMonth - 1;
			int mod = nextMonth % 11;
			if (nextMonth < 0 && nextMonth == -1) {
				nextMonth = 11;
				isChangeInYear = true;
			}
		}

		return monthYearList;
	}
}
