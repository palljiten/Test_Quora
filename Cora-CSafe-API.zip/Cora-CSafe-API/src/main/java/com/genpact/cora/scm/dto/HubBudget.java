package com.genpact.cora.scm.dto;

import java.io.Serializable;

public class HubBudget implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer hubId;
	private Integer countryId;
	private float budgetPercentage;
	
	public Integer getHubId() {
		return hubId;
	}
	public void setHubId(Integer hubId) {
		this.hubId = hubId;
	}
	public float getBudgetPercentage() {
		return budgetPercentage;
	}
	public void setBudgetPercentage(float budgetPercentage) {
		this.budgetPercentage = budgetPercentage;
	}
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
}
