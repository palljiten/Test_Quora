package com.genpact.cora.scm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[dbo].[tbl_master_EmailAlert]")
public class EmailAlertMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;
	
	@Column(name = "TemplateID")
	private String templateId;
	
	@Column(name = "AlertCode")
	private String alertCode;
	
	@Column(name = "AlertType")
	private String alertType;
	
	@Column(name = "AlertDescription")
	private String alertDescription;
	
	@Column(name = "DefaultSubjectLine")
	private String defaultSubjectLine;
	
	@Column(name = "DefaultTO")
	private String defaultTo;
	
	@Column(name = "DefaultCC")
	private String defaultCc;
	
	@Column(name = "IsAutoMail")
	private Boolean isAutoMail;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateID) {
		this.templateId = templateID;
	}

	public String getAlertCode() {
		return alertCode;
	}

	public void setAlertCode(String alertCode) {
		this.alertCode = alertCode;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public String getAlertDescription() {
		return alertDescription;
	}

	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}

	public Boolean getIsAutoMail() {
		return isAutoMail;
	}

	public void setIsAutoMail(Boolean isAutoMail) {
		this.isAutoMail = isAutoMail;
	}

	public String getDefaultSubjectLine() {
		return defaultSubjectLine;
	}

	public void setDefaultSubjectLine(String defaultSubjectLine) {
		this.defaultSubjectLine = defaultSubjectLine;
	}

	public String getDefaultTo() {
		return defaultTo;
	}

	public void setDefaultTo(String defaultTo) {
		this.defaultTo = defaultTo;
	}

	public String getDefaultCc() {
		return defaultCc;
	}

	public void setDefaultCc(String defaultCc) {
		this.defaultCc = defaultCc;
	}
}
